﻿namespace Reggie.WPF.Utilities.Utils.Http
{
    public class HttpMethodConstants
    {
        public const string Get = "Get";
        public const string Post = "Post";
        public const string Put = "Put";
        public const string Delete = "DELETE";
    }
}
