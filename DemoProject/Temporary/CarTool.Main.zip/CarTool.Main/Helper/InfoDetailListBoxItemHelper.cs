﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CarTool.Main.Helper
{
    public static class InfoDetailListBoxItemHelper
    {
        /// <summary>
        /// 车信息项可能表现的状态
        /// </summary>
        public enum Status
        {
            None,
            /// <summary>
            /// 没有使能
            /// </summary>
            Disable,
            /// <summary>
            /// 已使能
            /// </summary>
            Normal,
            /// <summary>
            /// 已激活（部分项拥有）:指示开状态(转向灯同时亮也显示该状态)
            /// </summary>
            Active,
            /// <summary>
            /// 故障（部分项拥有）
            /// </summary>
            Defective,

            /// <summary>
            /// 左状态（转向灯特有）
            /// </summary>
            ExtraLeft,
            /// <summary>
            /// 右状态(转向灯特有)
            /// </summary>
            ExtraRight,

            /// <summary>
            /// 左前(窗/门)
            /// </summary>
            ExtraFrontLeft,

            /// <summary>
            /// 前右(窗/门)
            /// </summary>
            ExtraFrontRight,

            /// <summary>
            /// 左后(窗/门)
            /// </summary>
            ExtraRearLeft,

            /// <summary>
            /// 右后(窗/门)
            /// </summary>
            ExtraRearRight,

        }
    }
}
