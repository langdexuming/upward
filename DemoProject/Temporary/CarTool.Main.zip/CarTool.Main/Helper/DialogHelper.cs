﻿using CarTool.CommonComponents.Controls;
using CarTool.Main.MVVM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Media;
using System.Windows;
using CarTool.Main.Windows;
using CarTool.Main;

namespace CarTool.Main.Helper
{
    public static class DialogHelper
    {
        private static Dictionary<Type, Tuple<BaseDialog, Window>> _dialogs = new Dictionary<Type, Tuple<BaseDialog, Window>>();
        public static bool? ShowDialog(BaseDialogViewModel vm)
        {
            BaseDialog dialog;
            if (vm is NormalDialogViewModel)
            {
                dialog = new NormalDialog();
            }
            else if (vm is ModalDialogViewModel)
            {
                dialog = new ModalDialog();
            }
            else if (vm is ProgressDialogViewModel)
            {
                dialog = new ProgressDialog();
            }
            else
            {
                return false;//可以算异常
            }

            if (Application.Current.MainWindow != null)
            {
                Window window= Application.Current.MainWindow;

                //弹出蒙版窗体
                MaskingWindow maskingWindow = new MaskingWindow();
                maskingWindow.Width = window.ActualWidth;
                maskingWindow.Height = window.ActualHeight;
                if (window.WindowState != WindowState.Maximized)
                {
                    maskingWindow.Left = window.Left;
                    maskingWindow.Top = window.Top;
                }
                else
                {//透明窗体引起的放大缩小问题
                    maskingWindow.Left = 0;
                    maskingWindow.Top = 0;
                }
                maskingWindow.Opacity = 0.6;
                maskingWindow.Owner = window;
                maskingWindow.ShowInTaskbar = false;

                dialog.Title = vm.Title;
                dialog.Content = vm;

                maskingWindow.Show();
                dialog.Owner = maskingWindow;
                dialog.WindowStartupLocation = System.Windows.WindowStartupLocation.CenterOwner;
                dialog.ShowInTaskbar = false;

                var result = dialog.ShowDialog();
                
                //关闭蒙版窗体
                //关闭时，，不会导致主窗口最小化
                maskingWindow.Owner = null;
                maskingWindow.Hide();
                maskingWindow.Close();

                return result;
            }
            return false;
        }

        public static void Show(BaseDialogViewModel vm,bool isNeedMask=true)
        {
            BaseDialog dialog;
            if (vm is NormalDialogViewModel)
            {
                dialog = new NormalDialog();
            }
            else if (vm is ModalDialogViewModel)
            {
                dialog = new ModalDialog();
            }
            else if (vm is ProgressDialogViewModel)
            {
                dialog = new ProgressDialog();
            }
            else
            {
                throw new ArgumentNullException(nameof(vm));
            }

            if (Application.Current.MainWindow != null)
            {
                Window window = null;
                Window ownerWindow = null;
                foreach (Window win in Application.Current.Windows)
                {
                    if (win.IsActive)
                    {
                        window = win;
                    }
                }

                if (window == null) window = Application.Current.MainWindow;

                if (isNeedMask)
                {
                    ownerWindow = CreateMaskWindow();
                    ownerWindow.Show();
                }
                else
                {
                    ownerWindow = window;
                }
              
                dialog.Title = vm.Title;
                dialog.Content = vm;

                dialog.Owner = ownerWindow;
                dialog.WindowStartupLocation = System.Windows.WindowStartupLocation.CenterOwner;
                dialog.ShowInTaskbar = false;

                dialog.Show();

                var type = vm.GetType();
                if (!_dialogs.ContainsKey(type))
                {
                    _dialogs.Add(vm.GetType(), new Tuple<BaseDialog, Window>(dialog, ownerWindow));
                }
                else
                {
                    _dialogs[type] = new Tuple<BaseDialog, Window>(dialog, ownerWindow);
                }
            }
        }

        public static void Close(BaseDialogViewModel vm)
        {
            Action action = (() =>
                {
                    var type = vm.GetType();
                    if (_dialogs.ContainsKey(type))
                    {
                        _dialogs[type].Item1.Close();

                        var maskWindow = _dialogs[type].Item2 as MaskingWindow;
                        if (maskWindow != null)
                        {
                            //关闭蒙版窗体
                            //关闭时，，不会导致主窗口最小化
                            maskWindow.Owner = null;
                            maskWindow.Hide();
                            maskWindow.Close();
                        }

                        _dialogs.Remove(type);
                    }
                }
            );

            if (Application.Current.Dispatcher.CheckAccess())
            {
                action.Invoke();
            }
            else
            {
                Application.Current.Dispatcher.Invoke(action);
            }
        }

        public static MaskingWindow CreateMaskWindow()
        {
            if (Application.Current.MainWindow == null) throw new Exception("Fatal");

            //弹出蒙版窗体
            MaskingWindow maskingWindow = new MaskingWindow();
            Window mainWindow = Application.Current.MainWindow;
            maskingWindow.Width = mainWindow.ActualWidth;
            maskingWindow.Height = mainWindow.ActualHeight;
            if (mainWindow.WindowState != WindowState.Maximized)
            {
                maskingWindow.Left = mainWindow.Left;
                maskingWindow.Top = mainWindow.Top;
            }
            else
            {
                //透明窗体引起的放大缩小问题
                maskingWindow.Left = 0;
                maskingWindow.Top = 0;
            }
            maskingWindow.Opacity = 0.6;
            maskingWindow.Owner = mainWindow;
            maskingWindow.ShowInTaskbar = false;

            return maskingWindow;
        }
    }

}
