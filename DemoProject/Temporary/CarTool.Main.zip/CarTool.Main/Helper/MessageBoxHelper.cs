﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CarTool.Main.Helper
{
    public static class MessageBoxHelper
    {
        public static void Show(string msg)
        {
            //msg
        }
    }
}
