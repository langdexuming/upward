﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace CarTool.Main.Config
{
    public class AppConstants
    {
        /// <summary>
        /// 滚现列表的最大显示数量
        /// </summary>
        public const int MinorModelsCanMaxCount = 400;
        /// <summary>
        /// 车型库列表最大提示消息数量
        /// </summary>
        public const int MaxTipMessageCounts = 10;

        public static readonly string ConfigFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "config.xml");

        ///// <summary>
        ///// 刷新界面的时间
        ///// </summary>
        //public static int InterfaceRefreshMsec = 50;
    }
}
