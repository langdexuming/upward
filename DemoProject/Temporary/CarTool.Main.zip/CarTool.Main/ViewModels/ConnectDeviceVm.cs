﻿using CarTool.Main.Models;

namespace CarTool.Main.ViewModels
{
    public class ConnectDeviceVm
    {
        public AutoSpotBaudRateViewModel autoSpotBaudRateVm1 { get; set; }
        public AutoSpotBaudRateViewModel autoSpotBaudRateVm2 { get; set; }

        public ConnectDevice model { get; set; }

        public ConnectDeviceVm()
        {
            model = new ConnectDevice(false);

            autoSpotBaudRateVm1 = new AutoSpotBaudRateViewModel(0); //Can1通道自动识别
            autoSpotBaudRateVm2 = new AutoSpotBaudRateViewModel(1); //Can2通道自动识别
        }
    }
}
