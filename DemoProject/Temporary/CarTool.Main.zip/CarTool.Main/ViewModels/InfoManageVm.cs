﻿using CarInfoDB;
using CarTool.Main.Commands;
using CarTool.Main.Utils;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using static CarTool.Main.Enums.CommonEnums;
using CarTool.Main.MVVM;
using CarTool.Main.Models;

namespace CarTool.Main.ViewModels
{
    public class InfoManageVm : ViewModelBase
    {
        public ICollection<Infomation> Infomations { get; }
        public List<MainDataType> DataTypes { get; private set; }
        public List<string> PositiveTip { get; private set; }
        public List<string> OppositeTips { get; private set; }
        public List<string> ValueUnits { get; private set; }


        public InfoItem CurrentSelectedItem { get; set; }

        private InfoItem _currentEditItem;

        public InfoItem CurrentEditItem
        {
            get
            {
                if (_currentEditItem == null)
                    _currentEditItem = new InfoItem();
                return _currentEditItem;
            }
            set
            {
                _currentEditItem = value;
                RaisePropertyChanged(() => CurrentEditItem);
            }
        }

        private OpStatus _currentOpState = OpStatus.Add;

        public OpStatus CurrentOpState
        {
            get { return _currentOpState; }
            set
            {
                _currentOpState = value;
                RaisePropertyChanged(() => CurrentOpState);
            }
        }

        public ICommand SelectedItemChangedCommand
        {
            get
            {
                return new RelayCommand<object, string>(obj =>
                {
                    var infoItem = obj as InfoItem;
                    if (infoItem != null)
                    {
                        var item = infoItem;
                        CurrentSelectedItem = item;
                        RaisePropertyChanged(() => CurrentSelectedItem);
                        CurrentOpState = OpStatus.Replace;

                        if (CurrentSelectedItem != null)
                            CurrentEditItem.Copy(CurrentSelectedItem);
                    }
                    else
                    {
                        CurrentSelectedItem = null;
                    }
                    RaisePropertyChanged(() => CanModify);
                }, null);
            }
        }

        public bool CanModify => CurrentSelectedItem?.CanModify ?? false;

        public ICommand AddInfoItemCommand => new RelayCommand<object, string>(obj =>
        {
            CurrentOpState = OpStatus.Add;
            CurrentEditItem = new InfoItem();
        }, null);

        public ICommand UpdateInfoItemCommand
            => new RelayCommand<object, string>(obj => { CurrentOpState = OpStatus.Replace; }, null);

        public ICommand DeleteInfoItemCommand => new RelayCommand<object, string>(obj =>
        {
            CurrentOpState = OpStatus.Delete;
            if (CurrentSelectedItem != null)
            {
                if (MessageBox.Show("删除该信息项，将同时删除该信息项对应的数据，是否继续删除?", "警告", MessageBoxButton.YesNo) ==
                    MessageBoxResult.Yes)
                    if (DataManager.GetInstance().UpdateInfoItem(CurrentSelectedItem, null))
                    {
                        foreach (var info in Infomations)
                            if (info.DataTypeName == CurrentSelectedItem.MainDataTypeName)
                            {
                                if (info.InfoItems.Contains(CurrentSelectedItem))
                                    info.InfoItems.Remove(CurrentSelectedItem);
                                break;
                            }
                        MessageBox.Show("删除成功");
                        if (CurrentSelectedItem == CurrentEditItem)
                            CurrentEditItem = new InfoItem(); //重新分配
                    }
                    else
                    {
                        MessageBox.Show("删除失败");
                    }
            }
            else
            {
                MessageBox.Show("请选择信息项");
            }

            CurrentOpState = OpStatus.Replace;
        }, null);

        public ICommand SumbitCommand => new RelayCommand<object, string>(obj =>
        {
            switch (CurrentOpState)
            {
                case OpStatus.Add:
                    var itemAdd = CurrentEditItem.Copy();
                    if (DataManager.GetInstance().UpdateInfoItem(null, itemAdd))
                    {
                        foreach (var info in Infomations)
                            if (info.DataTypeName == CurrentEditItem.MainDataTypeName)
                            {
                                if (!info.InfoItems.Contains(CurrentEditItem))
                                    info.InfoItems.Add(itemAdd);
                                break;
                            }
                        MessageBox.Show("添加成功");
                        CurrentEditItem = new InfoItem(); //重新分配(如果使用该引用，上面集合中的数据会受影响)
                    }
                    else
                    {
                        MessageBox.Show("添加失败");
                    }
                    CurrentOpState = OpStatus.Add;
                    break;
                case OpStatus.Replace:
                    if (CurrentSelectedItem == null)
                    {
                        MessageBox.Show("请选择信息项");
                        return;
                    }
                    var itemReplace = CurrentEditItem.Copy();
                    var oldItem = CurrentSelectedItem.Copy();
                    if (DataManager.GetInstance().UpdateInfoItem(CurrentSelectedItem, itemReplace))
                    {
                        if (oldItem.MainDataTypeName != CurrentEditItem.MainDataTypeName)
                        {
                            //组名发生改变
                            foreach (var info in Infomations)
                                if (info.DataTypeName == oldItem.MainDataTypeName)
                                {
                                    if (info.InfoItems.Contains(CurrentSelectedItem))
                                        info.InfoItems.Remove(CurrentSelectedItem);
                                    break;
                                }
                            foreach (var info in Infomations)
                                if (info.DataTypeName == CurrentEditItem.MainDataTypeName)
                                {
                                    if (!info.InfoItems.Contains(CurrentEditItem))
                                        info.InfoItems.Add(itemReplace); //注意，要保持新数据
                                    break;
                                }
                        }
                        MessageBox.Show("修改成功");
                    }
                    else
                    {
                        MessageBox.Show("修改失败");
                    }
                    break;
                case OpStatus.Delete: //
                    //if (DataManager.GetInstance().UpdateInfoItem(CurrentSelectedItem, null))
                    //{
                    //    MessageBox.Show("删除成功");
                    //}
                    //else
                    //{
                    //    MessageBox.Show("删除失败");
                    //}
                    //CurrentOpState = OpStatus.Replace;
                    break;
                default:
                    break;
            }
        }, null);

        public ICommand ResetCommand => new RelayCommand<object, string>(obj =>
        {
            if (CurrentSelectedItem != null)
                CurrentEditItem.Copy(CurrentSelectedItem);
        }, null);

        public InfoManageVm()
        {
            Infomations = new ObservableCollection<Infomation>();
            var dataTypeNameList = new List<MainDataType>();
            dataTypeNameList.AddRange(InfoItem.NormalDataTypes);
            dataTypeNameList.AddRange(InfoItem.EobdDataTypes);
            foreach (var dataType in dataTypeNameList)
            {
                var items = DataManager.GetInstance().InfoItems.Where(x => x.MainDataTypeName == dataType.MainDataTypeName);
                Infomations.Add(new Infomation(dataType.MainDataTypeName, new ObservableCollection<InfoItem>(items)));
            }

            DataTypes = DataManager.GetInstance().GetMainDataTypes();
            PositiveTip = DataManager.GetInstance().GetPositiveTip();
            OppositeTips = DataManager.GetInstance().GetOppositeTip();
            ValueUnits = DataManager.GetInstance().GetValueUnit();
        }
    }
}
