﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataAcquisitionCenter.ViewModels
{
    public class ProgressVm
    {
        public Models.ProgressBase model { get; set; }
        
        public ProgressVm()
        {

            model = new Models.ProgressBase();
        }
    }
}
