﻿using CarTool.Main.Commands;
using CarTool.Main.Utils;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Input;
using CarTool.Main.MVVM;
using static CarTool.Main.Enums.CommonEnums;
using CarTool.Main.Services;
using CarTool.Main.Models;
using System.Windows;
using CarTool.Main.Windows;
using System.IO;
using CarTool.Main.Algorithm;
using CarTool.Main.HeaderFile;

namespace CarTool.Main.ViewModels
{
    /// <summary>
    ///     过期
    /// </summary>
    public class EobdDataModel : INotifyPropertyChanged
    {
        public int InfoItemId { get; set; }
        public string Title { get; set; }

        private string _value;

        public EobdDataModel(int infoItemId, string title, string _value, string unit)
        {
            InfoItemId = infoItemId;
            Title = title;
            this._value = _value;
            Unit = unit;
        }

        public string Unit { get; set; }

        public string Value
        {
            get { return _value; }

            set
            {
                _value = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("Value"));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        public void OnPropertyChanged(PropertyChangedEventArgs e)
        {
            PropertyChanged?.Invoke(this, e);
        }
    }


    public class EOBDVm : ViewModelBase
    {
        private EobdStatus _eobdState;

        public EobdStatus EobdState
        {
            get { return _eobdState; }
            set
            {
                _eobdState = value;
                RaisePropertyChanged(() => EobdState);
            }
        }


        private byte _canId;

        public byte CanId
        {
            get { return _canId; }
            set
            {
                _canId = value;
                RaisePropertyChanged(() => CanId);
            }
        }

        private bool IsEobdDataInit;

        private ICommand _canOpreateCommand;

        public ICommand CanOpreateCommand
        {
            get
            {
                return _canOpreateCommand ?? (_canOpreateCommand = new DelegateCommand
                {
                    ExecuteAtion = obj =>
                    {
                        // if (EobdState==EobdStatus.None)
                        {
                            if (EobdState == EobdStatus.None)
                            {
                                //连接
                                EobdState = EobdStatus.Connecting;
                                Task.Factory.StartNew(() =>
                                {
                                    //加载Eobe请求数据（根据需要加载）
                                    //ServiceManager.GetInstance().CanCoreCommunicateService.LoadEobdCommunicatedInfo(Properties.Resources.eobd, Modules.DataAnalysis);
                                    //执行EOBD连接请求
                                    ConnectError error;
                                    IsEobdDataInit = false;
                                    var result =
                                        ServiceManager.GetInstance()
                                            .CanCoreCommunicateService.ConnectEobd(Modules.DataAnalysis, out error,
                                                CanId);
                                    if (result)
                                    {
                                        //Thread.Sleep(1000);
                                        EobdState = EobdStatus.Connected;
                                        foreach (var item in EobdDataCollection)
                                            item.Content = "";
                                        IsEobdDataInit = true;
                                    }
                                    else
                                    {
                                        EobdState = EobdStatus.None;
                                        if (error != null)
                                            switch (error.ErrorCode)
                                            {
                                                case 6:
                                                    MessageBox.Show("请先断开车型库界面的EOBD连接！");
                                                    break;
                                                default:
                                                    MessageBox.Show("EOBD连接失败");
                                                    break;
                                            }
                                        else
                                            MessageBox.Show("EOBD连接失败");
                                    }
                                });
                            }
                            else
                            {
                                //断开
                                ServiceManager.GetInstance()
                                    .CanCoreCommunicateService.DisconnectEobd(Modules.DataAnalysis);
                                EobdState = EobdStatus.None;
                            }
                        }
                    }
                });
            }
            set
            {
                _canOpreateCommand = value;
                RaisePropertyChanged("CanOpreateCommand");
            }
        }

        private ICommand _exportCommand;

        public ICommand ExportCommand
        {
            get
            {
                return _exportCommand ?? (_exportCommand = new RelayCommand<object>(obj =>
                {
                    var list = obj as IList;
                    if (list != null)
                    {
                        if (!App.ViewModel.DataAnalysisVM.IsLoadedCarInfoSuccessful)
                        {
                            MessageBox.Show("请载入车型！");
                            return;
                        }
                        var items = list;

                        if (items?.Count <= 0)
                        {
                            MessageBox.Show("请选择信息项！");
                        }
                        else
                        {
                            //if (EobdState != EobdStatus.Connected)
                            //{
                            //    MessageBox.Show("请在连接成功后，再进行导出！");
                            //    return;
                            //}
                            //弹出进度框
                            var vm = new ProgressBase();

                            var progressView = new RingProgressWindow
                            {
                                DataContext = vm
                            };
                            progressView.Show();

                            Task.Factory.StartNew(() =>
                            {
                                var exportIdList = new List<int>();

                                exportIdList.Add((int)CanDataBoredom.EobdRequestId.Handshake);
                                exportIdList.Add((int)CanDataBoredom.EobdAnswerId.Handshake);

                                foreach (var item in items)
                                {
                                    var infoDetail = (InfoDetailReview) item;
                                    switch (infoDetail.InfoItemId)
                                    {
                                        case (int)CanDataBoredom.EobdAnswerId.Handshake: //EOBD连接--默认添加
                                            break;
                                        case (int)CanDataBoredom.EobdAnswerId.VinCode: //Vin码
                                            exportIdList.Add((int)CanDataBoredom.EobdRequestId.VinCode);
                                            exportIdList.Add((int)CanDataBoredom.EobdAnswerId.VinCode);
                                            exportIdList.Add((int)CanDataBoredom.EobdRequestId.VinSecond);
                                            exportIdList.Add((int)CanDataBoredom.EobdAnswerId.VinSecond);
                                            break;
                                        case (int)CanDataBoredom.EobdAnswerId.FaultCode: //故障码
                                            exportIdList.Add((int)CanDataBoredom.EobdRequestId.FaultCode);
                                            exportIdList.Add((int)CanDataBoredom.EobdAnswerId.FaultCode);
                                            exportIdList.Add((int)CanDataBoredom.EobdRequestId.FaultSecond);
                                            exportIdList.Add((int)CanDataBoredom.EobdAnswerId.FaultSecond);
                                            break;
                                        default: //通用算法类型
                                            exportIdList.Add(infoDetail.InfoItemId - 1);//请求项
                                            exportIdList.Add(infoDetail.InfoItemId);//应答项
                                            break;
                                    }
                                }
                                var count = exportIdList.Count;

                                foreach (var review in App.ViewModel.DataAnalysisVM.AllInfoItemReviews)
                                    if (exportIdList.Contains(review.InfoItemId))
                                    {
                                        //借助数据管理类生成对应DataTypeObject
                                        var dataTypeObjcet =
                                            DataManager.GetInstance().SearchDataTypeObjectBy(review.InfoItemId);
                                        if (dataTypeObjcet != null)
                                        {
                                            dataTypeObjcet.CanID = CanId;
                                            review.DataTypeObject = dataTypeObjcet;
                                            review.IsEnable = true;//导出项默认使能
                                        }
                                        vm.PercentageValue += (double) 100 / count;
                                        //指示进度
                                        Thread.Sleep(1);
                                    }

                                vm.PercentageValue = 100;
                                //关闭进度框
                                MessageBox.Show("导出成功！");

                                Application.Current.Dispatcher.Invoke(new Action(() => { progressView.Close(); }));
                            });
                        }
                    }
                }));
            }
            set
            {
                _exportCommand = value;
                RaisePropertyChanged(() => ExportCommand);
            }
        }


        //public ICollection<EobdDataModel> EobdDataCollection { get; } = new ObservableCollection<EobdDataModel>() {
        //    new EobdDataModel(1,"Vin码","",""),
        //    new EobdDataModel(2,"当前故障码","",""),
        //    new EobdDataModel(3,"绝对负荷值","","%"),
        //    new EobdDataModel(4,"冷却液温度","","℃"),
        //    new EobdDataModel(5,"节气门绝对位置","","%"),
        //    new EobdDataModel(6,"控制模块电压","","V"),
        //    new EobdDataModel(7,"燃油液位输入","","%或L"),
        //    new EobdDataModel(8,"气缸1点火提前角","","%"),
        //    new EobdDataModel(9,"发动机负荷","","ms或%"),
        //    new EobdDataModel(10,"空气流量传感器的空气流量","","g/s"),
        //    new EobdDataModel(11,"自发动机起动的时间","","S"),
        //    new EobdDataModel(12,"进气温度","","℃"),
        //    new EobdDataModel(13,"进气歧管传感器压力","","kPa"),
        //};
        private ICollection<InfoDetailReview> _eobdDataCollection;

        public ICollection<InfoDetailReview> EobdDataCollection
        {
            get { return _eobdDataCollection; }
            set
            {
                _eobdDataCollection = value;
                RaisePropertyChanged(() => EobdDataCollection);
            }
        }

        public EOBDVm(byte canId = 1)
        {
            CanId = canId;
            EobdDataCollection = new ObservableCollection<InfoDetailReview>();

            //生成EOBD项结果视图
            Task.Factory.StartNew(() =>
            {
                var reviews = new List<InfoDetailReview>();
                var infoItems = DataManager.GetInstance().InfoItems?.Where(x => x.InfoType == 1 && x.MainDataType == 0 && !x.IsExtend);
                var ingnoreList = DataManager.GetInstance().IgnoreDisplayInfoItemIdList;
                foreach (var infoItem in infoItems)
                {
                    var key = infoItem.InfoItemID;
                    //如果不需要显示在界面上的，就跳过
                    if (ingnoreList?.Contains(key) ?? false)
                        continue;
                    var review = new InfoDetailReview(key, infoItem.InfoItemName, true)
                    {
                        ValueType = infoItem.ValueType,
                        ValueUnit = infoItem.ValueUnit,
                        IsExtend = infoItem.IsExtend
                    };
                    //review.DefaultAssign();
                    reviews.Add(review);
                }
                Application.Current.Dispatcher.Invoke(
                    new Action(() => { EobdDataCollection = new ObservableCollection<InfoDetailReview>(reviews); }));
            });

            //EOBD信息同步事件
            ServiceManager.GetInstance().CanCoreCommunicateService.OnEobdPerformInfoActive += (s, e) =>
            {
                if (!IsEobdDataInit)
                    return;

                if (e._result == null)
                    return;

                var id = e._infoItemId;
                var result = e._result;

                switch (id)
                {
                    case (int)CanDataBoredom.EobdAnswerId.VinSecond: //VIN码二次应答
                        id = (int)CanDataBoredom.EobdAnswerId.VinCode; //VIN码
                        break;
                    case (int)CanDataBoredom.EobdAnswerId.FaultSecond: //故障码二次应答
                        id = (int)CanDataBoredom.EobdAnswerId.FaultCode; //故障码
                        break;
                    case (int)CanDataBoredom.EobdAnswerId.Handshake://连接
                        return;
                }
                //判断是否存在错误
                switch (result.ToString())
                {
                    case AlgorithmParse.ParameterParseError:
                        App.Log(e._infoItemId +"-" + AlgorithmParse.ParameterParseError.ToString(), App.Module.Eobd,
                            App.LogLevel.Normal);
                        return; //该错误直接返回
                    case AlgorithmParse.DeepParseParseError:
                        App.Log(e._infoItemId + "-" + AlgorithmParse.DeepParseParseError.ToString(), App.Module.Eobd,
                            App.LogLevel.Normal);
                        return; //该错误直接返回
                    case "?": //暂时支持
                        break;
                    default:
                        break;
                }

                var items = EobdDataCollection.Where(x => x.InfoItemId == id);

                foreach (var item in items)
                {
                    if (result is double)
                        item.Content = ((double) result).ToString(".##") + item.ValueUnit;
                    else
                        item.Content = result.ToString() + item.ValueUnit;
                    break;
                }
            };

            //从文本中加载EOBD通信规则
            var path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"Resources/Txt/eobd.txt");
            var content = string.Empty;
            StreamReader reader = null;
            try
            {
                reader = File.OpenText(path);
                content = reader?.ReadToEnd();
            }
            catch
            {
                App.Log("加载EOBD文本时发生错误！", App.Module.Eobd, App.LogLevel.Fatal);
            }
            finally
            {
                reader?.Close();
            }
            //Properties.Resources.eobd
            ServiceManager.GetInstance().CanCoreCommunicateService.LoadEobdCommunicatedInfo(content);
        }
    }
}
