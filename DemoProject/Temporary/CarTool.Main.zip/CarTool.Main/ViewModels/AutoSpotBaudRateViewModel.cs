﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows;
using CarTool.Main.Commands;
using CarTool.Main.ECanUsb;
using CarTool.Main.Models;
using CarTool.Main.MVVM;
using CarTool.Main.Services;
using CarTool.Main.Utils;

namespace CarTool.Main.ViewModels
{
    public class AutoSpotBaudRateViewModel : NormalDialogViewModel
    {
        private readonly byte CanChannel;
        private string _errorText;
        public string BaudRate;
        private bool _isFindCompatibleBaudRate;

        public bool IsFindCompatibleBaudRate
        {
            get { return _isFindCompatibleBaudRate; }
            set
            {
                _isFindCompatibleBaudRate = value;
                RaisePropertyChanged(() => IsFindCompatibleBaudRate);
            }
        }
        /// <summary>
        /// 向界面集合添加项
        /// </summary>
        /// <param name="model"></param>
        private delegate void DelegateCollectionOperate(AutoSpotBaudRateReview model);

        public AutoSpotBaudRateViewModel(byte _canId)
        {
            //初始化一些数据
            Title = "CAN" + (_canId + 1) + "波特率自动识别";
            _errorText = "";
            Models = new ObservableCollection<AutoSpotBaudRateReview>();
            SpotBaudRates = new List<string>();
            MinValue = "";
            MaxValue = "";
            CanChannel = _canId;

            ////定义相关Command
            StandardSpotStartCommand = new DelegateCommand {ExecuteAtion = StandardSpotStart};

            StandardSpotStopCommand = new DelegateCommand {ExecuteAtion = StandardSpotStop};

            RangeSpotStartCommand = new DelegateCommand {ExecuteAtion = RangeSpotStart};

            RangeSpotStopCommand = new DelegateCommand {ExecuteAtion = RangeSpotStop};

            CloseDialogWithOkCommand = new RelayCommand<string, string>(e => CloseDialogWithOk(e));

            CloseDialogWithCancelCommand = new DelegateCommand {ExecuteAtion = CloseDialogWithCancel};
        }

        public DelegateCommand StandardSpotStartCommand { get; set; }
        public DelegateCommand StandardSpotStopCommand { get; set; }

        public DelegateCommand RangeSpotStartCommand { get; set; }
        public DelegateCommand RangeSpotStopCommand { get; set; }

        private RelayCommand<string, string> closeDialogWithOkCommand;
        public DelegateCommand CloseDialogWithCancelCommand { get; set; }

        public string ErrorText
        {
            get { return _errorText; }

            set
            {
                _errorText = value;
                RaisePropertyChanged("ErrorText");
            }
        }


        public string MinValue { get; set; }

        public string MaxValue { get; set; }

        public ObservableCollection<AutoSpotBaudRateReview> Models { get; set; }


        public List<string> SpotBaudRates { get; set; }

        public RelayCommand<string, string> CloseDialogWithOkCommand
        {
            get { return closeDialogWithOkCommand; }

            set
            {
                closeDialogWithOkCommand = value;
                RaisePropertyChanged("CloseDialogWithOkCommand");
            }
        }

        private object CloseDialogWithOk(object e)
        {
            return null;
        }


        private void CloseDialogWithCancel(object obj)
        {
        }
        /// <summary>
        /// 范围识别停止
        /// </summary>
        /// <param name="obj"></param>
        private void RangeSpotStop(object obj)
        {
            ServiceManager.GetInstance()
                .CanCoreCommunicateService.StopAutoSpotBaudRate(CanChannel);
        }

        /// <summary>
        ///     范围识别波特率
        /// </summary>
        /// <param name="obj"></param>
        private void RangeSpotStart(object obj)
        {
            //验证
            ushort minValue = 0;
            ushort maxValue = 0;
            try
            {
                minValue = Convert.ToUInt16(MinValue);
                maxValue = Convert.ToUInt16(MaxValue);
                if (minValue < 0 || minValue > 1000) throw new Exception("value error");
                if (maxValue < 0 || maxValue > 1000) throw new Exception("value error");
                if (minValue > maxValue) throw new Exception("value error");
            }
            catch
            {
                MessageBox.Show("请注意输入格式（0-1000的整数）,左边的值需小于右边的值");
                return;
            }

            StartAutoSpot(GetRangeBaudRates(minValue, maxValue));
        }

        /// <summary>
        ///     标准识别-停止
        /// </summary>
        /// <param name="obj"></param>
        private void StandardSpotStop(object obj)
        {
            ServiceManager.GetInstance()
                .CanCoreCommunicateService.StopAutoSpotBaudRate(CanChannel);
        }

        /// <summary>
        ///     标准识别-开始
        /// </summary>
        /// <param name="obj"></param>
        private void StandardSpotStart(object obj)
        {
            StartAutoSpot(GetStandardBaudRates());
        }

        /// <summary>
        ///     开始自动识别波特率
        /// </summary>
        /// <param name="baudRates"></param>
        private void StartAutoSpot(List<string> baudRates)
        {
            var status = ServiceManager.GetInstance()
                .CanCoreCommunicateService.StartAutoSpotBaudRate(CanChannel, baudRates,
                    ar =>
                    {
                        var result=ar as AutoSpotBaudRateResult;
                        if (result != null)
                        {
                            if (result.IsOk)
                            {
                                Application.Current.Dispatcher.Invoke(new DelegateCollectionOperate(Models.Add),
                                    new AutoSpotBaudRateReview("o", result.BaudRate, "该波特率匹配成功", CanChannel));

                                BaudRate = result.BaudRate;
                                IsFindCompatibleBaudRate = true;
                            }
                            else
                            {
                                Application.Current.Dispatcher.Invoke(new DelegateCollectionOperate(Models.Add),
                                    new AutoSpotBaudRateReview("x", result.BaudRate, "该波特率匹配失败", CanChannel));
                            }
                        }
                    },
                    () =>
                    {
                        
                    });

            switch (status)
            {
                case AutoSpotBaudRateStatus.Ok:
                    //清空列表集合
                    Models.Clear();
                    ErrorText = "";
                    IsFindCompatibleBaudRate = false;
                    break;
                case AutoSpotBaudRateStatus.Busy:
                    ErrorText = "正在识别.....";
                    break;
                case AutoSpotBaudRateStatus.DeviceOpenError:
                    ErrorText = "请检查设备是否正常连接！";
                    break;
                default:
                    return;
            }
        }

        /// <summary>
        ///     标准识别的波特率集合
        /// </summary>
        /// <returns></returns>
        public List<string> GetStandardBaudRates()
        {
            var BaudRates = new List<string>
            {
                "5k",
                "10k",
                "20k",
                "40k",
                "50k",
                "80k",
                "100k",
                "125k",
                "200k",
                "250k",
                "400k",
                "500k",
                "666k",
                "800k",
                "1000k"
            };
            BaudRates.Reverse();
            return BaudRates;
        }

        /// <summary>
        ///     全范围识别方法根据5%的精度识别，获取集合
        /// </summary>
        /// <param name="minValue"></param>
        /// <param name="maxValue"></param>
        /// <returns></returns>
        public List<string> GetRangeBaudRates(ushort minValue, ushort maxValue)
        {
            var baudRates = new List<string>();
            var precision = maxValue - minValue < 50 ? 1 : 10;
            for (var i = 0; i < (maxValue - minValue) / precision + 1; i++)
            {
                var value = (ushort) (minValue + precision * i);
                baudRates.Add(value + "k");
            }
            return baudRates;
        }
    }
}