﻿using CarTool.Main.MVVM;

namespace CarTool.Main.ViewModels
{
    public class ConfirmationTipsViewModel : ModalDialogViewModel
    {
        public string Tip { get; set; }

        public ConfirmationTipsViewModel(string title, string tip)
        {
            Title = title;
            Tip = tip;
        }
    }
}
