﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using CarTool.Main.Commands;
using CarTool.Main.Config;
using CarTool.Main.Models;
using CarTool.Main.MVVM;
using CarTool.Main.Services;
using CarTool.Main.Utils;
using Microsoft.Win32;
using static CarTool.Main.HeaderFile.CanDataBoredom;

namespace CarTool.Main.ViewModels
{
    public class CanDataVm : ViewModelBase
    {
        public enum CanDataMode
        {
            Default = 0,
            Main = 0,
            Match
        }

        private string _canRunText;
        private int _currentPage;

        private string _filterMinorText;
        private int _maxPageRowCounts;

        private int _maxPageSize;

        public ObservableCollection<CanDataReview> _pageDataGridSource;

        private ICommand _sendCommand;

        private int selectPostion;

        private List<string> CanDataIdentiyMatchGroup;

        private const int MinorModelsCanMaxCount = AppConstants.MinorModelsCanMaxCount;

        private int _minorModelsCanId;

        /// <summary>
        ///     构造
        /// </summary>
        public CanDataVm(byte _canId)
        {
            MainModelsCan = new ObservableCollection<CanDataReview>();
            MatchModelsCan = new ObservableCollection<CanDataReview>();
            MinorModelsCan = new ObservableCollection<CanDataStandardReview>();


            CurrentModelsCan = MainModelsCan; //默认显示
            PageDataGridSource = new ObservableCollection<CanDataReview>();

            CanDataDisplayConfigReview = new CanDataDisplayConfigReview();

            CanId = _canId;

            this.CanDataDisplayConfigReview.PropertyChanged +=
                new PropertyChangedEventHandler(this.CanDataDisplayConfigReview_PropertyChanged);

            _currentPage = 1;

            SaveCurrentCanDataCommand = new RelayCommand<string, string>(SaveCurrentCanData, null);
            StopCanDataCommand = new RelayCommand<string, string>(StopCanData, null);

            CanClearCanData = true;
            ClearCanDataCommand = new RelayCommand<string, string>(ClearCanData, e => CanClearCanData);
            ClearMinorDataCommand = new RelayCommand<string, string>(ClearMinorCanData, null);
            FilterMinorDataCommand = new RelayCommand<string, string>(FilterMinorData, null);
            SaveMinorTxtCommand = new RelayCommand<string, string>(SaveMinorTxtData, null);

            CanRunText = "暂停";
            FilterMinorText = "过滤数据";

            //查找OrderId
            OrderIdSearchCommand = new RelayCommand<string, string>(OrderIdSearch, null);

            //取消所有滚现
            ClearGoNowOrderCommand = new RelayCommand<string, string>(ClearGoNowOrder, null);

        }

        /// <summary>
        /// 保存滚现文本
        /// </summary>
        /// <param name="obj"></param>
        private void SaveMinorTxtData(string obj)
        {
            var sf = new SaveFileDialog();

            sf.Title = "Save text Files";
            sf.DefaultExt = "txt";
            sf.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
            sf.FilterIndex = 1;
            sf.RestoreDirectory = true;

            var txt = new List<string>();
            var models = new List<CanDataStandardReview>(MinorModelsCan);

            var task = new Task(() =>
            {
                foreach (var item in models)
                    txt.Add(item.ToString("Text", null)); //+ "\r\n"
            });
            task.Start();
            var showDialog = sf.ShowDialog();
            if (showDialog != null && (bool)showDialog)
            {
                task.Wait();
                using (var fs = new FileStream(sf.FileName, FileMode.Create))
                {
                    using (var sw = new StreamWriter(fs, Encoding.Default))
                    {
                        for (var i = 0; i < txt.Count; i++)
                            sw.WriteLine(txt[i]);
                    }
                }
            }
        }

        /// <summary>
        /// 清空滚现列表数据
        /// </summary>
        /// <param name="obj"></param>
        private void ClearMinorCanData(string obj)
        {
            MinorModelsCan.Clear();
            _minorModelsCanId = 0;
        }

        /// <summary>
        /// 匹配集合（用于暂时缓存CanDataRevicw数据）
        /// </summary>
        public ObservableCollection<CanDataReview> MatchModelsCan { get; set; }

        /// <summary>
        /// 所有数据集合
        /// </summary>
        public ObservableCollection<CanDataReview> MainModelsCan { get; set; }

        /// <summary>
        /// 当前数据集合（指向MainModelsCan或MatchModelsCan）
        /// </summary>
        public ObservableCollection<CanDataReview> CurrentModelsCan { get; set; }

        /// <summary>
        /// 滚现列表数据
        /// </summary>
        public ObservableCollection<CanDataStandardReview> MinorModelsCan { get; set; }

        /// <summary>
        /// Can配置
        /// </summary>
        public CanDataDisplayConfigReview CanDataDisplayConfigReview { get; set; }

        /// <summary>
        /// 分页显示的页面数据
        /// </summary>
        public ObservableCollection<CanDataReview> PageDataGridSource
        {
            get { return _pageDataGridSource; }
            set
            {
                _pageDataGridSource = value;
                RaisePropertyChanged("PageDataGridSource");
            }
        }

        //private ICommand _goNowCommand;

        //public ICommand GoNowCommand {
        //    get
        //    {
        //        return _goNowCommand??(_goNowCommand=new RelayCommand<CanDataReview,bool>(canDataReview=> {
        //            ;
        //        },null));
        //    }
        //}

        /// <summary>
        /// 发送帧数据命令
        /// </summary>
        public ICommand SendCommand
        {
            get
            {
                return _sendCommand ?? (_sendCommand = new RelayCommand<object, bool>(obj =>
                {
                    var canDataReview = obj as CanDataReview;
                    if (canDataReview != null)
                    {
                        var review = canDataReview;
                        ServiceManager.GetInstance()
                            .CanCoreCommunicateService.SendCanData((ICanData)review.CanDataBaseObject,CanId);
                    }
                }, null));
            }
        }

        public byte CanId { get; } = 1;

        public int MaxPageSize
        {
            get { return _maxPageSize; }
            set
            {
                //无用
                _maxPageSize = value;

                RaisePropertyChanged("MaxPageSize");
                RaisePropertyChanged("PageTag");
            }
        }

        /// <summary>
        ///     当前页
        /// </summary>
        public int CurrentPage
        {
            get { return _currentPage; }
            set
            {
                if (value < 1 || value > MaxPageSize)
                    return;
                //Reset
                PageDataGridSource =
                    new ObservableCollection<CanDataReview>(
                        CurrentModelsCan.Take(value * MaxPageRowCounts).Skip((value - 1) * MaxPageRowCounts));
                _currentPage = value;
                // this.PageTag=this.CurrentPage.ToString() + "/" + this.MaxPageSize.ToString();
                RaisePropertyChanged("CurrentPage");
                RaisePropertyChanged("PageTag");
            }
        }

        /// <summary>
        ///     每页最大行数量
        /// </summary>
        public int MaxPageRowCounts
        {
            get { return _maxPageRowCounts; }
            set
            {
                _maxPageRowCounts = value;

                //容器高度发生改变=>MaxPageRowCounts改变
                Task.Factory.StartNew(() =>
                {
                    //校正最大页码
                    if (CurrentModelsCan.Count % MaxPageRowCounts > 0)
                        MaxPageSize = CurrentModelsCan.Count / MaxPageRowCounts + 1;
                    else
                        MaxPageSize = CurrentModelsCan.Count / MaxPageRowCounts;

                    if (CurrentPage > MaxPageSize)
                        CurrentPage = MaxPageSize;
                    else
                        CurrentPage = _currentPage; //引发页面数据源改变
                });
            }
        }

        public string PageTag => _currentPage + "/" + _maxPageSize;

        public RelayCommand<string, string> SaveCurrentCanDataCommand { get; }

        public RelayCommand<string, string> StopCanDataCommand { get; }

        public RelayCommand<string, string> ClearCanDataCommand { get; }

        public bool CanClearCanData { get; set; }

        public RelayCommand<string, string> FilterMinorDataCommand { get; }


        public RelayCommand<string, string> OrderIdSearchCommand { get; }

        public RelayCommand<string, string> ClearGoNowOrderCommand { get; }

        public RelayCommand<string, string> ClearMinorDataCommand { get; }

        public RelayCommand<string, string> SaveMinorTxtCommand { get; }
        

        public string CanRunText
        {
            get { return _canRunText; }

            set
            {
                _canRunText = value;
                RaisePropertyChanged("CanRunText");
            }
        }

        public string FilterMinorText
        {
            get { return _filterMinorText; }

            set
            {
                _filterMinorText = value;
                RaisePropertyChanged("FilterMinorText");
            }
        }

        public CanDataReview SelectedSpotCanDataReview { get; set; }

        public int SelectPostion
        {
            get { return selectPostion; }

            set
            {
                selectPostion = value;
                RaisePropertyChanged("SelectPostion");
            }
        }

        public enum DisplayMode
        {
            Normal,
            Filter
        }

        public DisplayMode CurrentDisplayMode;

         /// <summary>
         ///     如果检测到显示模式改变，则清空匹配集合，添加现列表的集合到匹配集合中
         /// </summary>
         /// <param name="sender"></param>
         /// <param name="e"></param>
        private void CanDataDisplayConfigReview_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            switch (e.PropertyName)
            {
                case nameof(CanDataDisplayConfigReview.DisplayTickMode):
                      switch (CanDataDisplayConfigReview.DisplayTickMode)
                        {
                            case 0://正常模式
                                Task.Factory.StartNew(() =>
                                {
                                    ServiceManager.GetInstance()
                                        .CanCoreCommunicateService.StartFilter(1, FilterMode.None, null,
                                            (list) => { CurrentDisplayMode = DisplayMode.Normal; }, null);
                                    ClearPageSource();
                                    //清除滚现命令文本
                                    foreach (var item in MatchModelsCan.Where(x => x.IsGoNow))
                                        item.IsGoNow = false;

                                    //提供界面效果
                                    Thread.Sleep(1000);
                                    CurrentModelsCan = MainModelsCan;
                                    ResetPage();
                                    CanClearCanData = true;

                                    Application.Current.Dispatcher.Invoke(
                                        new Action(
                                            () => { ClearCanDataCommand.RaiseCanExecuteChanged(); }));
                                });
                                break;
                            case 1://n秒内
                                CanDataDisplayConfigReview.CountdownTimer =
                                    CanDataDisplayConfigReview.WithinMsec;
                                ServiceManager.GetInstance().CanCoreCommunicateService.StartFilter(1, FilterMode.Within,
                                    FilterReadyAction,FilterReportAction, FilterCompleteAction,
                                    CanDataDisplayConfigReview.WithinMsec);
                                break;
                            case 2://n-m秒
                                CanDataDisplayConfigReview.CountdownTimer =
                                    CanDataDisplayConfigReview.MaxMsec;
                                ServiceManager.GetInstance().CanCoreCommunicateService.StartFilter(1, FilterMode.Period,
                                    FilterReadyAction, FilterReportAction, FilterCompleteAction,
                                    CanDataDisplayConfigReview.MinMsec, CanDataDisplayConfigReview.MaxMsec);
                                break;
                            default:
                                break;
                        }
                    break;
                case nameof(CanDataDisplayConfigReview.IsFilterMinorCanData):
                    break;
                case nameof(CanDataDisplayConfigReview.IsRunCanData):
                    ServiceManager.GetInstance().CanCoreCommunicateService.SetRun(CanId, CanDataDisplayConfigReview.IsRunCanData);
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// 开始过滤要执行操作
        /// </summary>
        private void FilterReadyAction()
        {
            CanClearCanData = false;

            Application.Current.Dispatcher.Invoke(
                new Action(() => { ClearCanDataCommand.RaiseCanExecuteChanged(); }));
            //MainModelsCan->MatchModelsCan
            CurrentModelsCan = MatchModelsCan;
            //this.CurrentModelsCan.Clear();
            CanDataDisplayConfigReview.IsCanFilter = false;

            CurrentModelsCan.Clear();
            ClearPage();

            //清除滚现命令文本
            foreach (var item in MainModelsCan.Where(x => x.IsGoNow))
                item.IsGoNow = false;
        }



        /// <summary>
        /// 过滤进度报告
        /// </summary>
        /// <param name="ar"></param>
        private void FilterReportAction(IAsyncResult ar)
        {
            var report = ar as FilterTimingReport;
            if (report != null)
            {
                CanDataDisplayConfigReview.CountdownTimer = report.CountDown;
            }
        }

        /// <summary>
        /// 过滤完的操作
        /// </summary>
        /// <param name="list"></param>
        private void FilterCompleteAction(List<string> list)
        {

            CanDataIdentiyMatchGroup = list;
            CanDataDisplayConfigReview.IsCanFilter = true;
            CurrentDisplayMode = DisplayMode.Filter;
            if (CanDataIdentiyMatchGroup?.Count > 0)
            {
                Application.Current.Dispatcher.Invoke(
                    new Action(() =>
                    {
                        int id = 0;
                        foreach (var canDataReview in MainModelsCan)
                        {
                            if (CanDataIdentiyMatchGroup.Contains(canDataReview.Identity))
                            {
                                var candataReview = new CanDataReview()
                                {
                                    CanDataBaseObject = canDataReview.CanDataBaseObject,
                                    CanDataChangeColorModelObject = canDataReview.CanDataChangeColorModelObject,
                                    Id = id
                                };
                                MatchModelsCan.Add(candataReview);
                                //这里对过滤后的集合监听，从而改变主集合(暂用于改变滚现)
                                candataReview.PropertyChanged += (s, e) =>
                                {
                                    if (e.PropertyName == nameof(CanDataReview.IsGoNow))
                                    {
                                        var goNowItem = s as CanDataReview;
                                        if (goNowItem != null)
                                        {
                                            var item = MainModelsCan.FirstOrDefault(x=>x.Identity== goNowItem.Identity);
                                            if (item != null)
                                            {
                                                item.IsGoNow = goNowItem.IsGoNow;
                                            }
                                        }
                                    }
                                };
                                id ++;
                            }
                        }
                        ResetPage();
                    })
                    );
            }
        }

        /// <summary>
        /// 清空CanData
        /// </summary>
        /// <param name="obj"></param>
        private void ClearCanData(string obj)
        {
            //由于底层数据变化较快，清空时，先停止底层处理
            ServiceManager.GetInstance().CanCoreCommunicateService.ClearCanData(CanId);
            CurrentModelsCan.Clear();
            ClearPage();
            CanDataDisplayConfigReview.OrderID = "";
        }

        private void StopCanData(string obj)
        {
            if (CanDataDisplayConfigReview.IsRunCanData)
            {
                CanDataDisplayConfigReview.IsRunCanData = false;
                CanRunText = "开始";
            }
            else
            {
                CanDataDisplayConfigReview.IsRunCanData = true;
                CanRunText = "暂停";
            }
        }

        /// <summary>
        ///     保存主列表当前项
        /// </summary>
        /// <param name="obj"></param>
        private void SaveCurrentCanData(string obj)
        {
            var sf = new SaveFileDialog
            {
                Title = "Save text Files",
                DefaultExt = "txt",
                Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*",
                FilterIndex = 1,
                RestoreDirectory = true
            };

            var txt = new List<string>();
            var models = new List<CanDataReview>(CurrentModelsCan);
            var task = new Task(() =>
            {
                //此处需注意线程安全问题
                foreach (var item in models)
                    txt.Add(item.ToString("Text")); //+ "\r\n"
            });
            task.Start();
            var showDialog = sf.ShowDialog();
            if (showDialog != null && (bool) showDialog)
            {
                task.Wait();
                using (var fs = new FileStream(sf.FileName, FileMode.Create))
                {
                    using (var sw = new StreamWriter(fs, Encoding.Default))
                    {
                        for (var i = 0; i < txt.Count; i++)
                            sw.WriteLine(txt[i]);
                    }
                }
            }
        }

        private void ClearGoNowOrder(string obj)
        {
            Task.Factory.StartNew(() =>
            {
                foreach (var item in MainModelsCan)
                {
                    if (item.IsGoNow)
                        item.IsGoNow = false;
                }

                foreach (var item in MatchModelsCan)
                {
                    if (item.IsGoNow)
                        item.IsGoNow = false;
                }
            });
        }

        private void FilterMinorData(string obj)
        {
            if (CanDataDisplayConfigReview.IsFilterMinorCanData)
            {
                FilterMinorText = "过滤数据";
                CanDataDisplayConfigReview.IsFilterMinorCanData = false;
            }
            else
            {
                FilterMinorText = "取消过滤";
                CanDataDisplayConfigReview.IsFilterMinorCanData = true;
            }
        }

        private void OrderIdSearch(string obj)
        {
            if (!string.IsNullOrWhiteSpace(obj))
            {
                uint orderId = 0;
                try
                {
                    orderId = Convert.ToUInt32(obj, 16);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("输入错误，请输入16进制的数字!");
                    return;
                }

                var task = Task.Factory.StartNew(() =>
                {
                    var postion = 0;
                    var isExist = false;
                    foreach (var item in CurrentModelsCan)
                    {
                        if (item.CanDataBaseObject.OrderId == orderId)
                        {
                            isExist = true;
                            break;
                        }
                        postion++;
                    }
                    if (isExist) //找到该数据
                        Application.Current.Dispatcher.Invoke(new OpreateIndex(LocateItem), postion);
                    else
                        MessageBox.Show("没有找到 [" + string.Format("0x{0:X}", orderId) + "] 对应的数据"); //orderId
                });
            }
        }


        /// <summary>
        /// </summary>
        /// <param name="review"></param>
        public void AddItem(CanDataReview review)
        {
            review.PropertyChanged += ModelsCanItem_PropertyChanged;

            review.Id = MainModelsCan.Count; //
            MainModelsCan.Add(review);
            ////暂不会出现下列这种情况
            //if (CurrentDisplayMode == DisplayMode.Filter)
            //{
            //    MatchModelsCan.Add(review);
            //}

            //校正最大页码
            if (CurrentModelsCan.Count % MaxPageRowCounts > 0)
                MaxPageSize = CurrentModelsCan.Count / MaxPageRowCounts + 1;
            else
                MaxPageSize = CurrentModelsCan.Count / MaxPageRowCounts;

            if (MaxPageRowCounts > PageDataGridSource.Count)
                PageDataGridSource.Add(review);
        }

        private bool isAddedFilterData = false;
        /// <summary>
        /// 更新值
        /// </summary>
        /// <param name="detailedCanData"></param>
        private void ItemAssign(DetailedCanData detailedCanData)
        {
            var canDataReview = MainModelsCan.FirstOrDefault(x => x.Identity == detailedCanData.Identity);
            if (canDataReview != null)
            {
                canDataReview.CanDataObjectAssign(detailedCanData);
                //滚现
                if (canDataReview.IsGoNow)
                {
                    if (CanDataDisplayConfigReview.IsFilterMinorCanData && detailedCanData.IsDataSame)
                        return;

                    var canDataStandardReview = new CanDataStandardReview(canDataReview.CanDataBaseObject.Copy());
                    canDataStandardReview.Id = _minorModelsCanId;
                    MinorModelsCan.Add(canDataStandardReview);
                    _minorModelsCanId++;
                    if (!isAddedFilterData)
                    {
                        isAddedFilterData = true;
                    }
                }
            }

            //添加的是一个引用，上面已经修改成功
            //if (CurrentDisplayMode == DisplayMode.Filter)
            //{
            //    var matchGroup = MatchModelsCan.Where(x => x.Identity == detailedCanData.Identity);
            //    foreach (var canDataReview in matchGroup)
            //    {
            //        canDataReview.CanDataObjectAssign(detailedCanData);
            //    }
            //}

        }

        public void ItemsAssign(IList<DetailedCanData> list,Action filterDataAddCompleteAction)
        {
            isAddedFilterData = false;
            foreach (var detailedCanData in list)
            {
                ItemAssign(detailedCanData);
            }
            //若存在有添加过滤集合的数据
            if (isAddedFilterData)
            {
                //移除部分数据
                if (MinorModelsCan.Count >= MinorModelsCanMaxCount)
                {
                    for (var i = 0; i < MinorModelsCanMaxCount / 4; i++)
                    {
                        MinorModelsCan.RemoveAt(0);
                    }
                }

                //通知赋值完成的事件,通知UI层滚动到最后
                filterDataAddCompleteAction?.Invoke();
            }
        }
        /// <summary>
        ///     行属性改变
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ModelsCanItem_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            switch (e.PropertyName)
            {
                case "IsGoNow":
                    var GoNow_item = sender as CanDataReview;

                    if (GoNow_item != null)
                        if (GoNow_item.IsGoNow)
                            CanDataDisplayConfigReview.OrderID += " " +
                                                                  string.Format("0x{0:x}",
                                                                      GoNow_item.CanDataBaseObject.OrderId);
                        else
                            CanDataDisplayConfigReview.OrderID = OrderIdRemove(CanDataDisplayConfigReview.OrderID,
                                GoNow_item.CanDataBaseObject.OrderId);

                    break;
                default:
                    break;
            }
        }

        private static string OrderIdRemove(string old_orderId, uint _removeId)
        {
            var builder = new StringBuilder(old_orderId);
            builder.Replace(" " + string.Format("0x{0:x}", _removeId), "");
            return builder.ToString();
        }

        /// <summary>
        ///     提供对页面数据的清空和页码的修正---采用委托
        /// </summary>
        public void ClearPage()
        {
            //校正最大页码
            Application.Current.Dispatcher.Invoke(new DelegateCollectionOperat(PageDataGridSource.Clear));
            CurrentPage = 1;
            MaxPageSize = 0;
        }


        /// <summary>
        ///     提供对页面数据的清空和页码的修正---采用委托
        /// </summary>
        public void ClearPageSource()
        {
            //校正最大页码
            Application.Current.Dispatcher.Invoke(new DelegateCollectionOperat(PageDataGridSource.Clear));
            //this.CurrentPage = 1;
            //this.MaxPageSize = 0;
        }

        /// <summary>
        ///     提供对页面数据和页码的重置---采用委托
        /// </summary>
        public void ResetPage()
        {
            //校正最大页码
            if (CurrentModelsCan.Count % MaxPageRowCounts > 0)
                MaxPageSize = CurrentModelsCan.Count / MaxPageRowCounts + 1;
            else
                MaxPageSize = CurrentModelsCan.Count / MaxPageRowCounts;

            CurrentPage = 1; //修改页面会产生集合改变
        }


        /// <summary>
        ///     排序
        /// </summary>
        /// <param name="sortColumn">The column or member that is the basis for sorting.</param>
        /// <param name="ascending">Set to true if the sort</param>
        public void Sort(string sortColumn, bool ascending)
        {
            var sortedProducts = new ObservableCollection<CanDataReview>();

            switch (sortColumn)
            {
                case "Id":
                    sortedProducts = new ObservableCollection<CanDataReview>
                    (
                        from p in CurrentModelsCan
                        orderby p.Id
                        select p
                    );
                    break;
                case "CanDataBaseObject.OrderId":
                    sortedProducts = new ObservableCollection<CanDataReview>
                    (
                        from p in CurrentModelsCan
                        orderby p.CanDataBaseObject.OrderId
                        select p
                    );
                    break;
            }

            sortedProducts = ascending
                ? sortedProducts
                : new ObservableCollection<CanDataReview>(sortedProducts.Reverse());

            CurrentModelsCan = sortedProducts;
            PageDataGridSource.Clear();
            foreach (
                var item in
                CurrentModelsCan.Take(_currentPage * MaxPageRowCounts).Skip((_currentPage - 1) * MaxPageRowCounts))
                PageDataGridSource.Add(item);
        }


        /// <summary>
        ///     跳到首页
        /// </summary>
        public void SetPageIndex()
        {
            CurrentPage = 1;
        }


        /// <summary>
        ///     定位到指定位置项
        /// </summary>
        /// <param name="postion"></param>
        public void LocateItem(int postion)
        {
            var count = CurrentModelsCan.Count;
            if (postion < 0 || postion > count - 1)
                return;
            //将当前数据源置换到指定页
            CurrentPage = postion / MaxPageRowCounts + 1;
            SelectPostion = postion % MaxPageRowCounts;
        }

        private delegate void DelegateCollectionOperat();

        private delegate void DelegateCollectionOperate(CanDataReview model);

        private delegate void OpreateIndex(int _int);
    }
}