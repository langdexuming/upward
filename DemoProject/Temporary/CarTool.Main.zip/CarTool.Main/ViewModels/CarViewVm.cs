﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Media;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Threading;
using CarInfoDB;
using CarTool.Main.Algorithm;
using CarTool.Main.Commands;
using CarTool.Main.Config;
using CarTool.Main.HeaderFile;
using CarTool.Main.Models;
using CarTool.Main.Models.Base;
using CarTool.Main.MVVM;
using CarTool.Main.Properties;
using CarTool.Main.Services;
using CarTool.Main.Utils;
using CarTool.Main.ViewModels.CouplingEventArgs;
using static CarTool.Main.Helper.InfoDetailListBoxItemHelper;
using static CarTool.Main.Enums.CommonEnums;
using Timer = System.Timers.Timer;

namespace CarTool.Main.ViewModels
{
    public class CarViewVm : ViewModelBase
    {
        //带参数ItemId
        public delegate void ExportLibraryDoingEventHandler(object sender, InfoItemEventArgs e);


        //带参数当前车型配置
        public delegate void ExportLibraryEndEventHandler(object sender, CanConfigurationEventArgs e);

        /// 定义导出车型库事件触发源
        public delegate void ExportLibraryStartEventHandler(object sender, EventArgs e);

        private const int MaxTipMessageCount = AppConstants.MaxTipMessageCounts; //提示的消息条数

        private static readonly SoundPlayer Player = new SoundPlayer();

        //储存车型库所有信息
        private readonly Dictionary<int, InfoDetailBase> AllInfoDetailDictionary = new Dictionary<int, InfoDetailBase>();

        public readonly Dictionary<int, object> CarStatusDictionayBuffer;

        private readonly BackgroundWorker ExportCarLibraryBackgroundWorker; //后台线程-导出车型库

        private readonly List<int> IgnoreDisplayIdList = DataManager.GetInstance().IgnoreDisplayInfoItemIdList;

        private readonly DispatcherTimer MainDispatcherTimer;

        private readonly BackgroundWorker OperateCarLibraryBackgroundWorker; //后台线程-载入
        //播放声音
        private readonly Timer PlaySoundTimer;
        public readonly object sync_lockCarStatusBuffer = new object();

        private readonly object sync_sounds = new object();

        //品牌集合
        private ICollection<Brand> _brands;

        private ICommand _canOpreateCommand;

        private BrandAndModel _currentBrandAndModel;

        private ObservableCollection<InfoDetailReview> _currentOnlyReadInfoDetailReviews;


        //////////////////////////////////////EOBD
        /// <summary>
        ///     EOBD状态
        /// </summary>
        private EobdStatus _eobdState;


        private InfoReviewDisplayModes _onlyReadReviewDisplayMode;

        private string _runTip = "暂未连接";
        private bool CanExportLibrary; //指示是否可以导出（当没有载入车型库时，无法导出）


        //提供信息查找字典
        private Dictionary<int, InfoAttribute> InfoDetails;
        private bool IsConnectCarSuccessful; //指示通讯是否正常


        //指示声音是否打开
        private bool isOpenVoice;

        public ListBox MessageTipListBox;

        private double progressValue;

        /// <summary>
        ///     播放队列为
        /// </summary>
        public Dictionary<string, int> Sounds = new Dictionary<string, int>();


        public CarViewVm()
        {
            //配置定时器
            MainDispatcherTimer = new DispatcherTimer();
            MainDispatcherTimer.Tick += MainDispatcherTimer_Tick;
            MainDispatcherTimer.Interval = new TimeSpan(0, 0, 0, 0, 50); //50ms
            MainDispatcherTimer.Start();

            CarStatusDictionayBuffer = new Dictionary<int, object>();

            //播放声音
            PlaySoundTimer = new Timer(2000);
            PlaySoundTimer.Elapsed += PlaySoundTimer_Elapsed;


            //载入并连接
            LoadCommand = new RelayCommand<object, bool>(e =>
            {
                #region 载入并连接

                if (!OperateCarLibraryBackgroundWorker.IsBusy)
                {
                    var brandAndModel = e as BrandAndModel;
                    if (brandAndModel != null)
                    {
                        CurrentBrandAndModel = brandAndModel;

                        IsConnectCarSuccessful = false;
                        CanExportLibrary = false;

                        ServiceManager.GetInstance().CanCoreCommunicateService.CloseDevice(); //先关闭设备

                        AllInfoDetailDictionary.Clear();

                        OnlyReadInfoDictionary.Clear();
                        // this.CurrentOnlyReadInfoDetailReviews.Clear();
                        AllOnlyReadInfoDetailReviews.Clear();
                        CurrentOnlyReadInfoDetailReviews.Clear();
                        MessageTipReviews.Clear();
                        ViewLeftOnlyReadInfoDetailReviews.Clear();
                        ViewRightOnlyReadInfoDetailReviews.Clear();

                        MoreControlInfoDetailReviews.Clear();
                        MoreOnlyReadInfoDetailReviews.Clear();

                        EobdOnlyReadInfoDetailReviews.Clear();

                        lock (sync_lockCarStatusBuffer)
                        {
                            CarStatusDictionayBuffer.Clear();
                        }

                        ServiceManager.GetInstance().CanCoreCommunicateService.ClearRealTimeInfo();

                        OperateCarLibraryBackgroundWorker.RunWorkerAsync();
                    }
                    else
                    {
                        MessageBox.Show("请选择车型！");
                    }
                }

                #endregion
            });
            //导出车型库
            ExportLibraryCommand = new RelayCommand<bool, bool>(e =>
            {
                #region 导出

                if (!CanExportLibrary)
                {
                    MessageBox.Show("无法导出，请确保数据正常载入！");
                }
                else
                {
                    if (AllInfoDetailDictionary.Values.Count(x => x.IsSelected) > 0)
                    {
                        if (!ExportCarLibraryBackgroundWorker.IsBusy)
                        {
                            ExportItemsIdGroup.Clear();

                            ExportCarLibraryBackgroundWorker.RunWorkerAsync();
                        }
                    }
                    else
                    {
                        MessageBox.Show("请选择导出信息项!");
                    }
                }

                #endregion
            });

            //生成品牌集合
            _brands = DataManager.GetInstance().HasDataBrands;

            //导出项集合
            ExportItemsIdGroup = new List<int>();

            //当前车型配置
            CurrentBrandAndModel = new BrandAndModel(); //跟导出一致

            //初始化后台线程

            //载入并连接
            OperateCarLibraryBackgroundWorker = new BackgroundWorker
            {
                WorkerReportsProgress = true,
                WorkerSupportsCancellation = true
            };
            OperateCarLibraryBackgroundWorker.DoWork += BackgroundWorker_DoWork;
            OperateCarLibraryBackgroundWorker.ProgressChanged += BackgroundWorker_ProgressChanged;
            OperateCarLibraryBackgroundWorker.RunWorkerCompleted += BackgroundWorker_RunWorkerCompleted;

            //导出车型库
            ExportCarLibraryBackgroundWorker = new BackgroundWorker
            {
                WorkerReportsProgress = true,
                WorkerSupportsCancellation = true
            };
            ExportCarLibraryBackgroundWorker.DoWork += ExportCarLibraryBackgroundWorker_DoWork;
            ExportCarLibraryBackgroundWorker.ProgressChanged += ExportCarLibraryBackgroundWorker_ProgressChanged;
            ExportCarLibraryBackgroundWorker.RunWorkerCompleted += ExportCarLibraryBackgroundWorker_RunWorkerCompleted;


            //模糊对应数据库的信息项
            InfoDictionary = GetDefaultDictionary();
            InfoIndexDictionary = GetOnlyReadDetailReviewsIndex(); //获取所有车身状态项对应数据库索引

            //包含所有的只读信息对应的数据展示结果,ID索引
            OnlyReadInfoDictionary = new Dictionary<int, InfoDetailReview>();

            //加载默认数据
            AllOnlyReadInfoDetailReviews = GetDefaultDetailReviewsNoSql();
            CurrentOnlyReadInfoDetailReviews = GetDefaultDetailReviewsNoSql();

            OnlyReadInfoImageAndTipDictionary = GetDefaultOnlyReadInfoImageAndTipDictionary();

            DataManager.GetInstance().InfoItems.CollectionChanged += (s, e) =>
            {
                switch (e.Action)
                {
                    case NotifyCollectionChangedAction.Replace:
                        break;
                    case NotifyCollectionChangedAction.Add:
                        if (e.NewItems.Count > 0)
                        {
                            var infoItem = e.NewItems[0] as InfoItem;
                            if (infoItem != null)
                                if (infoItem.IsExtend)
                                    OnlyReadInfoImageAndTipDictionary?.Add(infoItem.InfoItemID,
                                        new ImageShowReview("", "", infoItem.PositiveTip, infoItem.OppositeTip)
                                        {
                                            InfoItem = infoItem
                                        });
                        }
                        break;
                    case NotifyCollectionChangedAction.Remove:
                        if (e.OldItems.Count > 0)
                        {
                            var infoItem = e.OldItems[0] as InfoItem;
                            if (infoItem?.IsExtend == true)
                                OnlyReadInfoImageAndTipDictionary?.Remove(infoItem.InfoItemID);
                        }
                        break;
                }
            };

            foreach (var infoItem in DataManager.GetInstance().InfoItems)
            {
                if (infoItem.InfoType == (int) InfoTypeFlag.Normal && infoItem.IsExtend)
                {
                    OnlyReadInfoImageAndTipDictionary.Add(infoItem.InfoItemID,
                        new ImageShowReview("", "", infoItem.PositiveTip, infoItem.OppositeTip)
                        {
                            InfoItem = infoItem
                        });
                }
            }

            EobdOnlyReadInfoDetailReviews = GetDefaultEobdDetailReviewsNoSql();

            ViewLeftOnlyReadInfoDetailReviews = new ObservableCollection<InfoDetailReview>();
            ViewRightOnlyReadInfoDetailReviews = new ObservableCollection<InfoDetailReview>();

            MoreControlInfoDetailReviews = new ObservableCollection<ControlInfoDetailReview>();
            MoreOnlyReadInfoDetailReviews = new ObservableCollection<InfoDetailReview>();


            var group1 = from item in CurrentOnlyReadInfoDetailReviews
                where item.CurrentActiveTipArea == InfoDetailReview.ActiveTipArea.VirtualScenesLeftBoxArea
                select item;
            foreach (var item in group1)
                ViewLeftOnlyReadInfoDetailReviews.Add(item);

            var group2 = from item in CurrentOnlyReadInfoDetailReviews
                where item.CurrentActiveTipArea == InfoDetailReview.ActiveTipArea.VirtualScenesRightBoxArea
                select item;
            foreach (var item in group2)
                ViewRightOnlyReadInfoDetailReviews.Add(item);

            //初始化消息提示
            MessageTipReviews = new ObservableCollection<MessageTipReview>();
            //指示存在正在读取的声音
            Player.LoadCompleted += PlayerLoadCompleted;
            //  Player.StreamChanged += new EventHandler(this.PlayerStreamChanged);


            //订阅事件(车信息有变化)
            ServiceManager.GetInstance().CanCoreCommunicateService.OnPerformInfoActive +=
                CanCoreCommunicateService_PerformInfoChange;

            #region 若是改为集合绑定,可使用该快捷语法

            //ControlInfoDictionary.Add(82, new ControlInfoDetailReview(82, "上锁", true)
            //{
            //    DisableBrushUri = "Images/CarView/btn_lock_disable.png",
            //    NormalBrushUri = "Images/CarView/btn_lock_default.png",
            //    ClickBrushUri = "Images/CarView/btn_lock_click.png",
            //    ClickCommand = new RelayCommand<bool, bool>(x => {
            //        SendControlSignal(84);
            //    }, null)
            //});

            #endregion

            ControlInfoDictionary = new Dictionary<int, ControlInfoDetailReview>();

            #region 控制项初始化

            //上锁
            ControlLockInfoDetailReview = new ControlInfoDetailReview(84, "上锁", true)
            {
                DisableBrushUri = "Images/CarView/btn_lock_disable.png",
                NormalBrushUri = "Images/CarView/btn_lock_default.png",
                ClickBrushUri = "Images/CarView/btn_lock_click.png",
                ClickCommand = new RelayCommand<bool, bool>(x => { SendControlSignal(84); }, null)
            };
            ControlInfoDictionary.Add(84, ControlLockInfoDetailReview);

            ////点火熄火（去掉）
            //ControlPowerInfoDetailReview = new ControlInfoDetailReview(82, "", true)
            //{
            //    DisableBrushUri = "Images/CarView/btn_Ignition_disable.png",
            //    SwitchOffBrushUri = "Images/CarView/btn_Ignition_off.png",
            //    SwitchOnBrushUri = "Images/CarView/btn_Ignition_on.png",
            //    ClickCommand = new RelayCommand<bool, bool>(x =>
            //    {
            //        if (x) SendControlSignal(82); else SendControlSignal(83);
            //    }, null)
            //};
            //ControlInfoDictionary.Add(82, ControlPowerInfoDetailReview);
            //ControlInfoDictionary.Add(83, ControlPowerInfoDetailReview);
            //开锁
            ControlUnLockInfoDetailReview = new ControlInfoDetailReview(85, "开锁", true)
            {
                DisableBrushUri = "Images/CarView/btn_unlock_disable.png",
                NormalBrushUri = "Images/CarView/btn_unlock_default.png",
                ClickBrushUri = "Images/CarView/btn_unlock_click.png",
                ClickCommand = new RelayCommand<bool, bool>(x => { SendControlSignal(85); }, null)
            };
            ControlInfoDictionary.Add(85, ControlUnLockInfoDetailReview);
            //尾箱
            ControlTrunkInfoDetailReview = new ControlInfoDetailReview(92, "尾箱", true)
            {
                DisableBrushUri = "Images/CarView/btn_trunkstate_disable.png",
                SwitchOffBrushUri = "Images/CarView/btn_trunkstate_off.png",
                SwitchOnBrushUri = "Images/CarView/btn_trunkstate_on.png",
                ClickCommand = new RelayCommand<bool, bool>(x =>
                { SendControlSignal(!x ? 92 : 93); }, null)
            };
            ControlInfoDictionary.Add(92, ControlTrunkInfoDetailReview);
            ControlInfoDictionary.Add(93, ControlTrunkInfoDetailReview);

            ////寻车（去掉）
            //ControlRemoteCarFindingInfoDetailReview = new ControlInfoDetailReview(86, "寻车", true)
            //{
            //    DisableBrushUri = "Images/CarView/btn_remotecarfinding_disable.png",
            //    NormalBrushUri = "Images/CarView/btn_remotecarfinding_default.png",
            //    ClickBrushUri = "Images/CarView/btn_remotecarfinding_click.png",
            //    ClickCommand = new RelayCommand<bool, bool>(x =>
            //    {
            //        SendControlSignal(86);
            //    }, null)
            //};
            //ControlInfoDictionary.Add(86, ControlRemoteCarFindingInfoDetailReview);
            //危险灯控制
            ControlHazardLightsInfoDetailReview = new ControlInfoDetailReview(94, "危险灯", true)
            {
                DisableBrushUri = "Images/CarView/btn_opreatehazardlights_disable.png",
                SwitchOffBrushUri = "Images/CarView/btn_opreatehazardlights_off.png",
                SwitchOnBrushUri = "Images/CarView/btn_opreatehazardlights_on.png",
                ClickCommand = new RelayCommand<bool, bool>(x =>
                { SendControlSignal(!x ? 94 : 95); }, null)
            };
            ControlInfoDictionary.Add(94, ControlHazardLightsInfoDetailReview);
            ControlInfoDictionary.Add(95, ControlHazardLightsInfoDetailReview);
            //大灯控制
            ControlHeadlightInfoDetailReview = new ControlInfoDetailReview(98, "大灯", true)
            {
                DisableBrushUri = "Images/CarView/btn_headlight_disable.png",
                SwitchOffBrushUri = "Images/CarView/btn_headlight_off.png",
                SwitchOnBrushUri = "Images/CarView/btn_headlight_on.png",
                ClickCommand = new RelayCommand<bool, bool>(x =>
                { SendControlSignal(!x ? 98 : 99); }, null)
            };
            ControlInfoDictionary.Add(98, ControlHeadlightInfoDetailReview);
            ControlInfoDictionary.Add(99, ControlHeadlightInfoDetailReview);
            //天窗控制
            ControlSkyLightInfoDetailReview = new ControlInfoDetailReview(100, "天窗", true)
            {
                DisableBrushUri = "Images/CarView/btn_skylight_disable.png",
                SwitchOffBrushUri = "Images/CarView/btn_skylight_off.png",
                SwitchOnBrushUri = "Images/CarView/btn_skylight_on.png",
                ClickCommand = new RelayCommand<bool, bool>(x =>
                { SendControlSignal(!x ? 100 : 101); }, null)
            };
            ControlInfoDictionary.Add(100, ControlSkyLightInfoDetailReview);
            ControlInfoDictionary.Add(101, ControlSkyLightInfoDetailReview);
            //扬声器控制
            ControlSpeakersInfoDetailReview = new ControlInfoDetailReview(96, "扬声器控制", true)
            {
                DisableBrushUri = "Images/CarView/btn_opreatespeakers_disable.png",
                SwitchOffBrushUri = "Images/CarView/btn_opreatespeakers_off.png",
                SwitchOnBrushUri = "Images/CarView/btn_opreatespeakers_on.png",
                ClickCommand = new RelayCommand<bool, bool>(x =>
                { SendControlSignal(!x ? 96 : 97); }, null)
            };
            ControlInfoDictionary.Add(96, ControlSpeakersInfoDetailReview);
            ControlInfoDictionary.Add(97, ControlSpeakersInfoDetailReview);


            //左前窗
            ControlFrontLeftWindowInfoDetailReview = new ControlInfoDetailReview(115, "左前窗", true)
            {
                //DisableBrushUri = "Images/CarView/btn_risingwindow_disable.png",
                //NormalBrushUri = "Images/CarView/btn_opreatewindow_default.png",
                //ExtraLeftPressBrushUri = "Images/CarView/btn_risingwindow_click.png",
                //ExtraRightPressBrushUri = "Images/CarView/btn_droppingwindow_click.png",
                OnCommand = new RelayCommand<bool, bool>(x => { SendControlSignal(115); }, null),
                OffCommand = new RelayCommand<bool, bool>(x => { SendControlSignal(116); }, null)
            };
            ControlInfoDictionary.Add(115, ControlFrontLeftWindowInfoDetailReview);
            ControlInfoDictionary.Add(116, ControlFrontLeftWindowInfoDetailReview);
            //全窗
            ControlAllWindowsInfoDetailReview = new ControlInfoDetailReview(123, "全窗", true)
            {
                //DisableBrushUri = "Images/CarView/btn_risingwindow_disable.png",
                //NormalBrushUri = "Images/CarView/btn_opreatewindow_default.png",
                //ExtraLeftPressBrushUri = "Images/CarView/btn_risingwindow_click.png",
                //ExtraRightPressBrushUri = "Images/CarView/btn_droppingwindow_click.png",
                OnCommand = new RelayCommand<bool, bool>(x => { SendControlSignal(123); }, null),
                OffCommand = new RelayCommand<bool, bool>(x => { SendControlSignal(124); }, null)
            };
            ControlInfoDictionary.Add(123, ControlAllWindowsInfoDetailReview);
            ControlInfoDictionary.Add(124, ControlAllWindowsInfoDetailReview);
            //右前窗
            ControlFrontRightWindowInfoDetailReview = new ControlInfoDetailReview(117, "右前窗", true)
            {
                OnCommand = new RelayCommand<bool, bool>(x => { SendControlSignal(117); }, null),
                OffCommand = new RelayCommand<bool, bool>(x => { SendControlSignal(118); }, null)
            };
            ControlInfoDictionary.Add(117, ControlFrontRightWindowInfoDetailReview);
            ControlInfoDictionary.Add(118, ControlFrontRightWindowInfoDetailReview);
            //左后窗
            ControlRearLeftWindowInfoDetailReview = new ControlInfoDetailReview(119, "左后窗", true)
            {
                OnCommand = new RelayCommand<bool, bool>(x => { SendControlSignal(119); }, null),
                OffCommand = new RelayCommand<bool, bool>(x => { SendControlSignal(120); }, null)
            };
            ControlInfoDictionary.Add(119, ControlRearLeftWindowInfoDetailReview);
            ControlInfoDictionary.Add(120, ControlRearLeftWindowInfoDetailReview);
            //右后窗
            ControlRearRightWindowInfoDetailReview = new ControlInfoDetailReview(121, "右后窗", true)
            {
                OnCommand = new RelayCommand<bool, bool>(x => { SendControlSignal(121); }, null),
                OffCommand = new RelayCommand<bool, bool>(x => { SendControlSignal(122); }, null)
            };
            ControlInfoDictionary.Add(121, ControlRearRightWindowInfoDetailReview);
            ControlInfoDictionary.Add(122, ControlRearRightWindowInfoDetailReview);
            //水温查询
            ControlWaterTemperatureQueryInfoDetailReview = new ControlInfoDetailReview(104, "水温查询", true)
            {
                DisableBrushUri = "Images/CarView/btn_watertemperaturequery_disable.png",
                NormalBrushUri = "Images/CarView/btn_watertemperaturequery_default.png",
                ClickBrushUri = "Images/CarView/btn_watertemperaturequery_click.png",
                ClickCommand = new RelayCommand<bool, bool>(x => { SendControlSignal(104); }, null)
            };
            ControlInfoDictionary.Add(104, ControlWaterTemperatureQueryInfoDetailReview);
            //车速查询
            ControlSpeedQueryInfoDetailReview = new ControlInfoDetailReview(105, "车速查询", true)
            {
                DisableBrushUri = "Images/CarView/btn_speedquery_disable.png",
                NormalBrushUri = "Images/CarView/btn_speedquery_default.png",
                ClickBrushUri = "Images/CarView/btn_speedquery_click.png",
                ClickCommand = new RelayCommand<bool, bool>(x => { SendControlSignal(105); }, null)
            };
            ControlInfoDictionary.Add(105, ControlSpeedQueryInfoDetailReview);

            //故障代码查询
            ControlFaultCodeQueryInfoDetailReview = new ControlInfoDetailReview(106, "故障代码查询", true)
            {
                DisableBrushUri = "Images/CarView/btn_faultcodequery_disable.png",
                NormalBrushUri = "Images/CarView/btn_faultcodequery_default.png",
                ClickBrushUri = "Images/CarView/btn_faultcodequery_click.png",
                ClickCommand = new RelayCommand<bool, bool>(x => { SendControlSignal(106); }, null)
            };
            ControlInfoDictionary.Add(106, ControlFaultCodeQueryInfoDetailReview);
            //四轮车速查询
            ControlFourWheelVehicleSpeedQueryInfoDetailReview = new ControlInfoDetailReview(107, "四轮车速查询", true)
            {
                DisableBrushUri = "Images/CarView/btn_fourwheelvehiclespeedquery_disable.png",
                NormalBrushUri = "Images/CarView/btn_fourwheelvehiclespeedquery_default.png",
                ClickBrushUri = "Images/CarView/btn_fourwheelvehiclespeedquery_click.png",
                ClickCommand = new RelayCommand<bool, bool>(x => { SendControlSignal(107); }, null)
            };
            ControlInfoDictionary.Add(107, ControlFourWheelVehicleSpeedQueryInfoDetailReview);
            //空调状态查询
            ControlAirConditioningStatusQueryInfoDetailReview = new ControlInfoDetailReview(108, "空调状态查询", true)
            {
                DisableBrushUri = "Images/CarView/btn_airconditioningstatequery_disable.png",
                NormalBrushUri = "Images/CarView/btn_airconditioningstatequery_default.png",
                ClickBrushUri = "Images/CarView/btn_airconditioningstatequery_click.png",
                ClickCommand = new RelayCommand<bool, bool>(x => { SendControlSignal(108); }, null)
            };
            ControlInfoDictionary.Add(108, ControlAirConditioningStatusQueryInfoDetailReview);
            //电池电压状态查询
            ControlBatteryVoltageQueryInfoDetailReview = new ControlInfoDetailReview(109, "电池电压状态查询", true)
            {
                DisableBrushUri = "Images/CarView/btn_batteryvoltagequery_disable.png",
                NormalBrushUri = "Images/CarView/btn_batteryvoltagequery_default.png",
                ClickBrushUri = "Images/CarView/btn_batteryvoltagequery_click.png",
                ClickCommand = new RelayCommand<bool, bool>(x => { SendControlSignal(109); }, null)
            };
            ControlInfoDictionary.Add(109, ControlBatteryVoltageQueryInfoDetailReview);

            #endregion
            #region 声音资源:映射到Property.Resources
            //声音资源:映射到Property.Resources
            VoiceResourcesDictionary = new Dictionary<string, UnmanagedMemoryStream>
            {
                {"Resources/Voice/Ignition_open.wav", Resources.Ignition_open},
                {"Resources/Voice/Ignition_close.wav", Resources.Ignition_close},
                {"Resources/Voice/acc_open.wav", Resources.acc_open},
                {"Resources/Voice/acc_close.wav", Resources.acc_close},
                {"Resources/Voice/gas_up.wav", Resources.gas_up},
                {"Resources/Voice/gas_down.wav", Resources.gas_down},
                {"Resources/Voice/footbrake_up.wav", Resources.footbrake_up},
                {"Resources/Voice/footbrake_down.wav", Resources.footbrake_down},
                {"Resources/Voice/manualbrake_off.wav", Resources.manualbrake_off},
                {"Resources/Voice/manualbrake_on.wav", Resources.manualbrake_on},
                {"Resources/Voice/lockstate_off.wav", Resources.lockstate_off},
                {"Resources/Voice/lockstate_on.wav", Resources.lockstate_on},
                {"Resources/Voice/airconditioning_on.wav", Resources.airconditioning_on},
                {"Resources/Voice/airconditioning_off.wav", Resources.airconditioning_off},
                {"Resources/Voice/smalllight_on.wav", Resources.smalllight_on},
                {"Resources/Voice/smalllight_off.wav", Resources.smalllight_off},
                {"Resources/Voice/skylight_on.wav", Resources.skylight_on},
                {"Resources/Voice/skylight_off.wav", Resources.skylight_off},
                {"Resources/Voice/headlight_on.wav", Resources.headlight_on},
                {"Resources/Voice/headlight_off.wav", Resources.headlight_off},
                {"Resources/Voice/hazardlights_on.wav", Resources.hazardlights_on},
                {"Resources/Voice/hazardlights_off.wav", Resources.hazardlights_off},
                {"Resources/Voice/sumpcoverstate_on.wav", Resources.sumpcoverstate_on},
                {"Resources/Voice/sumpcoverstate_off.wav", Resources.sumpcoverstate_off},
                {"Resources/Voice/enginecoverstate_on.wav", Resources.enginecoverstate_on},
                {"Resources/Voice/enginecoverstate_off.wav", Resources.enginecoverstate_off},
                {"Resources/Voice/trunkstate_on.wav", Resources.trunkstate_on},
                {"Resources/Voice/trunkstate_off.wav", Resources.trunkstate_off},
                {"Resources/Voice/leftturnsignal_on.wav", Resources.leftturnsignal_on},
                {"Resources/Voice/leftturnsignal_off.wav", Resources.leftturnsignal_off},
                {"Resources/Voice/rightturnsignal_on.wav", Resources.rightturnsignal_on},
                {"Resources/Voice/rightturnsignal_off.wav", Resources.rightturnsignal_off},
                {"Resources/Voice/seatbelt_off.wav", Resources.seatbelt_off},
                {"Resources/Voice/seatbelt_on.wav", Resources.seatbelt_on},
                {"Resources/Voice/frontleftdoor_open.wav", Resources.frontleftdoor_open},
                {"Resources/Voice/frontleftdoor_close.wav", Resources.frontleftdoor_close},
                {"Resources/Voice/frontrightdoor_open.wav", Resources.frontrightdoor_open},
                {"Resources/Voice/frontrightdoor_close.wav", Resources.frontrightdoor_close},
                {"Resources/Voice/rearleftdoor_open.wav", Resources.rearleftdoor_open},
                {"Resources/Voice/rearleftdoor_close.wav", Resources.rearleftdoor_close},
                {"Resources/Voice/rearrightdoor_open.wav", Resources.rearrightdoor_open},
                {"Resources/Voice/rearrightdoor_close.wav", Resources.rearrightdoor_close},
                {"Resources/Voice/frontleftwindow_open.wav", Resources.frontleftwindow_open},
                {"Resources/Voice/frontleftwindow_close.wav", Resources.frontleftwindow_close},
                {"Resources/Voice/frontrightwindow_open.wav", Resources.frontrightwindow_open},
                {"Resources/Voice/frontrightwindow_close.wav", Resources.frontrightwindow_close},
                {"Resources/Voice/rearleftwindow_open.wav", Resources.rearleftwindow_open},
                {"Resources/Voice/rearleftwindow_close.wav", Resources.rearleftwindow_close},
                {"Resources/Voice/rearrightwindow_open.wav", Resources.rearrightwindow_open},
                {"Resources/Voice/rearrightwindow_close.wav", Resources.rearrightwindow_close},
                {"Resources/Voice/enginefailurelight_on.wav", Resources.enginefailurelight_on},
                {"Resources/Voice/enginefailurelight_off.wav", Resources.enginefailurelight_off},
                {"Resources/Voice/airbagfailurelight_on.wav", Resources.airbagfailurelight_on},
                {"Resources/Voice/airbagfailurelight_off.wav", Resources.airbagfailurelight_off},
                {"Resources/Voice/enginestate_on.wav", Resources.enginestate_on},
                {"Resources/Voice/enginestate_off.wav", Resources.enginestate_off},
                {"Resources/Voice/changeoillight_on.wav", Resources.changeoillight_on},
                {"Resources/Voice/changeoillight_off.wav", Resources.changeoillight_off}
            };
            //该项已删除（原因：与发动机状态重叠）
            //VoiceResourcesDictionary.Add("Resources/Voice/car_start.wav", Properties.Resources.car_start) ;
            //VoiceResourcesDictionary.Add("Resources/Voice/car_stop.wav", Properties.Resources.car_stop);
            #endregion

            //控制状态提示(弃用)
            ControlImageTipReview = new ImageTipReview();
        }

        public ICommand LoadCommand { get; }

        public ICommand ExportLibraryCommand { get; }

        public string RunTip
        {
            get { return _runTip; }
            set
            {
                _runTip = value;
                RaisePropertyChanged("RunTip");
            }
        }

        public ICollection<Brand> Brands
        {
            get { return _brands; }

            set
            {
                _brands = value;
                RaisePropertyChanged("Brands");
            }
        }

        public BrandAndModel CurrentBrandAndModel
        {
            get { return _currentBrandAndModel; }
            set
            {
                _currentBrandAndModel = value;
                RaisePropertyChanged("CurrentBrandAndModel");
            }
        }

        public double ProgressValue
        {
            get { return progressValue; }

            set
            {
                progressValue = value;
                RaisePropertyChanged("ProgressValue");
            }
        }

        public ObservableCollection<InfoDetailReview> CurrentOnlyReadInfoDetailReviews
        {
            get { return _currentOnlyReadInfoDetailReviews; }
            set
            {
                _currentOnlyReadInfoDetailReviews = value;
                RaisePropertyChanged(() => CurrentOnlyReadInfoDetailReviews);
            }
        }

        public ObservableCollection<InfoDetailReview> AllOnlyReadInfoDetailReviews { get; set; }

        public ObservableCollection<InfoDetailReview> ViewLeftOnlyReadInfoDetailReviews { get; set; }
        public ObservableCollection<InfoDetailReview> ViewRightOnlyReadInfoDetailReviews { get; set; }

        public ObservableCollection<MessageTipReview> MessageTipReviews { get; set; }

        //public Dictionary<int, InfoDetailReview> OnlyReadInfoImageAndTipDictionary { get; set; }

        public ObservableCollection<ControlInfoDetailReview> MoreControlInfoDetailReviews { get; }
        public ObservableCollection<InfoDetailReview> MoreOnlyReadInfoDetailReviews { get; }

        public ObservableCollection<InfoDetailReview> EobdOnlyReadInfoDetailReviews { get; }

        /// <summary>
        ///     供导出
        /// </summary>
        public List<int> ExportItemsIdGroup { get; set; }

        public EobdStatus EobdState
        {
            get { return _eobdState; }
            set
            {
                _eobdState = value;
                RaisePropertyChanged(() => EobdState);
            }
        }

        public ICommand CanOpreateCommand
        {
            get
            {
                return _canOpreateCommand ?? (_canOpreateCommand = new RelayCommand<object, bool>(obj =>
                {
                    // if (EobdState==EobdStatus.None)
                    {
                        if (EobdState == EobdStatus.None)
                        {
                            //连接
                            EobdState = EobdStatus.Connecting;
                            if (IsConnectCarSuccessful)
                            {
                                //找到连接的CanId
                                //var connectItem = EobdOnlyReadInfoDetailReviews.Where(x=>x.InfoItemId==);
                                Task.Factory.StartNew(() =>
                                {
                                    //执行EOBD连接请求
                                    ConnectError error;
                                    if (
                                        ServiceManager.GetInstance()
                                            .CanCoreCommunicateService.ConnectEobd(Modules.CarView, out error))
                                    {
                                        EobdState = EobdStatus.Connected;
                                    }
                                    else
                                    {
                                        EobdState = EobdStatus.None;
                                        if (error != null)
                                            switch (error.ErrorCode)
                                            {
                                                case 6:
                                                    MessageBox.Show("请先断开数据分析界面的EOBD连接！");
                                                    break;
                                                case 12:
                                                    MessageBox.Show("EOBD连接失败，EOBD数据解析时，发现无效的请求数据，请检测EOBD数据项！");
                                                    break;
                                                case 152:
                                                    MessageBox.Show("EOBD连接请求数据格式有误,无法正常加载数据！");
                                                    break;
                                                case 200:
                                                    MessageBox.Show("EOBD信息请求数据格式有误,无法正常加载数据！");
                                                    break;
                                                default:
                                                    MessageBox.Show("EOBD连接失败");
                                                    break;
                                            }
                                        else
                                            MessageBox.Show("EOBD连接失败");
                                    }
                                });
                            }
                            else
                            {
                                EobdState = EobdStatus.None;
                                MessageBox.Show("通讯异常，无法连接！");
                            }
                        }
                        else
                        {
                            //断开
                            ServiceManager.GetInstance().CanCoreCommunicateService.DisconnectEobd(Modules.CarView);
                            EobdState = EobdStatus.None;
                        }
                    }
                }, null));
            }
            set
            {
                _canOpreateCommand = value;
                RaisePropertyChanged("CanOpreateCommand");
            }
        }

        /// <summary>
        ///显示信息格式改变（全部/已使能）
        /// </summary>
        public InfoReviewDisplayModes OnlyReadReviewDisplayMode
        {
            get { return _onlyReadReviewDisplayMode; }

            set
            {
                _onlyReadReviewDisplayMode = value;
                ResetReviews(value);
            }
        }

        public Dictionary<int, InfoDetailReview> OnlyReadInfoDictionary { get; set; }

        public Dictionary<int, ImageShowReview> OnlyReadInfoImageAndTipDictionary { get; }

        /// <summary>
        /// 暂不需要（控制显示）
        /// </summary>
        public ImageTipReview ControlImageTipReview { get; set; } //控制状态提示

        public bool IsOpenVoice
        {
            get { return isOpenVoice; }
            set
            {
                isOpenVoice = value;

                PlaySoundTimer.Enabled = value;
            }
        }

        public Dictionary<int, ControlInfoDetailReview> ControlInfoDictionary { get; set; }

        public Dictionary<string, UnmanagedMemoryStream> VoiceResourcesDictionary { get; set; }

        /// 创建一个字典 infoItemID(int)  CarView中的视图名称 Name(string)
        /// 此处，ID和Name与数据库中有出入
        /// 模糊映射1-1 2-2 31-32,32,33,34
        public Dictionary<int, string> InfoDictionary { get; set; }

        public Dictionary<int, int> InfoIndexDictionary { get; set; }
        public event ExportLibraryStartEventHandler ExportLibraryStartEvent;

        public void ActivateExportLibraryStart()
        {
            ExportLibraryStartEvent?.Invoke(this, new EventArgs());
        }

        public event ExportLibraryDoingEventHandler ExportLibraryDoingEvent;

        public void ActivateExportDoingLibrary(InfoItemReview _item)
        {
            ExportLibraryDoingEvent?.Invoke(this, new InfoItemEventArgs(_item));
        }

        public event ExportLibraryEndEventHandler ExportLibraryEndEvent;

        public void ActivateExportLibraryEnd(BrandAndModel _brandAndModel)
        {
            ExportLibraryEndEvent?.Invoke(this, new CanConfigurationEventArgs(_brandAndModel));
        }

        /// <summary>
        /// 重置视图
        /// </summary>
        private void ResetReviews(InfoReviewDisplayModes mode)
        {
            Application.Current.Dispatcher.Invoke(new Action(() =>
            {
                MoreOnlyReadInfoDetailReviews.Clear();
                CurrentOnlyReadInfoDetailReviews.Clear();
                ViewLeftOnlyReadInfoDetailReviews.Clear();
                ViewRightOnlyReadInfoDetailReviews.Clear();
            }));

            Task task = null;
            //展示动态添加过程
            switch (mode)
            {
                case InfoReviewDisplayModes.All:
                    task = Task.Factory.StartNew(() =>
                    {
                        Application.Current.Dispatcher.Invoke(new Action(() =>
                        {
                            foreach (var item in AllOnlyReadInfoDetailReviews)
                                if (!item.IsExtend)
                                    CurrentOnlyReadInfoDetailReviews.Add(item);
                                else
                                    MoreOnlyReadInfoDetailReviews.Add(item);
                        }));
                    });
                    break;
                case InfoReviewDisplayModes.Enabled:
                    task = Task.Factory.StartNew(() =>
                    {
                        Application.Current.Dispatcher.Invoke(new Action(() =>
                        {
                            foreach (var item in AllOnlyReadInfoDetailReviews.Where(e => e.IsEnabled))
                                if (!item.IsExtend)
                                    CurrentOnlyReadInfoDetailReviews.Add(item);
                                else
                                    MoreOnlyReadInfoDetailReviews.Add(item);
                        }));
                    });
                    break;
                default:
                    break;
            }
            task?.ContinueWith(e =>
            {
                var group1 = from item in CurrentOnlyReadInfoDetailReviews
                    where item.CurrentActiveTipArea == InfoDetailReview.ActiveTipArea.VirtualScenesLeftBoxArea
                    select item;
                foreach (var item in group1)
                    Application.Current.Dispatcher.BeginInvoke(
                        new Action(() => { ViewLeftOnlyReadInfoDetailReviews.Add(item); }));

                var group2 = from item in CurrentOnlyReadInfoDetailReviews
                    where item.CurrentActiveTipArea == InfoDetailReview.ActiveTipArea.VirtualScenesRightBoxArea
                    select item;
                foreach (var item in group2)
                    Application.Current.Dispatcher.BeginInvoke(
                        new Action(() => { ViewRightOnlyReadInfoDetailReviews.Add(item); }
                        ));
            });
        }

        /// <summary>
        ///     发送控制信号
        /// </summary>
        /// <param name="id"></param>
        private static void SendControlSignal(int id)
        {
            Task.Factory.StartNew(() =>
            {
                //从数据库中获得
                var result = ServiceManager.GetInstance().CanCoreCommunicateService.SendControlCanData(id);

                if (!result)
                {
                    MessageBox.Show("控制数据格式错误，控制失败！");
                }

            });
        }

        private ObservableCollection<InfoDetailReview> GetDefaultEobdDetailReviewsNoSql()
        {
            var reviews = new ObservableCollection<InfoDetailReview>();
            reviews.Add(new InfoDetailReview(-1, "绝对负荷值"));
            reviews.Add(new InfoDetailReview(-1, "节气门绝对位置"));
            reviews.Add(new InfoDetailReview(-1, "燃油液位输入"));
            reviews.Add(new InfoDetailReview(-1, "点火提前角"));
            reviews.Add(new InfoDetailReview(-1, "空气流量"));
            reviews.Add(new InfoDetailReview(-1, "控制模块电压"));
            reviews.Add(new InfoDetailReview(-1, "自发动机启动时间"));
            reviews.Add(new InfoDetailReview(-1, "冷却液温度"));
            reviews.Add(new InfoDetailReview(-1, "进气温度"));
            reviews.Add(new InfoDetailReview(-1, "进气岐管绝对气压"));
            reviews.Add(new InfoDetailReview(-1, "VIN码"));
            reviews.Add(new InfoDetailReview(-1, "当前故障码"));
            return reviews;
        }

        private Dictionary<int, ImageShowReview> GetDefaultOnlyReadInfoImageAndTipDictionary()
        {
            //采用集合绑定
            var dictionary = new Dictionary<int, ImageShowReview>();

            #region 车身动态展示、消息提示、 语音提示初始化

            dictionary.Add(1,
                new ImageShowReview("", "", "点火开关已打开.", "点火开关已关闭.", "Resources/Voice/Ignition_open.wav",
                    "Resources/Voice/Ignition_close.wav"));
            dictionary.Add(2,
                new ImageShowReview("", "", "ACC已启动.", "ACC已关闭.", "Resources/Voice/acc_open.wav",
                    "Resources/Voice/acc_close.wav")); //ACC
            //该项已删除（原因：与发动机状态重叠）
            // dictionary.Add(3, new ImageShowReview("","","车已启动.","车已停止.", "Resources/Voice/car_start.wav", "Resources/Voice/car_stop.wav"));//启动
            dictionary.Add(4,
                new ImageShowReview("", "", "正在踩油门.", "油门已松.", "Resources/Voice/gas_up.wav",
                    "Resources/Voice/gas_down.wav")); //油门
            dictionary.Add(5,
                new ImageShowReview("", "", "脚刹已踩.", "脚刹已松.", "Resources/Voice/footbrake_down.wav",
                    "Resources/Voice/footbrake_up.wav")); //脚刹
            dictionary.Add(6,
                new ImageShowReview("", "", "手刹已拉.", "手刹已松.", "Resources/Voice/manualbrake_off.wav",
                    "Resources/Voice/manualbrake_on.wav")); //手刹
            dictionary.Add(7,
                new ImageShowReview("Images/CarView/view_unlock.png", "Images/CarView/view_lock.png", "已开锁.", "已上锁.",
                    "Resources/Voice/lockstate_on.wav", "Resources/Voice/lockstate_off.wav")); //锁
            dictionary.Add(8,
                new ImageShowReview("", "", "空调已开.", "空调已关.", "Resources/Voice/airconditioning_on.wav",
                    "Resources/Voice/airconditioning_off.wav")); //空调
            dictionary.Add(9, new ImageShowReview()); //温度

            dictionary.Add(10,
                new ImageShowReview("", "", "小灯已开.", "小灯已关.", "Resources/Voice/smalllight_on.wav",
                    "Resources/Voice/smalllight_off.wav")); //小灯

            dictionary.Add(11, new ImageShowReview()); //档位
            dictionary.Add(12,
                new ImageShowReview("", "", "天窗已开.", "天窗已关.", "Resources/Voice/skylight_on.wav",
                    "Resources/Voice/skylight_off.wav")); //天窗
            dictionary.Add(13, new ImageShowReview()); //速度
            dictionary.Add(14, new ImageShowReview("", "", "雨刮器已开.", "雨刮器已关.")); //雨刮

            dictionary.Add(15, new ImageShowReview()); //里程
            dictionary.Add(16, new ImageShowReview()); //水温
            dictionary.Add(17,
                new ImageShowReview("Images/CarView/view_headlight.png", "", "大灯已打开.", "大灯已关闭.",
                    "Resources/Voice/headlight_on.wav", "Resources/Voice/headlight_off.wav"));
            dictionary.Add(24,
                new ImageShowReview("", "", "油箱盖已开.", "油箱盖已关.", "Resources/Voice/sumpcoverstate_on.wav",
                    "Resources/Voice/sumpcoverstate_off.wav")); //油箱盖
            dictionary.Add(25,
                new ImageShowReview("", "", "引擎盖已开.", "引擎盖已关.", "Resources/Voice/enginecoverstate_on.wav",
                    "Resources/Voice/enginecoverstate_off.wav")); //引擎盖
            dictionary.Add(26,
                    new ImageShowReview("Images/CarView/view_trunkstate_on.png",
                        "Images/CarView/view_trunkstate_off.png",
                        "后备箱已开.", "后备箱已关.", "Resources/Voice/trunkstate_on.wav", "Resources/Voice/trunkstate_off.wav"));
                //后备箱
            dictionary.Add(27,
                new ImageShowReview("", "", "左转向灯开启.", "左转向灯关闭.", "Resources/Voice/leftturnsignal_on.wav",
                    "Resources/Voice/leftturnsignal_off.wav")); //左转向灯
            dictionary.Add(28,
                new ImageShowReview("", "", "右转向灯开启.", "右转向灯关闭.", "Resources/Voice/rightturnsignal_on.wav",
                    "Resources/Voice/rightturnsignal_off.wav")); //右转向灯
            dictionary.Add(29,
                new ImageShowReview("", "", "安全带已系.", "安全带未系.", "Resources/Voice/seatbelt_off.wav",
                    "Resources/Voice/seatbelt_on.wav")); //安全带（主)

            dictionary.Add(30, new ImageShowReview()); //方向盘

            dictionary.Add(31,
                new ImageShowReview("Images/CarView/view_frontleftdoor_open.png",
                    "Images/CarView/view_frontleftdoor_close.png", "左前门已打开.", "左前门已关闭.",
                    "Resources/Voice/frontleftdoor_open.wav", "Resources/Voice/frontleftdoor_close.wav")); //门（左前）
            dictionary.Add(32,
                new ImageShowReview("Images/CarView/view_frontrightdoor_open.png",
                    "Images/CarView/view_frontrightdoor_close.png", "右前门已打开.", "右前门已关闭.",
                    "Resources/Voice/frontrightdoor_open.wav", "Resources/Voice/frontrightdoor_close.wav")); //门（右前)
            dictionary.Add(33,
                new ImageShowReview("Images/CarView/view_rearleftdoor_open.png",
                    "Images/CarView/view_rearleftdoor_close.png", "左后门已打开.", "左后门已关闭.",
                    "Resources/Voice/rearleftdoor_open.wav", "Resources/Voice/rearleftdoor_close.wav")); //门（左后）
            dictionary.Add(34,
                new ImageShowReview("Images/CarView/view_rearrightdoor_open.png",
                    "Images/CarView/view_rearrightdoor_close.png", "右后门已打开.", "右后门已关闭.",
                    "Resources/Voice/rearrightdoor_open.wav", "Resources/Voice/rearrightdoor_close.wav")); //门（右后）

            dictionary.Add(35,
                new ImageShowReview("Images/CarView/view_frontleftwindow_open.png",
                    "Images/CarView/view_frontleftwindow_close.png", "左前窗已打开.", "左前窗已关闭.",
                    "Resources/Voice/frontleftwindow_open.wav", "Resources/Voice/frontleftwindow_close.wav")); //窗（左前）
            dictionary.Add(36,
                new ImageShowReview("Images/CarView/view_frontrightwindow_open.png",
                    "Images/CarView/view_frontrightwindow_close.png", "右前窗已打开.", "右前窗已关闭.",
                    "Resources/Voice/frontrightwindow_open.wav", "Resources/Voice/frontrightwindow_close.wav")); //窗（右前）
            dictionary.Add(37,
                new ImageShowReview("Images/CarView/view_rearleftwindow_open.png",
                    "Images/CarView/view_rearleftwindow_close.png", "左后窗已打开.", "左后窗已关闭.",
                    "Resources/Voice/rearleftwindow_open.wav", "Resources/Voice/rearleftwindow_close.wav")); //窗（左后）
            dictionary.Add(38,
                new ImageShowReview("Images/CarView/view_rearrightwindow_open.png",
                    "Images/CarView/view_rearrightwindow_close.png", "右后窗已打开.", "右后窗已关闭.",
                    "Resources/Voice/rearrightwindow_open.wav", "Resources/Voice/rearrightwindow_close.wav")); //窗（右后）

            dictionary.Add(39, new ImageShowReview()); //胎压（左前）
            dictionary.Add(40, new ImageShowReview()); //胎压（右前）
            dictionary.Add(41, new ImageShowReview()); //胎压（左后）
            dictionary.Add(42, new ImageShowReview()); //胎压（右后）

            dictionary.Add(43, new ImageShowReview()); //车轮速度（左前）
            dictionary.Add(44, new ImageShowReview()); //车轮速度（右前）
            dictionary.Add(45, new ImageShowReview()); //车轮速度（左后）
            dictionary.Add(46, new ImageShowReview()); //车轮速度（右后）

            dictionary.Add(60, new ImageShowReview()); //剩余油量
            dictionary.Add(61, new ImageShowReview()); //平均油耗
            dictionary.Add(62, new ImageShowReview()); //电池电压
            dictionary.Add(63, new ImageShowReview()); //再续里程
            dictionary.Add(64,
                new ImageShowReview("", "", "发动机故障灯已打开.", "发动机故障灯已关闭.", "Resources/Voice/enginefailurelight_on.wav",
                    "Resources/Voice/enginefailurelight_off.wav")); //发动机故障灯
            dictionary.Add(65,
                new ImageShowReview("", "", "气囊故障灯已打开.", "气囊故障灯已关闭.", "Resources/Voice/airbagfailurelight_on.wav",
                    "Resources/Voice/airbagfailurelight_off.wav")); //气囊故障灯
            dictionary.Add(66, new ImageShowReview()); //发动机转速
            dictionary.Add(67, new ImageShowReview()); //瞬时油耗
            dictionary.Add(68,
                new ImageShowReview("", "", "发动机已启动", "发动机已关闭", "Resources/Voice/enginestate_on.wav",
                    "Resources/Voice/enginestate_off.wav"));
            dictionary.Add(69,
                new ImageShowReview("", "", "机油指示灯已打开", "机油指示灯已关闭", "Resources/Voice/changeoillight_on.wav",
                    "Resources/Voice/changeoillight_off.wav"));

            //危险灯，当左转向灯和右转向灯同时亮时，指示该状态
            dictionary.Add(70,
                new ImageShowReview("Images/CarView/view_redlight.png", "", "危险灯已开启", "危险灯已关闭",
                    "Resources/Voice/hazardlights_on.wav", "Resources/Voice/hazardlights_off.wav"));

            #endregion

            return dictionary;
        }

        /// <summary>
        ///     导出车型库（报告）
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ExportCarLibraryBackgroundWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            ProgressValue = e.ProgressPercentage;
        }

        /// <summary>
        ///     导出车型库（完成）
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ExportCarLibraryBackgroundWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
//被异步取消
            }
            else if (e.Error != null)
            {
//完成带有错误
            }
            else
            {
//完成，处理e.result
                MessageBox.Show("导出完成！");
            }
        }

        /// <summary>
        ///     导出车型库（正在进行）
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ExportCarLibraryBackgroundWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            double _progress = 0;
            ExportCarLibraryBackgroundWorker.ReportProgress((int) _progress);

            ActivateExportLibraryStart(); //导出开始

            //1.找到需要导出的信息项ID
            foreach (var value in AllInfoDetailDictionary.Values)
                if (value.IsSelected)
                    if (value.InfoType == 0)
                    {
//控制项比较特殊，多个
                        if (!ExportItemsIdGroup.Contains(value.InfoItemId))
                        {
                            ExportItemsIdGroup.Add(value.InfoItemId); //Id顺序问题，将EOBD和普通单独处理
                            //由于有的项含有多个子项,所以单独处理
                            switch (value.InfoItemId)
                            {
                                case 27:
                                    ExportItemsIdGroup.Add(28); //
                                    break;
                                case 31:
                                    ExportItemsIdGroup.Add(32); //
                                    ExportItemsIdGroup.Add(33); //
                                    ExportItemsIdGroup.Add(34); //
                                    break;
                                case 35:
                                    ExportItemsIdGroup.Add(36); //
                                    ExportItemsIdGroup.Add(37); //
                                    ExportItemsIdGroup.Add(38); //
                                    break;
                                case 39:
                                    ExportItemsIdGroup.Add(40); //
                                    ExportItemsIdGroup.Add(41); //
                                    ExportItemsIdGroup.Add(42); //
                                    break;
                                case 43:
                                    ExportItemsIdGroup.Add(44); //
                                    ExportItemsIdGroup.Add(45); //
                                    ExportItemsIdGroup.Add(46); //
                                    break;
                                case 82: //点火-熄火（已去掉)
                                    ExportItemsIdGroup.Add(83); //
                                    break;
                                case 92: //尾箱
                                    ExportItemsIdGroup.Add(93); //
                                    break;
                                case 94: //危险灯
                                    ExportItemsIdGroup.Add(95); //
                                    break;
                                case 98: //大灯
                                    ExportItemsIdGroup.Add(99); //
                                    break;
                                case 100: //天窗
                                    ExportItemsIdGroup.Add(101); //
                                    break;
                                case 96: //扬声器控制
                                    ExportItemsIdGroup.Add(97); //
                                    break;
                                case 115: //左前窗
                                    ExportItemsIdGroup.Add(116); //
                                    break;
                                case 117: //右前窗
                                    ExportItemsIdGroup.Add(118); //
                                    break;
                                case 119: //左后窗
                                    ExportItemsIdGroup.Add(120); //
                                    break;
                                case 121: //右后窗
                                    ExportItemsIdGroup.Add(122); //
                                    break;
                                case 123: //全窗
                                    ExportItemsIdGroup.Add(124); //
                                    break;
                                default:
                                    break;
                            }
                        }
                    }
                    else
                    {
                        //特殊添加
                        if (!ExportItemsIdGroup.Contains(151))
                            ExportItemsIdGroup.Add(151);
                        if (!ExportItemsIdGroup.Contains(152))
                            ExportItemsIdGroup.Add(152);
                        switch (value.InfoItemId)
                        {
                            case 154:
                                ExportItemsIdGroup.Add(153);
                                ExportItemsIdGroup.Add(154);
                                ExportItemsIdGroup.Add(155);
                                ExportItemsIdGroup.Add(156);
                                break;
                            case 158:
                                ExportItemsIdGroup.Add(157);
                                ExportItemsIdGroup.Add(158);
                                ExportItemsIdGroup.Add(159);
                                ExportItemsIdGroup.Add(160);
                                break;
                            case 162:
                            case 164:
                            case 166:
                            case 168:
                            case 170:
                            case 172:
                            case 174:
                            case 176:
                            case 178:
                            case 180:
                            case 182:
                                ExportItemsIdGroup.Add(value.InfoItemId - 1);
                                ExportItemsIdGroup.Add(value.InfoItemId);
                                break;
                            default:
                                ExportItemsIdGroup.Add(value.InfoItemId);
                                break;
                        }
                    }

            #region 未优化-旧代码(已注释)

            ////只读项
            //foreach (var item in CurrentOnlyReadInfoDetailReviews)
            //{
            //    if (item.IsSelected)
            //    {
            //        ExportItemsIdGroup.Add(item.InfoItemId);//
            //        //由于有的项含有多个子项,所以单独处理
            //        switch (item.InfoItemId)
            //        {
            //            case 27:
            //                ExportItemsIdGroup.Add(28);//
            //                break;
            //            case 31:
            //                ExportItemsIdGroup.Add(32);//
            //                ExportItemsIdGroup.Add(33);//
            //                ExportItemsIdGroup.Add(34);//
            //                break;
            //            case 35:
            //                ExportItemsIdGroup.Add(36);//
            //                ExportItemsIdGroup.Add(37);//
            //                ExportItemsIdGroup.Add(38);//
            //                break;
            //            case 39:
            //                ExportItemsIdGroup.Add(40);//
            //                ExportItemsIdGroup.Add(41);//
            //                ExportItemsIdGroup.Add(42);//
            //                break;
            //            case 43:
            //                ExportItemsIdGroup.Add(44);//
            //                ExportItemsIdGroup.Add(45);//
            //                ExportItemsIdGroup.Add(46);//
            //                break;
            //            default:
            //                break;
            //        }
            //    }
            //}  

            ////控制项
            //foreach(var item in ControlInfoDictionary)
            //{
            //    if (item.Value.IsSelected)
            //        ExportItemsIdGroup.Add(item.Key);
            //}

            #endregion

            _progress = 10;
            ExportCarLibraryBackgroundWorker.ReportProgress((int) _progress);
            var items = DataManager.GetInstance().ConvertFrom(InfoDetails);
            var count = ExportItemsIdGroup.Count;
            //2.根据当前品牌、型号和信息项ID找出对应的信息集合
            foreach (var id in ExportItemsIdGroup)
            {
                InfoItemReview item;
                var result = items.TryGetValue(id, out item);
                if (!result)
                    throw new Exception("代码有误");
                ActivateExportDoingLibrary(item); //发布导出事件(逐项导出)

                _progress += (double) 80 / count;
                ExportCarLibraryBackgroundWorker.ReportProgress((int) _progress);
                Thread.Sleep(1);
            }
            _progress = 90;
            ExportCarLibraryBackgroundWorker.ReportProgress((int) _progress);

            //3.同时查找Can配置
            //CurrentBrandAndModel
            //4.生成集合
            //
            //5.发布事件--------
            //Completed
            ActivateExportLibraryEnd(CurrentBrandAndModel); //发布导出完成事件

            _progress = 100.0;
            ExportCarLibraryBackgroundWorker.ReportProgress((int) _progress);
            Thread.Sleep(100);
        }

        /// <summary>
        ///只读信息项状态发生改变
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CanCoreCommunicateService_PerformInfoChange(object sender, PerformInfoEventArgs e)
        {
            lock (sync_lockCarStatusBuffer)
            {
                if (CarStatusDictionayBuffer.ContainsKey(e._infoItemId))
                    CarStatusDictionayBuffer[e._infoItemId] = e._result;
                else
                    CarStatusDictionayBuffer.Add(e._infoItemId, e._result);
            }
            // SetDisplayValueByItemId(e.InfoItemId, 1, e.Result);
        }

        /// <summary>
        /// 处理缓存
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MainDispatcherTimer_Tick(object sender, EventArgs e)
        {
            if (CarStatusDictionayBuffer.Count > 0)
            {
                Dictionary<int, object> CarStatusDictionay = null;
                lock (sync_lockCarStatusBuffer)
                {
                    CarStatusDictionay = new Dictionary<int, object>(CarStatusDictionayBuffer);
                    CarStatusDictionayBuffer.Clear();
                }
                if (MessageTipReviews.Count > 0)
                    MessageTipReviews.Last().IsLast = false;

                //CarStatusDictionayBuffer可能被其它线程清空
                foreach (var item in CarStatusDictionay)
                {
                    SetDisplayValueByItemId(item.Key, 1, item.Value);
                }

                if (MessageTipReviews.Count > 0)
                {
                    if (MessageTipReviews.Count > MaxTipMessageCount)
                        MessageTipReviews.RemoveAt(0);
                    var lastOne = MessageTipReviews.Last();
                    lastOne.IsLast = true;
                    //由与滚动速率较快，不宜采用事件触发滚动模式
                    MessageTipListBox.ScrollIntoView(lastOne);
                }
            }
        }

        private void BackgroundWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                //被异步取消
            }
            else if (e.Error != null)
            {
                //完成带有错误
                MessageBox.Show("载入车型库时发生错误，请重新载入！");
            }
            else
            {
                //完成，处理e.result
                if (e.Result != null)
                {
                    var _result = Convert.ToInt32(e.Result);
                    switch (_result)
                    {
                        case -1: //打开设备时发生错误
                            CanExportLibrary = true;
                            RunTip = "载入车型库成功，但打开串口设备时发生异常！";
                            MessageBox.Show("载入车型库成功，但打开串口设备时发生异常！");
                            break;
                        default:
                            break;
                    }
                }
                else
                {
                    CanExportLibrary = true;
                    IsConnectCarSuccessful = true;
                    RunTip = "载入车型库成功且可以正常通讯";
                    MessageBox.Show("载入成功！");
                }
            }
        }

        private void BackgroundWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            ProgressValue = e.ProgressPercentage;
        }

        /// <summary>
        ///     载入并连接过程
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BackgroundWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            //对所有控制项进行使能失效操作
            foreach (var item in ControlInfoDictionary)
            {
                item.Value.IsEnabled = false;
                item.Value.IsChecked = false;
                item.Value.IsSelected = false;
            }

            double _progress = 0;
            var count = DataManager.GetInstance().InfoItems.Count;
            OperateCarLibraryBackgroundWorker.ReportProgress((int) _progress);

            InfoDetails = App.CarDB.GetInfoItemsDetailDictionary(CurrentBrandAndModel.BrandAndModelID);

            foreach (var infoItem in DataManager.GetInstance().InfoItems)
            {
                var key = infoItem.InfoItemID;
                //根据brand,model,item.Key获取具体的详细信息
                InfoAttribute infoAttribute = null;
                var isEnable = false;
                //获取数据，将已使能的实时数据写入到通讯类中
                if (InfoDetails.TryGetValue(key, out infoAttribute))
                {
                    isEnable = infoAttribute.IsEnable;
                    if (isEnable) //如果使能
                        ServiceManager.GetInstance()
                            .CanCoreCommunicateService.AddRealTimeInfo(key, infoAttribute, Convert.ToByte(infoItem.InfoType));
                }
                //将数据转换成界面类
                InfoDetailBase review = null;
                switch (infoItem.MainDataType)
                {
                    case 0: //只读项
                        string item;
                        if (InfoDictionary.TryGetValue(key, out item) || infoItem.IsExtend || infoItem.InfoType == 1)
                        {
                            if (item == default(string))
                                item = infoItem.InfoItemName;

                            review = new InfoDetailReview(key, item, isEnable)
                            {
                                ValueType = infoItem.ValueType,
                                ValueUnit = infoItem.ValueUnit,
                                IsExtend = infoItem.IsExtend,
                                InfoType = infoItem.InfoType
                            };
                        }

                        break;
                    case 1: //控制项
                        ControlInfoDetailReview controlReview = null;
                        if (ControlInfoDictionary.TryGetValue(infoItem.InfoItemID, out controlReview))
                        {
                            //由于有的控制项是切换控制，如果有一个有效，该按钮就有效
                            if (!controlReview.IsEnabled)
                                controlReview.IsEnabled = isEnable;
                        }
                        else
                        {
                            //EOBD控制数据，暂时不生成
                            if (infoItem.InfoType == 0)
                            {
                                controlReview = new ControlInfoDetailReview(infoItem.InfoItemID, infoItem.InfoItemName,
                                    isEnable);
                                controlReview.ClickCommand =
                                    new RelayCommand<bool, bool>(x => { SendControlSignal(controlReview.InfoItemId); },
                                        x => isEnable);
                            }
                        }

                        if (controlReview != null)
                        {
                            controlReview.IsExtend = infoItem.IsExtend;
                            controlReview.InfoType = infoItem.InfoType;
                        }

                        review = controlReview;
                        break;
                    default:
                        break;
                }
                //将转化后的数据进行界面分布
                if (review != null)
                {
                    //未使能暂时不加进去，还未用上
                    if (review.IsEnabled)
                        AllInfoDetailDictionary.Add(infoItem.InfoItemID, review);
                    //不在忽略显示列表内
                    if (!IgnoreDisplayIdList.Contains(infoItem.InfoItemID))
                    {
                        var infoDetailReview = review as InfoDetailReview;
                        if (infoDetailReview != null)
                        {
                            //只读信息
                            var onlyReadReview = infoDetailReview;
                            if (infoItem.InfoType == 0)
                            {
                                if (infoItem.IsExtend)
                                {
                                    if (OnlyReadReviewDisplayMode == InfoReviewDisplayModes.All)
                                    {
                                        Application.Current.Dispatcher.Invoke(
                                            new OpreateCollectionReview(MoreOnlyReadInfoDetailReviews.Add),
                                            onlyReadReview);
                                    }
                                    else
                                    {
                                        if (OnlyReadReviewDisplayMode == InfoReviewDisplayModes.Enabled && isEnable)
                                            Application.Current.Dispatcher.Invoke(
                                                new OpreateCollectionReview(MoreOnlyReadInfoDetailReviews.Add),
                                                onlyReadReview);
                                    }
                                }
                                else
                                {
                                    if (OnlyReadReviewDisplayMode == InfoReviewDisplayModes.All)
                                    {
                                        Application.Current.Dispatcher.Invoke(
                                            new OpreateCollectionReview(CurrentOnlyReadInfoDetailReviews.Add),
                                            onlyReadReview);
                                    }
                                    else
                                    {
                                        if (OnlyReadReviewDisplayMode == InfoReviewDisplayModes.Enabled &&
                                            onlyReadReview.IsEnabled)
                                            Application.Current.Dispatcher.Invoke(
                                                new OpreateCollectionReview(CurrentOnlyReadInfoDetailReviews.Add),
                                                onlyReadReview);
                                    }
                                }
                                AllOnlyReadInfoDetailReviews.Add(onlyReadReview);
                            }
                            else
                            {
                                Application.Current.Dispatcher.Invoke(
                                    new OpreateCollectionReview(EobdOnlyReadInfoDetailReviews.Add), onlyReadReview);
                            }
                        }
                        else if (review is ControlInfoDetailReview)
                        {
                            if (infoItem.IsExtend && infoItem.InfoType == 0)
                                Application.Current.Dispatcher.Invoke(
                                    new Action(
                                        () => { MoreControlInfoDetailReviews.Add((ControlInfoDetailReview) review); }));
                        }
                    }
                }

                //延时用于进度
                Thread.Sleep(1);

                _progress += (double) 80 / count;
                OperateCarLibraryBackgroundWorker.ReportProgress((int) _progress);
            }

            //生成虚拟场景状态文字
            var group1 = from item in CurrentOnlyReadInfoDetailReviews
                where item.CurrentActiveTipArea == InfoDetailReview.ActiveTipArea.VirtualScenesLeftBoxArea
                select item;
            foreach (var item in group1)
                Application.Current.Dispatcher.BeginInvoke(
                    new OpreateCollectionReview(ViewLeftOnlyReadInfoDetailReviews.Add), item);

            var group2 = from item in CurrentOnlyReadInfoDetailReviews
                where item.CurrentActiveTipArea == InfoDetailReview.ActiveTipArea.VirtualScenesRightBoxArea
                select item;
            foreach (var item in group2)
                Application.Current.Dispatcher.BeginInvoke(
                    new OpreateCollectionReview(ViewRightOnlyReadInfoDetailReviews.Add), item);

            _progress = 90;
            OperateCarLibraryBackgroundWorker.ReportProgress((int) _progress);

            var isOk = false;

            #region 打开设备

            ServiceManager.GetInstance().CanCoreCommunicateService.SetCanType(CurrentBrandAndModel.CanType); ; //指示如何处理单双Can
            switch (CurrentBrandAndModel.CanType)
            {
                case 1:
                    var _baudRate = CurrentBrandAndModel.BaudRate;
                    var baudRate = Convert.ToByte(DataManager.GetInstance().GetBaudRates().IndexOf(_baudRate)); //后续更改

                    isOk = ServiceManager.GetInstance().CanCoreCommunicateService.OpenDevice(baudRate, baudRate);
                    break;
                case 2:
                    var _baudRate1 = CurrentBrandAndModel.BaudRate;
                    var _baudRate2 = CurrentBrandAndModel.BaudRate2;
                    var baudRate1 = Convert.ToByte(DataManager.GetInstance().GetBaudRates().IndexOf(_baudRate1)); //后续更改
                    var baudRate2 = Convert.ToByte(DataManager.GetInstance().GetBaudRates().IndexOf(_baudRate2)); //后续更改

                    isOk = ServiceManager.GetInstance().CanCoreCommunicateService.OpenDevice(baudRate1, baudRate2);
                    break;
                default:
                    MessageBox.Show("该车型Can接口类型未定义，无法正常连接！");
                    break;
            }

            #endregion

            if (!isOk)
                e.Result = -1; //指示打开设备发生错误

            _progress = 100;
            OperateCarLibraryBackgroundWorker.ReportProgress((int) _progress);
            Thread.Sleep(100);
        }

        /// <summary>
        /// 对应信息视图(显示项)
        /// </summary>
        /// <returns></returns>
        private Dictionary<int, string> GetDefaultDictionary()
        {
            var dictionary = new Dictionary<int, string>();
            dictionary.Add(1, "点火开关"); //1
            dictionary.Add(2, "Acc");
            //该项已删除（原因：与发动机状态重叠）
            //dictionary.Add(3, "启动");
            dictionary.Add(4, "油门");
            dictionary.Add(5, "脚刹");
            dictionary.Add(6, "手刹");
            dictionary.Add(7, "锁");
            dictionary.Add(8, "空调");
            dictionary.Add(9, "温度");
            dictionary.Add(10, "小灯");
            dictionary.Add(11, "档位");
            dictionary.Add(12, "天窗");
            dictionary.Add(13, "速度");
            dictionary.Add(14, "雨刮");
            dictionary.Add(15, "里程");
            dictionary.Add(16, "水温");
            //Add
            dictionary.Add(17, "大灯");

            dictionary.Add(24, "油箱盖");
            dictionary.Add(25, "引擎盖");
            dictionary.Add(26, "后备箱");
            dictionary.Add(27, "转向灯");
            dictionary.Add(29, "安全带");
            dictionary.Add(30, "方向盘");
            dictionary.Add(31, "门");
            dictionary.Add(35, "窗");
            dictionary.Add(39, "胎压");
            dictionary.Add(43, "车轮速度");
            dictionary.Add(60, "剩余油量");
            dictionary.Add(61, "平均油耗");
            dictionary.Add(62, "电池电压");
            dictionary.Add(63, "再续里程");
            dictionary.Add(64, "发动机故障灯");
            dictionary.Add(65, "气囊故障灯");
            dictionary.Add(66, "发动机转速");
            dictionary.Add(67, "瞬间油耗值");

            //Add
            dictionary.Add(68, "发动机状态");
            dictionary.Add(69, "机油指示灯");
            return dictionary;
        }

        /// <summary>
        /// 构建通过ItemId查找OnlyReadDetailReviews的下标。2016.9.2   增加2项-大灯，发动机状态
        /// </summary>
        /// <returns></returns>
        private Dictionary<int, int> GetOnlyReadDetailReviewsIndex()
        {
            var dictionary = new Dictionary<int, int>();
            dictionary.Add(1, 0);
            dictionary.Add(2, 1);
            //该项已删除（原因：与发动机状态重叠）
            //dictionary.Add(3, 2);
            dictionary.Add(4, 2);
            dictionary.Add(5, 3);
            dictionary.Add(6, 4);
            dictionary.Add(7, 5);
            dictionary.Add(8, 6);
            dictionary.Add(9, 7);
            dictionary.Add(10, 8);
            dictionary.Add(11, 9);
            dictionary.Add(12, 10);
            dictionary.Add(13, 11);
            dictionary.Add(14, 12);
            dictionary.Add(15, 13);
            dictionary.Add(16, 14); //水温
            //Add
            dictionary.Add(17, 15);
            dictionary.Add(24, 16);
            dictionary.Add(25, 17);
            dictionary.Add(26, 18); //后备箱
            dictionary.Add(27, 19); //左转向灯
            dictionary.Add(28, 19); //右转向灯
            dictionary.Add(70, 19); //危险灯
            dictionary.Add(29, 20);
            dictionary.Add(30, 21);
            dictionary.Add(31, 22); //门(左前)
            dictionary.Add(32, 22); //门(右前)
            dictionary.Add(33, 22); //门(左后)
            dictionary.Add(34, 22); //门(右后)
            dictionary.Add(35, 23); //窗（左前）
            dictionary.Add(36, 23); //窗（右前）
            dictionary.Add(37, 23); //窗（左后）
            dictionary.Add(38, 23); //窗（右后）
            dictionary.Add(39, 24); //胎压（左前）
            dictionary.Add(40, 24); //胎压（右前）
            dictionary.Add(41, 24); //胎压（左后）
            dictionary.Add(42, 24); //胎压（右后）
            dictionary.Add(43, 25); //车轮速度（左前）
            dictionary.Add(44, 25); //车轮速度（右前）
            dictionary.Add(45, 25); //车轮速度（左后）
            dictionary.Add(46, 25); //车轮速度（右后）
            dictionary.Add(60, 26);
            dictionary.Add(61, 27);
            dictionary.Add(62, 28);
            dictionary.Add(63, 29);
            dictionary.Add(64, 30);
            dictionary.Add(65, 31);
            dictionary.Add(66, 32);
            dictionary.Add(67, 33);

            //Add
            dictionary.Add(68, 34);
            dictionary.Add(69, 35);

            return dictionary;
        }

        // private object sync_lockSetDisplayValue = new object();
        /// <summary>
        ///     修改指定对象(此处键值跟数据库一一对应)--------
        /// </summary>
        /// <param name="infoItemID"></param>
        /// <param name="state">0-默认值  1-运行时计算值 </param>
        /// <param name="value">附加对象，可以代表算法值，也可以添加四值</param>
        /// <returns></returns>
        private void SetDisplayValueByItemId(int infoItemID, int state = 0, object value = null)
        {
            App.Log("Receive OnlyReadData info Id:" + infoItemID, App.Module.ReceiveOnlyReadInfo);

            if (value == null)
                return; //异常

            //存在于视图显示忽略列表里
            if (IgnoreDisplayIdList.Contains(infoItemID))
            {
                //特殊
                switch (infoItemID)
                {
                    case (int)CanDataBoredom.EobdAnswerId.VinSecond: //VIN码二次应答
                        infoItemID = (int)CanDataBoredom.EobdAnswerId.VinCode; //VIN码
                        break;
                    case (int)CanDataBoredom.EobdAnswerId.FaultSecond: //故障码二次应答
                        infoItemID = (int)CanDataBoredom.EobdAnswerId.FaultCode; //故障码
                        break;
                    default:
                        return; //界面上不需要该Id信息
                }

            }

            //判断是否存在错误
            switch (value.ToString())
            {
                case AlgorithmParse.ParameterParseError:
                    return; //该错误直接返回
                case AlgorithmParse.DeepParseParseError:
                    return; //该错误直接返回
                case "?": //暂时支持
                    break;
                default:
                    break;
            }

            #region 设置结果

            //lock (sync_lockSetDisplayValue)//主线程运行
            {
                var _potion = 0;
                InfoDetailReview review;
                if (InfoIndexDictionary.TryGetValue(infoItemID, out _potion))
                    review = AllOnlyReadInfoDetailReviews[_potion];
                else
                    review = (InfoDetailReview) AllInfoDetailDictionary[infoItemID];
                ImageShowReview showReview;
                //EOBD类型该项为null
                OnlyReadInfoImageAndTipDictionary.TryGetValue(infoItemID, out showReview);

                switch (infoItemID)
                {
                        #region 旧版本硬编码，暂时不管

                    case 1: //点火开关
                        if (!(value is bool))
                            try
                            {
                                value = Convert.ToBoolean(value);
                            }
                            catch (Exception ex)
                            {
                                Debug.WriteLine(ex.Message + "Error Code " + " set error");
                            }
                        if (!(bool) value)
                        {
                            review.Content = "Off";
                            review.CurrentState = Status.Normal;
                        }
                        else
                        {
                            review.Content = "On";
                            review.CurrentState = Status.Active;
                        }
                        showReview.State = (bool) value; //引发提示语改变
                        // //引发控制按钮状态切换
                        //ControlPowerInfoDetailReview.IsChecked = (bool)value;
                        MessageTipReviews.Add(new MessageTipReview(showReview.TipText));
                        if (review.CanPlaySound)
                            PlaySoundHanlder(showReview.TipVoiceUri);
                        break;
                    case 2: //ACC
                        if (!(value is bool))
                            try
                            {
                                value = Convert.ToBoolean(value);
                            }
                            catch (Exception ex)
                            {
                                Debug.WriteLine(ex.Message + "Error Code " + " set error");
                            }
                        if (!(bool) value)
                        {
                            review.Content = "Off";
                            review.CurrentState = Status.Normal;
                        }
                        else
                        {
                            review.Content = "On";
                            review.CurrentState = Status.Active;
                        }
                        showReview.State = (bool) value; //引发提示语改变
                        MessageTipReviews.Add(new MessageTipReview(showReview.TipText));
                        if (review.CanPlaySound)
                            PlaySoundHanlder(showReview.TipVoiceUri);
                        break;

                        #region 该项已删除（原因：与发动机状态重叠）

                        //case 3://启动
                        //    if (!(value is bool))
                        //    {
                        //        try
                        //        {
                        //            value = Convert.ToBoolean(value);
                        //        }
                        //        catch (Exception ex)
                        //        {
                        //            Debug.WriteLine(ex.Message + "Error Code " + " set error");
                        //        }
                        //    }
                        //    if (!(bool)value)
                        //    {
                        //        review.Content = "×";
                        //        review.CurrentState = Status.Normal;
                        //    }
                        //    else
                        //    {
                        //        review.Content = "√";
                        //        review.CurrentState = Status.Active;
                        //    }
                        //    //引发控制按钮状态切换
                        //    ControlPowerInfoDetailReview.IsChecked = (bool)value;
                        //    showReview.State = (bool)value;//引发提示语改变
                        //    this.MessageTipReviews.Add(new MessageTipReview(showReview.TipText));
                        //    if (review.CanPlaySound)
                        //        PlaySoundHanlder(showReview.TipVoiceUri);

                        //    break;

                        #endregion

                    case 4: //油门
                        if (!(value is bool))
                            try
                            {
                                value = Convert.ToBoolean(value);
                            }
                            catch (Exception ex)
                            {
                                Debug.WriteLine(ex.Message + "Error Code " + " set error");
                            }
                        if (!(bool) value)
                        {
                            review.Content = "↑";
                            review.CurrentState = Status.Normal;
                        }
                        else
                        {
                            review.Content = "↓";
                            review.CurrentState = Status.Active;
                        }
                        showReview.State = (bool) value; //引发提示语改变
                        MessageTipReviews.Add(new MessageTipReview(showReview.TipText));
                        if (review.CanPlaySound)
                            PlaySoundHanlder(showReview.TipVoiceUri);
                        break;
                    case 5: //脚刹
                        if (!(value is bool))
                            try
                            {
                                value = Convert.ToBoolean(value);
                            }
                            catch (Exception ex)
                            {
                                Debug.WriteLine(ex.Message + "Error Code " + " set error");
                            }
                        if (!(bool) value)
                        {
                            review.Content = "↓";
                            review.CurrentState = Status.Normal;
                        }
                        else
                        {
                            review.Content = "↑";
                            review.CurrentState = Status.Active;
                        }
                        showReview.State = (bool) value; //引发提示语改变
                        MessageTipReviews.Add(new MessageTipReview(showReview.TipText));
                        if (review.CanPlaySound)
                            PlaySoundHanlder(showReview.TipVoiceUri, 2); //
                        break;
                    case 6: //手刹
                        if (!(value is bool))
                            try
                            {
                                value = Convert.ToBoolean(value);
                            }
                            catch (Exception ex)
                            {
                                Debug.WriteLine(ex.Message + "Error Code " + " set error");
                            }
                        if (!(bool) value)
                        {
                            review.Content = "×";
                            review.CurrentState = Status.Normal;
                        }
                        else
                        {
                            review.Content = "√";
                            review.CurrentState = Status.Active;
                        }
                        showReview.State = (bool) value; //引发提示语改变
                        MessageTipReviews.Add(new MessageTipReview(showReview.TipText));
                        if (review.CanPlaySound)
                            PlaySoundHanlder(showReview.TipVoiceUri);
                        break;
                    case 7: //锁
                        if (!(value is bool))
                            try
                            {
                                value = Convert.ToBoolean(value);
                            }
                            catch (Exception ex)
                            {
                                Debug.WriteLine(ex.Message + "Error Code " + " set error");
                            }
                        if (!(bool) value)
                        {
                            review.Content = "Off";
                            review.CurrentState = Status.Active;
                        }
                        else
                        {
                            review.Content = "On";
                            review.CurrentState = Status.Normal;
                        }
                        showReview.State = (bool) value; //引发提示语改变
                        MessageTipReviews.Add(new MessageTipReview(showReview.TipText));
                        if (review.CanPlaySound)
                            PlaySoundHanlder(showReview.TipVoiceUri, 3);
                        break;
                    case 8: //空调
                        if (!(value is bool))
                            try
                            {
                                value = Convert.ToBoolean(value);
                            }
                            catch (Exception ex)
                            {
                                Debug.WriteLine(ex.Message + "Error Code " + " set error");
                            }
                        if (!(bool) value)
                        {
                            review.Content = "Off";
                            review.CurrentState = Status.Normal;
                        }
                        else
                        {
                            review.Content = "On";
                            review.CurrentState = Status.Active;
                        }
                        showReview.State = (bool) value; //引发提示语改变
                        MessageTipReviews.Add(new MessageTipReview(showReview.TipText));
                        if (review.CanPlaySound)
                            PlaySoundHanlder(showReview.TipVoiceUri);
                        break;
                    case 9: //温度
                        if (state == 0)
                        {
                            review.Content = "0 ℃";
                        }
                        else
                        {
                            review.Content = Convert.ToString(value) + " ℃";
                            review.CurrentState = Status.Active;
                        }
                        break;
                    case 10: //小灯
                        if (!(value is bool))
                            try
                            {
                                value = Convert.ToBoolean(value);
                            }
                            catch (Exception ex)
                            {
                                Debug.WriteLine(ex.Message + "Error Code " + " set error");
                            }
                        if (!(bool) value)
                        {
                            review.Content = "Off";
                            review.CurrentState = Status.Normal;
                        }
                        else
                        {
                            review.Content = "On";
                            review.CurrentState = Status.Active;
                        }
                        showReview.State = (bool) value; //引发提示语改变
                        MessageTipReviews.Add(new MessageTipReview(showReview.TipText));
                        if (review.CanPlaySound)
                            PlaySoundHanlder(showReview.TipVoiceUri);
                        break;
                    case 11: //此处需区分 //档位
                        if (state == 0)
                        {
                            review.Content = "P";
                        }
                        else
                        {
                            review.Content = value.ToString();
                            review.CurrentState = Status.Active;
                            //int _value = 0;
                            //if (int.TryParse(Convert.ToString(value), out _value))
                            //{
                            //    switch (_value) {
                            //        case 0:
                            //            review.Content = "P";//后续改进
                            //            break;
                            //        case 1:
                            //            review.Content = "N";//后续改进
                            //            break;
                            //        case 2:
                            //            review.Content = "S";//后续改进
                            //            break;
                            //        case 3:
                            //            review.Content = "D";//后续改进
                            //            break;
                            //        default:
                            //            review.Content = "?";//后续改进
                            //            break;
                            //    }

                            //}
                        }


                        break;
                    case 12: //天窗
                        if (!(value is bool))
                            try
                            {
                                value = Convert.ToBoolean(value);
                            }
                            catch (Exception ex)
                            {
                                Debug.WriteLine(ex.Message + "Error Code " + " set error");
                            }
                        if (!(bool) value)
                        {
                            review.Content = "Off";
                            review.CurrentState = Status.Normal;
                        }
                        else
                        {
                            review.Content = "On";
                            review.CurrentState = Status.Active;
                        }
                        //引发控制按钮状态切换(特殊)
                        ControlSkyLightInfoDetailReview.IsChecked = (bool) value;
                        showReview.State = (bool) value; //引发提示语改变
                        MessageTipReviews.Add(new MessageTipReview(showReview.TipText));
                        if (review.CanPlaySound)
                            PlaySoundHanlder(showReview.TipVoiceUri);
                        break;
                    case 13: //速度
                        if (state == 0)
                        {
                            review.Content = "00 km/h";
                        }
                        else
                        {
                            review.Content = Convert.ToString(value) + " km/h";
                            review.CurrentState = Status.Active;
                        }

                        break;
                    case 14: //雨刮
                        if (!(value is bool))
                            try
                            {
                                value = Convert.ToBoolean(value);
                            }
                            catch (Exception ex)
                            {
                                Debug.WriteLine(ex.Message + "Error Code " + " set error");
                            }
                        if (!(bool) value)
                        {
                            review.Content = "关";
                            review.CurrentState = Status.Normal;
                        }
                        else
                        {
                            review.Content = "开";
                            review.CurrentState = Status.Active;
                        }
                        showReview.State = (bool) value; //引发提示语改变
                        MessageTipReviews.Add(new MessageTipReview(showReview.TipText));
                        //分等级
                        //if(value is bool)
                        //{
                        //    if (!(bool)value)
                        //        review.Content = "0";
                        //    else
                        //    {
                        //        review.Content = "1";
                        //        review.CurrentState = Status.Active;
                        //    }

                        //}//正常状态
                        //else
                        //{
                        //    if (state == 0)
                        //        review.Content = "0";
                        //    else
                        //    {
                        //        review.Content = Convert.ToString(value);
                        //        review.CurrentState = Status.Active;
                        //    }   
                        //}


                        break;
                    case 15: //里程
                        if (state == 0)
                        {
                            review.Content = "0 km";
                        }
                        else
                        {
                            review.Content = Convert.ToString(value) + " km";
                            review.CurrentState = Status.Active;
                        }
                        break;
                    case 16: //水温
                        if (state == 0)
                        {
                            review.Content = "0 ℃";
                        }
                        else
                        {
                            review.Content = Convert.ToString(value) + " ℃";
                            review.CurrentState = Status.Active;
                        }

                        break;
                    case 17: //大灯
                        if (!(value is bool))
                            try
                            {
                                value = Convert.ToBoolean(value);
                            }
                            catch (Exception ex)
                            {
                                Debug.WriteLine(ex.Message + "Error Code " + " set error");
                            }
                        if (!(bool) value)
                        {
                            review.Content = "Off";
                            review.CurrentState = Status.Normal;
                        }
                        else
                        {
                            review.Content = "On";
                            review.CurrentState = Status.Active;
                        }
                        //引发控制按钮状态切换
                        ControlHeadlightInfoDetailReview.IsChecked = (bool) value;
                        showReview.State = (bool) value; //引发提示语改变
                        MessageTipReviews.Add(new MessageTipReview(showReview.TipText));
                        if (review.CanPlaySound)
                            PlaySoundHanlder(showReview.TipVoiceUri);
                        break;
                    case 24: //油箱盖
                        if (!(value is bool))
                            try
                            {
                                value = Convert.ToBoolean(value);
                            }
                            catch (Exception ex)
                            {
                                Debug.WriteLine(ex.Message + "Error Code " + " set error");
                            }
                        if (!(bool) value)
                        {
                            review.Content = "Off";
                            review.CurrentState = Status.Normal;
                        }
                        else
                        {
                            review.Content = "On";
                            review.CurrentState = Status.Active;
                        }
                        showReview.State = (bool) value; //引发提示语改变
                        MessageTipReviews.Add(new MessageTipReview(showReview.TipText));
                        if (review.CanPlaySound)
                            PlaySoundHanlder(showReview.TipVoiceUri);
                        break;
                    case 25: //引擎盖
                        if (!(value is bool))
                            try
                            {
                                value = Convert.ToBoolean(value);
                            }
                            catch (Exception ex)
                            {
                                Debug.WriteLine(ex.Message + "Error Code " + " set error");
                            }
                        if (!(bool) value)
                        {
                            review.Content = "Off";
                            review.CurrentState = Status.Normal;
                        }
                        else
                        {
                            review.Content = "On";
                            review.CurrentState = Status.Active;
                        }
                        showReview.State = (bool) value; //引发提示语改变
                        MessageTipReviews.Add(new MessageTipReview(showReview.TipText));
                        if (review.CanPlaySound)
                            PlaySoundHanlder(showReview.TipVoiceUri);
                        break;
                    case 26: //后备箱
                        if (!(value is bool))
                            try
                            {
                                value = Convert.ToBoolean(value);
                            }
                            catch (Exception ex)
                            {
                                Debug.WriteLine(ex.Message + "Error Code " + " set error");
                            }
                        if (!(bool) value)
                        {
                            review.Content = "Off";
                            review.CurrentState = Status.Normal;
                        }
                        else
                        {
                            review.Content = "On";
                            review.CurrentState = Status.Active;
                        }
                        //引发控制按钮状态切换
                        ControlTrunkInfoDetailReview.IsChecked = (bool) value;
                        showReview.State = (bool) value; //引发提示语改变
                        MessageTipReviews.Add(new MessageTipReview(showReview.TipText));
                        if (review.CanPlaySound)
                            PlaySoundHanlder(showReview.TipVoiceUri, 1);
                        break;
                    case 27: //左转向灯
                        if (!(value is bool))
                            try
                            {
                                value = Convert.ToBoolean(value);
                            }
                            catch (Exception ex)
                            {
                                Debug.WriteLine(ex.Message + "Error Code " + " set error");
                            }
                        if (!(bool) value)
                        {
                            review.LeftBottomValue = "左Off";
                            if (review.CurrentState == Status.ExtraLeft)
                                review.CurrentState = Status.Normal;
                            if (review.CurrentState == Status.Active)
                            {
                                review.CurrentState = Status.ExtraRight;
                                OnlyReadInfoImageAndTipDictionary[70].State = false;
                                MessageTipReviews.Add(new MessageTipReview(OnlyReadInfoImageAndTipDictionary[70].TipText));
                                if (review.CanPlaySound)
                                    PlaySoundHanlder(OnlyReadInfoImageAndTipDictionary[70].TipVoiceUri, 1);
                            }
                        }
                        else
                        {
                            review.LeftBottomValue = "左On";
                            if (review.CurrentState == Status.ExtraRight) //如果此时右转向灯已亮起
                            {
                                review.CurrentState = Status.Active;
                                OnlyReadInfoImageAndTipDictionary[70].State = true;
                                MessageTipReviews.Add(new MessageTipReview(OnlyReadInfoImageAndTipDictionary[70].TipText));
                                if (review.CanPlaySound)
                                    PlaySoundHanlder(OnlyReadInfoImageAndTipDictionary[70].TipVoiceUri, 1);
                            }
                            else
                            {
                                review.CurrentState = Status.ExtraLeft;
                            }
                        }
                        review.Content = "";


                        showReview.State = (bool) value;

                        MessageTipReviews.Add(new MessageTipReview(showReview.TipText));
                        if (review.CanPlaySound)
                            PlaySoundHanlder(showReview.TipVoiceUri);

                        //移入定时模块

                        break;
                    case 28: //右转向灯
                        if (!(value is bool))
                            try
                            {
                                value = Convert.ToBoolean(value);
                            }
                            catch (Exception ex)
                            {
                                Debug.WriteLine(ex.Message + "Error Code " + " set error");
                            }
                        if (!(bool) value)
                        {
                            review.RightBottomValue = "右Off";
                            if (review.CurrentState == Status.ExtraRight)
                                review.CurrentState = Status.Normal;
                            if (review.CurrentState == Status.Active)
                            {
                                review.CurrentState = Status.ExtraLeft;
                                OnlyReadInfoImageAndTipDictionary[70].State = false;
                                MessageTipReviews.Add(new MessageTipReview(OnlyReadInfoImageAndTipDictionary[70].TipText));
                                if (review.CanPlaySound)
                                    PlaySoundHanlder(OnlyReadInfoImageAndTipDictionary[70].TipVoiceUri, 1);
                            }
                        }
                        else
                        {
                            review.RightBottomValue = "右On";
                            if (review.CurrentState == Status.ExtraLeft) //如果此时左转向灯已亮起
                            {
                                review.CurrentState = Status.Active;
                                OnlyReadInfoImageAndTipDictionary[70].State = true;
                                MessageTipReviews.Add(new MessageTipReview(OnlyReadInfoImageAndTipDictionary[70].TipText));
                                if (review.CanPlaySound)
                                    PlaySoundHanlder(OnlyReadInfoImageAndTipDictionary[70].TipVoiceUri, 1);
                            }
                            else
                            {
                                review.CurrentState = Status.ExtraRight;
                            }
                        }

                        review.Content = "";


                        showReview.State = (bool) value;
                        MessageTipReviews.Add(new MessageTipReview(showReview.TipText));
                        if (review.CanPlaySound)
                            PlaySoundHanlder(showReview.TipVoiceUri);
                        ////特殊操作
                        //if (OnlyReadInfoImageAndTipDictionary[70].State == true)
                        //{
                        //    OnlyReadInfoImageAndTipDictionary[70].State = false; //特殊
                        //    this.MessageTipReviews.Add(new MessageTipReview(OnlyReadInfoImageAndTipDictionary[70].TipText));
                        //    if (review.CanPlaySound)
                        //    {
                        //        PlaySoundHanlder(OnlyReadInfoImageAndTipDictionary[70].TipVoiceUri, 1);
                        //    }

                        //    //引发控制按钮状态切换(特殊)
                        //    ControlHazardLightsInfoDetailReview.IsChecked = OnlyReadInfoImageAndTipDictionary[70].State;
                        //    isHazardLights = true;
                        //}


                        break;
                    case 70: //危险灯
                        if (!(value is bool))
                            try
                            {
                                value = Convert.ToBoolean(value);
                            }
                            catch (Exception ex)
                            {
                                Debug.WriteLine(ex.Message + "Error Code " + " set error");
                            }
                        //review.LeftBottomValue = "";
                        //review.RightBottomValue = "";
                        if (!(bool) value)
                        {
                            //review.Content = "危险灯关闭";
                        }
                        //
                        showReview.State = (bool) value;
                        MessageTipReviews.Add(new MessageTipReview(showReview.TipText));
                        if (review.CanPlaySound)
                            PlaySoundHanlder(OnlyReadInfoImageAndTipDictionary[70].TipVoiceUri, 1);
                        //引发控制按钮状态切换(特殊)
                        ControlHazardLightsInfoDetailReview.IsChecked = showReview.State;
                        break;
                    case 29: //安全带（主）
                        if (!(value is bool))
                            try
                            {
                                value = Convert.ToBoolean(value);
                            }
                            catch (Exception ex)
                            {
                                Debug.WriteLine(ex.Message + "Error Code " + " set error");
                            }
                        if (!(bool) value)
                        {
                            review.Content = "×";
                            review.CurrentState = Status.Normal;
                        }
                        else
                        {
                            review.Content = "√";
                            review.CurrentState = Status.Active;
                        }
                        showReview.State = (bool) value; //引发提示语改变
                        MessageTipReviews.Add(new MessageTipReview(showReview.TipText));
                        if (review.CanPlaySound)
                            PlaySoundHanlder(showReview.TipVoiceUri, 1);
                        break;
                    case 30: //方向盘-可能传进来"?"
                        if (state == 0)
                        {
                            review.Content = "中";
                        }
                        else
                        {
                            double _value = 0;
                            if (double.TryParse(value.ToString(), out _value))
                                if (_value < 0)
                                {
                                    review.Content = "左" + (0 - (int) _value) + "度";
                                }
                                else
                                {
                                    if (_value == 0)
                                        review.Content = "中";
                                    else
                                        review.Content = "右" + (int) _value + "度";
                                }
                            else
                                review.Content = value.ToString(); //"?"
                            review.CurrentState = Status.Active;
                        }

                        break;
                    case 31: //门（左前）
                        if (state == 0)
                        {
                            review.LeftTopValue = "Off";
                            review.Content = "";
                        }
                        else
                        {
                            if (!(value is bool))
                                try
                                {
                                    value = Convert.ToBoolean(value);
                                }
                                catch (Exception ex)
                                {
                                    Debug.WriteLine(ex.Message + "Error Code " + " set error");
                                }
                            review.IsExtraFrontLeftActive = (bool) value; //额外

                            if (!(bool) value)
                                review.LeftTopValue = "Off";
                            else
                                review.LeftTopValue = "On";
                            review.Content = "";
                        }

                        if (review.IsExtraActive)
                            review.CurrentState = Status.Active;
                        else
                            review.CurrentState = Status.Normal;

                        showReview.State = (bool) value; //引发提示语改变
                        MessageTipReviews.Add(new MessageTipReview(showReview.TipText));
                        if (review.CanPlaySound)
                            PlaySoundHanlder(showReview.TipVoiceUri, 2);
                        break;
                    case 32: //门（右前）
                        if (state == 0)
                        {
                            review.RightTopValue = "Off";
                            review.Content = "";
                        }
                        else
                        {
                            if (!(value is bool))
                                try
                                {
                                    value = Convert.ToBoolean(value);
                                }
                                catch (Exception ex)
                                {
                                    Debug.WriteLine(ex.Message + "Error Code " + " set error");
                                }
                            review.IsExtraFrontRightActive = (bool) value; //额外
                            if (!(bool) value)
                                review.RightTopValue = "Off";
                            else
                                review.RightTopValue = "On";
                            review.Content = "";
                        }
                        if (review.IsExtraActive)
                            review.CurrentState = Status.Active;
                        else
                            review.CurrentState = Status.Normal;

                        showReview.State = (bool) value; //引发提示语改变
                        MessageTipReviews.Add(new MessageTipReview(showReview.TipText));
                        if (review.CanPlaySound)
                            PlaySoundHanlder(showReview.TipVoiceUri, 2);
                        break;
                    case 33: //门（左后）
                        if (state == 0)
                        {
                            review.LeftBottomValue = "Off";
                            review.Content = "";
                        }
                        else
                        {
                            if (!(value is bool))
                                try
                                {
                                    value = Convert.ToBoolean(value);
                                }
                                catch (Exception ex)
                                {
                                    Debug.WriteLine(ex.Message + "Error Code " + " set error");
                                }
                            review.IsExtraRearLeftActive = (bool) value; //额外
                            if (!(bool) value)
                                review.LeftBottomValue = "Off";
                            else
                                review.LeftBottomValue = "On";
                            review.Content = "";
                        }
                        if (review.IsExtraActive)
                            review.CurrentState = Status.Active;
                        else
                            review.CurrentState = Status.Normal;

                        showReview.State = (bool) value; //引发提示语改变
                        MessageTipReviews.Add(new MessageTipReview(showReview.TipText));
                        if (review.CanPlaySound)
                            PlaySoundHanlder(showReview.TipVoiceUri, 2);
                        break;
                    case 34: //门（右后）
                        if (state == 0)
                        {
                            review.RightBottomValue = "Off";
                            review.Content = "";
                        }
                        else
                        {
                            if (!(value is bool))
                                try
                                {
                                    value = Convert.ToBoolean(value);
                                }
                                catch (Exception ex)
                                {
                                    Debug.WriteLine(ex.Message + "Error Code " + " set error");
                                }
                            review.IsExtraRearRightActive = (bool) value; //额外

                            if (!(bool) value)
                                review.RightBottomValue = "Off";
                            else
                                review.RightBottomValue = "On";
                            review.Content = "";
                        }
                        if (review.IsExtraActive)
                            review.CurrentState = Status.Active;
                        else
                            review.CurrentState = Status.Normal;

                        showReview.State = (bool) value; //引发提示语改变
                        MessageTipReviews.Add(new MessageTipReview(showReview.TipText));
                        if (review.CanPlaySound)
                            PlaySoundHanlder(showReview.TipVoiceUri, 2);

                        break;
                    case 35: //窗（左前）
                        if (state == 0)
                        {
                            review.LeftTopValue = "Off";
                            review.Content = "";
                        }
                        else
                        {
                            if (!(value is bool))
                                try
                                {
                                    value = Convert.ToBoolean(value);
                                }
                                catch (Exception ex)
                                {
                                    Debug.WriteLine(ex.Message + "Error Code " + " set error");
                                }

                            review.IsExtraFrontLeftActive = (bool) value; //额外

                            if (!(bool) value)
                                review.LeftTopValue = "Off";
                            else
                                review.LeftTopValue = "On";
                            review.Content = "";
                        }
                        if (review.IsExtraActive)
                            review.CurrentState = Status.Active;
                        else
                            review.CurrentState = Status.Normal;

                        showReview.State = (bool) value; //引发提示语改变
                        MessageTipReviews.Add(new MessageTipReview(showReview.TipText));
                        if (review.CanPlaySound)
                            PlaySoundHanlder(showReview.TipVoiceUri, 2);
                        break;
                    case 36: //窗（右前）
                        if (state == 0)
                        {
                            review.RightTopValue = "Off";
                            review.Content = "";
                        }
                        else
                        {
                            if (!(value is bool))
                                try
                                {
                                    value = Convert.ToBoolean(value);
                                }
                                catch (Exception ex)
                                {
                                    Debug.WriteLine(ex.Message + "Error Code " + " set error");
                                }
                            review.IsExtraFrontRightActive = (bool) value; //额外

                            if (!(bool) value)
                                review.RightTopValue = "Off";
                            else
                                review.RightTopValue = "On";
                            review.Content = "";
                        }
                        if (review.IsExtraActive)
                            review.CurrentState = Status.Active;
                        else
                            review.CurrentState = Status.Normal;
                        showReview.State = (bool) value; //引发提示语改变
                        MessageTipReviews.Add(new MessageTipReview(showReview.TipText));
                        if (review.CanPlaySound)
                            PlaySoundHanlder(showReview.TipVoiceUri, 2);
                        break;
                    case 37: //窗（左后）
                        if (state == 0)
                        {
                            review.LeftBottomValue = "Off";
                            review.Content = "";
                        }
                        else
                        {
                            if (!(value is bool))
                                try
                                {
                                    value = Convert.ToBoolean(value);
                                }
                                catch (Exception ex)
                                {
                                    Debug.WriteLine(ex.Message + "Error Code " + " set error");
                                }
                            review.IsExtraRearLeftActive = (bool) value; //额外
                            if (!(bool) value)
                                review.LeftBottomValue = "Off";
                            else
                                review.LeftBottomValue = "On";
                            review.Content = "";
                        }
                        if (review.IsExtraActive)
                            review.CurrentState = Status.Active;
                        else
                            review.CurrentState = Status.Normal;
                        showReview.State = (bool) value; //引发提示语改变
                        MessageTipReviews.Add(new MessageTipReview(showReview.TipText));
                        if (review.CanPlaySound)
                            PlaySoundHanlder(showReview.TipVoiceUri, 2);
                        break;
                    case 38: //窗（右后）
                        if (state == 0)
                        {
                            //  review.Content = "";
                            review.RightBottomValue = "Off";
                        }
                        else
                        {
                            if (!(value is bool))
                                try
                                {
                                    value = Convert.ToBoolean(value);
                                }
                                catch (Exception ex)
                                {
                                    Debug.WriteLine(ex.Message + "Error Code " + " set error");
                                }
                            review.IsExtraRearRightActive = (bool) value; //额外
                            if (!(bool) value)
                                review.RightBottomValue = "Off";
                            else
                                review.RightBottomValue = "On";
                        }
                        review.Content = "";
                        if (review.IsExtraActive)
                            review.CurrentState = Status.Active;
                        else
                            review.CurrentState = Status.Normal;
                        showReview.State = (bool) value; //引发提示语改变
                        MessageTipReviews.Add(new MessageTipReview(showReview.TipText));
                        if (review.CanPlaySound)
                            PlaySoundHanlder(showReview.TipVoiceUri, 2);
                        break;
                    case 39: //胎压（左前）
                        if (state == 0)
                        {
                            review.LeftTopValue = "0";
                            review.Content = " bar";
                        }
                        else
                        {
                            review.LeftTopValue = Convert.ToString(value);
                            review.Content = " bar";
                            review.CurrentState = Status.Active;
                        }
                        break;
                    case 40: //胎压（右前）
                        if (state == 0)
                        {
                            review.RightTopValue = "0";
                            review.Content = " bar";
                        }
                        else
                        {
                            review.RightTopValue = Convert.ToString(value);
                            review.Content = " bar";
                            review.CurrentState = Status.Active;
                        }
                        break;
                    case 41: //胎压（左后）
                        if (state == 0)
                        {
                            review.LeftBottomValue = "0";
                            review.Content = " bar";
                        }
                        else
                        {
                            review.LeftBottomValue = Convert.ToString(value);
                            review.Content = " bar";
                            review.CurrentState = Status.Active;
                        }
                        break;
                    case 42: //胎压（右后）
                        if (state == 0)
                        {
                            review.RightBottomValue = "0";
                            review.Content = " bar";
                        }
                        else
                        {
                            review.RightBottomValue = Convert.ToString(value);
                            review.Content = " bar";
                            review.CurrentState = Status.Active;
                        }
                        break;
                    case 43: //车轮速度（左前）
                        if (state == 0)
                        {
                            review.LeftTopValue = "0";
                            review.Content = " km/h";
                        }
                        else
                        {
                            review.LeftTopValue = Convert.ToString(value);
                            review.Content = " km/h";
                            review.CurrentState = Status.Active;
                        }

                        break;
                    case 44: //车轮速度（右前）
                        if (state == 0)
                        {
                            review.RightTopValue = "0";
                            review.Content = " km/h";
                        }
                        else
                        {
                            review.RightTopValue = Convert.ToString(value);
                            review.Content = " km/h";
                            review.CurrentState = Status.Active;
                        }

                        break;
                    case 45: //车轮速度（左后）
                        if (state == 0)
                        {
                            review.LeftBottomValue = "0";
                            review.Content = " km/h";
                        }
                        else
                        {
                            review.LeftBottomValue = Convert.ToString(value);
                            review.Content = " km/h";
                            review.CurrentState = Status.Active;
                        }
                        break;
                    case 46: //车轮速度（右后）
                        if (state == 0)
                        {
                            review.RightBottomValue = "0";
                            review.Content = " km/h";
                        }
                        else
                        {
                            review.RightBottomValue = Convert.ToString(value);
                            review.Content = " km/h";
                            review.CurrentState = Status.Active;
                        }
                        break;
                    case 60: //剩余油量
                        if (state == 0)
                        {
                            review.Content = "0 L";
                        }
                        else
                        {
                            review.Content = Convert.ToString(value) + " L";
                            review.CurrentState = Status.Active;
                        }

                        break;
                    case 61: //平均油耗
                        if (state == 0)
                        {
                            review.Content = "0 L/1000km";
                        }
                        else
                        {
                            review.Content = Convert.ToString(value) + " L/1000km";
                            review.CurrentState = Status.Active;
                        }

                        break;
                    case 62: //电池电压
                        if (state == 0)
                        {
                            review.Content = "0 V";
                        }
                        else
                        {
                            review.Content = Convert.ToString(value) + " V";
                            review.CurrentState = Status.Active;
                        }

                        break;
                    case 63: //再续里程
                        if (state == 0)
                        {
                            review.Content = "0 Km";
                        }
                        else
                        {
                            review.Content = Convert.ToString(value) + " Km";
                            review.CurrentState = Status.Active;
                        }

                        break;
                    case 64: //发动机故障灯
                        if (!(value is bool))
                            try
                            {
                                value = Convert.ToBoolean(value);
                            }
                            catch (Exception ex)
                            {
                                Debug.WriteLine(ex.Message + "Error Code " + " set error");
                            }
                        if (!(bool) value)
                        {
                            review.Content = "Off";
                            review.CurrentState = Status.Normal;
                        }
                        else
                        {
                            review.Content = "On";
                            review.CurrentState = Status.Defective;
                        }

                        showReview.State = (bool) value; //引发提示语改变
                        MessageTipReviews.Add(new MessageTipReview(showReview.TipText));
                        if (review.CanPlaySound)
                            PlaySoundHanlder(showReview.TipVoiceUri, 4);
                        break;
                    case 65: //气囊故障灯
                        if (!(value is bool))
                            try
                            {
                                value = Convert.ToBoolean(value);
                            }
                            catch (Exception ex)
                            {
                                Debug.WriteLine(ex.Message + "Error Code " + " set error");
                            }
                        if (!(bool) value)
                        {
                            review.Content = "Off";
                            review.CurrentState = Status.Normal;
                        }
                        else
                        {
                            review.Content = "On";
                            review.CurrentState = Status.Defective;
                        }
                        showReview.State = (bool) value; //引发提示语改变
                        MessageTipReviews.Add(new MessageTipReview(showReview.TipText));
                        if (review.CanPlaySound)
                            PlaySoundHanlder(showReview.TipVoiceUri, 4);
                        break;
                    case 66: //发动机转速
                        if (state == 0)
                        {
                            review.Content = "0 rpm";
                        }
                        else
                        {
                            review.Content = Convert.ToString(value) + " rpm";
                            review.CurrentState = Status.Active;
                        }

                        break;
                    case 67: //瞬时油耗
                        if (state == 0)
                        {
                            review.Content = "0 L/1000km";
                        }
                        else
                        {
                            review.Content = Convert.ToString(value) + " L/1000km";
                            review.CurrentState = Status.Active;
                        }

                        break;
                    case 68: //发动机状态
                        if (!(value is bool))
                            try
                            {
                                value = Convert.ToBoolean(value);
                            }
                            catch (Exception ex)
                            {
                                Debug.WriteLine(ex.Message + "Error Code " + " set error");
                            }
                        if (!(bool) value)
                        {
                            review.Content = "Off";
                            review.CurrentState = Status.Normal;
                        }
                        else
                        {
                            review.Content = "On";
                            review.CurrentState = Status.Active;
                        }
                        showReview.State = (bool) value; //引发提示语改变
                        MessageTipReviews.Add(new MessageTipReview(showReview.TipText));
                        if (review.CanPlaySound)
                            PlaySoundHanlder(showReview.TipVoiceUri, 1);
                        break;
                    case 69: //机油指示灯
                        if (!(value is bool))
                            try
                            {
                                value = Convert.ToBoolean(value);
                            }
                            catch (Exception ex)
                            {
                                Debug.WriteLine(ex.Message + "Error Code " + " set error");
                            }
                        if (!(bool) value)
                        {
                            review.Content = "Off";
                            review.CurrentState = Status.Normal;
                        }
                        else
                        {
                            review.Content = "On";
                            review.CurrentState = Status.Defective;
                        }
                        showReview.State = (bool) value; //引发提示语改变
                        MessageTipReviews.Add(new MessageTipReview(showReview.TipText));
                        if (review.CanPlaySound)
                            PlaySoundHanlder(showReview.TipVoiceUri, 1);
                        break;
                    case 71: //锁（原车钥匙）
                        if (!(value is bool))
                            try
                            {
                                value = Convert.ToBoolean(value);
                            }
                            catch (Exception ex)
                            {
                                Debug.WriteLine(ex.Message + "Error Code " + " set error");
                            }

                        //if (!(bool)value)
                        //{
                        //    review.Content = "Off";
                        //    review.CurrentState = Status.Normal;
                        //}
                        //else
                        //{
                        //    review.Content = "On";
                        //    review.CurrentState = Status.Active;
                        //}
                        //引发控制按钮状态切换
                        showReview.State = (bool) value; //引发提示语改变
                        MessageTipReviews.Add(new MessageTipReview(showReview.TipText));
                        //if (review.CanPlaySound)
                        // PlaySoundHanlder(showReview.TipVoiceUri);
                        break;

                        #endregion

                    default:
                        if (review.ValueType == 0)
                        {
                            //0/1类型
                            if (!(value is bool))
                                try
                                {
                                    value = Convert.ToBoolean(value);
                                }
                                catch (Exception ex)
                                {
                                    Debug.WriteLine(ex.Message + "Error Code " + " set error");
                                }
                            if (!(bool) value)
                            {
                                review.Content = "0";
                                review.CurrentState = Status.Normal;
                            }
                            else
                            {
                                review.Content = "1";
                                review.CurrentState = Status.Active;
                            }
                            if (showReview != null)
                            {
                                showReview.State = (bool) value; //引发提示语改变
                                //引发控制按钮状态切换
                                if (!string.IsNullOrWhiteSpace(showReview.TipText))
                                    MessageTipReviews.Add(new MessageTipReview(showReview.TipText));
                                //if (review.CanPlaySound)
                                //    PlaySoundHanlder(showReview.TipVoiceUri);
                            }
                        }
                        else
                        {
                            //数值类型
                            if (value is double)
                                review.Content = ((double) value).ToString(".##") + review.ValueUnit;
                            else
                                review.Content = string.Format("{0} {1}", value?.ToString() ?? "?", review.ValueUnit);
                        }
                        break;
                }

                #endregion
            }
        }

        private void PlayerLoadCompleted(object sender, AsyncCompletedEventArgs e)
        {
            //if(e.Error!=null)
            //    Debug.WriteLine(e.Error.Message + "Error Code : " + "C123");
        }

        private void PlayerStreamChanged(object sender, EventArgs e)
        {
            //Debug.WriteLine("Player stream is changed");
        }

        private void PlaySoundTimer_Elapsed(object sender, ElapsedEventArgs e)
        {
            string path;
            if (Sounds.Count != 0)
            {
                var maxValue = Sounds.Values.Max();
                if (maxValue != 0)
                {
                    var item = Sounds.Last(x => x.Value == maxValue);
                    path = item.Key;
                }
                else
                {
                    path = Sounds.Keys.Last(); //播放最后一个
                }
                //与集合添加操作冲突
                lock (sync_sounds)
                {
                    Sounds.Clear();
                }

                Task.Factory.StartNew(() =>
                {
                    Player.Stream = VoiceResourcesDictionary[path];
                    Player.Stream.Position = 0;
                    try
                    {
                        Player.Play();
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine(ex.Message + "Error Code : " + "C124");
                    }
                    //IsPlayerBusy = false;
                });
            }
        }

        /// <summary>
        ///     处理声音播放(由于播放时间的问题，2秒内只能播放一个声音)
        /// </summary>
        private void PlaySoundHanlder(string path, int priority = 0)
        {
            if (IsOpenVoice)
            {
                Debug.WriteLine(path);
                lock (sync_sounds)
                {
                    if (!Sounds.ContainsKey(path))
                        Sounds.Add(path, priority);
                }
                //SoundsQueue.Enqueue(path);
                //加入播放列表/单独播放
                //由于WPF声音文件不支持Resource资源，所以，将声音文件加载至Propertier.Resources(非托管内存块)(应该只支持wav)
                //if (!IsPlayerBusy)
                //{
                //    IsPlayerBusy = true;
                //}
                //if (SoundsQueue.Count > 3)
                //{
                //    SoundsQueue.Dequeue();
                //}
            }
        }

        public ObservableCollection<InfoDetailReview> GetDefaultDetailReviewsNoSql()
        {
            var reviews = new ObservableCollection<InfoDetailReview>();
            //    //"√" "↓"  "↑" "On" "Off" "×"
            reviews.Add(new InfoDetailReview(1, "点火开关"));
            reviews.Add(new InfoDetailReview(2, "Acc"));
            //该项已删除（原因：与发动机状态重叠）
            //reviews.Add(new Models.InfoDetailReview(3,"启动"));
            reviews.Add(new InfoDetailReview(4, "油门"));
            reviews.Add(new InfoDetailReview(5, "脚刹"));
            reviews.Add(new InfoDetailReview(6, "手刹"));
            reviews.Add(new InfoDetailReview(7, "锁"));
            reviews.Add(new InfoDetailReview(8, "空调"));
            reviews.Add(new InfoDetailReview(9, "温度"));
            reviews.Add(new InfoDetailReview(10, "小灯"));
            reviews.Add(new InfoDetailReview(11, "档位"));
            reviews.Add(new InfoDetailReview(12, "天窗"));
            reviews.Add(new InfoDetailReview(13, "速度"));
            reviews.Add(new InfoDetailReview(14, "雨刮"));
            reviews.Add(new InfoDetailReview(15, "里程"));
            reviews.Add(new InfoDetailReview(16, "水温")); //
            reviews.Add(new InfoDetailReview(17, "大灯")); //
            reviews.Add(new InfoDetailReview(24, "油箱盖"));
            reviews.Add(new InfoDetailReview(25, "引擎盖"));
            reviews.Add(new InfoDetailReview(26, "后备箱"));
            reviews.Add(new InfoDetailReview(27, "转向灯"));
            reviews.Add(new InfoDetailReview(29, "安全带"));
            reviews.Add(new InfoDetailReview(30, "方向盘"));
            reviews.Add(new InfoDetailReview(31, "门"));
            reviews.Add(new InfoDetailReview(35, "窗"));
            reviews.Add(new InfoDetailReview(39, "胎压"));
            reviews.Add(new InfoDetailReview(43, "车轮速度")); //

            reviews.Add(new InfoDetailReview(60, "剩余油量"));
            reviews.Add(new InfoDetailReview(61, "平均油耗"));
            reviews.Add(new InfoDetailReview(62, "电池电压"));
            reviews.Add(new InfoDetailReview(63, "再续里程"));
            reviews.Add(new InfoDetailReview(64, "发动机故障灯"));
            reviews.Add(new InfoDetailReview(65, "气囊故障灯"));
            reviews.Add(new InfoDetailReview(66, "发动机转速"));
            reviews.Add(new InfoDetailReview(67, "瞬间油耗值"));
            reviews.Add(new InfoDetailReview(68, "发动机状态"));
            reviews.Add(new InfoDetailReview(69, "机油指示灯"));
            return reviews;
        }

        private delegate void OpreateCollectionReview(InfoDetailReview review);

        #region 控制模块声明

        /// <summary>
        ///     上锁
        /// </summary>
        public ControlInfoDetailReview ControlLockInfoDetailReview { get; set; }

        /// <summary>
        ///     控制点火和熄火
        /// </summary>
        public ControlInfoDetailReview ControlPowerInfoDetailReview { get; set; }

        /// <summary>
        ///     开锁
        /// </summary>
        public ControlInfoDetailReview ControlUnLockInfoDetailReview { get; set; }

        /// <summary>
        ///     控制尾箱
        /// </summary>
        public ControlInfoDetailReview ControlTrunkInfoDetailReview { get; set; }

        /// <summary>
        ///     寻车
        /// </summary>
        public ControlInfoDetailReview ControlRemoteCarFindingInfoDetailReview { get; set; }

        /// <summary>
        ///     危险灯控制
        /// </summary>
        public ControlInfoDetailReview ControlHazardLightsInfoDetailReview { get; set; }

        /// <summary>
        ///     大灯控制
        /// </summary>
        public ControlInfoDetailReview ControlHeadlightInfoDetailReview { get; set; }

        /// <summary>
        ///     天窗控制
        /// </summary>
        public ControlInfoDetailReview ControlSkyLightInfoDetailReview { get; set; }

        /// <summary>
        ///     扬声器控制
        /// </summary>
        public ControlInfoDetailReview ControlSpeakersInfoDetailReview { get; set; }

        /// <summary>
        ///     左前窗控制
        /// </summary>
        public ControlInfoDetailReview ControlFrontLeftWindowInfoDetailReview { get; set; }


        /// <summary>
        ///     全窗控制
        /// </summary>
        public ControlInfoDetailReview ControlAllWindowsInfoDetailReview { get; set; }


        /// <summary>
        ///     右前窗
        /// </summary>
        public ControlInfoDetailReview ControlFrontRightWindowInfoDetailReview { get; set; }

        /// <summary>
        ///     左后窗
        /// </summary>
        public ControlInfoDetailReview ControlRearLeftWindowInfoDetailReview { get; set; }

        /// <summary>
        ///     左后窗
        /// </summary>
        public ControlInfoDetailReview ControlRearRightWindowInfoDetailReview { get; set; }

        /// <summary>
        ///     水温查询
        /// </summary>
        public ControlInfoDetailReview ControlWaterTemperatureQueryInfoDetailReview { get; set; }

        /// <summary>
        ///     车速查询
        /// </summary>
        public ControlInfoDetailReview ControlSpeedQueryInfoDetailReview { get; set; }

        /// <summary>
        ///     故障代码查询
        /// </summary>
        public ControlInfoDetailReview ControlFaultCodeQueryInfoDetailReview { get; set; }


        /// <summary>
        ///     四轮车速查询
        /// </summary>
        public ControlInfoDetailReview ControlFourWheelVehicleSpeedQueryInfoDetailReview { get; set; }


        /// <summary>
        ///     空调状态查询
        /// </summary>
        public ControlInfoDetailReview ControlAirConditioningStatusQueryInfoDetailReview { get; set; }


        /// <summary>
        ///     电池电压状态查询
        /// </summary>
        public ControlInfoDetailReview ControlBatteryVoltageQueryInfoDetailReview { get; set; }

        #endregion---可以使用ID索引去掉该申明
    }
}