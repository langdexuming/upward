﻿using DataAcquisitionCenter.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Text;

namespace DataAcquisitionCenter.ViewModels
{
    public class CarInfoVm
    {
       


        

        public Models.InfoDetail model { get; set; }


        //暂定所有信息固定位置
        public Models.InfoDetail model_1 { get; set; }
        public Models.InfoDetail model_2 { get; set; }
        public Models.InfoDetail model_3 { get; set; }
        public Models.InfoDetail model_4 { get; set; }
        public Models.InfoDetail model_5 { get; set; }
        public Models.InfoDetail model_6 { get; set; }
        public Models.InfoDetail model_7 { get; set; }
        public Models.InfoDetail model_8 { get; set; }
        public Models.InfoDetail model_9 { get; set; }
        public Models.InfoDetail model_10 { get; set; }
        public Models.InfoDetail model_11 { get; set; }
        public Models.InfoDetail model_12 { get; set; }
        public Models.InfoDetail model_13 { get; set; }
        public Models.InfoDetail model_14 { get; set; }
        public Models.InfoDetail model_15 { get; set; }
        public Models.InfoDetail model_16 { get; set; }
        public Models.InfoDetail model_17 { get; set; }
        public Models.InfoDetail model_18 { get; set; }
        public Models.InfoDetail model_19 { get; set; }
        public Models.InfoDetail model_20 { get; set; }
        public Models.InfoDetail model_21 { get; set; }
        public Models.InfoDetail model_22 { get; set; }
        public Models.InfoDetail model_23 { get; set; }
        public Models.InfoDetail model_24 { get; set; }
        public Models.InfoDetail model_25 { get; set; }
        public Models.InfoDetail model_26 { get; set; }
        public Models.InfoDetail model_27 { get; set; }
        public Models.InfoDetail model_28 { get; set; }
        public Models.InfoDetail model_29 { get; set; }
        public Models.InfoDetail model_30 { get; set; }
        public Models.InfoDetail model_31 { get; set; }
        public Models.InfoDetail model_32 { get; set; }
        public Models.InfoDetail model_33 { get; set; }
        public Models.InfoDetail model_34 { get; set; }


        public CarInfoVm()
        {
            model = new Models.InfoDetail();


            //"√" "↓"  "↑" "On" "Off" "×"
            model_1 = new Models.InfoDetail("点火开关","On");
            model_2 = new Models.InfoDetail("Acc", "Off");
            model_3 = new Models.InfoDetail("启动", "√");
            model_4 = new Models.InfoDetail("油门", "↓");
            model_5 = new Models.InfoDetail("脚刹", "↑");
            model_6 = new Models.InfoDetail("手刹", "√");
            model_7 = new Models.InfoDetail("锁", "On");
            model_8 = new Models.InfoDetail("空调", "On");
            model_9 = new Models.InfoDetail("温度", "23℃");
            model_10 = new Models.InfoDetail("小灯", "On");
            model_11 = new Models.InfoDetail("档位", "P");
            model_12 = new Models.InfoDetail("天窗", "on");
            model_13 = new Models.InfoDetail("速度", "60 km/h");
            model_14 = new Models.InfoDetail("雨刮", "0");
            model_15 = new Models.InfoDetail("里程", "5000km");
            model_16 = new Models.InfoDetail("水温", "30℃");//

            model_17 = new Models.InfoDetail("油箱盖", "Off");
            model_18 = new Models.InfoDetail("引擎盖", "Off");
            model_19 = new Models.InfoDetail("后备箱", "On");
            model_20 = new Models.InfoDetail("转向灯", "左On  右Off");
            model_21 = new Models.InfoDetail("安全带", "√");
            model_22 = new Models.InfoDetail("方向盘", "左180°");
            model_23 = new Models.InfoDetail("门", "", "Off", "On", "Off", "On");
            model_24 = new Models.InfoDetail("窗", "", "Off", "On", "Off", "On");
            model_25 = new Models.InfoDetail("胎压", "bar", "0.1", "0.2", "0.3", "0.4");
            model_26 = new Models.InfoDetail("车轮速度", "km/h","55","56","57","58");//

            model_27 = new Models.InfoDetail("剩余油量", "1.8L");
            model_28 = new Models.InfoDetail("平均油耗", "8.0 l/1000km");
            model_29 = new Models.InfoDetail("电池电压", "13V");
            model_30 = new Models.InfoDetail("再续里程", "200 KM");
            model_31 = new Models.InfoDetail("发动机故障灯", "On");
            model_32 = new Models.InfoDetail("气囊故障灯", "Off");
            model_33 = new Models.InfoDetail("发动机转速", "2000 rpm");
            model_34 = new Models.InfoDetail("瞬间油耗值", "8.0 l/1000km");

        }


     



    }
}
