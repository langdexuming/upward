﻿using System;
using CarInfoDB;
using CarTool.Main.MVVM;

namespace CarTool.Main.ViewModels
{
    public class AddCarViewModel : ModalDialogViewModel
    {
        public enum AddTypes
        {
            AddBrand,

            AddModel
        }

        public AddCarViewModel(string title, BrandAndModel model)
        {
            Title = title;

            EditBrandAndModel = model;

            if (model.Brand == default(string))
                AddType = AddTypes.AddBrand;
            else
                AddType = AddTypes.AddModel;

            if (string.IsNullOrEmpty(model.SuitYear))
            {
                model.SuitYear = DateTime.Now.Year.ToString();
            }
        }

        public BrandAndModel EditBrandAndModel { get; }

        public AddTypes AddType { get; }
    }
}