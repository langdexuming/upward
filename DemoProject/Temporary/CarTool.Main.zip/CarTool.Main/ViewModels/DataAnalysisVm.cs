﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Threading;
using CarInfoDB;
using CarTool.Main.Commands;
using CarTool.Main.Helper;
using CarTool.Main.Models;
using CarTool.Main.MVVM;
using CarTool.Main.Services;
using CarTool.Main.Utils;
using CarTool.Main.Windows;
using static CarTool.Main.Enums.CommonEnums;
using static CarTool.Main.HeaderFile.CanDataBoredom;

namespace CarTool.Main.ViewModels
{
    public class DataAnalysisVm : ViewModelBase
    {
        private const string TAG = nameof(DataAnalysisVm);

        private readonly Dictionary<int, byte[]> InfoItemDictionary;

        /// <summary>
        ///定时刷新主列表数据
        /// </summary>
        private readonly DispatcherTimer MainDispatcherTimer;

        public readonly List<DetailedCanData> MainModelsCanBuffer = new List<DetailedCanData>();
        public readonly List<DetailedCanData> MatchModelsCanBuffer = new List<DetailedCanData>();

        public readonly object sync_lockMainBuffer = new object();
        public readonly object sync_lockMatchBuffer = new object();

        public readonly object sync_lockMinor = new object();
        public readonly object sync_lockMinorBuffer = new object();


        //品牌集合
        private ICollection<Brand> _brands;


        private InfoReviewDisplayModes _infoReviewDisplayMode;


        private bool _isForwarding;

        private readonly BackgroundWorker backgroundWorker_loadCarInfo;
        private readonly BackgroundWorker backgroundWorker_sumbitCarInfo;

        /// <summary>
        ///     指示当前提交是否属于跨车型
        /// </summary>
        private bool IsCrossModelSubmit;

        //构建缓存
        public List<CanDataStandardReview> MinorModelsCanBuffer = new List<CanDataStandardReview>();
        private RingProgressWindow ProgressView;

        public DataGrid AutoScrollContainer;

        public DataAnalysisVm()
        {
            //生成品牌集合
            _brands = DataManager.GetInstance().Brands;

            //配置定时器
            MainDispatcherTimer = new DispatcherTimer();
            MainDispatcherTimer.Tick += MainDispatcherTimer_Tick;
            MainDispatcherTimer.Interval = new TimeSpan(0, 0, 0, 0, 50); //50ms
            MainDispatcherTimer.Start();

            //生成可选列表集合
            VaildBytesAndBits = GetVaildBytesAndBits();
            VaildValue = GetVaildValues();
            VaildMask = GetVaildMask();

            //初始化
            CanDataFirstVm = new CanDataVm(1);
            CanDataSecondVm = new CanDataVm(2);

            ProgressVM = new ProgressBase();

            //载入
            LoadCommand = new RelayCommand<object, bool>(e =>
            {
                if (!backgroundWorker_loadCarInfo.IsBusy)
                    if (e is BrandAndModel)
                    {
                        CurrentBrandAndModel = (BrandAndModel) e;
                        AllInfoItemReviews.Clear();
                        CurrentInfoItemReviews.Clear();

                        ProgressVM.PercentageValue = 0;

                        ProgressView = new RingProgressWindow
                        {
                            DataContext = ProgressVM
                        };

                        ProgressView.Show();

                        IsLoadedCarInfoSuccessful = false;

                        backgroundWorker_loadCarInfo.RunWorkerAsync();
                    }
                    else
                    {
                        MessageBox.Show("请选择车型！");
                    }
            });
            //提交
            SubmitCommand = new RelayCommand<object, bool>(e =>
            {
                if (!backgroundWorker_sumbitCarInfo.IsBusy)
                    if (e is BrandAndModel)
                    {
                        var model = (BrandAndModel) e;
                        if (!IsLoadedCarInfoSuccessful)
                        {
                            MessageBox.Show("请先载入......");
                            return;
                        }

                        if (model != CurrentBrandAndModel)
                        {
                            var tip = "载入车型为:" +
                                      string.Format("{0}-{1}", CurrentBrandAndModel.Brand, CurrentBrandAndModel.Model) +
                                      " 即将提交的车型为:" + string.Format("{0}-{1}", model.Brand, model.Model) + "\n" +
                                      "是否正常提交?";
                            var vm = new ConfirmationTipsViewModel(string.Empty, tip);
                            var result = DialogHelper.ShowDialog(vm);
                            if (result != true)
                                return;
                            //强制将当前车型改为选择车型
                            CurrentBrandAndModel = model;
                            IsCrossModelSubmit = true;
                        }
                        else
                        {
                            IsCrossModelSubmit = false;
                        }
                        ProgressVM.PercentageValue = 0;

                        ProgressView = new RingProgressWindow
                        {
                            DataContext = ProgressVM
                        };

                        ProgressView.Show();

                        backgroundWorker_sumbitCarInfo.RunWorkerAsync();
                    }
            });

            backgroundWorker_loadCarInfo = new BackgroundWorker();
            backgroundWorker_loadCarInfo.WorkerReportsProgress = true;
            backgroundWorker_loadCarInfo.WorkerSupportsCancellation = true;
            backgroundWorker_loadCarInfo.DoWork += BackgroundWorker_loadCarInfo_DoWork;
            backgroundWorker_loadCarInfo.ProgressChanged += BackgroundWorker_loadCarInfo_ProgressChanged;
            backgroundWorker_loadCarInfo.RunWorkerCompleted += BackgroundWorker_loadCarInfo_RunWorkerCompleted;

            backgroundWorker_sumbitCarInfo = new BackgroundWorker();
            backgroundWorker_sumbitCarInfo.WorkerReportsProgress = true;
            backgroundWorker_sumbitCarInfo.WorkerSupportsCancellation = true;
            backgroundWorker_sumbitCarInfo.DoWork += BackgroundWorker_submitCarInfo_DoWork;
            backgroundWorker_sumbitCarInfo.ProgressChanged += BackgroundWorker_submitCarInfo_ProgressChanged;
            backgroundWorker_sumbitCarInfo.RunWorkerCompleted += BackgroundWorker_submitCarInfo_RunWorkerCompleted;

            InfoItemDictionary = new Dictionary<int, byte[]>();


            CurrentInfoItemReviews = new ObservableCollection<InfoItemReview>();
            AllInfoItemReviews = new ObservableCollection<InfoItemReview>();

            CurrentBrandAndModel = new BrandAndModel("", "无", "");

            foreach (var item in GetDefaultInfo())
            {
                CurrentInfoItemReviews.Add(item);
                AllInfoItemReviews.Add(item);
            }

            ServiceManager.GetInstance().CanCoreCommunicateService.OnCanDataActive += CanDataInfoActive;

        }

        public bool IsLoadedCarInfoSuccessful { get; set; }

        public ObservableCollection<CanDataStandardReview> MinorModelsCan { get; set; }

        public ObservableCollection<InfoItemReview> CurrentInfoItemReviews { get; set; }

        public ObservableCollection<InfoItemReview> AllInfoItemReviews { get; set; }

        ///**two parts ***/
        public CanDataVm CanDataFirstVm { get; set; }

        public CanDataVm CanDataSecondVm { get; set; }

        public BrandAndModel CurrentBrandAndModel { get; set; }

        /// <summary>
        ///     是否转发
        /// </summary>
        public bool IsForwarding
        {
            get { return _isForwarding; }
            set
            {
                ServiceManager.GetInstance().CanCoreCommunicateService.SetForwarding(value);
                _isForwarding = value;
            }
        }

        public ICollection<Brand> Brands
        {
            get { return _brands; }

            set
            {
                _brands = value;
                RaisePropertyChanged("Brands");
            }
        }

        public ICommand LoadCommand { get; }
        public ICommand SubmitCommand { get; }

        public InfoReviewDisplayModes InfoReviewDisplayMode
        {
            get { return _infoReviewDisplayMode; }

            set
            {
                _infoReviewDisplayMode = value;
                switch (value)
                {
                    case InfoReviewDisplayModes.All: //全部项
                        Task.Factory.StartNew(() =>
                        {
                            Thread.Sleep(500);

                            Application.Current.Dispatcher.Invoke(new Action(() =>
                            {
                                CurrentInfoItemReviews.Clear();

                                foreach (var item in AllInfoItemReviews)
                                    CurrentInfoItemReviews.Add(item);
                            }));
                        });
                        break;
                    case InfoReviewDisplayModes.Enabled: //已使能项
                        Task.Factory.StartNew(() =>
                        {
                            Thread.Sleep(500);
                            Application.Current.Dispatcher.Invoke(new Action(() =>
                            {
                                CurrentInfoItemReviews.Clear();

                                foreach (var item in AllInfoItemReviews.Where(x => x.IsEnable))
                                    CurrentInfoItemReviews.Add(item);
                            }));
                        });
                        break;
                    case InfoReviewDisplayModes.Disenabled: //未使能项
                        Task.Factory.StartNew(() =>
                        {
                            Thread.Sleep(500);
                            Application.Current.Dispatcher.Invoke(new Action(() =>
                            {
                                CurrentInfoItemReviews.Clear();

                                foreach (
                                    var item in
                                    AllInfoItemReviews.Where(
                                        x => !x.IsEnable && x.DataTypeObject.GetType() != typeof(DataTypeBase)))
                                    CurrentInfoItemReviews.Add(item);
                            }));
                        });
                        break;
                    case InfoReviewDisplayModes.Collected: //已采集项
                        Task.Factory.StartNew(() =>
                        {
                            Thread.Sleep(500);
                            Application.Current.Dispatcher.Invoke(new Action(() =>
                            {
                                CurrentInfoItemReviews.Clear();

                                foreach (
                                    var item in
                                    AllInfoItemReviews.Where(x => x.DataTypeObject.GetType() != typeof(DataTypeBase)))
                                    CurrentInfoItemReviews.Add(item);
                            }));
                        });
                        break;
                    case InfoReviewDisplayModes.NotCollected: //未采集项
                        Task.Factory.StartNew(() =>
                        {
                            Thread.Sleep(500);
                            Application.Current.Dispatcher.Invoke(new Action(() =>
                            {
                                CurrentInfoItemReviews.Clear();

                                foreach (
                                    var item in
                                    AllInfoItemReviews.Where(x => x.DataTypeObject.GetType() == typeof(DataTypeBase)))
                                    CurrentInfoItemReviews.Add(item);
                            }));
                        });
                        break;
                    default:
                        break;
                }
                RaisePropertyChanged(() => InfoReviewDisplayMode);
            }
        }


        public ProgressBase ProgressVM { get; set; }

        //有效字节和位
        public List<byte> VaildBytesAndBits { get; }

        //有效值
        public List<byte> VaildValue { get; }

        //有效掩码
        public List<byte> VaildMask { get; }

        /// <summary>
        ///     加载车库信息核心业务
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BackgroundWorker_loadCarInfo_DoWork(object sender, DoWorkEventArgs e)
        {
            double progress = 0;
            backgroundWorker_loadCarInfo.ReportProgress((int) progress);
            //1.获取任务量
            var count = DataManager.GetInstance().InfoItems?.Count ?? 0;
            //哈希值集合
            InfoItemDictionary.Clear();

            var items = DataManager.GetInstance().GetInfoItemReviews(CurrentBrandAndModel.BrandAndModelID);

            foreach (var item in DataManager.GetInstance().InfoItems)
            {
                if (backgroundWorker_loadCarInfo.CancellationPending)
                    break;

                InfoItemReview reviewModel;
                var result = items.TryGetValue(item.InfoItemID, out reviewModel);
                if (!result)
                    throw new Exception("代码有误");

                //reviewModel.DataTypeObject.InfoItem = item;//TODO:新添加

                InfoItemDictionary.Add(item.InfoItemID, HashUtil.ComputeHashValue(reviewModel.ToString()));

                AllInfoItemReviews.Add(reviewModel);

                //区分模式加载
                switch (InfoReviewDisplayMode)
                {
                    case InfoReviewDisplayModes.All:
                        var model = reviewModel;
                        Application.Current.Dispatcher.Invoke(
                            new Action(() => { CurrentInfoItemReviews.Add(model); }));
                        break;
                    case InfoReviewDisplayModes.Enabled:
                        if (reviewModel.IsEnable)
                        {
                            var model1 = reviewModel;
                            Application.Current.Dispatcher.Invoke(
                                new Action(() => { CurrentInfoItemReviews.Add(model1); }));
                        }
                        break;
                    case InfoReviewDisplayModes.Disenabled:
                        if (!reviewModel.IsEnable && reviewModel.DataTypeObject.GetType() != typeof(DataTypeBase))
                        {
                            var model1 = reviewModel;
                            Application.Current.Dispatcher.Invoke(
                                new Action(() => { CurrentInfoItemReviews.Add(model1); }));
                        }
                        break;
                    case InfoReviewDisplayModes.Collected:
                        if (reviewModel.DataTypeObject.GetType() != typeof(DataTypeBase))
                        {
                            var model1 = reviewModel;
                            Application.Current.Dispatcher.Invoke(
                                new Action(() => { CurrentInfoItemReviews.Add(model1); }));
                        }
                        break;
                    case InfoReviewDisplayModes.NotCollected:
                        if (reviewModel.DataTypeObject.GetType() == typeof(DataTypeBase))
                        {
                            var model1 = reviewModel;
                            Application.Current.Dispatcher.Invoke(
                                new Action(() => { CurrentInfoItemReviews.Add(model1); }));
                        }
                        break;
                    default:
                        break;
                }
                //延时用于进度
                Thread.Sleep(1);
                progress += (double) 100 / count;
                backgroundWorker_loadCarInfo.ReportProgress((int) progress);
            }
            progress = 100;
            backgroundWorker_loadCarInfo.ReportProgress((int) progress);
            Thread.Sleep(100);
        }

        /// <summary>
        ///     加载进度
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BackgroundWorker_loadCarInfo_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            ProgressVM.PercentageValue = e.ProgressPercentage;
        }

        private void BackgroundWorker_loadCarInfo_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (ProgressView.IsVisible)
                ProgressView.Close();
            //创建Table
            if (e.Cancelled)
            {
                //被异步取消
            }
            else
            {
                if (e.Error != null)
                {
                    //完成带有错误
                }
                else
                {
                    IsLoadedCarInfoSuccessful = true;
                    //完成，处理e.result
                }
                MessageBox.Show("信息载入成功！", "提示", MessageBoxButton.OK, MessageBoxImage.Information, MessageBoxResult.None,
                    MessageBoxOptions.ServiceNotification);
            }
        }

        /// <summary>
        ///     提交车库信息核心业务(新建、更改、删除)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BackgroundWorker_submitCarInfo_DoWork(object sender, DoWorkEventArgs e)
        {
            double progress = 0;
            backgroundWorker_sumbitCarInfo.ReportProgress((int) progress);
            //车身数据更新过程
            var count = AllInfoItemReviews.Count;

            foreach (var item in AllInfoItemReviews)
            {
                //异步取消
                if (backgroundWorker_sumbitCarInfo.CancellationPending)
                    break;
                //过滤掉使用基类进行初始化的对象
                if (item.DataTypeObject.GetType() != typeof(DataTypeBase))
                {
                    //过滤掉没改变的对象
                    var compareHashValue = HashUtil.ComputeHashValue(item.ToString());
                    byte[] HashValue;
                    if (InfoItemDictionary.TryGetValue(item.InfoItemId, out HashValue))
                    {
                        InfoItemDictionary[item.InfoItemId] = compareHashValue;
                        //如果不同或者跨车型
                        if (!HashUtil.CompareHash(HashValue, compareHashValue) || IsCrossModelSubmit)
                        {
                            DataManager.GetInstance()
                                .UpdateInfoItemReview(CurrentBrandAndModel.BrandAndModelID, item);
                            App.Log(TAG + ": InfoItem has changed,id is " + item.InfoItemId);
                        }
                    }
                    else
                    {
                        InfoItemDictionary.Add(item.InfoItemId, compareHashValue);
                        DataManager.GetInstance()
                            .UpdateInfoItemReview(CurrentBrandAndModel.BrandAndModelID, item);
                        App.Log(TAG + ": InfoItem has changed,id is " + item.InfoItemId);
                    }
                    
                }

                progress += (double) 100 / count;
                backgroundWorker_sumbitCarInfo.ReportProgress((int) progress);
            }
            //如果配置发生改变-更新Can配置
            var dataCount = AllInfoItemReviews.Count(x => x.DataTypeObject.GetType() != typeof(DataTypeBase));
            DataManager.GetInstance().UpdateBrandAndModel(CurrentBrandAndModel, dataCount);

            progress = 100;
            backgroundWorker_sumbitCarInfo.ReportProgress((int) progress);
            Thread.Sleep(100);
        }

        /// <summary>
        ///     提交进度
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BackgroundWorker_submitCarInfo_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            ProgressVM.PercentageValue = e.ProgressPercentage;
        }

        /// <summary>
        ///     提交完成
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BackgroundWorker_submitCarInfo_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (ProgressView.IsVisible)
                ProgressView.Close();
            if (e.Cancelled)
            {
                //被异步取消
            }
            else
            {
                if (e.Error != null)

                {
                    //完成带有错误
                }
                else
                {
                    //完成，处理e.result
                    MessageBox.Show("提交成功！", "提示", MessageBoxButton.OK, MessageBoxImage.Information,
                        MessageBoxResult.None, MessageBoxOptions.ServiceNotification);
                }
                //  MessageBox.Show("修改成功！","提示",MessageBoxButton.OK,MessageBoxImage.Information,MessageBoxResult.None, MessageBoxOptions.ServiceNotification);
            }
            // MessageBox.Show("信息载入成功！", "提示", MessageBoxButton.OK, MessageBoxImage.Information, MessageBoxResult.None, MessageBoxOptions.ServiceNotification);
        }

        /// <summary>
        ///     接收到正常模式数据----数据核心处理(MainModelsCan)处理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void CanDataInfoActive(object sender, EventArgs ea)
        {
            var e = ea as CanDataEventArgs;
            if (e != null)
            {
                var canData = e.DetailedCanDataObject;
                lock (sync_lockMainBuffer)
                {
                    MainModelsCanBuffer.Add(canData);
                }
            }
        }

        /// <summary>
        ///     Can数据主处理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MainDispatcherTimer_Tick(object sender, EventArgs e)
        {
            /////处理两部分(改变量只作为参考，Copy数组时不使用该变量)
            var mainModelsCount = MainModelsCanBuffer.Count;
            //异步处理
            if (mainModelsCount > 0)
            {
                DetailedCanData[] tempBuffer = null;
                lock (sync_lockMainBuffer)
                {
                    //模式转换时，可能会产生少量缓存（要求:底层变量控制优先级>该任务优先级）
                    tempBuffer = new DetailedCanData[MainModelsCanBuffer.Count];
                    MainModelsCanBuffer.CopyTo(tempBuffer);
                    MainModelsCanBuffer.Clear();
                }
#if false
                Stopwatch sw = new Stopwatch();
                sw.Start();            
#endif
                CanDataHandler(tempBuffer);

#if false
                sw.Stop();
                Console.WriteLine(sw.ElapsedMilliseconds);          
#endif

            }
        }

        /// <summary>
        ///     对缓存数据进行异步处理
        /// </summary>
        private void CanDataHandler(DetailedCanData[] tempBuffer)
        {
            var isRunCan1 = CanDataFirstVm.CanDataDisplayConfigReview.IsRunCanData;
            var isRunCan2 = CanDataSecondVm.CanDataDisplayConfigReview.IsRunCanData;
            #region Can1

            if (isRunCan1)
            {
                var groupCan1 = tempBuffer.Where(x => x.CanId == 1);
                if (groupCan1.Any())
                {
                    //如果需要添加(添加优先)
                    var replaceGroup = new List<DetailedCanData>();
                    foreach (var _canData in groupCan1)
                    {
                        if (!_canData.IsExist)
                        {
                            var _review = new CanDataReview(_canData);
                            CanDataFirstVm.AddItem(_review);
                        }
                        else
                        {
                            replaceGroup.Add(_canData);
                        }
                    }
                    //添加完再替换
                    CanDataFirstVm.ItemsAssign(replaceGroup, () =>
                    {
                        //对于毫秒级的数据，该滚动消耗i5处理器(3代，实测)CPU-10%
                        this.AutoScrollContainer?.ScrollIntoView(CanDataFirstVm.MinorModelsCan.Last());
                    });
                }

            }

            #endregion

            #region Can2

            if (isRunCan2)
            {
                var groupCan2 = tempBuffer.Where(x => x.CanId == 2);
                if (groupCan2.Any())
                {
                    //如果需要添加(添加优先)
                    var replaceGroup = new List<DetailedCanData>();
                    foreach (var _canData in groupCan2)
                    {
                        if (!_canData.IsExist)
                        {
                            var _review = new CanDataReview(_canData);
                            CanDataSecondVm.AddItem(_review);
                        }
                        else
                        {
                            replaceGroup.Add(_canData);
                        }
                    }
                    //添加完再替换
                    CanDataSecondVm.ItemsAssign(replaceGroup, () =>
                    {
                        this.AutoScrollContainer?.ScrollIntoView(CanDataSecondVm.MinorModelsCan.Last());
                    });
                }

            }

            #endregion
        }

        /// <summary>
        ///     测试时使用
        /// </summary>
        public void SetTimerSpan(int value)
        {
            MainDispatcherTimer.Interval = new TimeSpan(0, 0, 0, 0, value);
        }

        /// <summary>
        ///     测试时使用
        /// </summary>
        public int GetTimerSpan()
        {
            return MainDispatcherTimer.Interval.Milliseconds;
        }


        /// <summary>
        ///     提供默认值
        /// </summary>
        /// <returns></returns>
        internal IEnumerable<InfoItemReview> GetDefaultInfo()
        {
            var models = new List<InfoItemReview>();
            var infoItems = new List<string> {"点火开关", "ACC", "启动", "油门", "脚刹", "锁", "空调", "小灯", "档位", "速度"};
            for (var i = 0; i < 10; i++)
            {
                var model = new InfoItemReview(i, infoItems[i], "普通只读信息", false, "请载入车型");
                models.Add(model);
            }
            return models;
        }


        /************************以下为数据分析界面的可选项集合**********************************/

        public List<byte> GetVaildBytesAndBits()
        {
            var list = new List<byte> {0, 1, 2, 3, 4, 5, 6, 7};
            return list;
        }


        public List<byte> GetVaildValues()
        {
            var list = new List<byte> {0, 1};
            return list;
        }

        public List<byte> GetVaildMask()
        {
            var list = new List<byte> {2, 4, 8, 16, 255};
            return list;
        }
    }
}