﻿using CarTool.Main.Models;
using CarTool.Main.MVVM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CarInfoDB;
using CarTool.Main.Utils;
using static CarTool.Main.Enums.CommonEnums;

namespace CarTool.Main.ViewModels
{
    public class SaveCarInfoViewModel : ModalDialogViewModel
    {
        public ActionTypes ActionType { get; }

        private InfoItem _currentInfoItem;

        public InfoItem CurrentInfoItem
        {
            get { return _currentInfoItem; }
            set
            {
                _currentInfoItem = value;

                CurrentInfoItemReview?.SetInfoItem(value);

                RaisePropertyChanged(() => CurrentInfoItem);
            }
        }


        private DataType _currentDataType;

        public DataType CurrentDataType
        {
            get { return _currentDataType; }
            set
            {
                _currentDataType = value;

                CurrentInfoItemReview?.DataTypeObject?.SetDataType(value);

                RaisePropertyChanged(() => CurrentDataType);
            }
        }
        private InfoItemReview _currentInfoItemReview;
        public InfoItemReview CurrentInfoItemReview
        {
            get { return _currentInfoItemReview; }
            set
            {
                _currentInfoItemReview = value;
                RaisePropertyChanged(() => CurrentInfoItemReview);
            }
        }

        public string FrameText;


        public SaveCarInfoViewModel(string title, InfoItemReview model, ActionTypes actionType, string frameText = "")
        {
            Title = title;
            _currentInfoItemReview = model;
            _currentInfoItem = DataManager.GetInstance().InfoItems.FirstOrDefault(x => x.InfoItemID == model?.InfoItemId);
            _currentDataType = DataManager.GetInstance().DataTypes.FirstOrDefault(x => x.DataTypeID == model?.DataTypeObject?.DataTypeID);
            ActionType = actionType;
            FrameText = frameText;
        }


        //~SaveCarInfoViewModel()
        //{
        //    //释放

        //}

        /// <summary>
        ///     界面绑定的属性
        /// </summary>
        public List<FrameFormat> FrameFormatList { get; } = new List<FrameFormat>
        {
            new FrameFormat {FormatId = 0, FormatName = "数据帧"},
            new FrameFormat {FormatId = 1, FormatName = "远程帧"}
        };

        /// <summary>
        ///     界面绑定的属性
        /// </summary>
        public List<FrameType> FrameTypeList { get; } = new List<FrameType>
        {
            new FrameType {TypeId = 0, TypeName = "标准帧"},
            new FrameType {TypeId = 1, TypeName = "扩展帧"}
        };

        /// <summary>
        ///     界面绑定的属性
        /// </summary>
        public List<byte> VaildBytesAndBitList { get; } = new List<byte> {0, 1, 2, 3, 4, 5, 6, 7};

        /// <summary>
        ///     界面绑定的属性
        /// </summary>
        public List<byte> VaildValueList { get; } = new List<byte> {0, 1};

        /// <summary>
        ///     界面绑定的属性
        /// </summary>
        public List<byte> VaildMaskList { get; } = new List<byte> {2, 4, 8, 16, 255};


    }
}
