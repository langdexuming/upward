﻿using System.Collections.ObjectModel;
using CarTool.Main.Models;
using CarTool.Main.MVVM;

namespace CarTool.Main.ViewModels
{
    public class VoiceSettingsViewModel : NormalDialogViewModel
    {
        /// <summary>
        ///     只进行引用，不重新初始化
        /// </summary>
        public ObservableCollection<InfoDetailReview> EnabledOnlyReadInfoDetailReviews { get; set; }

        public VoiceSettingsViewModel(string title, ObservableCollection<InfoDetailReview> collections)
        {
            Title = title;
            EnabledOnlyReadInfoDetailReviews = collections;
        }
    }
}
