﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using CarTool.Main.Models;
using CarTool.Main.ViewModels.CouplingEventArgs;
using CarTool.Main.Services;
using CarTool.Main.Utils;
using static CarTool.Main.Enums.CommonEnums;

namespace CarTool.Main.ViewModels
{
    public class ViewModel
    {
        private ConnectDeviceVm _connectDevice_vm;
        public ConnectDeviceVm ConnectDeviceVM => _connectDevice_vm ?? (_connectDevice_vm = new ConnectDeviceVm());

        private CarViewVm _carView_vm;
        public CarViewVm CarViewVM => _carView_vm ?? (_carView_vm = new CarViewVm());

        private DataAnalysisVm _dataAnalysis_vm;
        public DataAnalysisVm DataAnalysisVM => _dataAnalysis_vm ?? (_dataAnalysis_vm = new DataAnalysisVm());

        private CarManageVm _carManage_vm;
        public CarManageVm CarManageVM => _carManage_vm ?? (_carManage_vm = new CarManageVm());

        private EOBDVm _eobd_vm;
        public EOBDVm EobdVM => _eobd_vm ?? (_eobd_vm = new EOBDVm(2));

        public ViewModel()
        {
            //CarView导出车型库事件
            CarViewVM.ExportLibraryStartEvent += ExportLibraryStart;
            CarViewVM.ExportLibraryDoingEvent += ExportLibraryDoing;
            CarViewVM.ExportLibraryEndEvent += ExportLibraryEnd;

            //CAN连接状态发生变化
            ServiceManager.GetInstance().CanCoreCommunicateService.OnConnectStateChanged += (s, e) =>
            {
                switch (e.CurrentConnectState)
                {
                    case ConnectState.Connect:
                        ConnectDeviceVM.model.SetConnectState(true);
                        break;
                    case ConnectState.Disconnect:
                        //EOBD应该单独成事件通知，目前机制可以不用
                        if (EobdVM.EobdState == EobdStatus.Connected)
                            EobdVM.EobdState = EobdStatus.None;
                        if (CarViewVM.EobdState == EobdStatus.Connected)
                            CarViewVM.EobdState = EobdStatus.None;
                        ConnectDeviceVM.model.SetConnectState(false);
                        break;
                }
            };
        }

        /// <summary>
        /// 车型库界面导出车型数据事件结束
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ExportLibraryEnd(object sender, CanConfigurationEventArgs e)
        {
            //添加未导出的项
            foreach (var item in DataManager.GetInstance().InfoItems)
            {
                var id = item.InfoItemID;
                if (!CarViewVM.ExportItemsIdGroup.Contains(id))
                {
                    //如果无记录，则临时生成
                    var reviewModel = DataManager.GetInstance().GetDefaultInfoBy(id);
                    DataAnalysisVM.AllInfoItemReviews.Add(reviewModel);
                }
            }
            //排序
            DataAnalysisVM.AllInfoItemReviews = new ObservableCollection<InfoItemReview>(DataAnalysisVM.AllInfoItemReviews.OrderBy(x => x.InfoItemId)); 

            //DataAnalysisVM.CurrentBrandAndModel = e._BrandAndModel;
            DataAnalysisVM.CurrentBrandAndModel.CanType = e._BrandAndModel.CanType;
            DataAnalysisVM.CurrentBrandAndModel.BaudRate = e._BrandAndModel.BaudRate;
            DataAnalysisVM.CurrentBrandAndModel.BaudRate2 = e._BrandAndModel.BaudRate2;
            DataAnalysisVM.InfoReviewDisplayMode = InfoReviewDisplayModes.Collected;
        }
        /// <summary>
        /// 车型库界面导出车型数据进行中
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ExportLibraryDoing(object sender, InfoItemEventArgs e)
        {
            DataAnalysisVM.AllInfoItemReviews.Add(e._infoItemReview);
        }
        /// <summary>
        /// 车型库界面导出车型数据开始
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ExportLibraryStart(object sender, EventArgs e)
        {
            DataAnalysisVM.AllInfoItemReviews.Clear();
        }
    }
}
