﻿using CarTool.Main.Commands;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using Excel = Microsoft.Office.Interop.Excel;
using Word = Microsoft.Office.Interop.Word;
using CarInfoDB;
using System.Xml;
using CarTool.Main.Helper;
using CarTool.Main.Utils;
using CarTool.Main.MVVM;
using CarTool.Main.Properties;

namespace CarTool.Main.ViewModels
{
    public class CarManageVm : ViewModelBase
    {
        private ICollection<Brand> _brands;

        public ICollection<Brand> Brands
        {
            get { return _brands; }

            set
            {
                _brands = value;
                RaisePropertyChanged("Brands");
            }
        }

        public ICommand SelectedItemChangedCommand
        {
            get
            {
                return new SimpleCommand(obj =>
                {
                    var brand = obj as Brand;
                    if (brand != null)
                    {
                        SelectedBrand = brand;
                        CurrentEditBrand = brand.Copy();
                    }
                    else
                    {
                        var brandAndModel = obj as BrandAndModel;
                        if (brandAndModel != null)
                        {
                            SelectedBrandAndModel = brandAndModel;
                            CurrentEditBrandAndModel = brandAndModel.Copy();
                        }
                    }
                });
            }
        }

        public Brand SelectedBrand { get; set; }

        public BrandAndModel SelectedBrandAndModel { get; set; }

        private Brand _currentEditBrand;

        public Brand CurrentEditBrand
        {
            get { return _currentEditBrand; }
            set
            {
                _currentEditBrand = value;
                RaisePropertyChanged(()=>CurrentEditBrand);
            }
        }


        private BrandAndModel _currentEditBrandAndModel;

        public BrandAndModel CurrentEditBrandAndModel
        {
            get { return _currentEditBrandAndModel; }
            set
            {
                _currentEditBrandAndModel = value;
                RaisePropertyChanged(()=>CurrentEditBrandAndModel);
            }
        }

        public ICommand ChangeBrandCommand
        {
            get
            {
                return new SimpleCommand((obj) =>
                {
                    if (SelectedBrand == null) return;

                    if (CurrentEditBrand != null)
                    {
                        //更新品牌名称
                        Task.Factory.StartNew(
                            () =>
                            {
                                MessageBox.Show(DataManager.GetInstance().UpdateBrand(SelectedBrand, CurrentEditBrand) ? "修改成功" : "修改失败");
                            });
                    }
                });
            }
        }

        public ICommand ResetBrandCommand
        {
            get
            {
                return new SimpleCommand((obj) =>
                {
                    CurrentEditBrand?.Copy(SelectedBrand);
                });
            }
        }

        public ICommand ChangeBrandAndModelCommand
        {
            get
            {
                return new SimpleCommand((obj) =>
                {
                    if (SelectedBrandAndModel == null) return;

                    if (CurrentEditBrandAndModel != null)
                    {
                        Task.Factory.StartNew(
                            () =>
                            {
                                MessageBox.Show(DataManager.GetInstance()
                                    .UpdateBrandAndModel(SelectedBrandAndModel, CurrentEditBrandAndModel)
                                    ? "修改成功！"
                                    : "修改失败！");
                            });
                    }
                });
            }
        }
        public ICommand ResetBrandAndModelCommand
        {
            get
            {
                return new SimpleCommand((obj) =>
                {
                    CurrentEditBrandAndModel?.Copy(SelectedBrandAndModel);
                });
            }
        }


        public CarManageVm()
        {
            _brands = DataManager.GetInstance().Brands;
            _currentEditBrand = new Brand(string.Empty,null);
            _currentEditBrandAndModel = new BrandAndModel();
        }

        public void RefreshBrandsAndPorducts()
        {
            Brands = DataManager.GetInstance().Brands;
        }

        public List<string> ExportTypes => new List<string>
        {
            "导出当前车型数据(word)",
            "导出当前车型数据到(xml)"
        };

        public List<string> ImportTypes => new List<string> {"导入车型数据(xml)"};

        //public List<string> ImportTypes
        //{
        //    get
        //    {
        //        return new List<string> { "导入当前车型数据到excel",
        //            "导入当前车型数据到txt",
        //            "导入当前车型数据到xml",
        //            "导入所有车型数据到excel",
        //            "导入所有车型数据到txt",
        //            "导入所有车型数据到xml" };
        //    }
        //}
        private enum ImportType
        {
            Default = 0,
            OneXml = 0
        }

        private enum ExportType
        {
            Default = 0,
            OneExcel = 0,
            OneXml,
            OneTxt = 2,
            AllExcel,
            AllTxt,
            AllXml
        }

        public int ExportTypeIndex { get; set; }
        public int ImportTypeIndex { get; set; }

        private ICommand exportCommandWithParameter;

        public ICommand ExportCommandWithParameter => exportCommandWithParameter ?? (exportCommandWithParameter = new SimpleCommand
        {
            CanExecuteDelegate = x => true,
            ExecuteDelegate = x =>
            {
                var ds = new DataSet();
                //获取ds
                if (x is string)
                {
                    Task.Factory.StartNew(() => { ds = App.CarDataSet.GetInfoAndConfig(x.ToString()); });
                }
                else
                {
                    MessageBox.Show("请选择车型");
                    return;
                }
                var type = (ExportType) ExportTypeIndex;
                var sf = new SaveFileDialog();
                switch (type)
                {
                    case ExportType.Default:
                        sf.Title = "请选择要导出的位置";
                        sf.DefaultExt = "doc";
                        sf.Filter = "doc files (*.doc)|*.doc|All files (*.*)|*.*";
                        sf.FilterIndex = 1;
                        sf.RestoreDirectory = true;

                        var showDialog = sf.ShowDialog();
                        if (showDialog != null && (bool) showDialog)
                        {
                            var vm = new LoadingViewModel();
                            DialogHelper.Show(vm,false);

                            Task.Factory.StartNew(() =>
                            {
                                //定义Word对象 
                                var app = new Word.Application();
                                var doc = new Word.Document();
                                var result = false;
                                //string templateFile = "C:/Users/Sumeite/Documents/自定义 Office 模板/CarInfoTemplate.dot";
                                // string templateFile = "/CarTool.Main;component/Resources/Dot/CarInfoTemplate.dot";
                                var fileNameWord = sf.FileName;
                                object Obj_FileName = fileNameWord;
                                object Visible = false;
                                object ReadOnly = false;
                                object missing = Missing.Value;
                                FileStream fStream = null;
                                try
                                {
                                    fStream = File.Create(fileNameWord);
                                    var bs = Resources.CarInfoTemplate;
                                    fStream.Write(bs, 0, bs.Length);
                                }
                                catch
                                {
                                    fStream?.Close();
                                    DialogHelper.Close(vm);
                                    MessageBox.Show("导出失败！");
                                    return;
                                }

                                fStream?.Close();

                                try
                                {
                                    // File.Copy(templateFile, fileNameWord, true);
                                    doc = app.Documents.Open(ref Obj_FileName, ref missing, ref ReadOnly,
                                        ref missing, ref missing, ref missing, ref missing,
                                        ref missing, ref missing, ref missing, ref missing, ref Visible,
                                        ref missing, ref missing, ref missing, ref missing);
                                    doc.Activate();
                                    //插入数据
                                    //替换主要参数
                                    doc.Variables["Model"].Value = ds.Tables["BrandAndModel"].Rows[0]["Brand"] +
                                                                   "-" +
                                                                   ds.Tables["BrandAndModel"].Rows[0]["Model"];
                                    doc.Variables["ParseDate"].Value = DateTime.Now.Date.ToShortDateString();
                                    doc.Variables["BaudRate"].Value =
                                        ds.Tables["BrandAndModel"].Rows[0]["BaudRate"].ToString();
                                    doc.Variables["BaudRate2"].Value =
                                        int.Parse(ds.Tables["BrandAndModel"].Rows[0]["CanType"].ToString()) == 2
                                            ? ds.Tables["BrandAndModel"].Rows[0]["BaudRate2"].ToString()
                                            : " ";
                                    //插入采集到的数据
                                    //计算数据行
                                    var rows = ds.Tables["DetailInfo"].Rows.Count;
                                    //列固定数目为5
                                    var columns = 5;
                                    ////创建表格
                                    var newTable = doc.Tables.Add(doc.Bookmarks["InfoTable"].Range, rows + 5,
                                        columns, ref missing, ref missing);
                                    newTable.Borders.OutsideLineStyle = Word.WdLineStyle.wdLineStyleSingle;
                                    newTable.Borders.InsideLineStyle = Word.WdLineStyle.wdLineStyleSingle;
                                    //表格的标题头

                                    var rowIndex = 1;
                                    newTable.Cell(rowIndex, 1).Range.Text = "项目";
                                    newTable.Cell(rowIndex, 2).Range.Text = "总线";
                                    newTable.Cell(rowIndex, 3).Range.Text = "命令";
                                    newTable.Cell(rowIndex, 4).Range.Text = "作用域";
                                    newTable.Cell(rowIndex, 5).Range.Text = "说明";
                                    rowIndex++;

                                    //区分只读项和控制项
                                    var onlyReadCollection = new List<DataRow>();
                                    var controlCollection = new List<DataRow>();

                                    foreach (DataRow dr in ds.Tables["DetailInfo"].Rows)
                                        if (byte.Parse(dr["MainDataType"].ToString()) == 0)
                                            onlyReadCollection.Add(dr);
                                        else
                                            controlCollection.Add(dr);

                                    //插入采集到的数据
                                    newTable.Rows[rowIndex].Cells.Merge();
                                    newTable.Rows[rowIndex].Cells[1].Range.Text = "车身只读项";
                                    newTable.Rows[rowIndex].Range.Shading.ForegroundPatternColor =
                                        Word.WdColor.wdColorGray05;
                                    rowIndex++;

                                    var onlyReadDataRowCount = onlyReadCollection.Count;
                                    var controlDataRowCount = controlCollection.Count;

                                    if (onlyReadDataRowCount > 0)
                                    {
                                        foreach (var dr in onlyReadCollection)
                                        {
                                            newTable.Cell(rowIndex, 1).Range.Text =
                                                dr["InfoItemName"].ToString();
                                            newTable.Cell(rowIndex, 2).Range.Text = "协议" + dr["CanID"];
                                            newTable.Cell(rowIndex, 3).Range.Text = dr["OrderID"].ToString();

                                            var text1 = "";
                                            var text2 = "";
                                            switch ((byte) dr["DataTypeID"])
                                            {
                                                case 0: //Bool
                                                    text1 = "BYTE" + dr["EffectiveByte"] + " Bit" +
                                                            dr["EffectiveBit"];
                                                    text2 = "有效值(" + dr["EffectiveValue"] + ")";
                                                    break;
                                                case 1: //单字节
                                                    text1 = "BYTE" + dr["EffectiveByte"] + " Mask(" +
                                                            string.Format("0x{0:X}", dr["Mask"]) + ")";
                                                    text2 = dr["Algorithm"].ToString();
                                                    break;
                                                case 2: //双字节
                                                    text1 = "高:" + "BYTE" + dr["HighEffectiveByte"] + " Mask(" +
                                                            string.Format("0x{0:X}", dr["HighMask"]) + ")" +
                                                            "\n" +
                                                            "低:" + "BYTE" + dr["LowEffectiveByte"] + " Mask(" +
                                                            string.Format("0x{0:X}", dr["LowMask"]);
                                                    text2 = dr["Algorithm"].ToString();
                                                    break;
                                                case 3: //三字节
                                                    text1 = "高:" + "BYTE" + dr["HighEffectiveByte"] + " Mask(" +
                                                            string.Format("0x{0:X}", dr["HighMask"]) + ")" +
                                                            "\n" +
                                                            "中:" + "BYTE" + dr["MiddleEffectiveByte"] + " Mask(" +
                                                            string.Format("0x{0:X}", dr["MiddleMask"]) + ")" +
                                                            "\n" +
                                                            "低:" + "BYTE" + dr["LowEffectiveByte"] + " Mask(" +
                                                            string.Format("0x{0:X}", dr["LowMask"]) + ")";
                                                    text2 = dr["Algorithm"].ToString();
                                                    break;
                                                case 16: //通用算法
                                                    text2 = dr["Algorithm"].ToString();
                                                    break;
                                                case 128: //特殊

                                                    break;
                                                default:

                                                    break;
                                            }

                                            newTable.Cell(rowIndex, 4).Range.Text = text1;
                                            newTable.Cell(rowIndex, 5).Range.Text = text2;
                                            rowIndex++;
                                        }
                                    }
                                    else
                                    {
                                        newTable.Rows[rowIndex].Cells.Merge();
                                        newTable.Rows[rowIndex].Cells[1].Range.Text = "无";
                                        rowIndex++;
                                    }

                                    newTable.Rows[rowIndex].Cells.Merge();
                                    newTable.Rows[rowIndex].Cells[1].Range.Text = "车身控制项";
                                    newTable.Rows[rowIndex].Range.Shading.ForegroundPatternColor =
                                        Word.WdColor.wdColorGray05;
                                    rowIndex++;

                                    if (controlDataRowCount > 0)
                                    {
                                        foreach (var dr in controlCollection)
                                        {
                                            newTable.Cell(rowIndex, 1).Range.Text =
                                                dr["InfoItemName"].ToString();
                                            newTable.Cell(rowIndex, 2).Range.Text = "协议" + dr["CanID"];

                                            newTable.Rows[rowIndex].Cells[3].Merge(
                                                newTable.Rows[rowIndex].Cells[5]);
                                            newTable.Cell(rowIndex, 3).Range.Text = dr["FrameData"].ToString();
                                            //newTable.Cell(rowIndex, 3).Range.Text = dr["OrderId"].ToString();
                                            //newTable.Cell(rowIndex, 4).Range.Text = dr["DataTypeName"].ToString();
                                            //newTable.Cell(rowIndex, 5).Range.Text = dr["FrameData"].ToString();
                                            rowIndex++;
                                        }
                                    }
                                    else
                                    {
                                        newTable.Rows[rowIndex].Cells.Merge();
                                        newTable.Rows[rowIndex].Cells[1].Range.Text = "无";
                                        rowIndex++;
                                    }

                                    doc.ResetFormFields();
                                    doc.Fields.Update();
                                    doc.Save();
                                    result = true;
                                    DialogHelper.Close(vm);
                                    MessageBox.Show("导出成功!");
                                }
                                catch (Exception ex)
                                {
                                    DialogHelper.Close(vm);
                                    MessageBox.Show("导出失败，请确认电脑已安装Office2003以上版本!");
                                }
                                finally
                                {
                                    doc.Close();
                                    app.Quit();
                                }
                            });
                        }
                        break;
                    case ExportType.OneXml:
                        sf.Title = "请选择要导出的位置";
                        sf.DefaultExt = "xml";
                        sf.Filter = "xml files (*.xml)|*.xml|All files (*.*)|*.*";
                        sf.FilterIndex = 1;
                        sf.RestoreDirectory = true;

                        var dialog = sf.ShowDialog();
                        if (dialog != null && (bool) dialog)
                            Task.Factory.StartNew(() =>
                            {
                                try
                                {
                                    ds.WriteXml(sf.FileName);
                                    MessageBox.Show("导出成功！");
                                }
                                catch (Exception ex) //XmlException,SecurityException
                                {
                                    Debug.WriteLine(ex.Message + "Exception Type:" + "SecurityException");
                                    MessageBox.Show("导出失败！");
                                }
                            });
                        break;
                }
            }
        });

        public ICommand ImportCommandWithParameter
        {
            get
            {
                return importCommandWithParameter ?? (importCommandWithParameter = new SimpleCommand
                {
                    CanExecuteDelegate = x => true,
                    ExecuteDelegate = x =>
                    {
                        //if (!(x is Guid))
                        //{
                        //    MessageBox.Show("请选择车型");
                        //    return;
                        //}
                        var type = (ImportType) ImportTypeIndex;
                        var of = new OpenFileDialog();
                        switch (type)
                        {
                            case ImportType.Default:
                                of.Title = "请选择要导入的文件";
                                of.DefaultExt = "xml";
                                of.Filter = "xml files (*.xml)|*.xml|All files (*.*)|*.*";
                                of.FilterIndex = 1;
                                of.RestoreDirectory = true;
                                var showDialog = of.ShowDialog();
                                if (showDialog != null && (bool) showDialog)
                                {
                                    var task = Task.Factory.StartNew(() =>
                                    {
                                        var dsSource = new DataSet();
                                        var result = false;
                                        try
                                        {
                                            dsSource.ReadXml(of.FileName);
                                            result = DataManager.GetInstance().ImportProducts(dsSource);
                                        }
                                        catch (XmlException xmlex)
                                        {
                                            Debug.WriteLine(xmlex.Message + "Exception Type:" + "XmlException");
                                            MessageBox.Show("导入失败,请选择xml格式文件！");
                                        }
                                        catch (Exception se)
                                        {
                                            Debug.WriteLine(se.Message + "Exception Type:" + "Exception");
                                            MessageBox.Show("导入失败！");
                                        }
                                        finally
                                        {
                                            if (result)
                                                MessageBox.Show("导入成功");
                                        }
                                    });
                                }
                                break;
                            default:
                                break;
                        }
                    }
                });
            }
        }

        private ICommand importCommandWithParameter;
    }
}
