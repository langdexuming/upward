﻿using CarTool.Main.MVVM;

namespace CarTool.Main.ViewModels
{
    public class LoadingViewModel : ProgressDialogViewModel
    {

    }
}
