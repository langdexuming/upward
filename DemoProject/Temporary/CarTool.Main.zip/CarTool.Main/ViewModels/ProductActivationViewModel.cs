﻿using CarTool.Main.MVVM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CarTool.Main.ViewModels
{
    public class ProductActivationViewModel: ViewModelBase
    {
        private string _serialNumber;

        public string SerialNumber
        {
            get
            {
                return _serialNumber;
            }
            set
            {
                _serialNumber = value;
                RaisePropertyChanged(() => SerialNumber);
            }
        }
    }
}
