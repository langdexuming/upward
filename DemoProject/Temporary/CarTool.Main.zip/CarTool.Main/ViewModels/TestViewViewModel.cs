﻿using CarTool.Main.MVVM;
using Prism.Commands;
using Prism.Mvvm;
using System;
using System.Collections.Generic;
using System.Linq;

namespace CarTool.Main.ViewModels
{
    public class TestViewViewModel : ViewModelBase
    {
        public TestViewViewModel()
        {

        }
    }
}
