﻿using CarTool.Main.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CarTool.Main.ViewModels.CouplingEventArgs
{
    public class InfoItemEventArgs : EventArgs
    {
        public InfoItemReview _infoItemReview;

        public InfoItemEventArgs(InfoItemReview _infoItemReview)
        {
            this._infoItemReview = _infoItemReview;
        }
    }
}
