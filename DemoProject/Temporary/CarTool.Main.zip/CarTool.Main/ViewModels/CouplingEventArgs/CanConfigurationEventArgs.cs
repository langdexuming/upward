﻿using CarInfoDB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CarTool.Main.ViewModels.CouplingEventArgs
{
    public class CanConfigurationEventArgs : System.EventArgs
    {
        public BrandAndModel _BrandAndModel;

        public CanConfigurationEventArgs(BrandAndModel _BrandAndModel)
        {
            this._BrandAndModel = _BrandAndModel;
        }
    }
}
