﻿/*
 *
 * 描述：提供界面所需数据的管理，同时，提供数据的变更到数据库的更新---如果，同步更新机制更改，需将数据库变更与界面数据变更处理分离
 * 
 * 版本：v1.0.0
 * 日期：2017.1.15 
 * 作者：Langdexuming
 */

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Windows;
using CarInfoDB;
using CarTool.Main.Models;
using CarTool.Main.MVVM;
using CarTool.Main.Services;
using static CarTool.Main.HeaderFile.CanDataBoredom;

namespace CarTool.Main.Utils
{
    public class DataManager : NotificationObject
    {
        private static DataManager CurrentDataManager;

        private ObservableCollection<Brand> _brands;
        private List<DataType> _dataTypes;
        private ObservableCollection<Brand> _hadDataBrands;

        private ObservableCollection<InfoItem> _infoItems;

        public ObservableCollection<Brand> Brands
        {
            get { return _brands; }

            set
            {
                _brands = value;
                RaisePropertyChanged(() => Brands);
            }
        }

        public ObservableCollection<Brand> HasDataBrands
        {
            get { return _hadDataBrands; }
            set
            {
                _hadDataBrands = value;
                RaisePropertyChanged(() => HasDataBrands);
            }
        }

        public ObservableCollection<InfoItem> InfoItems
        {
            get { return _infoItems; }

            set
            {
                _infoItems = value;
                RaisePropertyChanged(() => InfoItems);
            }
        }

        public List<DataType> DataTypes => _dataTypes ?? (_dataTypes = new List<DataType>(App.CarDB.GetDataTypes()));

        /// <summary>
        ///     不显示在车型库-EOBD视图的数据项ID
        /// </summary>
        public List<int> IgnoreDisplayInfoItemIdList { get; private set; } = new List<int>
        {
            (int)EobdAnswerId.Handshake, //EOBD连接
            (int)EobdAnswerId.VinSecond, //Vin码二次
            (int)EobdAnswerId.FaultSecond //故障码二次
        };

        public static DataManager GetInstance()
        {
            if (CurrentDataManager == null)
            {
                CurrentDataManager = new DataManager();

                //从数据库加载全局数据
                CurrentDataManager.Brands = new ObservableCollection<Brand>(App.CarDB.GetBrandsAndPorducts());
                CurrentDataManager._infoItems = new ObservableCollection<InfoItem>(App.CarDB.GetInfoItems());

                CurrentDataManager.HasDataBrands = new ObservableCollection<Brand>();
                ResetHasDataBrands();
            }
            return CurrentDataManager;
        }

        /// <summary>
        ///     解析已采集了数据的车型
        /// </summary>
        private static void ResetHasDataBrands()
        {
            foreach (var brand in CurrentDataManager.Brands)
            {
                if (brand.Products != null)
                {
                    var br = new Brand(brand.BrandName, new ObservableCollection<BrandAndModel>());
                    foreach (var model in brand.Products)
                    {
                        if (model.DataCount > 0)
                            br.Products.Add(model);
                    }
                    if (br.Products.Count > 0)
                        CurrentDataManager.HasDataBrands.Add(br);
                }
            }

        }


        /// <summary>
        ///     可选波特率集合
        /// </summary>
        /// <returns></returns>
        public List<string> GetBaudRates(bool isReverse = true)
        {
            var BaudRates = new List<string>
            {
                "5k",
                "10k",
                "20k",
                "40k",
                "50k",
                "80k",
                "100k",
                "125k",
                "200k",
                "250k",
                "400k",
                "500k",
                "666k",
                "800k",
                "1000k"
            };
            if (isReverse)
                BaudRates.Reverse();
            return BaudRates;
        }

        public List<MainDataType> GetMainDataTypes(bool isNormal = true)
        {
            return !isNormal ? InfoItem.EobdDataTypes : InfoItem.NormalDataTypes;
        }

        public List<string> GetPositiveTip()
        {
            return new List<string>
            {
                "已打开",
                "已启动"
            };
        }

        public List<string> GetOppositeTip()
        {
            return new List<string>
            {
                "已关闭",
                "已停止"
            };
        }

        public List<string> GetValueUnit()
        {
            var list = new List<string>
            {
                "km/h",
                "g/s",
                "℃"
            };
            //从数据库寻找不同的进行添加
            foreach (var item in InfoItems)
            {
                if (string.IsNullOrEmpty(item.ValueUnit?.Trim(' ')))
                    continue;
                //如果不包含
                if (!list.Contains(item.ValueUnit))
                    list.Add(item.ValueUnit);
            }
            return list;
        }

        /// <summary>
        ///     更新车型
        /// </summary>
        /// <param name="oldBrandAndModel"></param>
        /// <param name="newBrandAndModel"></param>
        /// <returns></returns>
        public bool UpdateBrandAndModel(BrandAndModel oldBrandAndModel, BrandAndModel newBrandAndModel)
        {
            if (oldBrandAndModel != null)
            {
                if (newBrandAndModel != null)
                {
                    //替换车型
                    if (App.CarDB.UpdateBrandAndModel(newBrandAndModel))
                    {
                        var oldBrandName = oldBrandAndModel.Brand;

                        //生效当前操作
                        var brandAndModel = oldBrandAndModel;
                        brandAndModel.Copy(newBrandAndModel);
                        if (oldBrandName != newBrandAndModel.Brand) //集合结构发生变化
                        {
                            Application.Current.Dispatcher.Invoke(new Action(() =>
                            {
                                //从旧品牌集合中删除
                                foreach (var brand in Brands.Where(x => x.BrandName == oldBrandName))
                                {
                                    brand.Products.Remove(brandAndModel);
                                    if (brand.Products.Count == 0)
                                        Brands.Remove(brand);
                                    break;
                                }
                                //从新品牌中增加
                                var brands = Brands.Where(x => x.BrandName == brandAndModel.Brand);
                                if (brands.Any())
                                {
                                    foreach (var item in brands)
                                    {
                                        item.Products.Add(brandAndModel);
                                        break;
                                    }
                                }
                                else
                                {
                                    //如果不存在该品牌,则新建
                                    var brand = new Brand(brandAndModel.Brand,
                                        new ObservableCollection<BrandAndModel>());
                                    brand.Products.Add(brandAndModel);
                                    Brands.Add(brand);
                                }
                            }));
                        }
                        return true;
                    }
                }
                else
                {
                    //删除车型
                    if (App.CarDB.DeleteBrandAndModel(oldBrandAndModel))
                    {
                        Application.Current.Dispatcher.Invoke(new Action(() =>
                        {
                            //查找
                            foreach (var brand in Brands.Where(x => x.BrandName == oldBrandAndModel.Brand))
                            {
                                brand.Products.Remove(oldBrandAndModel);
                                //如果删除的是最后一个，则删除品牌
                                if (brand.Products.Count == 0)
                                    Brands.Remove(brand);
                                break;
                            }
                            //同样对HasDataCountBrand进行删除
                            foreach (var brand in HasDataBrands.Where(x => x.BrandName == oldBrandAndModel.Brand))
                            {
                                brand.Products.Remove(oldBrandAndModel);
                                //如果删除的是最后一个，则删除品牌
                                if (brand.Products.Count == 0)
                                    HasDataBrands.Remove(brand);
                                break;
                            }
                        }));
                        return true;
                    }
                }
            }
            else
            {
                //增加车型
                if (newBrandAndModel != null)
                {
                    //增加
                    var _brands = Brands.Where(x => x.BrandName == newBrandAndModel.Brand);
                    foreach (var brand in _brands)
                    {
                        var models = brand.Products.Where(x => x.Model == newBrandAndModel.Model);
                        if (!models.Any())
                        {
                            //不存在，可以插入
                            newBrandAndModel.BrandAndModelID = Guid.NewGuid().ToString();
                            var result = App.CarDB.InsertBrandAndModel(newBrandAndModel);
                            if (result)
                            {
                                brand.Products.Add(newBrandAndModel);
                                return true;
                            }
                        }
                        break;
                    }
                }
            }

            return false;
        }


        public bool UpdateBrandAndModel(BrandAndModel model, int newDataCount)
        {
            if (newDataCount == 0 && model.DataCount > 0)
                foreach (var brand in HasDataBrands)
                    if (brand.BrandName == model.Brand)
                        Application.Current.Dispatcher.Invoke(new Action(() => { brand.Products.Remove(model); }));
            if (newDataCount > 0 && model.DataCount == 0)
            {
                //添加到车型库的已采集数据的车型列表中
                //model.DataCount = newDataCount;
                //AddBrandAndModel(HasDataBrands,model);

                var hasDataBrands = HasDataBrands.Where(x => x.BrandName == model.Brand);
                if (hasDataBrands.Any())
                    foreach (var brand in hasDataBrands)
                    {
                        Application.Current.Dispatcher.Invoke(new Action(() => { brand.Products.Add(model); }));
                        break;
                    }
                else
                    Application.Current.Dispatcher.Invoke(
                        new Action(
                            () =>
                            {
                            HasDataBrands.Add(new Brand(model.Brand,new ObservableCollection <BrandAndModel> {model}));
                            }));
            }
            model.DataCount = newDataCount;

            App.CarDB.UpdateBrandAndModel(model);
            return true;
        }

        public bool UpdateBrand(Brand oldBrand, Brand newBrand)
        {
            if (oldBrand != null)
            {
                if (newBrand != null)
                {
                    bool isExist = Brands.Any(x => x.BrandName == newBrand.BrandName);
                    if (!isExist)
                    {
                        if (App.CarDB.UpdateBrand(oldBrand.BrandName, newBrand.BrandName))
                        {
                            oldBrand.BrandName = newBrand.BrandName;
                            foreach (var model in oldBrand.Products)
                            {
                                model.Brand = newBrand.BrandName;
                            }
                            return true;
                        }
                    }
                }
                else
                {
                    //删除
                    if (App.CarDB.DeleteBrand(oldBrand))
                    {
                        if (Brands.Contains(oldBrand))
                            Application.Current.Dispatcher.Invoke(new Action(() =>
                            {
                                Brands.Remove(oldBrand);

                                //同样对HasDataCountBrand进行删除
                                foreach (var brand in HasDataBrands.Where(x => x.BrandName == oldBrand.BrandName))
                                {
                                    //删除品牌
                                    HasDataBrands.Remove(brand);
                                    break;
                                }
                            }));
                        return true;
                    }
                }
            }
            else
            {
                if (newBrand != null)
                {
                    var isExist = Brands.Any(x => x.BrandName == newBrand.BrandName);
                    if (!isExist)
                    {
                        if (newBrand.Products != null)
                        {
                            foreach (var model in newBrand.Products)
                            {
                                model.BrandAndModelID = Guid.NewGuid().ToString();
                                var result = App.CarDB.InsertBrandAndModel(model);
                                if (result)
                                {
                                    Application.Current.Dispatcher.Invoke(new Action(() => { Brands.Add(newBrand); }));
                                    return true;
                                }
                            }
                        }
                    }
                }
            }

            return false;
        }

        /// <summary>
        ///     导入产品(后续改为事务)
        /// </summary>
        /// <param name="dsSource"></param>
        /// <returns></returns>
        public bool ImportProducts(DataSet dsSource)
        {
            var result = false;
            //判断车型是否存在,存在则添加到当前Brand集合
            var _brandAndModelID = string.Empty;
            var _brand = string.Empty;
            var _model = string.Empty;
            var _suitYear = string.Empty;
            byte _canType = 0;
            var _baudRate = string.Empty;
            var _baudRate2 = string.Empty;
            byte _dataCount = 0;
            //异常为空
            if (dsSource.Tables["BrandAndModel"] == null)
                throw new Exception("车型为空");
            if (dsSource.Tables["BrandAndModel"].Rows.Count > 0)
                foreach (DataRow dr in dsSource.Tables["BrandAndModel"].Rows)
                {
                    //注意此处为空时，引发异常，以阻止导入
                    _brandAndModelID = dr["BrandAndModelID"].ToString(); //
                    _brand = dr["Brand"].ToString();
                    _model = dr["Model"].ToString();
                    //以下可空
                    _suitYear = dr["SuitYear"]?.ToString();
                    _canType = byte.Parse(dr["CanType"]?.ToString());
                    _baudRate = dr["BaudRate"]?.ToString();
                    _baudRate2 = dr["BaudRate2"]?.ToString();
                    _dataCount = byte.Parse(dr["DataCount"]?.ToString());
                    //暂时只支持导入一个
                    break;
                }

            if (_brand != string.Empty && _model != string.Empty)
            {
                //如果成功
                if (dsSource.Tables["DetailInfo"] == null)
                    throw new Exception("车型的信息数据为空");

                if (App.CarDataSet.ImportProduct(dsSource))
                {
                    Application.Current.Dispatcher.Invoke(new Action(() =>
                    {
                        var model = new BrandAndModel(_brandAndModelID, _brand, _model, _suitYear, _canType, _baudRate,
                            _baudRate2, _dataCount);

                        AddBrandAndModel(Brands, model);

                        if (model.DataCount > 0)
                            AddBrandAndModel(HasDataBrands, model);
                    }));

                    result = true;
                }
            }
            return result;
        }

        /// <summary>
        ///     单纯减少代码量
        /// </summary>
        /// <param name="brands"></param>
        /// <param name="model"></param>
        private void AddBrandAndModel(ObservableCollection<Brand> brands, BrandAndModel model)
        {
            var items = brands.Where(x => x.BrandName == model.Brand);
            if (items.Any())
                foreach (var brand in items)
                {
                    var models = brand.Products.Where(x => x.Model == model.Model);
                    if (models.Any())
                    {
                        //已经存在
                        //
                    }
                    else
                    {
                        //不存在
                        Application.Current.Dispatcher.Invoke(new Action(() => { brand.Products.Add(model); }));
                    }
                }
            else
                Application.Current.Dispatcher.Invoke(
                    new Action(
                        () => { brands.Add(new Brand(model.Brand,new ObservableCollection <BrandAndModel> {model})); }));
        }

        public bool UpdateInfoItem(InfoItem oldInfoItem, InfoItem newInfoItem)
        {
            if (oldInfoItem != null)
            {
                if (newInfoItem != null)
                {
                    //替换
                    if (App.CarDB.UpdateInfoItem(newInfoItem))
                    {
                        oldInfoItem.Copy(newInfoItem);
                        return true;
                    }
                }
                else
                {
                    //删除
                    if (App.CarDB.DeleteInfoItem(oldInfoItem))
                    {
                        App.CarDB.DeleteInfoAttribute(oldInfoItem.InfoItemID);
                        Application.Current.Dispatcher.Invoke(new Action(() => { InfoItems.Remove(oldInfoItem); }));
                        return true;
                    }
                }
            }
            else
            {
                //添加
                if (newInfoItem != null)
                {
                    var id = 0;
                    if (App.CarDB.InsertInfoItem(newInfoItem, out id))
                    {
                        newInfoItem.InfoItemID = id;
                        Application.Current.Dispatcher.Invoke(new Action(() => { InfoItems.Add(newInfoItem); }));
                        return true;
                    }
                }
            }
            return false;
        }

        public Dictionary<int, InfoItemReview> GetInfoItemReviews(string brandAndModelId)
        {
            var items = App.CarDB.GetInfoItemsDetailDictionary(brandAndModelId);
            return ConvertFrom(items);
        }

        public bool UpdateInfoItemReview(string brandAndModelId, InfoItemReview infoModel)
        {
            if (infoModel == null) throw new ArgumentNullException(nameof(infoModel));
            if (infoModel.DataTypeObject == null) throw new ArgumentNullException(nameof(infoModel.DataTypeObject));

            var infoAttribute = new InfoAttribute
            {
                BrandAndModelID = brandAndModelId,
                InfoItemID = infoModel.InfoItemId,
                IsEnable = infoModel.IsEnable,
                DataTypeID = Convert.ToByte(infoModel.DataTypeObject.DataTypeID),
                OrderID = infoModel.DataTypeObject.OrderID ?? string.Empty,
                CanID = infoModel.DataTypeObject.CanID,
                ExternFlag = infoModel.DataTypeObject.ExternFlag,
                RemoteFlag = infoModel.DataTypeObject.RemoteFlag
        };

            switch (infoModel.DataTypeObject.DataTypeID)
            {
                case (int)DataTypeFlag.Bool:
                    var dataTypeBoolObject = (DataTypeBool) infoModel.DataTypeObject;

                    infoAttribute.EffectiveByte = dataTypeBoolObject.EffectiveByte;
                    infoAttribute.EffectiveBit = dataTypeBoolObject.EffectiveBit;
                    infoAttribute.EffectiveValue = dataTypeBoolObject.EffectiveValue;
                    break;
                case (int)DataTypeFlag.SingleByte:
                    var dataTypeSingleByteObject = (DataTypeSingleByte) infoModel.DataTypeObject;

                    infoAttribute.EffectiveByte = dataTypeSingleByteObject.EffectiveByte;
                    infoAttribute.Mask = dataTypeSingleByteObject.Mask;
                    infoAttribute.Algorithm = dataTypeSingleByteObject.Algorithm ?? string.Empty;
                    break;
                case (int)DataTypeFlag.DoubleByte:
                    var dataTypeDoubleObject = (DataTypeDoubleByte) infoModel.DataTypeObject;

                    infoAttribute.HighEffectiveByte = dataTypeDoubleObject.HighEffectiveByte;
                    infoAttribute.HighMask = dataTypeDoubleObject.HighMask;
                    infoAttribute.LowEffectiveByte = dataTypeDoubleObject.LowEffectiveByte;
                    infoAttribute.LowMask = dataTypeDoubleObject.LowMask;
                    infoAttribute.Algorithm = dataTypeDoubleObject.Algorithm ?? string.Empty;
                    break;
                case (int)DataTypeFlag.ThreeByte:
                    var dataTypeThreeByteObject = (DataTypeThreeByte) infoModel.DataTypeObject;

                    infoAttribute.HighEffectiveByte = dataTypeThreeByteObject.HighEffectiveByte;
                    infoAttribute.HighMask = dataTypeThreeByteObject.HighMask;
                    infoAttribute.MiddleEffectiveByte = dataTypeThreeByteObject.MiddleEffectiveByte;
                    infoAttribute.MiddleMask = dataTypeThreeByteObject.MiddleMask;
                    infoAttribute.LowEffectiveByte = dataTypeThreeByteObject.LowEffectiveByte;
                    infoAttribute.LowMask = dataTypeThreeByteObject.LowMask;
                    infoAttribute.Algorithm = dataTypeThreeByteObject.Algorithm ?? string.Empty;
                    break;
                case (int)DataTypeFlag.Control:

                    var dataTypeControlObject = (DataTypeControl) infoModel.DataTypeObject;

                    infoAttribute.FrameData = FixedFrameText(dataTypeControlObject.FrameData) ?? string.Empty;
                    break;
                case (int)DataTypeFlag.Algorithm:
                    var dataTypeAlgorithmObject = (DataTypeAlgorithm) infoModel.DataTypeObject;

                    infoAttribute.Algorithm = dataTypeAlgorithmObject.Algorithm ?? string.Empty;
                    break;
                case (int)DataTypeFlag.Special:
                    var dataTypeSpecialObject = (DataTypeSpecial) infoModel.DataTypeObject;
                    //
                    break;
                default:
                    break;
            }

            return App.CarDB.UpdateInfoAttribute(brandAndModelId,infoAttribute);
        }
        public Dictionary<int, InfoItemReview> ConvertFrom(Dictionary<int, InfoAttribute> items)
        {
            var dictionary = new Dictionary<int, InfoItemReview>();

            foreach (var infoItem in InfoItems)
            {
                #region InfoAttribute->InfoItemReview

                InfoItemReview reviewModel;
                /**************处理格式***************/
                //判断是否含有该信息项数据
                var dataTypeBaseObject = new DataTypeBase();

                InfoAttribute infoAttribute = null;
                var infoItemID = infoItem.InfoItemID;
                var infoItemName = infoItem.InfoItemName;
                var mainDataTypeName = infoItem.MainDataTypeName;
                var englishName = infoItem.EnglishName;
                if (items.TryGetValue(infoItemID, out infoAttribute))
                {
                    var dataTypeID = infoAttribute.DataTypeID;
                    var dataTypeName = DataTypes.Find(x => x.DataTypeID == dataTypeID)?.DataTypeName ?? string.Empty;//查找
                    var isEnable = infoAttribute.IsEnable;
                    var orderId = infoAttribute.OrderID ?? string.Empty;
                    var canId = infoAttribute.CanID;
                    var externFlag = infoAttribute.ExternFlag;
                    var remoteFlag = infoAttribute.RemoteFlag;
                    var effectiveByte = infoAttribute.EffectiveByte;
                    var effectiveBit = infoAttribute.EffectiveBit;
                    var effectiveValue = infoAttribute.EffectiveValue;
                    var mask = infoAttribute.Mask;
                    var highEffectiveByte = infoAttribute.HighEffectiveByte;
                    var highMask = infoAttribute.HighMask;
                    var middleEffectiveByte = infoAttribute.MiddleEffectiveByte;
                    var middleMask = infoAttribute.MiddleMask;
                    var lowEffectiveByte = infoAttribute.LowEffectiveByte;
                    var lowMask = infoAttribute.LowMask;
                    var algorithm = infoAttribute.Algorithm ?? string.Empty;
                    var frameData = infoAttribute.FrameData ?? string.Empty;
                    switch (infoAttribute.DataTypeID)
                    {
                        case 0: //Bool类型
                            dataTypeBaseObject = new DataTypeBool(
                                dataTypeID,dataTypeName, orderId,
                                canId, englishName, externFlag,
                                remoteFlag,effectiveByte, effectiveBit, effectiveValue);
                            break;
                        case 1:
                            dataTypeBaseObject = new DataTypeSingleByte(
                                dataTypeID, dataTypeName, orderId,
                                canId, englishName, externFlag,
                                remoteFlag, effectiveByte,
                                mask, algorithm);
                            break;
                        case 2:
                            dataTypeBaseObject = new DataTypeDoubleByte(
                                dataTypeID, dataTypeName, orderId,
                                canId, englishName, externFlag,
                                remoteFlag, highEffectiveByte,
                                highMask, lowEffectiveByte,
                                lowMask, algorithm);
                            break;
                        case 3:
                            dataTypeBaseObject = new DataTypeThreeByte(
                                dataTypeID, dataTypeName, orderId,
                                canId, englishName, externFlag,
                                remoteFlag, highEffectiveByte,
                                highMask, middleEffectiveByte,
                                middleMask, lowEffectiveByte,
                                lowMask, algorithm);
                            break;
                        case 4:
                            dataTypeBaseObject = new DataTypeControl(
                                dataTypeID, dataTypeName, orderId,
                                canId, englishName, externFlag,
                                remoteFlag,frameData);
                            break;
                        case 16:
                            dataTypeBaseObject = new DataTypeAlgorithm(
                                dataTypeID, dataTypeName, orderId,
                                canId, englishName, externFlag,
                                remoteFlag,algorithm);
                            break;
                        case 128:
                            dataTypeBaseObject = new DataTypeSpecial(
                                dataTypeID, dataTypeName, orderId,
                                canId, englishName, externFlag,
                                remoteFlag);
                            break;
                        default:
                            break;
                    }

                    reviewModel = new InfoItemReview(infoItemID, infoItemName, mainDataTypeName, isEnable,
                        dataTypeBaseObject);
                }
                else
                {
                    //如果无记录，则临时生成
                    reviewModel = GetDefaultInfoBy(infoItemID);
                }

                #endregion

                dictionary.Add(infoItem.InfoItemID, reviewModel);
            }
            return dictionary;
        }

        public InfoItemReview GetDefaultInfoBy(int infoItemId)
        {
            var items = InfoItems.Where(x => x.InfoItemID == infoItemId);

            var dataTypeBaseObject = new DataTypeBase();

            var infoItemName = string.Empty;
            var englishName = string.Empty;
            var dataTypeName = string.Empty;

            foreach (var item in items)
            {
                infoItemName = item.InfoItemName;
                englishName = item.EnglishName;
                dataTypeName = item.MainDataTypeName;

                dataTypeBaseObject = new DataTypeBase(255, "null", "0x0", 1,
                    englishName, 0, 0);
                break;
            }

            return new InfoItemReview(infoItemId, infoItemName, dataTypeName, false, dataTypeBaseObject);
        }

        public DataTypeBase SearchDataTypeObjectBy(int infoItemId)
        {
            DataTypeBase dataTypeObject = null;

            //获取InfoItem
            var items = InfoItems.Where(x => x.InfoItemID == infoItemId);

            foreach (var item in items)
            {
                var searchId = infoItemId;
                if (item.InfoType == (int)InfoTypeFlag.Eobd)
                {
                    var info = ServiceManager.GetInstance().CanCoreCommunicateService.SearchEobdCommunicatedInfo(searchId, (MainDataTypeFlag)item.MainDataType);

                    if (info == null) return null;

                    DataType dataType = null;
                    if (item.MainDataType == (int)MainDataTypeFlag.Control)
                    {
                        dataType = DataTypes.Find(x => x.DataTypeID == (int) DataTypeFlag.Control);
                        dataTypeObject = new DataTypeControl(
                            dataType.DataTypeID, dataType.DataTypeName
                            , string.Format("0x{0:x}", info.RequestInfo.FrameData[0].OrderId), info.RequestInfo.CanId,
                            item.EnglishName, info.RequestInfo.FrameData[0].ExternFlag,
                            info.RequestInfo.FrameData[0].RemoteFlag,
                            ConvertToFramTextBy(info.RequestInfo.FrameData));
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(info.AnswerInfo.Algorithm))
                        {
                            dataType = DataTypes.Find(x => x.DataTypeID == (int) DataTypeFlag.Special);
                            dataTypeObject = new DataTypeSpecial(
                                dataType.DataTypeID, dataType.DataTypeName
                                , string.Format("0x{0:x}", info.AnswerInfo.OrderId), info.AnswerInfo.CanId,
                                item.EnglishName
                                , info.AnswerInfo.ExternFlag,info.AnswerInfo.RemoteFlag);
                        }
                        else
                        {
                            dataType = DataTypes.Find(x => x.DataTypeID == (int) DataTypeFlag.Algorithm);
                            dataTypeObject = new DataTypeAlgorithm(
                                dataType.DataTypeID, dataType.DataTypeName
                                , string.Format("0x{0:x}", info.AnswerInfo.OrderId), info.AnswerInfo.CanId,
                                item.EnglishName, info.AnswerInfo.ExternFlag, info.AnswerInfo.RemoteFlag,
                                info.AnswerInfo.Algorithm);
                        }
                    }
                }
                else
                {
                    throw new NotImplementedException();
                }

                break;
            }

            return dataTypeObject;
        }                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               

        /// <summary>
        /// 将数据列表转成控制格式数据
        /// </summary>
        /// <param name="list"></param>
        /// <returns></returns>
        public static string ConvertToFramTextBy(IList<CanData> list)
        {
            if (list == null || list.Count == 0) return string.Empty;

            var sb = new StringBuilder();
            var dataStr = string.Empty;

            foreach (var canData in list)
            {
                for (var i = 0; i < canData.Length; i++)
                    dataStr += string.Format("{0:X2}", canData.Data[i]) + " ";

                sb.Append(string.Format("0x{0:x}", canData.OrderId) + "\t" + canData.TimeInterval + "\t" +
                          canData.RemoteFlag
                          + "\t" + canData.ExternFlag + "\t" + canData.Length + "\t"
                          + dataStr + "\r\n");
            }

            return sb.ToString();
        }


        /// <summary>
        ///     校准控制数据的格式(增加帧格式和帧类型)--待优化
        /// </summary>
        public static string FixedFrameText(string str)
        {
            if (string.IsNullOrEmpty(str))
                return string.Empty;

            var builder = new StringBuilder();
            if (str != "")
            {
                char[] splitChrs = {'\r', '\n'};

                try
                {
                    var rows = str.Split(splitChrs);
                    char[] filterChrs = {'\r', '\n', ' ', '\t'};
                    foreach (var row in rows)
                    {
                        if (row.Trim(filterChrs) == "")
                            continue;
                        //!=""
                        //\t处理
                        var check1 = false;
                        var check2 = false;
                        var check3 = false;
                        var check4 = false;
                        var check5 = false;
                        var check6 = false;
                        var check7 = false;
                        var check8 = false;
                        var check9 = false;
                        var check10 = false;
                        var postions = new int[10];
                        var rowLength = row.Length;
                        for (var i = 0; i < rowLength; i++)
                        {
                            var _chr = row[i];
                            if (!check1 & char.IsWhiteSpace(_chr)) //记住空白
                            {
                                postions[0] = i;
                                check1 = true;
                                continue;
                            }
                            //等待1检测完
                            if (!check2 && check1 && !char.IsWhiteSpace(_chr)) //记住非空白
                            {
                                postions[1] = i;
                                check2 = true;
                                continue;
                            }
                            //等待2检测完
                            if (!check3 && check2 && char.IsWhiteSpace(_chr)) //记住空白
                            {
                                postions[2] = i;
                                check3 = true;
                                continue;
                            }
                            //等待3检测完
                            if (!check4 && check3 && !char.IsWhiteSpace(_chr)) //记住非空白
                            {
                                postions[3] = i;
                                check4 = true;
                                continue;
                            }
                            //等待4检测完
                            if (!check5 && check4 && char.IsWhiteSpace(_chr)) //记住空白
                            {
                                postions[4] = i;
                                check5 = true;
                                continue;
                            }
                            //等待5检测完
                            if (!check6 && check5 && !char.IsWhiteSpace(_chr)) //记住非空白
                            {
                                postions[5] = i;
                                check6 = true;
                                continue;
                            }

                            //等待6检测完
                            if (!check7 && check6 && char.IsWhiteSpace(_chr)) //记住空白
                            {
                                postions[6] = i;
                                check7 = true;
                                continue;
                            }
                            //等待7检测完
                            if (!check8 && check7 && !char.IsWhiteSpace(_chr)) //记住非空白
                            {
                                postions[7] = i;
                                check8 = true;
                                continue;
                            }
                            //等待8检测完
                            if (!check9 && check8 && char.IsWhiteSpace(_chr)) //记住空白
                            {
                                postions[8] = i;
                                check9 = true;
                                continue;
                            }
                            //等待9检测完
                            if (!check10 && check9 && !char.IsWhiteSpace(_chr)) //记住非空白
                            {
                                postions[9] = i;
                                check10 = true;
                            }
                        }
                        //order + time + len + Data[]
                        var strs = new string[6];
                        strs[0] = row.Substring(0, postions[0]);
                        strs[1] = row.Substring(postions[1], postions[2] - postions[1]);
                        strs[2] = row.Substring(postions[3], postions[4] - postions[3]);
                        strs[3] = row.Substring(postions[5], postions[6] - postions[5]);
                        strs[4] = row.Substring(postions[7], postions[8] - postions[7]);
                        strs[5] = row.Remove(0, postions[9]).TrimEnd(' ');
                        builder.Append(strs[0] + "\t" + strs[1] + "\t" + strs[2] + "\t" + strs[3] + "\t" +
                                       strs[4] + "\t" + strs[5] + "\r\n");
                    }
                }
                catch (Exception ex)
                {
                    App.Log("校准控制数据的格式时发生错误:" + ex.Message+",frameData:"+str );
                }
            }

            return builder.ToString();
        }
    }
}