﻿using CommonLibrary;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;

namespace CarTool.Main.Utils
{
    public static class AppUtil
    {
        private const string _programRegistryKeyName= @"SOFTWARE\Sunoo\Cartool";

        public static string GetProgramRegistryKeyName()
        {
            return _programRegistryKeyName;
        }

        public static string GetAppName()
        {
            return nameof(CarTool.Main)+".exe";
        }

        public static string GetAppStartUpPath()
        {
            return Path.Combine(Path.GetDirectoryName(Process.GetCurrentProcess().MainModule.FileName), GetAppName());
        }

        public static string GetAppStartUpRegistryValue()
        {
            var value = string.Empty;
            try
            {
                RegistryKeyUtil.SetSubKeyName(_programRegistryKeyName);
                value = RegistryKeyUtil.GetValue("StartupPath");
            }
            catch(Exception ex)
            {
                App.Log(ex.Message, level: App.LogLevel.Fatal);
            }

            return value;
        }

        public static bool IsProductActived()
        {
            var serialNumber = string.Empty;
            try
            {
                RegistryKeyUtil.SetSubKeyName(_programRegistryKeyName);
                serialNumber = RegistryKeyUtil.GetValue("SerialNumber");
            }
            catch (Exception ex)
            {
                App.Log(ex.Message, level: App.LogLevel.Fatal);
                //Ignore
            }

            return IsCorrectSerialNumber(serialNumber);
        }

        public static void WriteSeriesNumberToRegistryKey(string value)
        {
            try
            {
                RegistryKeyUtil.SetSubKeyName(_programRegistryKeyName);
                RegistryKeyUtil.SetValue("SerialNumber",value);
            }
            catch(Exception ex)
            {
                App.Log(ex.Message, level: App.LogLevel.Fatal);
                //Ignore
            }
        }

        private static int[] SerialNumberTag = new int[] { 87, 98, 56, 45 };

        /// <summary>
        /// 序列号是否正确
        /// </summary>
        /// <param name="seriesNumber"></param>
        /// <returns></returns>
        public static bool IsCorrectSerialNumber(string serialNumber)
        {
            if (string.IsNullOrEmpty(serialNumber))
            {
                return false;
            }
            var strs = serialNumber.Trim('-').Split('-');
            if (strs.Count() == 4)
            {
                for (var i = 0; i < 4; i++)
                {
                    var str = strs[i];
                    if (str.Length != 4) return false;
                    var a = 0;
                    var b = 0;
                    var c = 0;
                    if (!(int.TryParse(str[0].ToString(), out a) && int.TryParse(str[3].ToString(), out b) && int.TryParse(str.Substring(1, 2), out c)))
                    {
                        return false;
                    }
                    if (c != (a | b | SerialNumberTag[i]) % 100)
                    {
                        return false;
                    }
                }

                return true;
            }
            return false;
        }
    }
}
