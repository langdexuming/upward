﻿using CarTool.Main.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CarTool.Main.Utils
{
    public class ServiceManager
    {
        private static ServiceManager CurrentManager { get; set; }

        public static ServiceManager GetInstance()
        {
            if (CurrentManager == null)
            {
                CurrentManager = new ServiceManager();
                CurrentManager.CanCoreCommunicateService = new CanCoreCommunicateService();
            }
            return CurrentManager;
        }

        /// <summary>
        /// 安全调用
        /// </summary>
        public ICanCoreCommunicateService CanCoreCommunicateService;
    }
}
