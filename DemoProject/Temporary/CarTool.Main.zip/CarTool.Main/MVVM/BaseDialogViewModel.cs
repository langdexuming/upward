﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CarTool.Main.MVVM
{
    public abstract class BaseDialogViewModel:ViewModelBase
    {
        public virtual string Title { get; set; } = string.Empty;
    }
}
