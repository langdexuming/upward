﻿using CarTool.Main.MVVM;
using CarTool.Main.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace CarTool.Main.MVVM
{

    public class ViewModelBase : NotificationObject
    {
        
    }
}
