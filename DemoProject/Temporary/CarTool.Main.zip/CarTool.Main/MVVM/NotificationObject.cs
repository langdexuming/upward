﻿using System;
using System.ComponentModel;
using System.Linq.Expressions;
using System.Reflection;

namespace CarTool.Main.MVVM
{
    public class NotificationObject : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void RaisePropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        protected void RaisePropertyChanged(params string[] propertyNames)
        {
            if (propertyNames == null) throw new ArgumentNullException(nameof(propertyNames));

            foreach (var name in propertyNames)
                RaisePropertyChanged(name);
        }

        protected void RaisePropertyChanged<T>(Expression<Func<T>> propertyExpression)
        {
            var propertyName = ExtractPropertyName(propertyExpression);
            RaisePropertyChanged(propertyName);
        }

        public static string ExtractPropertyName<T>(Expression<Func<T>> propertyExpression)
        {
            if (propertyExpression == null)
                throw new ArgumentNullException(nameof(propertyExpression));

            var memberExpression = propertyExpression.Body as MemberExpression;
            if (memberExpression == null)
                throw new ArgumentException(@"PropertySupport_NotMemberAccessExpression_Exception", nameof(propertyExpression));

            var property = memberExpression.Member as PropertyInfo;
            if (property == null)
                throw new ArgumentException(@"PropertySupport_ExpressionNotProperty_Exception", nameof(propertyExpression));

            var getMethod = property.GetGetMethod(true);
            if (getMethod.IsStatic)
                throw new ArgumentException(@"PropertySupport_StaticExpression_Exception", nameof(propertyExpression));

            return memberExpression.Member.Name;
        }
    }
}