﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CarTool.Main.MVVM
{
    public class ProgressDialogViewModel:BaseDialogViewModel
    {
        private double _percentageValue;

        public double PercentageValue
        {
            get
            {
                return _percentageValue;
            }

            set
            {
                _percentageValue = value;
                RaisePropertyChanged(()=> PercentageValue);
            }
        }

        public int SuccessRate
        {
            get
            {
                return _successRate;
            }

            set
            {
                _successRate = value;
                RaisePropertyChanged(() => SuccessRate);
            }
        }

        private int _successRate = 100;
    }
}
