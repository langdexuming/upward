﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CarTool.Main.Windows
{
    /// <summary>
    /// AutoSpotGearsMessageBox.xaml 的交互逻辑
    /// </summary>
    public partial class AutoSpotGearsMessageBox : Window
    {

        public AutoSpotGearsMessageBox()
        {
            InitializeComponent();
        }
        private delegate void UiOpreate();
        //public bool? ShowDialog(string content,int time=0)
        //{
        //    this.textBlock_content.Text = content;
        //    if (time > 0)
        //    {
        //        this.button_ok.IsEnabled = false;
        //        Task.Factory.StartNew(() => {
        //            Thread.Sleep(time*1000);
        //            Dispatcher.Invoke(new UiOpreate(() => {
        //                this.button_ok.IsEnabled = true;
        //            }));
        //        });
        //    }
        //    return this.ShowDialog();
        //}
        public static bool? Show(string content, int time = 0)
        {
            var box = new AutoSpotGearsMessageBox {textBlock_content = {Text = content}};
            if (time > 0)
            {
                box.button_ok.IsEnabled = false;
                Task.Factory.StartNew(() => {
                    Thread.Sleep(time * 1000);
                    box.Dispatcher.Invoke(new UiOpreate(() => {
                        box.button_ok.IsEnabled = true;
                    }));
                });
            }
            return box.ShowDialog();
        }

        private void button_okClick(object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
        }

        private void button_cancelClick(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }
    }
}
