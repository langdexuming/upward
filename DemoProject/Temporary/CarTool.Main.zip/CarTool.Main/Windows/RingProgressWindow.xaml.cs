﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CarTool.Main.Windows
{
    /// <summary>
    /// RingProgressWindow.xaml 的交互逻辑
    /// </summary>
    public partial class RingProgressWindow : Window
    {
        public RingProgressWindow()
        {
            InitializeComponent();
        }
        private void button_close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }


        private void border_titleBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }
    }
}
