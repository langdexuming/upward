﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CarTool.Main.Windows
{
    /// <summary>
    /// AutoSpotItemResultDialog.xaml 的交互逻辑
    /// </summary>
    public partial class AutoSpotItemResultWindow : Window
    {
        public AutoSpotItemResultWindow()
        {
            InitializeComponent();
        }

        public enum Result
        {
            Ok,
            Continue,
            Close
        }

        public Result SubmitResult;
        private void button_ok_Click(object sender, RoutedEventArgs e)
        {
            if (this.listBox_spot.SelectedItem != null)
            {
                SubmitResult = Result.Ok;
                DialogResult = true;
            }
            else
            {
                MessageBox.Show("请选择一项结果！");
            }

        }

        private void button_continue_Click(object sender, RoutedEventArgs e)
        {
            SubmitResult = Result.Continue;
            DialogResult = true;
        }
    }
}