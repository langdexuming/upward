﻿using CarTool.Main.Utils;
using CarTool.Main.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CarTool.Main.Windows
{
    /// <summary>
    /// ProductActivationWindow.xaml 的交互逻辑
    /// </summary>
    public partial class ProductActivationWindow : Window
    {
        public ProductActivationWindow()
        {
            InitializeComponent();

            this.DataContext = new ProductActivationViewModel();
        }

        private void btnOkClick(object sender, RoutedEventArgs e)
        {
            //获取序列号
            var seriesNumber = (this.DataContext as ProductActivationViewModel)?.SerialNumber;
            if (string.IsNullOrEmpty(seriesNumber))
            {
                MessageBox.Show("请输入序列号！");
            }
            else if (!AppUtil.IsCorrectSerialNumber(seriesNumber))
            {
                MessageBox.Show("序列号有误，请重新输入！");
            }
            else
            {
                //将序列号写入注册表
                AppUtil.WriteSeriesNumberToRegistryKey(seriesNumber);

                this.DialogResult = true;
            }
        }

        private void btnCancelClick(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }
    }
}
