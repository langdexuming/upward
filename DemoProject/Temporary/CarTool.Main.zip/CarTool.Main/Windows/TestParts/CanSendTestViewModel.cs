﻿using CarTool.Main.Models;
using CarTool.Main.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CarTool.Main.Windows
{
    class CanSendTestViewModel
    {
        public AdderSubstractorReview AutoSendAdderSubstractorReview { get; set; }

        //  public CanDataStandardReview CommonCanDataStandardReview { get; set; }
        //  public CanDataStandardReview AutoCanDataStandardReview { get; set; }

        public CanDataBase CommonSendCanDataObject { get; set; }
        public CanDataBase AutoSendCanDataObject { get; set; }

        public string MyProperty { get; set; }

        public string FrameText { get; set; }
        public CanSendTestViewModel()
        {
            // CanDataBase 
            CommonSendCanDataObject = new CanDataBase();
            AutoSendCanDataObject = new CanDataBase();

            AutoSendAdderSubstractorReview = new AdderSubstractorReview(0);


        }
            
    }
}
