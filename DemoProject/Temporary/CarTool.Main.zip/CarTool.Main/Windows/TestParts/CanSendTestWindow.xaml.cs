﻿using CarTool.Main.Utils;
using CarTool.Main.ViewModels;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static CarTool.Main.HeaderFile.CanDataBoredom;

namespace CarTool.Main.Windows
{
    /// <summary>
    /// CanSendTestWindow.xaml 的交互逻辑
    /// </summary>
    public partial class CanSendTestWindow : Window
    {
        private CanSendTestViewModel ViewModel = new CanSendTestViewModel();

        private byte CanId = 2;
        private byte RemoteFlag = 0;
        private byte ExternFlag = 0;


        public CanSendTestWindow()
        {
            InitializeComponent();

            this.DataContext = ViewModel;

            this.Closed += (s, e) =>
            {
                this.IsAutoSend = false;
            };
        }
        /// <summary>
        /// 普通发送
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button_commonSend_Click(object sender, RoutedEventArgs e)
        {
            var _obj = ((ICanData) this.userControl_CommonSend.DataContext);
            _obj.RemoteFlag = RemoteFlag;
            _obj.ExternFlag = ExternFlag;
            ServiceManager.GetInstance().CanCoreCommunicateService.SendCanData(_obj,CanId);
        }
        /// <summary>
        /// 普通发送
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button_commonSend2_Click(object sender, RoutedEventArgs e)
        {
            
            var _obj = StringToCanData(this.textBox_commonSend.Text);
            _obj.RemoteFlag = RemoteFlag;
            _obj.ExternFlag = ExternFlag;
            ServiceManager.GetInstance().CanCoreCommunicateService.SendCanData(_obj, CanId);
        }

        private static ICanData StringToCanData(string _str)
        {
            var _candata = new CanData();
            try
            {
                string[] __strs = _str.Split(' ');

                string[] _strs = new string[10];
                int postion = 0;
                foreach(var item in __strs)
                {
                    if(item.Trim(' ') != "")
                    {
                        bool isOk = true;
                        foreach(var _chr in item)
                        {
                            if (char.IsControl(_chr))
                                isOk = false;
                        }
                        if (isOk)
                        {
                            _strs[postion] = item;
                            postion++;
                        }
                    }
                   
                }
                _candata.OrderId = System.Convert.ToUInt32(_strs[0],16);

                _candata.Length = System.Convert.ToByte(_strs[1]);
                _candata.Data = new byte[_candata.Length];//初始化

               for(int i=0;i< _candata.Length; i++)
                {
                    _candata.Data[i]= System.Convert.ToByte(_strs[2+i], 16);
                }
            }
            catch(Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }
            return _candata;
        }
        /// <summary>
        /// 自动发送
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button_autoSend_Click(object sender, RoutedEventArgs e)
        {
            var _obj = ((ICanData)this.userControl_AutoSend.DataContext);
            _obj.RemoteFlag = RemoteFlag;
            _obj.ExternFlag = ExternFlag;
            for (int i = 0; i < ((Models.AdderSubstractorReview)this.userControl_AutoSendNum.DataContext).Number; i++)
            {
                ServiceManager.GetInstance().CanCoreCommunicateService.SendCanData(_obj, CanId);
            }
        }

        /// <summary>
        /// 自动发送
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button_autoSend2_Click(object sender, RoutedEventArgs e)
        {

            var _obj = StringToCanData(this.textBox_autoSend.Text);
            _obj.RemoteFlag = RemoteFlag;
            _obj.ExternFlag = ExternFlag;
            for (int i = 0; i < ((Models.AdderSubstractorReview)this.userControl_AutoSendNum.DataContext).Number; i++)
            {
                ServiceManager.GetInstance().CanCoreCommunicateService.SendCanData(_obj,CanId);
            }
        }

        private bool IsAutoSend;
        private Task AutoSendTask;
        /// <summary>
        /// 控制发送
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button_controlSend_Click(object sender, RoutedEventArgs e)
        {
            //调用标准处理方法
            string _frameText = DataManager.FixedFrameText(this.textBlock_frameText.Text);
            this.button_controlSend.IsEnabled = false;
            if (AutoSendTask == null)
            {
                RestAutoSendTask(_frameText);
            }
            else
            {
                if (AutoSendTask.IsCompleted)
                {
                    RestAutoSendTask(_frameText);
                }
            }
        }

        private void RestAutoSendTask(string _frameText)
        {
            AutoSendTask = Task.Factory.StartNew(() =>
                {
                    try
                    {
                        do
                        {
                            ServiceManager.GetInstance()
                                .CanCoreCommunicateService.TestControlSend(_frameText, this.CanId);
                            Thread.Sleep(50);
                        } while (IsAutoSend);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("控制数据格式错误，控制失败！");
                    }
                    finally
                    {
                        Application.Current.Dispatcher.Invoke(
                            new Action(() => { this.button_controlSend.IsEnabled = true; }));
                    }
                }
            );
        }

        private void checkBox_can1_Click(object sender, RoutedEventArgs e)
        {
            this.CanId = 1;
            this.checkBox_can2.IsChecked = false;
        }

        private void checkBox_can2_Click(object sender, RoutedEventArgs e)
        {
            this.CanId = 2;
            this.checkBox_can1.IsChecked = false;
        }

        private void checkBox_extendFlag_Click(object sender, RoutedEventArgs e)
        {
            this.ExternFlag = 1;
        }

        private void checkBox_remoteFlag_Click(object sender, RoutedEventArgs e)
        {
            this.RemoteFlag = 1;
        }

        private void checkBox_extendFlag_Unchecked(object sender, RoutedEventArgs e)
        {
            this.ExternFlag = 0;
        }

        private void checkBox_remoteFlag_Unchecked(object sender, RoutedEventArgs e)
        {
            this.RemoteFlag = 0;
        }

        private void chbAutoSend_Checked(object sender, RoutedEventArgs e)
        {
            IsAutoSend = true;
        }

        private void chbAutoSend_Unchecked(object sender, RoutedEventArgs e)
        {
            IsAutoSend = false;
        }
    }
}
