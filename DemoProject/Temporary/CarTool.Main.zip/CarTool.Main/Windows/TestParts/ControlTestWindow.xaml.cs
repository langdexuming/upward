﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CarTool.Main.Windows
{
    /// <summary>
    /// ControlTestWindow.xaml 的交互逻辑
    /// </summary>
    public partial class ControlTestWindow : Window
    {
        public ControlTestWindow()
        {
            InitializeComponent();
            //this.dataGrid_canData.AutoGenerateColumns = false;
            
            //this.dataGrid_canData.ItemsSource = App.ViewModel.DataAnalysisVM.CanDataFirstVm.CurrentModelsCan.OrderBy(e => e.CanDataBaseObject.OrderId);
            // this.dataGrid_canData.ItemsSource = App.ViewModel.DataAnalysisVM.CanDataFirstVm.CurrentModelsCan;
        }
    }
}
