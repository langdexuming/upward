﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CarTool.Main.Windows
{
    /// <summary>
    /// AutoCanDataTestWindow.xaml 的交互逻辑
    /// </summary>
    public partial class AutoCanDataTestWindow : Window
    {
        private AutoCanDataTestViewModel viewModel = new AutoCanDataTestViewModel();
        public AutoCanDataTestWindow()
        {
            InitializeComponent();

            this.DataContext = viewModel;
        }
    }
}
