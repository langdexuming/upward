﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Speech.Synthesis;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CarTool.Main.Windows
{
    /// <summary>
    /// SpeechTestWindow.xaml 的交互逻辑
    /// </summary>
    public partial class SpeechTestWindow : Window
    {
        public SpeechTestWindow()
        {
            InitializeComponent();
        }

        private static CultureInfo Culture = new CultureInfo("zh-CN"); 
        private void Button_Click(object sender, RoutedEventArgs e)
        {

            string text = this.textBox_voice.Text.Trim(' ');



           SpeechSynthesizer synth = new SpeechSynthesizer();
            PromptBuilder pb1 = new PromptBuilder();

            synth.Speak(text);
            //string name = null;
            //foreach (var item in synth.GetInstalledVoices())
            //{
            //    //Debug.WriteLine(item.VoiceInfo.Name);
            //      MessageBox.Show(item.VoiceInfo.Name);
            //    name = item.VoiceInfo.Name;
            //}

            //if(name!=null)
            //    synth.SelectVoice(name);
            //  synth.SetOutputToDefaultAudioDevice();
            //  MessageBox.Show("voice name : " + synth.Voice.Name);
            // //synth.SelectVoice("Microsoft Zira Desktop");
            //  synth.SelectVoiceByHints(VoiceGender.Male, VoiceAge.Adult, 0, Culture);
            //string high = "<prosody pitch=\"x-high\"> 车已启动. </prosody >";
            //string loud = "<prosody volume=\"x-loud\"> 车已关闭. </prosody>";
            //string slow = "<prosody rate=\"slow\" pitch=\"x-high\" volume=\"x-loud\"> 车已上锁. </prosody>";
            //string fast = "<prosody rate=\"fast\" pitch=\"x-high\" volume=\"x-loud\"> 车已开锁. </prosody>";
            //pb1.AppendSsmlMarkup(high);
            //pb1.AppendSsmlMarkup(loud);
            //pb1.AppendSsmlMarkup(slow);
            //pb1.AppendSsmlMarkup(fast);

            //synth.Speak("我是谁");
            //synth.Speak(pb1);
            //synth.SetOutputToWaveFile(@"D:/test.wav");
            //pb1.AppendText("This sample asynchronously speaks a prompt to a WAVE file.");
            //// Speak the string asynchronously.
            //synth.SpeakAsync(pb1);


            //synth.SelectVoice();
            // synth.Speak(pb1);
            // synth.Speak("我是谁？");

            //System.Media.SoundPlayer player = new System.Media.SoundPlayer();
            //player.SoundLocation = "D:/test.wav";
            //player.Load();
            //player.Play();

        }
        /// <summary>
        /// 导出
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button_export_Click(object sender, RoutedEventArgs e)
        {
            string text = this.textBox_voice.Text.Trim(' ');

            SaveFileDialog sf = new SaveFileDialog();

            sf.Title = "Save wav Files";
            sf.DefaultExt = "wav";
            sf.Filter = "txt files (*.wav)|*.wav|All files (*.*)|*.*";
            sf.FilterIndex = 1;
            sf.RestoreDirectory = true;
            if((bool)sf.ShowDialog())
            {
                SpeechSynthesizer synth = new SpeechSynthesizer();
                PromptBuilder pb1 = new PromptBuilder();
                synth.SetOutputToWaveFile(sf.FileName);
                // Register for the SpeakCompleted event.
                synth.SpeakCompleted += new EventHandler<SpeakCompletedEventArgs>(synth_SpeakCompleted);


                pb1.AppendText(text);
                // Speak the string asynchronously.
                synth.SpeakAsync(pb1);
            }
        }

        private void button_openFile_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog of = new OpenFileDialog();
            of.Title = "Save wav Files";
            of.DefaultExt = "wav";
            of.Filter = "txt files (*.wav)|*.wav|All files (*.*)|*.*";
            of.FilterIndex = 1;
            of.RestoreDirectory = true;
            if ((bool)of.ShowDialog())
            {
                this.textBlock_filePath.Text = of.FileName;

                System.Media.SoundPlayer player = new System.Media.SoundPlayer();
                player.SoundLocation = of.FileName;
                //player.Load();
                player.Play();
            }


        }

        private void button_playFile_Click(object sender, RoutedEventArgs e)
        {
            // Create a SoundPlayer instance to play the output audio file.
            System.Media.SoundPlayer m_SoundPlayer =
              new System.Media.SoundPlayer(this.textBlock_filePath.Text);

            //  Play the output file.
            m_SoundPlayer.Play();
        }

        // Handle the SpeakCompleted event.
        static void synth_SpeakCompleted(object sender, SpeakCompletedEventArgs e)
        {
            Debug.WriteLine("Export Ok!");

            //// Create a SoundPlayer instance to play the output audio file.
            //System.Media.SoundPlayer m_SoundPlayer =
            //  new System.Media.SoundPlayer(e.Prompt);

            ////  Play the output file.
            //m_SoundPlayer.Play();
        }
        private static System.Media.SoundPlayer Player = new System.Media.SoundPlayer();
        private void butto_resouce_Click(object sender, RoutedEventArgs e)
        {

            Player.SoundLocation ="Resources/Voice/seatbelt_on.wav";
            
           // Player.Stream = Properties.Resources.seatbelt_on;

            Player.Play();
        }
    }
}
