﻿using CarTool.Main.Commands;
using CarTool.Main.ViewModels;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static CarTool.Main.HeaderFile.CanDataBoredom;
using CarTool.Main.MVVM;
using CarTool.Main.Utils;

namespace CarTool.Main.Windows
{
    public class AutoCanDataTestViewModel:ViewModelBase
    {
        public RelayCommand<string, bool> OpenFileCommand { get; set; }
        public RelayCommand<string, bool> SendCommand { get; set; }
        public RelayCommand<string, string> SimulateCommand { get; set; }
        
        public string TimeInterval { get; set; }

        public bool IsChecked_can1 { get; set; }
        public bool IsChecked_can2 { get; set; }

        public bool IsLoopSend { get; set; }
        public string FileName
        {
            get
            {
                return _fileName;
            }

            set
            {
                _fileName = value;
                RaisePropertyChanged("FileName");
            }
        }
        private string _fileName;

        public string SimulatBtnContent
        {
            get
            {
                return _simulatBtnContent;
            }

            set
            {
                _simulatBtnContent = value;
                RaisePropertyChanged("SimulatBtnContent");
            }
        }




        private string _simulatBtnContent;


        private bool CanSimulate=true;
        public AutoCanDataTestViewModel()
        {
            OpenFileCommand = new RelayCommand<string, bool>(OpenFile,null);
            SendCommand = new RelayCommand<string, bool>(Send,null);
            SimulateCommand = new RelayCommand<string,string>(e=>Simulate(e),null);

            _simulatBtnContent = "开始模拟";
            IsChecked_can1 = true;
            IsChecked_can2 = true;
        }

        //private bool IsCanSimulate=true;
        private void Simulate(string obj)
        {
            if (CanSimulate)
            {
                this.SimulatBtnContent = "停止模拟";
                 CanSimulate = false;
                int _time = 0;
                try
                {
                    _time = System.Convert.ToInt32(this.TimeInterval);
                }
                catch
                {

                }
                if (_time <= 0)
                    _time = 1;
                //SimulateCommand.RaiseCanExecuteChanged();
                Task.Factory.StartNew(()=>
                {
                    while (true)
                    {
                        if (!CanSimulate)
                        {
                            foreach (var textLine in TextLines)
                            {
                                if (CanSimulate)
                                    return;
                                if (!CanSimulate)
                                {
                                    CanData _obj = SimulateStringToCanData(textLine);

                                    if (this.IsChecked_can1)
                                    {
                                        _obj.RemoteFlag = 0;
                                        _obj.ExternFlag = 0;
                                        ServiceManager.GetInstance().CanCoreCommunicateService.SendCanData(_obj,1);
                                        Thread.Sleep(_time);
                                    }
                                    if (this.IsChecked_can2)
                                    {
                                        _obj.RemoteFlag = 0;
                                        _obj.ExternFlag = 0;
                                        ServiceManager.GetInstance().CanCoreCommunicateService.SendCanData(_obj,2);
                                        Thread.Sleep(_time);
                                    }
                                }
                            }
                        }
                            
                    }
                });
            }
            else
            {
                CanSimulate = true;
                this.SimulatBtnContent = "开始模拟";
                //SimulateCommand.RaiseCanExecuteChanged();
            }

        }



        private void Send(string obj)
        {
            Debug.WriteLine("Send");
            int _time = 0;
            try
            {
                _time = System.Convert.ToInt32(this.TimeInterval);
            }
            catch
            {

            }
            if (IsLoopSend)//循环发送
            {
                Task.Factory.StartNew(() =>
                {
                    while (IsLoopSend)
                    {
                        //屏蔽
                        if (flag)
                        {
                            _byte = 0;
                            flag = false;
                        }
                        else
                        {
                            _byte = 255;
                            flag = true;
                        }


                        if (this.IsChecked_can1)
                        {
                            foreach (var _str in TextLines)
                            {
                                CanData _obj = StringToCanData(_str);
                                _obj.RemoteFlag = 0;
                                _obj.ExternFlag = 0;
                                ServiceManager.GetInstance().CanCoreCommunicateService.SendCanData(_obj,1);
                                Thread.Sleep(_time);
                            }
                        }
                        if (this.IsChecked_can2)
                        {
                            foreach (var _str in TextLines)
                            {
                                CanData _obj = StringToCanData(_str);
                                _obj.RemoteFlag = 0;
                                _obj.ExternFlag = 0;
                                ServiceManager.GetInstance().CanCoreCommunicateService.SendCanData(_obj,2);
                                Thread.Sleep(_time);
                            }
                        }
                        Thread.Sleep(3000);
                    }
                });
            }



            else
            {
                if (this.IsChecked_can1)
                {
                    foreach (var _str in TextLines)
                    {
                        CanData _obj = StringToCanData(_str);
                        _obj.RemoteFlag = 0;
                        _obj.ExternFlag = 0;
                        ServiceManager.GetInstance().CanCoreCommunicateService.SendCanData(_obj,1);
                        Thread.Sleep(_time);
                    }
                }
                if (this.IsChecked_can2)
                {
                    foreach (var _str in TextLines)
                    {
                        CanData _obj = StringToCanData(_str);
                        _obj.RemoteFlag = 0;
                        _obj.ExternFlag = 0;
                        ServiceManager.GetInstance().CanCoreCommunicateService.SendCanData(_obj,2);
                        Thread.Sleep(_time);
                    }
                }

            }

        }


        List<string> TextLines = new List<string>();

        private static bool flag = false;
        private static byte _byte = 0;
        private CanData StringToCanData(string _str)
        {
            CanData candata = new CanData();
            try
            {
                string[] __strs = _str.Split(' ');

                string[] _strs = new string[10];
                int postion = 0;
                foreach (var item in __strs)
                {
                    if (item.Trim(' ') != "")
                    {
                        bool isOk = true;
                        foreach (var _chr in item)
                        {
                            if (char.IsControl(_chr))
                                isOk = false;
                        }
                        if (isOk)
                        {
                            _strs[postion] = item;
                            postion++;
                        }
                    }

                }
                candata.OrderId = System.Convert.ToUInt32(_strs[0], 16);
                candata.Length = System.Convert.ToByte(_strs[1]);
                candata.Data = new byte[candata.Length];
              for (int i=0;i< candata.Length; i++)
                {
                    candata.Data[i] = _byte;
                }
                //_candata._data1 = System.Convert.ToByte(_strs[2], 16);
                //_candata._data2 = System.Convert.ToByte(_strs[3], 16);
                //_candata._data3 = System.Convert.ToByte(_strs[4], 16);
                //_candata._data4 = System.Convert.ToByte(_strs[5], 16);
                //_candata._data5 = System.Convert.ToByte(_strs[6], 16);
                //_candata._data6 = System.Convert.ToByte(_strs[7], 16);
                //_candata._data7 = System.Convert.ToByte(_strs[8], 16);
                //_candata._data8 = System.Convert.ToByte(_strs[9], 16);
            }
            catch (Exception ex)
            {
                IsLoopSend = false;
                Debug.WriteLine(ex.Message);
            }
            return candata;
        }

        private static CanData SimulateStringToCanData(string _str)
        {
            CanData _candata = new CanData();
            try
            {
                string[] __strs = _str.Split(',');

                string[] _strs = new string[__strs.Length];
                int postion = 0;
                foreach (var item in __strs)
                {
                    if (item.Trim(' ') != "")
                    {
                        bool isOk = true;
                        foreach (var _chr in item)
                        {
                            if (char.IsControl(_chr))
                                isOk = false;
                        }
                        if (isOk)
                        {
                            _strs[postion] = item;
                            postion++;
                        }
                    }
                }
                _candata.OrderId = System.Convert.ToUInt32(_strs[3], 16);
                string[] _dataStrs=_strs[4].Split(' ');

                List<string> dataStrs = new List<string>();
                foreach(var item in _dataStrs)
                {
                    if (item.Trim(' ') != "")
                        dataStrs.Add(item);
                }

                _candata.Length = System.Convert.ToByte(dataStrs.Count);
                _candata.Data = new byte[_candata.Length];
                if (_candata.Length != _candata.Data.Length)
                {

                    Debug.WriteLine("_candata.Length != _candata.Data.Length");
                }else
                {
                    for (int i = 0; i < _candata.Length; i++)
                    {
                        _candata.Data[i] = System.Convert.ToByte(dataStrs[i], 16); ;
                    }
                }

                //_candata._data1 = System.Convert.ToByte(_strs[2], 16);
                //_candata._data2 = System.Convert.ToByte(_strs[3], 16);
                //_candata._data3 = System.Convert.ToByte(_strs[4], 16);
                //_candata._data4 = System.Convert.ToByte(_strs[5], 16);
                //_candata._data5 = System.Convert.ToByte(_strs[6], 16);
                //_candata._data6 = System.Convert.ToByte(_strs[7], 16);
                //_candata._data7 = System.Convert.ToByte(_strs[8], 16);
                //_candata._data8 = System.Convert.ToByte(_strs[9], 16);
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }
            return _candata;
        }
        private void OpenFile(string obj)
        {
            Debug.WriteLine("OpenFile");
            OpenFileDialog dialog = new OpenFileDialog();
            if ((bool)dialog.ShowDialog())
            {
                this.FileName = dialog.FileName;
                using (StreamReader reader = new StreamReader(this.FileName))
                {
                    this.TextLines.Clear();
                    string line = reader.ReadLine();

                    while (line != "" && line != null)
                    {
                        TextLines.Add(line);
                        line = reader.ReadLine();
                    }
                }
            }
        }
    }
}
