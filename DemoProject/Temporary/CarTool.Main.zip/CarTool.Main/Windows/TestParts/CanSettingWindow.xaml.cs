﻿using CarTool.Main.Config;
using CarTool.Main.Helper;
using CarTool.Main.Utils;
using CarTool.Main.ViewModels;
using CarTool.Main.Views;
using CarTool.Main.Views.Parts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CarTool.Main.Windows
{
    /// <summary>
    /// CanSettingWindow.xaml 的交互逻辑
    /// </summary>
    public partial class CanSettingWindow : Window
    {
        public CanSettingWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            int counts = 200;
            int times = 50;
            try
            {
                counts = Convert.ToInt32(this.comboBox_canDataReadBaseNumbers.Text);
                times = Convert.ToInt32(this.cbxInterfaceRefreshTime.Text);
            }
            catch
            {

            }
            ServiceManager.GetInstance().CanCoreCommunicateService.SetReadBaseNumbers(counts);

            var vm = Application.Current.MainWindow.DataContext;
            if (vm != null)
            {
                (vm as ViewModel)?.DataAnalysisVM?.SetTimerSpan(times);
            }
            //AppConstants.InterfaceRefreshMsec = times;

            MessageBox.Show($"已修改为: {counts},{times}");

        }
    }
}
