﻿using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using CarInfoDB;
using CarTool.Main.Helper;
using CarTool.Main.Utils;
using CarTool.Main.ViewModels;

namespace CarTool.Main.Windows
{
    /// <summary>
    ///     CarManageWindow.xaml 的交互逻辑
    /// </summary>
    public partial class CarManageWindow : Window
    {
        private readonly CarManageVm ViewModel = App.ViewModel.CarManageVM;

        public CarManageWindow()
        {
            InitializeComponent();

            DataContext = ViewModel;

            treeView_car.SelectedItemChanged += (s, e) =>
            {
                //子节点
                if (e.NewValue is BrandAndModel)
                {
                    stackPanel_input.Visibility = Visibility.Visible;
                    stackPanel_input2.Visibility = Visibility.Collapsed;
                }
                //父节点
                if (e.NewValue is Brand)
                {
                    stackPanel_input.Visibility = Visibility.Collapsed;
                    stackPanel_input2.Visibility = Visibility.Visible;
                }
            };
        }

        /// <summary>
        ///     右键菜单删除
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button_delete(object sender, RoutedEventArgs e)
        {
            //子节点
            if (treeView_car.SelectedItem is BrandAndModel)
                if (MessageBox.Show("该车型的配置及车身信息将会被删除，是否继续？", "警告", MessageBoxButton.OKCancel) == MessageBoxResult.OK)
                {
                    var model = (BrandAndModel) treeView_car.SelectedItem;
                    Task.Factory.StartNew(
                        () =>
                        {
                            MessageBox.Show(DataManager.GetInstance().UpdateBrandAndModel(model, null)
                                ? "删除成功！"
                                : "删除失败！");
                        });
                }
            //父节点
            if (treeView_car.SelectedItem is Brand)
                if (MessageBox.Show("该品牌下所有车型配置及车身信息将会被删除，是否继续？", "警告", MessageBoxButton.OKCancel) ==
                    MessageBoxResult.OK)
                {
                    var brand = (Brand) treeView_car.SelectedItem;
                    Task.Factory.StartNew(
                        () =>
                        {
                            MessageBox.Show(DataManager.GetInstance().UpdateBrand(brand, null) ? "删除成功！" : "删除失败！");
                        });
                }
        }

    }
}