﻿using CarInfoDB;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CarTool.Main.Windows
{
    /// <summary>
    /// InfoManageWindow.xaml 的交互逻辑
    /// </summary>
    public partial class InfoManageWindow : Window
    {
        public InfoManageWindow()
        {
            InitializeComponent();

            this.DataContext = new ViewModels.InfoManageVm();

            //ICollectionView view = CollectionViewSource.GetDefaultView(((ViewModels.InfoManageVm)this.DataContext).Infomations);
            //view.GroupDescriptions.Clear();
            //view.GroupDescriptions.Add(new PropertyGroupDescription("DataTypeName"));
        }

        //~InfoManageWindow()
        //{
        //    ICollectionView view = CollectionViewSource.GetDefaultView(((ViewModels.InfoManageVm)this.DataContext).InfoItems);
        //    view.GroupDescriptions.Clear();
        //}
    }
}
