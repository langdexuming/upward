﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Input;

namespace CarTool.Main.Commands
{
    public class RelayCommand<T1, T2> : ICommand
    {
        private Action<T1> _execute;
        private Func<T2, bool> _canexecute;

        public RelayCommand(Action<T1> execute, Func<T2, bool> canexecute):this(execute)
        {
            _execute = execute;
            _canexecute = canexecute;
        }

        public RelayCommand(Action<T1> execute)
        {
            _execute = execute;
           // _canexecute = e => true;
        }

        public bool CanExecute(object parameter)
        {
            if (_canexecute!=null)
            {
                if (parameter == null)
                    parameter = default(T2);
                return _canexecute((T2)parameter);
            }
            else
            {
                return true;
            }
        }

        public void Execute(object parameter)
        {
            if (_execute!=null)
            {
                if (parameter == null)
                    parameter = default(T1);//应该提供一个可随意转化的值 (string)类型可无视，(string)null=""
                _execute((T1)parameter);
            }
        }

        public event EventHandler CanExecuteChanged;
        //{
        //    add { CommandManager.RequerySuggested += value; }
        //    remove { CommandManager.RequerySuggested -= value; }
        //}
        //public void RaiseCanExecuteChanged()
        //{
        //    CommandManager.InvalidateRequerySuggested();
        //}

        public void RaiseCanExecuteChanged()
        {
            EventHandler canExecuteChanged = this.CanExecuteChanged;
            if (canExecuteChanged != null)
            {
                canExecuteChanged.Invoke(this, EventArgs.Empty);
            }
        }
    }

    public class RelayCommand<T> : ICommand
    {
        private Action<T> _execute;
        private Func<bool> _canexecute;

        public RelayCommand(Action<T> execute, Func<bool> canexecute) : this(execute)
        {
            _execute = execute;
            _canexecute = canexecute;
        }

        public RelayCommand(Action<T> execute)
        {
            _execute = execute;
            // _canexecute = e => true;
        }

        public bool CanExecute(object parameter)
        {
            if (_canexecute != null)
            {
                return _canexecute();
            }
            else
            {
                return true;
            }
        }

        public void Execute(object parameter)
        {
            if (_execute != null)
            {
                if (parameter == null)
                    parameter = default(T);//应该提供一个可随意转化的值 (string)类型可无视，(string)null=""
                _execute((T)parameter);
            }
        }

        public event EventHandler CanExecuteChanged;
        //{
        //    add { CommandManager.RequerySuggested += value; }
        //    remove { CommandManager.RequerySuggested -= value; }
        //}
        //public void RaiseCanExecuteChanged()
        //{
        //    CommandManager.InvalidateRequerySuggested();
        //}

        public void RaiseCanExecuteChanged()
        {
            EventHandler canExecuteChanged = this.CanExecuteChanged;
            if (canExecuteChanged != null)
            {
                canExecuteChanged.Invoke(this, EventArgs.Empty);
            }
        }
    }
}
