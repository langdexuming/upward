﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Input;

namespace CarTool.Main.Commands
{
    /// <summary>
    /// 无法控制按钮的使能
    /// </summary>
    public class DelegateCommand : ICommand
    {
        public event EventHandler CanExecuteChanged;

        public bool CanExecute(object parameter)
        {
            if (this.CanExecuteFunc == null)
                return true;
            return this.CanExecuteFunc(parameter);

        }

        public void Execute(object parameter)
        {
            ExecuteAtion?.Invoke(parameter);
        }
        public void RaiseCanExecuteChanged()
        {
            this.CanExecuteChanged?.Invoke(this, new EventArgs());
        }
        public Action<object> ExecuteAtion { get; set; }
        public Func<object,bool> CanExecuteFunc { get; set; }
    }
}
