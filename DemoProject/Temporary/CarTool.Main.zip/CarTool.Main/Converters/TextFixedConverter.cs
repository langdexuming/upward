﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Data;

namespace CarTool.Main.Converters
{
    /// <summary>
    /// 数据分析界面ListBoxItem采集箱的文本宽度限制
    /// </summary>
    public class TextFixedConverter : IMultiValueConverter
    {
        private const double BaseValue = 4.218;
        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            double _width = 0;
            var objects = values as object[];
            if (objects != null)
            {
                var obs = objects;
                var _text = (string)obs[0];
                try
                {
                    _width = System.Convert.ToDouble(obs[1]);
                }
                catch
                {
                    // ignored
                }
                if (!double.IsNaN(_width))
                {
                    var counts = (int)(_width / BaseValue);

                    if (_text.Length > counts)
                        return _text.Substring(0, counts)+"...";
                    else
                        return _text;
                }
            }
            return "";
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
