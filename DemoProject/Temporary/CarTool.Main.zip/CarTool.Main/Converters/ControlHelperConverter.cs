﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Data;

namespace CarTool.Main.Converters
{
    /// <summary>
    /// 避免单一功能使用控件模板和触发器的问题，使用转换器解决单一问题(WindowControlCard)
    /// </summary>
    public class ControlHelperConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var s = (string)parameter;
            if (s != null)
                switch (s.ToLower()) {
                    case "background":
                        //默认白色
                        if(value is bool)
                        {
                            if ((bool)value)
                                return "#FFFFFF";
                            else
                                return "#FFFFFF";
                        }
                        break;
                    case "foreground":
                        //默认黑色
                        if (value is bool)
                        {
                            if ((bool)value)
                                return "#000000";
                            else
                                return "#FF838383";
                        }
                        break;
                    default:
                        break;
                }
            return "#FFFFFF";
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
