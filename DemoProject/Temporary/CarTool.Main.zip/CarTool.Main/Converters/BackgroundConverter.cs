﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Data;

namespace DataAcquisitionCenter.Converters
{
    class BackgroundConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            System.Windows.Media.Color color = System.Windows.Media.Colors.YellowGreen ;
            if (String.IsNullOrWhiteSpace((string)parameter))
            {
                if (!(bool)value)
                {
                    color = System.Windows.Media.Colors.LightGray;
                }
                else
                {
                    color = System.Windows.Media.Colors.WhiteSmoke;
                }
            }else
            {
                if (value is string)
                {
                    if ((string)value == "o")
                    {
                        color = System.Windows.Media.Colors.LightSkyBlue;
                    }
                    else
                    {
                        color = System.Windows.Media.Colors.WhiteSmoke;
                    }
                }
            }
            return color.ToString();
           // throw new NotImplementedException();
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            System.Windows.Media.Color color;
            if ((bool)value)
            {
                color = System.Windows.Media.Colors.LightGray;
            }
            else
            {
                color = System.Windows.Media.Colors.WhiteSmoke;
            }
            return color;
            // throw new NotImplementedException();
        }
    }
}
