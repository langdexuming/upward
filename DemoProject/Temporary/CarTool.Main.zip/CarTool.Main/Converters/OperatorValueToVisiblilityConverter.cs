﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Data;
using System.Windows;
using System.Globalization;

namespace CarTool.Main.Converters
{
    public class OperatorValueToVisiblilityConverter : IMultiValueConverter
    {
        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {

            switch (((string)parameter).ToLower())
            {
                case "button":
                    if ((values[0] is bool) && (values[1] is bool))
                    {
                        if (((bool)values[0]) && (!(bool)values[1]))
                        {
                            return Visibility.Visible;
                        }
                        else
                        {
                            return Visibility.Collapsed; ;
                        }
                    }
                    break;
                case "textblock"://与非
                    if ((values[0] is bool) && (values[1] is bool))
                    {
                        if (((bool)values[0]) && (!(bool)values[1]))
                        {
                            return Visibility.Collapsed;
                        }
                        else
                        {
                            return Visibility.Visible;
                        }
                    }
                    break;

                default:
                    break;
            }

            return DependencyProperty.UnsetValue;
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
