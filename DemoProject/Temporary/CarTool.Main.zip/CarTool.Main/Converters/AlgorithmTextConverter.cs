﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Data;

namespace CarTool.Main.Converters
{
    class AlgorithmTextConverter : IValueConverter
    {
        /// <summary>
        /// 处理保存数据框中的算法数据
        /// </summary>
        /// <param name="value"></param>
        /// <param name="targetType"></param>
        /// <param name="parameter"></param>
        /// <param name="culture"></param>
        /// <returns></returns>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var text = "";
            if (value is string)
                text = (string) value;
            return text;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is string)
            {
                var str = (string) value;
                var position = str.IndexOf('=');
                if (position >= 0)
                {
                    var backValue = str.Remove(0, position + 1);
                    if (backValue.IndexOf('\n') == 0)
                        backValue = backValue.Remove(0, 1);
                    return backValue;
                }
                return str;//返回原来的值
            }
            return string.Empty;
        }
    }
}
