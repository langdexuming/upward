﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Data;

namespace CarTool.Main.Converters
{
    /// <summary>
    /// 用于确定保存数据界面Can1和Can2选择，双向绑定
    /// </summary>
    class InfoEditContentConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if(parameter!=null)
            {
                string temp = ((string)parameter);
                if (temp.Equals("CanID1"))
                {
                    if (value != null && (value.ToString().Equals("1"))){
                        return true;
                    }
                }
                if (temp.Equals("CanID2"))
                {
                    if (value != null && (value.ToString().Equals("2"))){
                        return true;
                    }
                }
            }
            return false;
                
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (parameter != null)
            {
                string temp = ((string)parameter);
                if (temp.Equals("CanID1"))
                {
                    if (value != null && ((bool)value))
                    {
                        return 1;
                    }
                }
                if (temp.Equals("CanID2"))
                {
                    if (value != null && ((bool)value))
                    {
                        return 2;
                    }
                }
            }
            return 0;
        }
    }
}
