﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Data;

namespace CarTool.Main.Converters
{
    /// <summary>
    /// CarView界面控制按钮大小转换
    /// </summary>
    public class CarViewControlItemIconSizeConverter : IValueConverter
    {
        //普通按钮
        private const double NormalButtonMinWidth = 42;
        private const double NormalButtonMinHeight = 30;
        private const double NormalButtonMaxWidth = 70;
        private const double NormalButtonMaxHeight = 50;
        private const double NormalButtonSizeRate = 70D / 50D;
        private const double NormalButtonItemSuitMinWidth = 113;
        private const double NormalButtonItemSuitMaxWidth = 173;//173
        private const double NormalButtonScaleRate = (NormalButtonItemSuitMaxWidth - NormalButtonItemSuitMinWidth) / (NormalButtonMaxWidth - NormalButtonMinWidth);

        //切换按钮
        private const double ToggleButtonMinWidth = 40;
        private const double ToggleButtonMinHeight = 30;
        private const double ToggleButtonMaxWidth = 60;
        private const double ToggleButtonMaxHeight = 48;
        private const double ToggleButtonSizeRate = 60D / 48D;
        private const double ToggleButtonItemSuitMinWidth = 81;
        private const double ToggleButtonItemSuitMaxWidth = 130;//130
        private const double ToggleButtonScaleRate = (ToggleButtonItemSuitMaxWidth - ToggleButtonItemSuitMinWidth) / (ToggleButtonMaxWidth - ToggleButtonMinWidth);

        //切换按钮
        private const double SpecialToggleButtonMinWidth = 81;
        private const double SpecialToggleButtonMinHeight = 81;
        private const double SpecialToggleButtonMaxWidth = 162;
        private const double SpecialToggleButtonMaxHeight = 162;
        private const double SpecialToggleButtonSizeRate = 162D / 162D;
        private const double SpecialToggleButtonItemSuitMinWidth = 113;
        private const double SpecialToggleButtonItemSuitMaxWidth = 173;//173
        private const double SpecialToggleButtonScaleRate = (SpecialToggleButtonItemSuitMaxWidth - SpecialToggleButtonItemSuitMinWidth) / (SpecialToggleButtonMaxWidth - SpecialToggleButtonMinWidth);

        //用户控件(按钮)
        private const double UserControlButtonMinWidth = 64;
        private const double UserControlButtonMinHeight = 24;
        private const double UserControlButtonMaxWidth = 98;
        private const double UserControlButtonMaxHeight = 34;
        private const double UserControlButtonSizeRate = 98D / 34D;
        private const double UserControlButtonItemSuitMinWidth = 113;
        private const double UserControlButtonItemSuitMaxWidth =173;//173
        private const double UserControlButtonScaleRate = (UserControlButtonItemSuitMaxWidth - UserControlButtonItemSuitMinWidth) / (UserControlButtonMaxWidth - UserControlButtonMinWidth);

        //查询按钮
        private const double QueryButtonMinWidth = 42;
        private const double QueryButtonMinHeight = 42;
        private const double QueryButtonMaxWidth = 64;
        private const double QueryButtonMaxHeight = 64;
        private const double QueryButtonSizeRate = 64D / 64D;
        private const double QueryButtonItemSuitMinWidth = 113;
        private const double QueryButtonItemSuitMaxWidth = 173;//173
        private const double QueryButtonScaleRate = (QueryButtonItemSuitMaxWidth - QueryButtonItemSuitMinWidth) / (QueryButtonMaxWidth - QueryButtonMinWidth);

       // private const double ScaleRate = 2;//自定义缩放比率




        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            double _value = 0;
            if (value is double)
            {
                // double temp= System.Convert.ToDouble(value);
                double temp = (double)value;
                if (temp <= 0) return 0;
                var s = (string)parameter;
                if (s != null)
                    switch (s.ToLower())
                    {
                        case "normalwidth":
                            if (temp < NormalButtonItemSuitMinWidth) return NormalButtonMinWidth;
                            if (temp > NormalButtonItemSuitMaxWidth) return NormalButtonMaxWidth;
                            return NormalButtonMinWidth + (temp - NormalButtonItemSuitMinWidth)/ NormalButtonScaleRate;
                        case "normalheight":
                            if (temp <= NormalButtonItemSuitMinWidth) return NormalButtonMinHeight;
                            if (temp >= NormalButtonItemSuitMaxWidth) return NormalButtonMaxHeight;
                            return NormalButtonMinHeight +(temp - NormalButtonItemSuitMinWidth) / (NormalButtonScaleRate * NormalButtonSizeRate);
                        case "togglewidth":
                            if (temp < ToggleButtonItemSuitMinWidth) return ToggleButtonMinWidth;
                            if (temp > ToggleButtonItemSuitMaxWidth) return ToggleButtonMaxWidth;
                            return ToggleButtonMinWidth + (temp - ToggleButtonItemSuitMinWidth) / ToggleButtonScaleRate;
                        case "toggleheight":
                            if (temp <= ToggleButtonItemSuitMinWidth) return ToggleButtonMinHeight;
                            if (temp >= ToggleButtonItemSuitMaxWidth) return ToggleButtonMaxHeight;
                            return ToggleButtonMinHeight +(temp - ToggleButtonItemSuitMinWidth) / (ToggleButtonScaleRate * ToggleButtonSizeRate);
                        case "specialtogglewidth":
                            if (temp < SpecialToggleButtonItemSuitMinWidth) return SpecialToggleButtonMinWidth;
                            if (temp > SpecialToggleButtonItemSuitMaxWidth) return SpecialToggleButtonMaxWidth;
                            return SpecialToggleButtonMinWidth + (temp - SpecialToggleButtonItemSuitMinWidth) / SpecialToggleButtonScaleRate;
                        case "specialtoggleheight":
                            if (temp <= SpecialToggleButtonItemSuitMinWidth) return SpecialToggleButtonMinHeight;
                            if (temp >= SpecialToggleButtonItemSuitMaxWidth) return SpecialToggleButtonMaxHeight;
                            return SpecialToggleButtonMinHeight +(temp - SpecialToggleButtonItemSuitMinWidth) / (SpecialToggleButtonScaleRate * SpecialToggleButtonSizeRate);
                        case "usercontrolwidth":
                            if (temp < UserControlButtonItemSuitMinWidth) return UserControlButtonMinWidth;
                            if (temp > UserControlButtonItemSuitMaxWidth) return UserControlButtonMaxWidth;
                            return UserControlButtonMinWidth + (temp - UserControlButtonItemSuitMinWidth) / UserControlButtonScaleRate;
                        case "usercontrolheight":
                            if (temp <= UserControlButtonItemSuitMinWidth) return UserControlButtonMinHeight;
                            if (temp >= UserControlButtonItemSuitMaxWidth) return UserControlButtonMaxHeight;
                            return UserControlButtonMinHeight +(temp - UserControlButtonItemSuitMinWidth) / ((UserControlButtonScaleRate * UserControlButtonSizeRate));
                        case "querywidth":
                            if (temp < QueryButtonItemSuitMinWidth) return QueryButtonMinWidth;
                            if (temp > QueryButtonItemSuitMaxWidth) return QueryButtonMaxWidth;
                            return QueryButtonMinWidth + (temp - QueryButtonItemSuitMinWidth) /QueryButtonScaleRate;
                        case "queryheight":
                            if (temp <= QueryButtonItemSuitMinWidth) return QueryButtonMinHeight;
                            if (temp >= QueryButtonItemSuitMaxWidth) return QueryButtonMaxHeight;
                            return QueryButtonMinHeight + (temp - QueryButtonItemSuitMinWidth) / (QueryButtonScaleRate * QueryButtonSizeRate);
                        default:
                            break;
                    }
            }
            return _value;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
