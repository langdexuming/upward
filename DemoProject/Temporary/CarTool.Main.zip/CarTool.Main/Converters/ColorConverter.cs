﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Data;

namespace CarTool.Main.Converters
{
    class ColorConverter : IValueConverter
    {
        /// <summary>
        /// 提供波特率识别结果行的颜色和Can数据显示变化的颜色
        /// </summary>
        /// <param name="value"></param>
        /// <param name="targetType"></param>
        /// <param name="parameter"></param>
        /// <param name="culture"></param>
        /// <returns></returns>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            System.Windows.Media.Color color = System.Windows.Media.Colors.YellowGreen;
            if (!string.IsNullOrWhiteSpace(value.ToString()))
            {
                if (value is int)
                {
                    string _color= "#FFFFFF";
                    if (parameter == null)//default is cell
                    {
                        switch (System.Convert.ToInt32(value))
                        {
                            case 0:
                                _color = System.Windows.Media.Colors.Transparent.ToString();
                                break;
                            case 1:
                                _color = "#e74c3c";
                                break;
                            case 2:
                                _color = "#2ecc71";
                                break;
                            case 3:
                                _color = "#95a5a6";
                                break;
                            default:
                                break;
                        }
                    }else
                    {
                        if(((string)parameter).ToLower()== "row")
                        {
                            switch (System.Convert.ToInt32(value))
                            {
                                case 0:
                                    //_color = System.Windows.Media.Colors.Transparent.ToString();
                                    break;
                                case 1:
                                    _color = "#b9baba";
                                    break;
                                default:
                                    break;
                            }
                        }
                    }
                    return _color;
                }
                if (value is string)
                {
                    switch ((string)value)
                    {
                        case "x":
                            color = System.Windows.Media.Colors.WhiteSmoke;
                            break;
                        case "o":
                            color = System.Windows.Media.Colors.Red;
                            break;
                        default:
                            break;
                    }

                }
            }
            return color.ToString(); 
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
