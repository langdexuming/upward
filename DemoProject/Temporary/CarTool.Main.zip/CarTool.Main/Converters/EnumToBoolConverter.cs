﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Data;
using CarTool.Main.Enums;

namespace CarTool.Main.Converters
{
    public class EnumToBoolConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if(value is CommonEnums.ActionTypes)
            {
                CommonEnums.ActionTypes _value;
                if (Enum.TryParse<CommonEnums.ActionTypes>(value.ToString(), out _value))
                {
                    switch (_value)
                    {
                        case CommonEnums.ActionTypes.Edit:
                            return false;
                        case CommonEnums.ActionTypes.Save:
                            return true;
                    }
                }
            }
            return null;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
