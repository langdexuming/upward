﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Data;

namespace CarTool.Main.Converters
{
    /// <summary>
    /// 用于确定Can类型索引
    /// </summary>
    class CanTypeIndexConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (parameter != null && ((string) parameter).Equals("CanType")) //CanType
            {
                if (value is int || value is byte)
                {
                    var _value = System.Convert.ToInt32(value);
                    if (_value == 1) return 0;
                    if (_value == 2) return 1;
                }
                return -1;
            }
            return 0;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (parameter != null)
                if (((string) parameter).Equals("CanType"))
                {
                    var typeId = System.Convert.ToInt32(value) + 1;
                    return typeId;
                }
            return "";
        }
    }
}
