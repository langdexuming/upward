﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Data;
using CarTool.Main.Enums;

namespace CarTool.Main.Converters
{
    public class IntToEnumConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (!string.IsNullOrEmpty(parameter?.ToString()))
            {
                CommonEnums.InfoReviewDisplayModes _value;
                if (Enum.TryParse(value?.ToString(), out _value))
                {
                    switch ((string)parameter)
                    {
                        case "DataAnalysis":
                            switch (_value)
                            {
                                case CommonEnums.InfoReviewDisplayModes.All:
                                    return 0;
                                case CommonEnums.InfoReviewDisplayModes.Enabled:
                                    return 1;
                                case CommonEnums.InfoReviewDisplayModes.Disenabled:
                                    return 2;
                                case CommonEnums.InfoReviewDisplayModes.Collected:
                                    return 3;
                                case CommonEnums.InfoReviewDisplayModes.NotCollected:
                                    return 4;
                                default:
                                    return -1;
                            }
                        case "CarView":
                            switch (_value)
                            {
                                case CommonEnums.InfoReviewDisplayModes.All:
                                    return 0;
                                case CommonEnums.InfoReviewDisplayModes.Enabled:
                                    return 1;
                                //case CommonEnums.InfoReviewDisplayModes.Disenabled:
                                //    return 2;
                                //case CommonEnums.InfoReviewDisplayModes.Collected:
                                //    return 3;
                                //case CommonEnums.InfoReviewDisplayModes.NotCollected:
                                //    return 4;
                                default:
                                    return -1;
                            }
                        default:
                            break;
                    }
                }
            }
            return null;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (!string.IsNullOrEmpty(parameter?.ToString()))
            {
                if (value is int)
                {
                    int _value;
                    if (int.TryParse(value?.ToString(), out _value))
                    {
                        switch ((string)parameter)
                        {
                            case "DataAnalysis":
                                switch (_value)
                                {
                                    case 0:
                                        return CommonEnums.InfoReviewDisplayModes.All;
                                    case 1:
                                        return CommonEnums.InfoReviewDisplayModes.Enabled;
                                    case 2:
                                        return CommonEnums.InfoReviewDisplayModes.Disenabled;
                                    case 3:
                                        return CommonEnums.InfoReviewDisplayModes.Collected;
                                    case 4:
                                        return CommonEnums.InfoReviewDisplayModes.NotCollected;
                                    default:
                                        return CommonEnums.InfoReviewDisplayModes.All;
                                }
                            case "CarView":
                                switch (_value)
                                {
                                    case 0:
                                        return CommonEnums.InfoReviewDisplayModes.All;
                                    case 1:
                                        return CommonEnums.InfoReviewDisplayModes.Enabled;
                                    //case 2:
                                    //    return CommonEnums.InfoReviewDisplayModes.Disenabled;
                                    //case CommonEnums.InfoReviewDisplayModes.Collected:
                                    //    return 3;
                                    //case CommonEnums.InfoReviewDisplayModes.NotCollected:
                                    //    return 4;
                                    default:
                                        return CommonEnums.InfoReviewDisplayModes.All;
                                }
                            default:
                                break;
                        }
                    }
                }
            }
            return null;
        }
    }
}
