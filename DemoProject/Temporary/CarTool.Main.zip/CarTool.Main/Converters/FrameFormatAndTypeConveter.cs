﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Data;

namespace CarTool.Main.Converters
{
    public class FrameFormatAndTypeConveter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if ((parameter != null)&&(value != null))
            {
                byte _value=0;
                switch (((string)parameter).ToLower())
                {
                    case "format":
                        if (byte.TryParse(value.ToString(), out _value))
                        {
                            return _value == 0 ? "Data" : "Remote";
                        }
                        break;
                    case "type":
                        if (byte.TryParse(value.ToString(), out _value))
                        {
                            return _value == 0 ? "Std" : "Ext";
                        }
                        break;
                    default:
                        break;
                }


            }
            return string.Empty;
            //throw new NotImplementedException();
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if ((parameter != null) && (value != null))
            {
                string _value;
                switch (((string)parameter).ToLower())
                {
                    case "format":
                        _value = value.ToString().ToLower();
                        if (_value == "remote")
                            return 1;
                        if (_value == "Data")
                            return 0;
                        break;
                    case "type":
                        _value = value.ToString().ToLower();
                        if (_value == "ext")
                            return 1;
                        if (_value == "std")
                            return 0;
                        break;
                    default:
                        break;
                }
            }
            return null;//可能引发异常
        }
    }
}
