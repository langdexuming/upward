﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Data;

namespace CarTool.Main.Converters
{
    /// <summary>
    /// 自定义
    /// </summary>
    public class StringFormatConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            string _value = null;
            if(value is uint)
            {
                _value = string.Format("0x{0:X}",value);
            }
            return _value;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            uint _convertValue = 0;
            try
            {

                if (value is string)
                {
                    _convertValue = System.Convert.ToUInt32((string)value, 16);
                }
            }
            catch(Exception ex)
            {
                Debug.WriteLine(ex.Message+"Error Code: "+"Converter error");
            }

            return _convertValue;
        }
    }
}
