﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Data;

namespace CarTool.Main.Converters
{
    public class OperatorValueConverter : IMultiValueConverter
    {
        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            switch (((string)parameter).ToLower()) {
                case "xor":
                    if ((values[0] is bool) && (values[1] is bool))
                    {
                        return ((bool)values[0] | (bool)values[1]);
                    }
                    break;
                case "nand"://与非
                    if ((values[0] is bool) && (values[1] is bool))
                    {
                        return !((bool)values[0] & (bool)values[1]);
                    }
                    break;
                case "and":
                    if ((values[0] is bool) && (values[1] is bool))
                    {
                        return ((bool)values[0] & (bool)values[1]);
                    }
                    break;

                default:
                    break;
            }

            return null;
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
