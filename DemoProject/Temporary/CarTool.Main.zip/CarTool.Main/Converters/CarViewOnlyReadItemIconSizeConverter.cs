﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Data;

namespace CarTool.Main.Converters
{
   public class CarViewOnlyReadItemIconSizeConverter : IValueConverter
    {
        
        private const double SizeRate = 70 / 50;//49/35

        private const double ItemSuitMinWidth =96;
        private const double ItemSuitMaxWidth = 156;

        //假定ListBoxItem左右间距为2,纵向滚动条宽为8
        //  private const double ExtraWidth = 16;

        private const double ScaleRate=8;//缩放比率

        private const double MinWith=49;
        private const double MaxHeight = 50;
        private const double MinHeight=35;
        private const double MaxWith = 70;
        /// <summary>
        /// 根据ListBoxItem宽度确定IconSize
        /// </summary>
        /// <param name="value"></param>
        /// <param name="targetType"></param>
        /// <param name="parameter"></param>
        /// <param name="culture"></param>
        /// <returns></returns>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            double _value = 0;
            if(value is double)
            {
                // double temp= System.Convert.ToDouble(value);
                var temp = (double)value;
                if (temp <= 0) return 0;
                var _temp = (temp - ItemSuitMinWidth);
                var s = (string)parameter;
                if (s != null)
                    switch (s.ToLower()) {
                        case "width":
                            if (temp < ItemSuitMinWidth) return MinWith;
                            if (temp > ItemSuitMaxWidth) return MaxWith;

                            return MinWith + _temp / ScaleRate;

                        case "height":
                            if (temp <= ItemSuitMinWidth) return MinHeight;
                            if (temp >= ItemSuitMaxWidth) return MaxHeight;

                            return MinHeight + _temp / (ScaleRate * SizeRate);

                        default:
                            break;
                    }
            }
            return _value;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
