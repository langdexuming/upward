﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media.Imaging;
using System.Windows.Media;
namespace CarTool.Main.Converters
{
    public class ImageResourcePathConverter: IValueConverter
    {
        private string ImageDirectory = "/CarTool.Main;component/";

        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if ((value == null) || ((string)value == ""))
                return DependencyProperty.UnsetValue;

            var imagePath = Path.Combine(ImageDirectory, (string)value);
            return imagePath;
           // return new BitmapImage(new Uri(imagePath,UriKind.Relative));
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotSupportedException("The method or operation is not implemented.");
        }
    }
}
