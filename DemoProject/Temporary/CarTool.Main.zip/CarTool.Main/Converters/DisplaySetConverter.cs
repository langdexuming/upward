﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Data;

namespace CarTool.Main.Converters
{
    class DisplaySetConverter : IValueConverter
    {
        /// <summary>
        /// 根据不同的checkBox和对应值确定过滤模式
        /// </summary>
        /// <param name="value"></param>
        /// <param name="targetType"></param>
        /// <param name="parameter"></param>
        /// <param name="culture"></param>
        /// <returns></returns>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            bool convertValue = false;
            if (value is int)
            {
                switch ((int)value)
                {
                    case 0:
                        break;
                    case 1:
                        var s = (string)parameter;
                        if (s != null && s.Equals("Within"))
                            convertValue = true;
                        break;
                    case 2:
                        var o = (string)parameter;
                        if (o != null && o.Equals("Period"))
                            convertValue = true;
                        break;
                }
            }
            return convertValue;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            int backValue=0;
            if(value is bool)
            {
                switch ((string)parameter) {
                    case "Within"://n sec within
                        if ((bool)value)
                            backValue = 1;
                        break;
                    case "Period"://period 
                        if ((bool)value)
                            backValue = 2;

                        break;
                }

            }
            return backValue;
        }
    }
}
