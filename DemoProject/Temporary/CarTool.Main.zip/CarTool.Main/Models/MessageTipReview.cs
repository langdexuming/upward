﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace CarTool.Main.Models
{
    public class MessageTipReview : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        public void OnPropertyChanged(PropertyChangedEventArgs e)
        {
            PropertyChanged?.Invoke(this, e);
        }

        public MessageTipReview(string _content,bool _isLast=false)
        {
            this.Content = _content;
            this._isLast = _isLast;
        }

        public string Content { get; set; }

        public bool IsLast
        {
            get
            {
                return _isLast;
            }

            set
            {
                _isLast = value;
                OnPropertyChanged(new PropertyChangedEventArgs("IsLast"));
            }
        }

        private bool _isLast;
    }
}
