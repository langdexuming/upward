﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CarTool.Main.Models
{
    public class DataTypeSpecial:DataTypeBase
    {
        public DataTypeSpecial(DataTypeBase dataTyptBase) : base(dataTyptBase)
        {

        }

         public override string ToString()
        {
            return "命令ID：" + OrderID + " Can通道: " + CanID + " " + DataTypeName + " " + GetFrameFormatName(RemoteFlag) + " " + GetFrameTypeName(ExternFlag);
        }

        public DataTypeSpecial(byte dataTypeID,
            string dataTypeName, string orderID, byte canID, string englishName,
            byte externFlag, byte remoteFlag) : base(dataTypeID,
             dataTypeName, orderID, canID, englishName, externFlag, remoteFlag)
        {

        }

        public DataTypeSpecial()
        {
        }

        public override DataTypeBase Copy()
        {
            var obj = new DataTypeSpecial();
            return BasePartCopy(obj);
        }
    }
}
