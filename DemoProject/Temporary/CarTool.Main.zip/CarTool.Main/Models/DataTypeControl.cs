﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace CarTool.Main.Models
{
    class DataTypeControl : DataTypeBase
    {
        private string _frameData = "";
        private string _algorithmText = "";

        /// <summary>
        /// 提供强转
        /// </summary>
        /// <param name="_dataTypeBaseObject"></param>
        public DataTypeControl(DataTypeBase _dataTypeBaseObject)
            :base(_dataTypeBaseObject)
        {
           // this.FrameData = "";
        }
        public override void OnPropertyChanged(PropertyChangedEventArgs e)
        {
            base.OnPropertyChanged(e);
            if (string.CompareOrdinal(e.PropertyName,"EnglishName")==0)
            {
                this.AlgorithmText = this.FrameData;
            }
        }

        public override DataTypeBase Copy()
        {
            var obj = new DataTypeControl
            {
                FrameData = _frameData,
                _algorithmText = _algorithmText
            };
            return BasePartCopy(obj);
        }
        private DataTypeControl()
        {

        }

        public DataTypeControl(byte dataTypeID, 
            string dataTypeName, string orderID, byte canID,string englishName,
             byte externFlag, byte remoteFlag,
            string frameData) :base(dataTypeID,
             dataTypeName, orderID, canID, englishName, externFlag, remoteFlag)
        {
            //直接触发Set业务
            this.FrameData = frameData;
        }
        public override string ToString()
        {
            return " Can通道: " + CanID + " " + DataTypeName   + "  控制数据：" + ConvertToTextFrom(FrameData);
            // return "命令ID：" + OrderId + " Can通道: " + CanID + " " + DataTypeName + " " + GetFrameFormatName(RemoteFlag) + " " + GetFrameTypeName(ExternFlag) + "  控制数据：" + FrameData;
        }
        public string ConvertToTextFrom(string frameData)
        {
            return frameData.Replace("\t","  ");
        }
        public string FrameData
        {
            get
            { //读与写入值设为不同
                return _frameData;
            }

            set
            {
                this._frameData = value;
                OnPropertyChanged(new PropertyChangedEventArgs("AlgorithmText"));
                OnPropertyChanged(new PropertyChangedEventArgs("FrameData"));
            }

        }


        public string AlgorithmText
        {
            get
            {
                return this.EnglishName + "="+"\n" + this._frameData;
            }
            set
            {
                this._algorithmText = value;
                this._frameData = value;
                OnPropertyChanged(new PropertyChangedEventArgs("AlgorithmText"));
            }
        }
    }
}
