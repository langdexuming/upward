﻿using CarTool.Main.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using CarInfoDB;

namespace CarTool.Main.Models
{
    public class ImageShowReview : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        public void OnPropertyChanged(PropertyChangedEventArgs e)
        {
            PropertyChanged?.Invoke(this, e);
        }

        public ImageShowReview(string _positiveImgUrl="",string _adverseImgUrl="", string _positiveTipText = "", string _adverseTipText = "",string _positiveTipVoiceUri="",string _adverseTipVoiceUri="",bool _state=false)
        {
            this._positiveImgUrl = _positiveImgUrl;
            this._adverseImgUrl = _adverseImgUrl;
            this.PositiveTipText = _positiveTipText;
            this.AdverseTipText = _adverseTipText;
            this.PositiveTipVoiceUri = _positiveTipVoiceUri;
            this.AdverseTipVoiceUri = _adverseTipVoiceUri;

            this.State = _state;
        }
        /// <summary>
        /// 弃用
        /// </summary>
        private bool _canPlaySound;
        public bool CanPlaySound
        {
            get
            {
                return _canPlaySound;
            }

            set
            {
                _canPlaySound = value;
                OnPropertyChanged(new PropertyChangedEventArgs("CanPlaySound"));
            }
        }

        private bool _state;
        private string _imgUrl;

        /// <summary>
        /// 通过该状态修改Image
        /// </summary>
        public bool State
        {
            get
            {
                return _state;
            }
            set
            {

                _state = value;
                if (!value)
                {
                    this.ImgUrl = _adverseImgUrl;
                    this.TipText = AdverseTipText;
                    this.TipVoiceUri = AdverseTipVoiceUri;
                }
                else
                {
                    this.ImgUrl = _positiveImgUrl;
                    this.TipText = PositiveTipText;
                    this.TipVoiceUri = PositiveTipVoiceUri;
                }

            }
        }
        private readonly string _positiveImgUrl;
        private readonly string _adverseImgUrl;


        [Bindable(true)]
        public string ImgUrl
        {
            get
            {
                return _imgUrl;
            }
            set
            {
                _imgUrl = value;
                OnPropertyChanged(new PropertyChangedEventArgs("ImgUrl"));
            }
        }

        public string TipText { get; set; }


        public string TipVoiceUri { get; set; }

        public string PositiveTipText { get; set; }

        public string AdverseTipText { get; set; }

        public string PositiveTipVoiceUri { get; set; }

        public string AdverseTipVoiceUri { get; set; }

        private InfoItem _infoItem;
        public InfoItem InfoItem
        {
            get
            {
                return _infoItem;
            }
            set
            {
                _infoItem = value;
                
                if (value != null)
                {
                    _infoItem.PropertyChanged += (s,e)=> {

                        if (e.PropertyName == nameof(_infoItem.PositiveTip))
                        {
                            PositiveTipText = _infoItem.PositiveTip;
                        }

                        if (e.PropertyName == nameof(_infoItem.OppositeTip))
                        {
                            AdverseTipText = _infoItem.OppositeTip;
                        }
                    };
                }
            }
        }
    }
}
