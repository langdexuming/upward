﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace CarTool.Main.Models
{
    public class DataTypeAlgorithm : DataTypeBase
    {
        private string _algorithm;
        private string _algorithmText;

        private DataTypeAlgorithm()
        {

        }

        public DataTypeAlgorithm(DataTypeBase dataTypeBase) : base(dataTypeBase)
        {

        }

        public override string ToString()
        {
            return "命令ID：" + OrderID + " Can通道: " + CanID + " " + DataTypeName + " " + GetFrameFormatName(RemoteFlag) + " " + GetFrameTypeName(ExternFlag)
                 + " 算法：" + Algorithm;
        }

        public override void OnPropertyChanged(PropertyChangedEventArgs e)
        {
            base.OnPropertyChanged(e);
            if (string.CompareOrdinal(e.PropertyName, "EnglishName") == 0)
            {
                this.AlgorithmText = this.Algorithm;
            }
        }

        public DataTypeAlgorithm(byte dataTypeID,
            string dataTypeName, string orderID, byte canID, string englishName, byte externFlag, byte remoteFlag,
            string algorithm
        ) : base(dataTypeID,
            dataTypeName, orderID, canID, englishName, externFlag, remoteFlag)
        {
            //直接触发Set
            this.Algorithm = algorithm;
        }
        public override DataTypeBase Copy()
        {
            var obj = new DataTypeAlgorithm
            {
                _algorithm = _algorithm,
                _algorithmText = _algorithmText
            };
            
            return BasePartCopy(obj);
        }
        public string Algorithm
        {
            get
            {
                return _algorithm;
            }
            set
            {
                _algorithm = value;
                OnPropertyChanged(new System.ComponentModel.PropertyChangedEventArgs("Algorithm"));
            }
        }
        public string AlgorithmText
        {
            get
            {
                return this.EnglishName + "=" + this._algorithm;
            }
            set
            {
                this._algorithm = value;
                _algorithmText = value;
                OnPropertyChanged(new System.ComponentModel.PropertyChangedEventArgs("AlgorithmText"));
            }
        }
    }
}
