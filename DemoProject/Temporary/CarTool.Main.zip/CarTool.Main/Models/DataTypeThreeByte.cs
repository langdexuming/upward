﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace CarTool.Main.Models
{
   public class DataTypeThreeByte:DataTypeBase
    {
        private string _algorithm="";
        private string _algorithmText="";

        /// <summary>
        /// 提供强转
        /// </summary>
        /// <param name="_dataTypeBaseObject"></param>
        public DataTypeThreeByte(DataTypeBase _dataTypeBaseObject)
            :base(_dataTypeBaseObject)
        {
            //this.Algorithm = "";
        }


        public DataTypeThreeByte(byte dataTypeID,
            string dataTypeName, string orderID, byte canID, string englishName,
            byte externFlag, byte remoteFlag,
         byte highEffectiveByte, byte highMask,
         byte middleEffectiveByte, byte middleMask,
         byte lowEffectiveByte, byte lowMask,
         string algorithm) : base(dataTypeID,dataTypeName, orderID, canID,englishName, externFlag, remoteFlag)
        {
            this.HighEffectiveByte = highEffectiveByte;
            this.HighMask = highMask;
            this.MiddleEffectiveByte = middleEffectiveByte;
            this.MiddleMask = middleMask;
            this.LowEffectiveByte = lowEffectiveByte;
            this.LowMask = lowMask;

            this.Algorithm = algorithm;
        }

        private DataTypeThreeByte()
        {
        }
        public override void OnPropertyChanged(PropertyChangedEventArgs e)
        {
            base.OnPropertyChanged(e);
            if (string.CompareOrdinal(e.PropertyName, "EnglishName") == 0)
            {
                this.AlgorithmText = this.Algorithm;
            }
        }
        public override string ToString()
        {
            return "命令ID：" + OrderID + " Can通道: " + CanID + " " + DataTypeName + " " + GetFrameFormatName(RemoteFlag) + " " + GetFrameTypeName(ExternFlag) + " 高位有效字节：" + HighEffectiveByte +
                                     " 高位掩码：" + HighMask + " 中位有效字节：" + MiddleEffectiveByte +
                                     " 中位掩码：" + MiddleMask + " 低位有效字节：" + LowEffectiveByte +
                                       " 低位掩码：" + LowMask + " 算法：" + Algorithm;
        }

        public override DataTypeBase Copy()
        {
            DataTypeThreeByte obj = new DataTypeThreeByte
            {
                HighEffectiveByte = HighEffectiveByte,
                HighMask = HighMask,
                MiddleEffectiveByte = MiddleEffectiveByte,
                MiddleMask = MiddleMask,
                LowEffectiveByte = LowEffectiveByte,
                LowMask = LowMask,
                _algorithm = _algorithm,
                _algorithmText = _algorithmText
            };

            return BasePartCopy(obj);
        }


        public byte HighEffectiveByte { get; set; } = 0;

        public byte HighMask { get; set; } = 0;

        public byte MiddleEffectiveByte { get; set; } = 0;

        public byte MiddleMask { get; set; } = 0;

        public byte LowEffectiveByte { get; set; } = 0;

        public byte LowMask { get; set; } = 0;

        public string Algorithm
        {
            get
            {
                return _algorithm;
            }

            set
            {
                this._algorithm = value;
                OnPropertyChanged(new PropertyChangedEventArgs("Algorithm"));
            }
        }

        public string AlgorithmText
        {
            get
            {
                return this.EnglishName + "=" + this._algorithm;
            }

            set
            {
                this._algorithm = value;
                this._algorithmText = value;
                OnPropertyChanged(new System.ComponentModel.PropertyChangedEventArgs("AlgorithmText"));
            }
        }


    }
}
