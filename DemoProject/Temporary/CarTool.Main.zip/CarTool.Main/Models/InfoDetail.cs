﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataAcquisitionCenter.Models
{
    public class InfoDetail
    {
        private string _name;
        private string _content;
        private string _leftTopValue;
        private string _rightTopValue;
        private string _leftBottomValue;
        private string _rightBottomValue;

        public InfoDetail(string _name, string _content, string _leftTopValue="", string _rightTopValue="", string _leftBottomValue="", string _rightBottomValue="")
        {
            this._name = _name;
            this._content = _content;
            this._leftTopValue = _leftTopValue;
            this._rightTopValue = _rightTopValue;
            this._leftBottomValue = _leftBottomValue;
            this._rightBottomValue = _rightBottomValue;
        }
        public InfoDetail()
        {
           //
        }

        public string Name
        {
            get
            {
                return _name;
            }

            set
            {
                _name = value;
            }
        }

        public string Content
        {
            get
            {
                return _content;
            }

            set
            {
                _content = value;
            }
        }

        public string LeftTopValue
        {
            get
            {
                return _leftTopValue;
            }

            set
            {
                _leftTopValue = value;
            }
        }

        public string RightTopValue
        {
            get
            {
                return _rightTopValue;
            }

            set
            {
                _rightTopValue = value;
            }
        }

        public string LeftBottomValue
        {
            get
            {
                return _leftBottomValue;
            }

            set
            {
                _leftBottomValue = value;
            }
        }

        public string RightBottomValue
        {
            get
            {
                return _rightBottomValue;
            }

            set
            {
                _rightBottomValue = value;
            }
        }
    }
}
