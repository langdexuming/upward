﻿using CarTool.Main.Models.Base;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using CarTool.Main.HeaderFile;

namespace CarTool.Main.Models
{
   public class CanDataStandardReview:IFormattable,CanDataBoredom.IdentityKey
    {
        public int Id { get; set; }

        public string Identity
        {
            get
            {
                if (CanDataBaseObject != null)
                {
                    return CanDataBaseObject.Identity;
                }
                return string.Empty;
            }
        }

        public CanDataStandardReview(CanDataBase canDataBaseObject)
        {
            CanDataBaseObject = canDataBaseObject;
        }

        public CanDataBase CanDataBaseObject { get; set; }

        private CanDataStandardReview()
        {

        }

        public CanDataStandardReview(CanDataStandardReview other)
        {
            CanDataBaseObject = new CanDataBase(other.CanDataBaseObject);
            this.Id = other.Id;
        }

        public CanDataStandardReview Copy()
        {
            return new CanDataStandardReview
            {
                CanDataBaseObject = this.CanDataBaseObject,
                Id = this.Id
            };
        }

        public override string ToString()
        {
            return this.ToString("Text");
        }
        public string ToString(string format)
        {
            return ToString(format, CultureInfo.CurrentCulture);
        }

        public string ToString(string format, IFormatProvider formatProvider)
        {
            if (CanDataBaseObject != null)
            {
                return this.CanDataBaseObject.ToString(format, CultureInfo.CurrentCulture);
            }
            return string.Empty;
        }
    }
}
