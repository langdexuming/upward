﻿using CarInfoDB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CarTool.Main.Models
{
    public class Infomation
    {
        public string DataTypeName { get; }

        public ICollection<InfoItem> InfoItems { get; }

        public Infomation(string dataTypeName, ICollection<InfoItem> infoItems)
        {
            DataTypeName = dataTypeName;
            InfoItems = infoItems;
        }
    }
}
