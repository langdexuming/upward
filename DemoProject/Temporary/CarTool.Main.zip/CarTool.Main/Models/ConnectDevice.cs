﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace CarTool.Main.Models
{
    public class ConnectDevice :INotifyPropertyChanged
    {
        private bool _isOnline;
        private string _connectState;
        private string _imgUrl;
        private string _text;
        private string _englishText;

        public ConnectDevice(bool _isOnline = false)
        {
            this._isOnline = _isOnline;
            if (!_isOnline)
            {
                _text = "离线模式";
                _connectState = "已关闭";
                _imgUrl = "Images/offline.png";
                _englishText = "offline";
            }
            else
            {
                _text = "在线模式";
                _connectState = "已打开";
                _englishText = "online";
                _imgUrl = "Images/online.png";
            }
        }

        public string ImgUrl
        {
            get
            {
                return _imgUrl;
            }

            set
            {
                _imgUrl = value;
                OnPropertyChanged(new PropertyChangedEventArgs("ImgUrl"));
            }
        }

        public string Text
        {
            get
            {
                return _text;
            }

            set
            {
                _text = value;
                OnPropertyChanged(new PropertyChangedEventArgs("Text"));
            }
        }

        public string ConnectState
        {
            get
            {
                return _connectState;
            }

            set
            {
                _connectState = value;
                OnPropertyChanged(new PropertyChangedEventArgs("ConnectState"));
            }
        }

        public string BaudRate { get; set; }

        public bool IsOnline
        {
            get
            {
                return _isOnline;
            }

            set
            {
                _isOnline = value;
                OnPropertyChanged(new PropertyChangedEventArgs("IsOnline"));
            }
        }

        public string BaudRate2 { get; set; }

        public string EnglishText
        {
            get
            {
                return _englishText;
            }

            set
            {
                _englishText = value;
                OnPropertyChanged(new PropertyChangedEventArgs("EnglishText"));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged(PropertyChangedEventArgs e)
        {
            PropertyChanged?.Invoke(this, e);
        }
        public void SetConnectState(bool state)
        {
            this.IsOnline = state;
            if (state)
            {
                this.Text = "在线模式";
                this.ConnectState = "已打开";
                this.EnglishText = "online";
                this.ImgUrl = "Images/online.png";
            }
            else
            {
                this.Text = "离线模式";
                this.ConnectState = "已关闭";
                this.EnglishText = "offline";
                this.ImgUrl = "Images/offline.png";
            }
            
        }

    }
}
