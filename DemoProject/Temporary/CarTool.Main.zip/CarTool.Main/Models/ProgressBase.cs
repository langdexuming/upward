﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace CarTool.Main.Models
{
   public class ProgressBase : INotifyPropertyChanged
    {
        private double _percentageValue;

        public double PercentageValue
        {
            get
            {
                return _percentageValue;
            }

            set
            {
                _percentageValue = value;
                OnPropertyChanged(new PropertyChangedEventArgs("PercentageValue"));
            }
        }

        public int SuccessRate
        {
            get
            {
                return _successRate;
            }

            set
            {
                _successRate = value;
                OnPropertyChanged(new PropertyChangedEventArgs("SuccessRate"));
            }
        }

        private int _successRate=100;

        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged(PropertyChangedEventArgs e)
        {
            PropertyChanged?.Invoke(this, e);
        }

      
    }
}
