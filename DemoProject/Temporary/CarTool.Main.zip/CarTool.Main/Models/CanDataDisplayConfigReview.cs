﻿using System.ComponentModel;

namespace CarTool.Main.Models
{
    public class CanDataDisplayConfigReview : INotifyPropertyChanged
    {
        private int _countdownTimer; //倒计时时间

        private int _displayTickMode; //0 无 1 多少秒以内 2范围

        private bool _isCanFilter = true;

        private bool _isFilterMinorCanData;

        private bool _isRunCanData = true;

        private string _orderID = "";


        public CanDataDisplayConfigReview()
        {
            AdderSubstractorReview = new AdderSubstractorReview(0);
            MinAdderSubstractorReview = new AdderSubstractorReview(0);
            MaxAdderSubstractorReview = new AdderSubstractorReview(0);


            AdderSubstractorReview.PropertyChanged += _adderSubstractorReview_PropertyChanged;
            MinAdderSubstractorReview.PropertyChanged += _minAdderSubstractorReview_PropertyChanged;
            MaxAdderSubstractorReview.PropertyChanged += _maxAdderSubstractorReview_PropertyChanged;
        }

        public string OrderID
        {
            get { return _orderID; }

            set
            {
                _orderID = value;
                OnPropertyChanged(new PropertyChangedEventArgs("OrderId"));
            }
        }

        public bool IsRunCanData
        {
            get { return _isRunCanData; }

            set
            {
                _isRunCanData = value;
                OnPropertyChanged(new PropertyChangedEventArgs("IsRunCanData"));
            }
        }

        public bool IsFilterMinorCanData
        {
            get { return _isFilterMinorCanData; }

            set
            {
                _isFilterMinorCanData = value;
                OnPropertyChanged(new PropertyChangedEventArgs("IsFilterMinorCanData"));
            }
        }

        public int WithinMsec { get; set; }

        public int MinMsec { get; set; }

        public int MaxMsec { get; set; }

        /// <summary>
        ///     数据显示模式 0-正常 1-1级匹配 2-2级匹配
        /// </summary>
        public int DisplayTickMode
        {
            get { return _displayTickMode; }

            set
            {
                _displayTickMode = value;
                OnPropertyChanged(new PropertyChangedEventArgs("DisplayTickMode"));
            }
        }

        public AdderSubstractorReview AdderSubstractorReview { get; set; }

        public AdderSubstractorReview MinAdderSubstractorReview { get; set; }

        public AdderSubstractorReview MaxAdderSubstractorReview { get; set; }

        public int FilterDisplayStartTick { get; set; } = 0;

        public int CountdownTimer
        {
            get { return _countdownTimer; }

            set
            {
                _countdownTimer = value;
                OnPropertyChanged(new PropertyChangedEventArgs("CountdownTimer"));
            }
        }

        /// <summary>
        ///     后期去掉
        /// </summary>
        public bool IsCanFilter
        {
            get { return _isCanFilter; }

            set
            {
                _isCanFilter = value;
                OnPropertyChanged(new PropertyChangedEventArgs("IsCanFilter"));
            }
        }


        public event PropertyChangedEventHandler PropertyChanged;

        private void _maxAdderSubstractorReview_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            switch (e.PropertyName)
            {
                case "Number":
                    MaxMsec = MaxAdderSubstractorReview.Number;
                    break;
                default:
                    break;
            }
        }

        private void _minAdderSubstractorReview_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            switch (e.PropertyName)
            {
                case "Number":
                    MinMsec = MinAdderSubstractorReview.Number;
                    break;
                default:
                    break;
            }
        }

        private void _adderSubstractorReview_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            switch (e.PropertyName)
            {
                case "Number":
                    WithinMsec = AdderSubstractorReview.Number;
                    break;
                default:
                    break;
            }
        }

        public void OnPropertyChanged(PropertyChangedEventArgs e)
        {
            PropertyChanged?.Invoke(this, e);
        }
    }
}