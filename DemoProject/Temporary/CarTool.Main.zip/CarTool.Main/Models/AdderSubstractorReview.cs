﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CarTool.Main.Models
{
    public class AdderSubstractorReview : Base.NumberBase
    {
        public AdderSubstractorReview(int _number) : base(_number)
        {

        }
    }
}
