﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace CarTool.Main.Models
{
    public class DataTypeSingleByte:DataTypeBase
    {
        private string _algorithm="";

        private string _algorithmText;


        /// <summary>
        /// 提供强转
        /// </summary>
        /// <param name="_dataTypeBaseObject"></param>
        public DataTypeSingleByte(DataTypeBase _dataTypeBaseObject)
            :base(_dataTypeBaseObject)
        {
            //this.Algorithm = "";
        }

        public override void OnPropertyChanged(PropertyChangedEventArgs e)
        {
            base.OnPropertyChanged(e);
            if (string.CompareOrdinal(e.PropertyName, "EnglishName") == 0)
            {
                this.AlgorithmText = this.Algorithm;
            }
        }
        public DataTypeSingleByte(byte dataTypeID, 
            string dataTypeName, string orderID, byte canID, string englishName,
            byte externFlag, byte remoteFlag,byte effectiveByte,byte mask,
            string algorithm) : base(dataTypeID,
             dataTypeName, orderID, canID, englishName, externFlag, remoteFlag)
        {
            this.EffectiveByte = effectiveByte;
            this.Mask = mask;

            this.Algorithm = algorithm;
        }


        private DataTypeSingleByte()
        {
        }

        public override DataTypeBase Copy()
        {
            var obj = new DataTypeSingleByte
            {
                EffectiveByte = EffectiveByte,
                Mask = Mask,
                _algorithm = _algorithm,
                _algorithmText = _algorithmText
            };

            return BasePartCopy(obj);
        }


        public override string ToString()
        {
            return "命令ID：" + OrderID + " Can通道: " + CanID + " " + DataTypeName + " " + GetFrameFormatName(RemoteFlag) + " " + GetFrameTypeName(ExternFlag) + " 有效字节：" + EffectiveByte +
                                    " 掩码：" + Mask + " 算法：" + Algorithm;
        }

        public byte EffectiveByte { get; set; } = 0;

        public byte Mask { get; set; } = 0;

        public string Algorithm
        {
            get
            {
                return _algorithm;
            }

            set
            {
                _algorithm = value;
                OnPropertyChanged(new System.ComponentModel.PropertyChangedEventArgs("Algorithm"));
            }
        }
        public string AlgorithmText
        {
            get
            {
                return this.EnglishName+"="+this._algorithm;
            }

            set
            {
                this._algorithm = value;
                this._algorithmText = value;
                OnPropertyChanged(new System.ComponentModel.PropertyChangedEventArgs("AlgorithmText"));
            }
        }
    }
}
