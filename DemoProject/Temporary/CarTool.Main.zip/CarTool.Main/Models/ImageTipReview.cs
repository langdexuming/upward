﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace CarTool.Main.Models
{
    /// <summary>
    /// 暂时废弃
    /// </summary>
    public class ImageTipReview : INotifyPropertyChanged
    {
        public enum ControlStateId {
            Default,
            FiringUp,//点火
            Stalled,//熄火
            LockUp,//上锁
            Unlocking,//开锁
            OpenTrunk,//打开后备箱
            CloseTrunk,//关闭后备箱
            TurnOnHazardLights,//打开危险灯
            TurnOffHazardLights,//关闭危险灯
            OpeningSpeakers,//打开扬声器
            ClosingSpeakers,//关闭扬声器
            WaterTemperatureQuery,//水温查询
            SpeedQuery,//车速查询
            FaultCodeQuery,//故障代码查询
            FourWheelVehicleSpeedQuery,//四轮车速查询
            AirConditioningStatusQuery,//空调状态查询
            BatteryVoltageQuery,//电池电压查询
            RisingFrontLeftWindow,//(左前)窗升
            DroppingFrontLeftWindow,//(左前)窗降
            RisingFrontRightWindow,//(右前)窗升
            DroppingFrontRightWindow,//(右前)窗降
            RisingRearLeftWindow,//(左后)窗升
            DroppingRearLeftWindow,//(左后)窗降
            RisingRearRightWindow,//(右后)窗升
            DroppingRearRightWindow//(右后)窗降
        }

        public event PropertyChangedEventHandler PropertyChanged;

        public void OnPropertyChanged(PropertyChangedEventArgs e)
        {
            PropertyChanged?.Invoke(this, e);

        }

        public ImageTipReview(ControlStateId _stateId= ControlStateId.Default)
        {
            this._stateId = _stateId;
        }

        private string _imgUrl;

        private ControlStateId _stateId;

        public ControlStateId StateId
        {
            get
            {
                return _stateId;
            }

            set
            {
                _stateId = value;
                switch (_stateId) {
                    case ControlStateId.Default:
                        ImgUrl = "";
                        break;
                    case ControlStateId.FiringUp://点火
                        ImgUrl = "";
                        break;
                    case ControlStateId.Stalled://熄火
                        ImgUrl = "";
                        break;
                    case ControlStateId.LockUp://上锁
                        ImgUrl = "Resources\\drawable_hdpi\\shangshuo_seletor.png";
                        break;
                    case ControlStateId.Unlocking://开锁
                        ImgUrl = "Resources\\drawable_hdpi\\jieshuo_seletor.png";
                        break;
                    case ControlStateId.OpenTrunk://打开后备箱
                        ImgUrl = "Resources\\drawable_hdpi\\houbeixiang.png";
                        break;
                    case ControlStateId.CloseTrunk://关闭后备箱
                        ImgUrl = "";
                        break;
                    case ControlStateId.TurnOnHazardLights://打开危险灯
                        ImgUrl = "";
                        break;
                    case ControlStateId.TurnOffHazardLights://关闭危险灯
                        ImgUrl = "";
                        break;
                    case ControlStateId.OpeningSpeakers://打开扬声器
                        ImgUrl = "";
                        break;
                    case ControlStateId.ClosingSpeakers://关闭扬声器
                        ImgUrl = "";
                        break;
                    case ControlStateId.WaterTemperatureQuery://水温查询
                        ImgUrl = "";
                        break;
                    case ControlStateId.SpeedQuery://车速查询
                        ImgUrl = "";
                        break;
                    case ControlStateId.FaultCodeQuery://故障代码查询
                        ImgUrl = "";
                        break;
                    case ControlStateId.FourWheelVehicleSpeedQuery://四轮车速查询
                        ImgUrl = "";
                        break;
                    case ControlStateId.AirConditioningStatusQuery://空调状态查询
                        ImgUrl = "";
                        break;
                    case ControlStateId.BatteryVoltageQuery://电池电压查询
                        ImgUrl = "";
                        break;
                    case ControlStateId.RisingFrontLeftWindow://(左前)窗升
                        ImgUrl = "";
                        break;
                    case ControlStateId.DroppingFrontLeftWindow://(左前)窗降
                        ImgUrl = "";
                        break;
                    case ControlStateId.RisingFrontRightWindow://(右前)窗升
                        ImgUrl = "";
                        break;
                    case ControlStateId.DroppingFrontRightWindow://(右前)窗降
                        ImgUrl = "";
                        break;
                    case ControlStateId.RisingRearLeftWindow://(左后)窗升
                        ImgUrl = "";
                        break;
                    case ControlStateId.DroppingRearLeftWindow://(左后)窗降
                        ImgUrl = "";
                        break;
                    case ControlStateId.RisingRearRightWindow://(右后)窗升
                        ImgUrl = "";
                        break;
                    case ControlStateId.DroppingRearRightWindow://(右后)窗降
                        ImgUrl = "";
                        break;
                    default:
                        ImgUrl = "";
                        break;
                }

            }
        }

        public string ImgUrl
        {
            get
            {
                return _imgUrl;
            }

            set
            {
                _imgUrl = value;
                OnPropertyChanged(new PropertyChangedEventArgs("ImgUrl"));
            }
        }
    }
}
