﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace DataAcquisitionCenter.Models
{
    public class AutoSpotBaudRate: INotifyPropertyChanged
    {
        private string _state;
        private string _baudRate;
        private string _result;
        private byte _channel;
        private string _minValue;
        private string _maxValue;

        public AutoSpotBaudRate(string _state, string _baudRate, string _result, byte _channel, string _minValue, string _maxValue)
        {
            this._state = _state;
            this._baudRate = _baudRate;
            this._result = _result;
            this._channel = _channel;
            this._minValue = _minValue;
            this._maxValue = _maxValue;
        }

        public AutoSpotBaudRate(string _state, string _baudRate, string _result, byte _channel)
        {
            this._state = _state;
            this._baudRate = _baudRate;
            this._result = _result;
            this._channel = _channel;
        }


        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged(PropertyChangedEventArgs e)
        {
            if (PropertyChanged != null)
            {
               // System.Diagnostics.Debug.WriteLine("Channel" + " changed");
                PropertyChanged(this, e);
            }
        }
        public string State
        {
            get
            {
                return _state;
            }

            set
            {
                _state = value;
            }
        }

        public string BaudRate
        {
            get
            {
                return _baudRate;
            }

            set
            {
                _baudRate = value;
            }
        }

        public string Result
        {
            get
            {
                return _result;
            }

            set
            {
                _result = value;
            }
        }

        public byte Channel
        {
            get
            {
                return _channel;
            }

            set
            {
                _channel = value;
                OnPropertyChanged(new PropertyChangedEventArgs("Channel"));
                
            }
        }

        public string MinValue
        {
            get
            {
                return _minValue;
            }

            set
            {
                _minValue = value;
            }
        }

        public string MaxValue
        {
            get
            {
                return _maxValue;
            }

            set
            {
                _maxValue = value;
            }
        }
    }
}
