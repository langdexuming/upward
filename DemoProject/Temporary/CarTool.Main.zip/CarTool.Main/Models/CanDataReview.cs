﻿using System;
using System.ComponentModel;
using System.Globalization;
using System.Threading;
using System.Timers;
using CarTool.Main.HeaderFile;
using CarTool.Main.Models.Base;
using Timer = System.Timers.Timer;

namespace CarTool.Main.Models
{
    public class CanDataChangeColorModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged(PropertyChangedEventArgs e)
        {
            PropertyChanged?.Invoke(this, e);
        }

        private int _cellData1ColorId;
        private int _cellData2ColorId;
        private int _cellData3ColorId;
        private int _cellData4ColorId;
        private int _cellData5ColorId;
        private int _cellData6ColorId;
        private int _cellData7ColorId;
        private int _cellData8ColorId;

        private int _rowColorId;


        public int RowColorId
        {
            get
            {
                return _rowColorId;
            }

            set
            {
                //  if (this._rowColorId != value)
                {
                    _rowColorId = value;
                    OnPropertyChanged(new PropertyChangedEventArgs("RowColorId"));
                }
            }
        }

        public int CellData1ColorId
        {
            get
            {
                return _cellData1ColorId;
            }

            set
            {
                //  if (this._cellData1ColorId != value)
                {
                    _cellData1ColorId = value;
                    OnPropertyChanged(new PropertyChangedEventArgs("CellData1ColorId"));
                }
            }
        }

        public int CellData2ColorId
        {
            get
            {
                return _cellData2ColorId;
            }

            set
            {
                // if (this._cellData2ColorId != value)
                {
                    _cellData2ColorId = value;
                    OnPropertyChanged(new PropertyChangedEventArgs("CellData2ColorId"));
                }
            }
        }

        public int CellData3ColorId
        {
            get
            {
                return _cellData3ColorId;
            }


            set
            {
                // if (this._cellData3ColorId != value)
                {
                    _cellData3ColorId = value;
                    OnPropertyChanged(new PropertyChangedEventArgs("CellData3ColorId"));
                }
            }
        }

        public int CellData4ColorId
        {
            get
            {
                return _cellData4ColorId;
            }

            set
            {
                // if (this._cellData4ColorId != value)
                {
                    _cellData4ColorId = value;
                    OnPropertyChanged(new PropertyChangedEventArgs("CellData4ColorId"));
                }
            }
        }

        public int CellData5ColorId
        {
            get
            {
                return _cellData5ColorId;
            }

            set
            {
                // if (this._cellData5ColorId != value)
                {
                    _cellData5ColorId = value;
                    OnPropertyChanged(new PropertyChangedEventArgs("CellData5ColorId"));
                }
            }
        }

        public int CellData6ColorId
        {
            get
            {
                return _cellData6ColorId;
            }

            set
            {
                // if (this._cellData6ColorId != value)
                {
                    _cellData6ColorId = value;
                    OnPropertyChanged(new PropertyChangedEventArgs("CellData6ColorId"));
                }
            }
        }

        public int CellData7ColorId
        {
            get
            {
                return _cellData7ColorId;
            }

            set
            {
                // if (this._cellData7ColorId != value)
                {
                    _cellData7ColorId = value;
                    OnPropertyChanged(new PropertyChangedEventArgs("CellData7ColorId"));
                }
            }
        }

        public int CellData8ColorId
        {
            get
            {
                return _cellData8ColorId;
            }

            set
            {
                // if (this._cellData8ColorId != value)
                {
                    _cellData8ColorId = value;
                    OnPropertyChanged(new PropertyChangedEventArgs("CellData8ColorId"));
                }
            }
        }


    }
    public class CanDataReview : INotifyPropertyChanged, CanDataBoredom.IdentityKey, IFormattable
    {
        private int _id;
        private bool _isGoNow;

        public CanDataBase CanDataBaseObject { get; set; }

        public CanDataChangeColorModel CanDataChangeColorModelObject { get; set; }

        private readonly Timer Data1Timer;
        private readonly Timer Data2Timer;
        private readonly Timer Data3Timer;
        private readonly Timer Data4Timer;
        private readonly Timer Data5Timer;
        private readonly Timer Data6Timer;
        private readonly Timer Data7Timer;
        private readonly Timer Data8Timer;

        private readonly Timer RowTimer;

        private const int QuickTimeIntervalFirst = 500;

        private const int QuickTimeIntervalSecond = 100;

        private const int LowLevelResetTimeInterval=2000;//2s重置颜色标志

        private const int HighLevelResetTimeInterval = 500;//0.5s重置颜色标志

      //  private const int HighLevelResetTimeInterval = 100;

        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged(PropertyChangedEventArgs e)
        {
            PropertyChanged?.Invoke(this, e);
        }

        public override string ToString()
        {
            return ToString("Text"); 
        }
        public string ToString(string format)
        {
            return ToString(format, CultureInfo.CurrentCulture);
        }

        public string ToString(string format, IFormatProvider formatProvider)
        {
            if (CanDataBaseObject != null)
            {
                return this.CanDataBaseObject.ToString(format, CultureInfo.CurrentCulture);
            }
            return string.Empty;
        }

        /// <summary>
        /// 赋值（为对象赋值，而不是new）
        /// </summary>
        /// <param name="detailedCanData"></param>
        public void CanDataObjectAssign(CanDataBoredom.DetailedCanData detailedCanData)
        {
            //修改行颜色
            RowTimer.Enabled = false;
            RowTimer.Enabled = true; //刷新定时器
            
            CanDataChangeColorModelObject.RowColorId = 0;

            CanDataBaseObject.TimeInterval = detailedCanData.TimeInterval;
            if (detailedCanData.Length != CanDataBaseObject.Length)
            {
                //可选
                CanDataBaseObject.Length = detailedCanData.Length;
                CanDataBaseObject.RemoteFlag = detailedCanData.RemoteFlag;
                CanDataBaseObject.ExternFlag = detailedCanData.ExternFlag;
                AssignDefaultReviewData();
                CanDataBaseObject.AssignCanData(detailedCanData);
            }
            else
            {
                SmartAssignData(detailedCanData);
            }
        }
        /// <summary>
        /// 聪明赋值，有变化才赋值
        /// </summary>
        private void SmartAssignData(CanDataBoredom.DetailedCanData detailedCanData)
        {
            for (var i = 0; i < detailedCanData.Length; i++)
                switch (i)
                {
                    case 0:
                        CanDataBaseObject.Data1 = string.Format("{0:X2}", detailedCanData.Data[i]); //若在界面修改值，此处应该这样赋值
                        if (detailedCanData.DataIsChanged[i])
                            if (!Data1Timer.Enabled)
                            {
                                if (detailedCanData.DataChangedTimeInterval[i] < QuickTimeIntervalFirst)
                                {
                                    if (detailedCanData.DataChangedTimeInterval[i] < QuickTimeIntervalSecond)
                                        CanDataChangeColorModelObject.CellData1ColorId = 3;
                                    else
                                        CanDataChangeColorModelObject.CellData1ColorId = 2;
                                    Data1Timer.Interval = HighLevelResetTimeInterval;
                                }
                                else
                                {
                                    CanDataChangeColorModelObject.CellData1ColorId = 1;
                                    Data1Timer.Interval = LowLevelResetTimeInterval;
                                }
                                Data1Timer.Enabled = true;
                            }
                        break;
                    case 1:
                        CanDataBaseObject.Data2 = string.Format("{0:X2}", detailedCanData.Data[i]);
                        if (detailedCanData.DataIsChanged[i])
                            if (!Data2Timer.Enabled)
                            {
                                if (detailedCanData.DataChangedTimeInterval[i] < QuickTimeIntervalFirst)
                                {
                                    if (detailedCanData.DataChangedTimeInterval[i] < QuickTimeIntervalSecond)
                                        CanDataChangeColorModelObject.CellData2ColorId = 3;
                                    else
                                        CanDataChangeColorModelObject.CellData2ColorId = 2;
                                    Data2Timer.Interval = HighLevelResetTimeInterval;
                                }
                                else
                                {
                                    CanDataChangeColorModelObject.CellData2ColorId = 1;
                                    Data2Timer.Interval = LowLevelResetTimeInterval;
                                }
                                Data2Timer.Enabled = true;
                            }
                        break;
                    case 2:
                        CanDataBaseObject.Data3 = string.Format("{0:X2}", detailedCanData.Data[i]);
                        if (detailedCanData.DataIsChanged[i])
                            if (!Data3Timer.Enabled)
                            {
                                if (detailedCanData.DataChangedTimeInterval[i] < QuickTimeIntervalFirst)
                                {
                                    if (detailedCanData.DataChangedTimeInterval[i] < QuickTimeIntervalSecond)
                                        CanDataChangeColorModelObject.CellData3ColorId = 3;
                                    else
                                        CanDataChangeColorModelObject.CellData3ColorId = 2;
                                    Data3Timer.Interval = HighLevelResetTimeInterval;
                                }
                                else
                                {
                                    CanDataChangeColorModelObject.CellData3ColorId = 1;
                                    Data3Timer.Interval = LowLevelResetTimeInterval;
                                }
                                Data3Timer.Enabled = true;
                            }

                        break;
                    case 3:
                        CanDataBaseObject.Data4 = string.Format("{0:X2}", detailedCanData.Data[i]);
                        if (detailedCanData.DataIsChanged[i])
                            if (!Data4Timer.Enabled)
                            {
                                if (detailedCanData.DataChangedTimeInterval[i] < QuickTimeIntervalFirst)
                                {
                                    if (detailedCanData.DataChangedTimeInterval[i] < QuickTimeIntervalSecond)
                                        CanDataChangeColorModelObject.CellData4ColorId = 3;
                                    else
                                        CanDataChangeColorModelObject.CellData4ColorId = 2;
                                    Data4Timer.Interval = HighLevelResetTimeInterval;
                                }
                                else
                                {
                                    CanDataChangeColorModelObject.CellData4ColorId = 1;
                                    Data4Timer.Interval = LowLevelResetTimeInterval;
                                }
                                Data4Timer.Enabled = true;
                            }
                        break;
                    case 4:
                        CanDataBaseObject.Data5 = string.Format("{0:X2}", detailedCanData.Data[i]);
                        if (detailedCanData.DataIsChanged[i])
                            if (!Data5Timer.Enabled)
                            {
                                if (detailedCanData.DataChangedTimeInterval[i] < QuickTimeIntervalFirst)
                                {
                                    if (detailedCanData.DataChangedTimeInterval[i] < QuickTimeIntervalSecond)
                                        CanDataChangeColorModelObject.CellData5ColorId = 3;
                                    else
                                        CanDataChangeColorModelObject.CellData5ColorId = 2;
                                    Data5Timer.Interval = HighLevelResetTimeInterval;
                                }
                                else
                                {
                                    CanDataChangeColorModelObject.CellData5ColorId = 1;
                                    Data5Timer.Interval = LowLevelResetTimeInterval;
                                }
                                Data5Timer.Enabled = true;
                            }

                        break;
                    case 5:
                        CanDataBaseObject.Data6 = string.Format("{0:X2}", detailedCanData.Data[i]);
                        if (detailedCanData.DataIsChanged[i])
                            if (!Data6Timer.Enabled)
                            {
                                if (detailedCanData.DataChangedTimeInterval[i] < QuickTimeIntervalFirst)
                                {
                                    if (detailedCanData.DataChangedTimeInterval[i] < QuickTimeIntervalSecond)
                                        CanDataChangeColorModelObject.CellData6ColorId = 3;
                                    else
                                        CanDataChangeColorModelObject.CellData6ColorId = 2;
                                    Data6Timer.Interval = HighLevelResetTimeInterval;
                                }
                                else
                                {
                                    CanDataChangeColorModelObject.CellData6ColorId = 1;
                                    Data6Timer.Interval = LowLevelResetTimeInterval;
                                }
                                Data6Timer.Enabled = true;
                            }
                        break;
                    case 6:
                        CanDataBaseObject.Data7 = string.Format("{0:X2}", detailedCanData.Data[i]);
                        if (detailedCanData.DataIsChanged[i])
                            if (!Data7Timer.Enabled)
                            {
                                if (detailedCanData.DataChangedTimeInterval[i] < QuickTimeIntervalFirst)
                                {
                                    if (detailedCanData.DataChangedTimeInterval[i] < QuickTimeIntervalSecond)
                                        CanDataChangeColorModelObject.CellData7ColorId = 3;
                                    else
                                        CanDataChangeColorModelObject.CellData7ColorId = 2;
                                    Data7Timer.Interval = HighLevelResetTimeInterval;
                                }
                                else
                                {
                                    CanDataChangeColorModelObject.CellData7ColorId = 1;
                                    Data7Timer.Interval = LowLevelResetTimeInterval;
                                }
                                Data7Timer.Enabled = true;
                            }
                        break;
                    case 7:
                        CanDataBaseObject.Data8 = string.Format("{0:X2}", detailedCanData.Data[i]);
                        if (detailedCanData.DataIsChanged[i])
                            if (!Data8Timer.Enabled)
                            {
                                if (detailedCanData.DataChangedTimeInterval[i] < QuickTimeIntervalFirst)
                                {
                                    if (detailedCanData.DataChangedTimeInterval[i] < QuickTimeIntervalSecond)
                                        CanDataChangeColorModelObject.CellData8ColorId = 3;
                                    else
                                        CanDataChangeColorModelObject.CellData8ColorId = 2;
                                    Data8Timer.Interval = HighLevelResetTimeInterval;
                                }
                                else
                                {
                                    CanDataChangeColorModelObject.CellData8ColorId = 1;
                                    Data8Timer.Interval = LowLevelResetTimeInterval;
                                }
                                Data8Timer.Enabled = true;
                            }

                        break;
                    default:
                        break;
                }

            //  this.IsAssignCanDataCompleted = true;
        }


        /// <summary>
        /// 默认构造函数
        /// </summary>
        public CanDataReview()
        {
            
        }
        

        /// <summary>
        /// 专用入口
        /// </summary>
        /// <param name="detailedCanData"></param>
        public CanDataReview(CanDataBoredom.DetailedCanData detailedCanData)
        {
            CanDataBaseObject = new CanDataBase(detailedCanData);
            CanDataChangeColorModelObject = new CanDataChangeColorModel();

            RowTimer = new Timer(3000) {AutoReset = false};
            RowTimer.Elapsed += ResetRowState;
            RowTimer.Enabled = false;

            RowTimer.Enabled = true;//刷新定时器

            Data1Timer = new Timer {AutoReset = false};
            Data1Timer.Elapsed += ResetData1CellState;
            Data1Timer.Enabled = false;

            Data2Timer = new Timer {AutoReset = false};
            Data2Timer.Elapsed += ResetData2CellState;
            Data2Timer.Enabled = false;

            Data3Timer = new Timer {AutoReset = false};
            Data3Timer.Elapsed += ResetData3CellState;
            Data3Timer.Enabled = false;

            Data4Timer = new Timer {AutoReset = false};
            Data4Timer.Elapsed += ResetData4CellState;
            Data4Timer.Enabled = false;

            Data5Timer = new Timer {AutoReset = false};
            Data5Timer.Elapsed += ResetData5CellState;
            Data5Timer.Enabled = false;

            Data6Timer = new Timer {AutoReset = false};
            Data6Timer.Elapsed += ResetData6CellState;
            Data6Timer.Enabled = false;

            Data7Timer = new Timer {AutoReset = false};
            Data7Timer.Elapsed += ResetData7CellState;
            Data7Timer.Enabled = false;

            Data8Timer = new Timer {AutoReset = false};
            Data8Timer.Elapsed += ResetData8CellState;
            Data8Timer.Enabled = false;
        }


        private void ResetRowState(object sender, ElapsedEventArgs e)
        {
            CanDataChangeColorModelObject.RowColorId = 1;
        }

        private void ResetData8CellState(object sender, ElapsedEventArgs e)
        {
            CanDataChangeColorModelObject.CellData8ColorId = 0;
        }

        private void ResetData7CellState(object sender, ElapsedEventArgs e)
        {
            CanDataChangeColorModelObject.CellData7ColorId = 0;
        }

        private void ResetData6CellState(object sender, ElapsedEventArgs e)
        {
            CanDataChangeColorModelObject.CellData6ColorId = 0;
        }

        private void ResetData5CellState(object sender, ElapsedEventArgs e)
        {
            CanDataChangeColorModelObject.CellData5ColorId = 0;
        }

        private void ResetData4CellState(object sender, ElapsedEventArgs e)
        {
            CanDataChangeColorModelObject.CellData4ColorId = 0;
        }

        private void ResetData3CellState(object sender, ElapsedEventArgs e)
        {
            CanDataChangeColorModelObject.CellData3ColorId = 0;
        }

        private void ResetData2CellState(object sender, ElapsedEventArgs e)
        {
            CanDataChangeColorModelObject.CellData2ColorId = 0;
        }

        private void ResetData1CellState(object sender, ElapsedEventArgs e)
        {
            CanDataChangeColorModelObject.CellData1ColorId = 0;
        }


        /// <summary>
        /// 赋默认颜色指示（单元格，行(暂无效)）
        /// </summary>
        private void AssignDefaultReviewData()
        {
            CanDataChangeColorModelObject.RowColorId = 0;
            CanDataChangeColorModelObject.CellData1ColorId = 0;
            CanDataChangeColorModelObject.CellData2ColorId = 0;
            CanDataChangeColorModelObject.CellData3ColorId = 0;
            CanDataChangeColorModelObject.CellData4ColorId = 0;
            CanDataChangeColorModelObject.CellData5ColorId = 0;
            CanDataChangeColorModelObject.CellData6ColorId = 0;
            CanDataChangeColorModelObject.CellData7ColorId = 0;
            CanDataChangeColorModelObject.CellData8ColorId = 0;
        }


        public int Id
        {
            get
            {
                return _id;
            }

            set
            {
                _id = value;
                OnPropertyChanged(new PropertyChangedEventArgs("Id"));
            }
        }

        public bool IsGoNow
        {
            get
            {
                return _isGoNow;
            }

            set
            {
                _isGoNow = value;
                OnPropertyChanged(new PropertyChangedEventArgs("IsGoNow"));
            }
        }

        
        public string Identity
        {
            get
            {
                if (CanDataBaseObject != null)
                {
                    return CanDataBaseObject.Identity;
                }
                return string.Empty;
            }
        }
    }
}
