﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CarTool.Main.Models
{
    public class DataTypeBool : DataTypeBase
    {
        /// <summary>
        /// 提供强转
        /// </summary>
        /// <param name="_dataTypeBaseObject"></param>
        public DataTypeBool(DataTypeBase _dataTypeBaseObject)
            :base(_dataTypeBaseObject)
        {
            
        }

        public DataTypeBool(byte _dataTypeID,
            string _dataTypeName, string _orderID, byte _canID,string _englishName
           ,byte _externFlag, byte _remoteFlag,byte _effectiveByte, byte _effectiveBit,
            byte _effectiveValue) :base(_dataTypeID,
             _dataTypeName, _orderID, _canID, _englishName,_externFlag,_remoteFlag)
        {
            this.EffectiveByte = _effectiveByte;
            this.EffectiveBit = _effectiveBit;
            this.EffectiveValue = _effectiveValue;
        }

        public override DataTypeBase Copy()
        {
            var obj = new DataTypeBool
            {
                EffectiveByte = EffectiveByte,
                EffectiveBit = EffectiveBit,
                EffectiveValue = EffectiveValue
            };
            return BasePartCopy(obj);
        }
        private DataTypeBool()
        {

        }

        public override string ToString()
        {
            return "命令ID：" + OrderID + " Can通道: " + CanID+" "+DataTypeName+ " "+ GetFrameFormatName(RemoteFlag) + " " + GetFrameTypeName(ExternFlag) + " 有效字节：" + EffectiveByte +
                                    " 有效位：" + EffectiveBit + " 有效值：" + EffectiveValue ;
        }


        public byte EffectiveByte { get; set; } = 0;

        public byte EffectiveBit { get; set; } = 0;

        public byte EffectiveValue { get; set; } = 1;

    }
}
