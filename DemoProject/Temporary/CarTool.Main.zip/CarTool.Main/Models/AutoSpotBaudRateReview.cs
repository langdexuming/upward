﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace CarTool.Main.Models
{
    public class AutoSpotBaudRateReview: INotifyPropertyChanged
    {
        private byte _channel;

        public AutoSpotBaudRateReview(string _state, string _baudRate, string _result, byte _channel)
        {
            this.State = _state;
            this.BaudRate = _baudRate;
            this.Result = _result;
            this._channel = _channel;
        }

        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged(PropertyChangedEventArgs e)
        {
            PropertyChanged?.Invoke(this, e);
        }
        public string State { get; set; }

        public string BaudRate { get; set; }

        public string Result { get; set; }

        public byte Channel
        {
            get
            {
                return _channel;
            }

            set
            {
                _channel = value;
                OnPropertyChanged(new PropertyChangedEventArgs("Channel"));
                
            }
        }

    }
}
