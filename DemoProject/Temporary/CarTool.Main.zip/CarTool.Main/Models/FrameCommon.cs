﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CarTool.Main.Models
{
    public class FrameFormat
    {
        public byte FormatId { get; set; }

        public string FormatName { get; set; }
    }

    public class FrameType
    {
        public byte TypeId { get; set; }

        public string TypeName { get; set; }
    }
}
