﻿using System;
using System.ComponentModel;
using System.Globalization;
using CarTool.Main.MVVM;
using static CarTool.Main.HeaderFile.CanDataBoredom;

namespace CarTool.Main.Models.Base
{
    public class CanDataBase : NotificationObject, ICanData, IFormattable
    {
        private string _data1;
        private string _data2;
        private string _data3;
        private string _data4;
        private string _data5;
        private string _data6;
        private string _data7;
        private string _data8;


        private uint _orderId;
        private byte _length;
        private byte _remoteFlag;
        private byte _externFlag;

        private int _timeInterval;
        private int _time;

        private bool _isAssignCanDataCompleted;//指示是否赋值完成，用于指示所有数据更新完成

        public CanDataBase(uint _orderID, byte _length, string _data1, string _data2, string _data3, string _data4, string _data5, string _data6, string _data7, string _data8)
        {
            this._orderId = _orderID;
            this._length = _length;
            this._data1 = _data1;
            this._data2 = _data2;
            this._data3 = _data3;
            this._data4 = _data4;
            this._data5 = _data5;
            this._data6 = _data6;
            this._data7 = _data7;
            this._data8 = _data8;
        }
        /// <summary>
        /// 后续删除
        /// </summary>
        public CanDataBase()
        {

        }


        public CanDataBase(CanDataBase other)
        {
            _orderId = other._orderId;
            _length = other._length;
            _data1 = other._data1;
            _data2 = other._data2;
            _data3 = other._data3;
            _data4 = other._data4;
            _data5 = other._data5;
            _data6 = other._data6;
            _data7 = other._data7;
            _data8 = other._data8;
            _remoteFlag = other.RemoteFlag;
            _externFlag = other._externFlag;
            _timeInterval = other._timeInterval;
            _time = other._time;

            _isAssignCanDataCompleted = other._isAssignCanDataCompleted;
        }
        /// <summary>
        /// 浅拷贝
        /// </summary>
        /// <returns></returns>
        public CanDataBase Copy()
        {
            var _obj = new CanDataBase
            {
                _orderId = this._orderId,
                _length = this._length,
                _data1 = this._data1,
                _data2 = this._data2,
                _data3 = this._data3,
                _data4 = this._data4,
                _data5 = this._data5,
                _data6 = this._data6,
                _data7 = this._data7,
                _data8 = this._data8,
                _remoteFlag = this.RemoteFlag,
                _externFlag = this._externFlag,
                _timeInterval = this._timeInterval,
                _time=this._time,

                _isAssignCanDataCompleted = this._isAssignCanDataCompleted
        };
            return _obj;
        }
        /// <summary>
        /// 把该结构体转换成用于界面的model
        /// </summary>
        /// <param name="canData"></param>
        public CanDataBase(ICanData canData)
        {
            this._orderId =  canData.OrderId;
            this._length = canData.Length;
            this.RemoteFlag = canData.RemoteFlag;
            this._externFlag=canData.ExternFlag;
            this.TimeInterval = canData.TimeInterval;

            this.AssignCanData(canData);//初始化，可精简
        }
        public override string ToString()
        {
            return ToString("Text");
        }
        public string ToString(string format)
        {
            return ToString(format, CultureInfo.CurrentCulture);
        }

        public string ToString(string format, IFormatProvider provider)
        {
            if (string.IsNullOrEmpty(format)) format = "Text";
            if (provider == null) provider = CultureInfo.CurrentCulture;
            string _str;
            switch (format.ToUpperInvariant())
            {
                case "TEXT":
                    _str = string.Format("0x{0:x}", OrderId) + "\t" + RemoteFlag + "\t" + ExternFlag + "\t" + Length + "\t" + Data1 + " " + Data2 + " " + Data3 + " " + Data4 + " " + Data5 + " " + Data6 + " " + Data7 + " " + Data8 + " ";
                    break;
                case "FRAME":
                    _str = string.Format("0x{0:x}", OrderId) + "\t" + TimeInterval + "\t" + RemoteFlag + "\t" + ExternFlag + "\t" + Length + "\t" + Data1 + " " + Data2 + " " + Data3 + " " + Data4 + " " + Data5 + " " + Data6 + " " + Data7 + " " + Data8;
                    break;
                default:
                    throw new FormatException(string.Format("The {0} format string is not supported.", format));
            }
            return _str;
        }
        /// <summary>
        /// 精确赋值，满足长度发生变化的数据改变需求
        /// </summary>
        /// <param name="canData"></param>
        public void AssignCanData(ICanData canData)
        {
            int length = canData.Length;
            for (int i = 0; i < 8;i++)
            {
                switch (i)
                {
                    case 0:
                        this.Data1 = i < length ? string.Format("{0:X2}", canData.Data[i]) : "";
                        break;
                    case 1:
                        this.Data2 = i < length ? string.Format("{0:X2}", canData.Data[i]) : "";
                        break;
                    case 2:
                        this.Data3 = i < length ? string.Format("{0:X2}", canData.Data[i]) : "";
                        break;
                    case 3:
                        this.Data4 = i < length ? string.Format("{0:X2}", canData.Data[i]) : "";
                        break;
                    case 4:
                        this.Data5 = i < length ? string.Format("{0:X2}", canData.Data[i]) : "";
                        break;
                    case 5:
                        this.Data6 = i < length ? string.Format("{0:X2}", canData.Data[i]) : "";
                        break;
                    case 6:
                        this.Data7 = i < length ? string.Format("{0:X2}", canData.Data[i]) : "";
                        break;
                    case 7:
                        this.Data8 = i < length ? string.Format("{0:X2}", canData.Data[i]) : "";
                        break;
                    default:
                        break;
                }
            }

            //赋值完成
            this.IsAssignCanDataCompleted = true;
        }
        /// <summary>
        /// 引发通知(该函数暂时无效)
        /// </summary>
        /// <param name="data1"></param>
        /// <param name="data2"></param>
        /// <param name="data3"></param>
        /// <param name="data4"></param>
        /// <param name="data5"></param>
        /// <param name="data6"></param>
        /// <param name="data7"></param>
        /// <param name="data8"></param>
        protected virtual void AssignData(string data1,string data2,string data3,string data4,string data5,string data6,string data7,string data8)
        {
            this.Data1 = data1;
            this.Data2 = data2;
            this.Data3 = data3;
            this.Data4 = data4;
            this.Data5 = data5;
            this.Data6 = data6;
            this.Data7 = data7;
            this.Data8 = data8;

            this.IsAssignCanDataCompleted = true;
        }

        public uint OrderId
        {
            get
            {
                return _orderId;
            }

            set
            {
                _orderId = value;
                RaisePropertyChanged(()=>OrderId);
            }
        }

        public byte Length
        {
            get
            {
                return _length;
            }

            set
            {
                if (value != _length)
                {
                    _length = value;
                    RaisePropertyChanged(() => Length);
                }
            }
        }

        public string Data1
        {
            get { return _data1; }

            set
            {
                if (value != _data1)
                {
                    _data1 = value;
                    RaisePropertyChanged(() => Data1);
                }
            }
        }

        public string Data2
        {
            get
            {
                return _data2;
            }
            set
            {
                if (value != _data2)
                {
                    _data2 = value;
                    RaisePropertyChanged(()=>Data2);
                }
            }
        }

        public string Data3
        {
            get { return _data3; }

            set
            {
                if (value != _data3)
                {
                    _data3 = value;
                    RaisePropertyChanged(() => Data3);
                }
            }
        }

        public string Data4
        {
            get { return _data4; }

            set
            {
                if (value != _data4)
                {
                    _data4 = value;
                    RaisePropertyChanged(() => Data4);
                }
            }
        }

        public string Data5
        {
            get { return _data5; }

            set
            {
                if (value != _data5)
                {
                    _data5 = value;
                    RaisePropertyChanged(() => Data5);
                }
            }
        }

        public string Data6
        {
            get { return _data6; }
            set
            {
                if (value != _data6)
                {
                    _data6 = value;
                    RaisePropertyChanged(() => Data6);
                }
            }
        }

        public string Data7
        {
            get { return _data7; }
            set
            {
                if (value != _data7)
                {
                    _data7 = value;
                    RaisePropertyChanged(() => Data7);
                }
            }
        }

        public string Data8
        {
            get { return _data8; }

            set
            {
                if (value != _data8)
                {
                    _data8 = value;
                    RaisePropertyChanged(() => Data8);
                }
            }
        }

        public byte RemoteFlag
        {
            get
            {
                return _remoteFlag;
            }

            set
            {
                _remoteFlag = value;
                RaisePropertyChanged(() => RemoteFlag);
            }
        }

        public byte ExternFlag
        {
            get
            {
                return _externFlag;
            }

            set
            {
                _externFlag = value;
                RaisePropertyChanged(() => ExternFlag);
            }
        }

        /// <summary>
        /// 赋值完成标志
        /// </summary>
        public bool IsAssignCanDataCompleted
        {
            get
            {
                return _isAssignCanDataCompleted;
            }

            set
            {
                _isAssignCanDataCompleted = value;
                RaisePropertyChanged(() => IsAssignCanDataCompleted);
            }
        }

      
        public int TimeInterval
        {
            get
            {
                return _timeInterval;
            }

            set
            {
                _timeInterval = value;
                RaisePropertyChanged(() => TimeInterval);
            }
        }

        public int Time
        {
            get { return _time; }
            set
            {
                _time = value;
                RaisePropertyChanged(() => Time);
            }
        }

        public string Identity => _orderId + _externFlag.ToString() + _remoteFlag.ToString();

        public byte[] Data
        {
            get
            {
                byte[] data = new byte[_length];
                for (int i = 0; i < _length; i++)
                {
                    switch (i)
                    {
                        case 0:
                            try
                            {
                                data[i] = Convert.ToByte(this.Data1, 16);
                            }
                            catch
                            {
                                // ignored
                            }
                            break;
                        case 1:
                            try
                            {
                                data[i] = Convert.ToByte(this.Data2, 16);
                            }
                            catch
                            {
                                // ignored
                            }
                            break;
                        case 2:
                            try
                            {
                                data[i] = Convert.ToByte(this.Data3, 16);
                            }
                            catch
                            {
                                // ignored
                            }
                            break;
                        case 3:
                            try
                            {
                                data[i] = Convert.ToByte(this.Data4, 16);
                            }
                            catch
                            {
                                // ignored
                            }
                            break;
                        case 4:
                            try
                            {
                                data[i] = Convert.ToByte(this.Data5, 16);
                            }
                            catch
                            {
                                // ignored
                            }
                            break;
                        case 5:
                            try
                            {
                                data[i] = Convert.ToByte(this.Data6, 16);
                            }
                            catch
                            {
                                // ignored
                            }
                            break;
                        case 6:
                            try
                            {
                                data[i] = Convert.ToByte(this.Data7, 16);
                            }
                            catch
                            {
                                // ignored
                            }
                            break;
                        case 7:
                            try
                            {
                                data[i] = Convert.ToByte(this.Data8, 16);
                            }
                            catch
                            {
                                // ignored
                            }
                            break;
                        default:
                            break;
                    }
                }
                return data;
            }
            set
            {
                throw new NotImplementedException();
            }
        }
    }
}
