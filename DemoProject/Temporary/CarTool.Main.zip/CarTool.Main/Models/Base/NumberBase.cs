﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace CarTool.Main.Models.Base
{
    public class NumberBase : INotifyPropertyChanged
    {
        private int _number;

        public NumberBase(int _number)
        {
            this._number = _number;
        }

        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged(PropertyChangedEventArgs e)
        {
            PropertyChanged?.Invoke(this, e);
        }
        public int Number
        {
            get
            {
                return _number;
            }

            set
            {
                if (0 <= value)
                {
                    _number = value;
                    OnPropertyChanged(new PropertyChangedEventArgs("Number"));
                }
            }
        }

    }
}
