﻿using CarTool.Main.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using CarInfoDB;
using CarTool.Main.Utils;

namespace CarTool.Main.Models
{
   public class DataTypeBase : INotifyPropertyChanged
    {
        private string _englishName;//算法前缀

        private string _dataTypeName;
        private byte _dataTypeID;

        private string _orderID;
        private byte _canID;

        private byte _remoteFlag;
        private byte _externFlag;


        public string GetFrameFormatName(byte remoteFlag)
        {
            return remoteFlag == 0 ? "[数据帧]" : "[远程帧]";
        }

        public string GetFrameTypeName(byte externFlag)
        {
            return externFlag == 0 ? "[标准帧]" : "[扩展帧]";
        }

        public event PropertyChangedEventHandler PropertyChanged;
        public virtual void OnPropertyChanged(PropertyChangedEventArgs e)
        {
            PropertyChanged?.Invoke(this, e);

        }

        public void SetDataType(DataType dataType)
        {
            if (dataType != null)
            {
                DataTypeID = dataType.DataTypeID;
                DataTypeName = dataType.DataTypeName;
            }
        }

        /// <summary>
        /// 提供对象的浅拷贝
        /// </summary>
        /// <returns></returns>
        public virtual DataTypeBase Copy()
        {
            var obj = new DataTypeBase
            {
                _canID = _canID,
                _dataTypeName = _dataTypeName,
                _orderID = _orderID,
                _dataTypeID = _dataTypeID,
                _englishName = _englishName,
                _externFlag = _externFlag,
                _remoteFlag = _remoteFlag,
            };
            return obj;
        }

        /// <summary>
        /// 提供基类部分的浅拷贝
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public DataTypeBase BasePartCopy(DataTypeBase obj)
        {
           // DataTypeBase obj = new DataTypeBase();
            obj._canID = _canID;
            obj._dataTypeName = _dataTypeName;
            obj._orderID = _orderID;
            obj._dataTypeID = _dataTypeID;
            obj._englishName = _englishName;
            obj._externFlag = _externFlag;
            obj._remoteFlag = _remoteFlag;
            return obj;
        }

        /// <summary>
        /// 专用构造
        /// </summary>
        /// <param name="infoItemId"></param>
        /// <param name="title"></param>
        /// <param name="dataTypeID"></param>
        /// <param name="dataTypeName"></param>
        /// <param name="orderID"></param>
        /// <param name="canID"></param>
        /// <param name="englishName"></param>
        /// <param name="externFlag"></param>
        /// <param name="remoteFlag"></param>
        public DataTypeBase(byte dataTypeID, string dataTypeName, string orderID, byte canID,string englishName, byte externFlag, byte remoteFlag)
        {
            this._dataTypeID = dataTypeID;
            this._dataTypeName = dataTypeName;
            this._orderID = orderID;
            this._canID = canID;
            this._englishName = englishName;
            //新添加
            this._externFlag = externFlag;
            this._remoteFlag = remoteFlag;
        }

        /// <summary>
        /// 专用构造
        /// </summary>
        public DataTypeBase(DataTypeBase other)
        {
            this._dataTypeID = other._dataTypeID;
            this._dataTypeName = other._dataTypeName;
            this._orderID = other._orderID;
            this._canID = other._canID;
            this._englishName = other._englishName;
            //新添加
            this._externFlag = other._externFlag;
            this._remoteFlag = other._remoteFlag;
        }

        /// <summary>
        /// 内部使用
        /// </summary>
        public DataTypeBase()
        {

        }

        public override string ToString()
        {
            return string.Empty;
        }


        public byte DataTypeID
        {
            get
            {
                return _dataTypeID;
            }

            set
            {
                _dataTypeID = value;
                OnPropertyChanged(new PropertyChangedEventArgs("DataTypeID"));
            }
        }

        public string DataTypeName
        {
            get
            {
                return _dataTypeName;
            }

            set
            {
                _dataTypeName = value;
                OnPropertyChanged(new PropertyChangedEventArgs("DataTypeName"));
            }
        }

        public string OrderID
        {
            get
            {
                return _orderID;
            }

            set
            {
                _orderID = value.Trim(' ').Trim('\t');
                OnPropertyChanged(new PropertyChangedEventArgs("OrderId"));
            }
        }

        public byte CanID
        {
            get
            {
                return _canID;
            }

            set
            {
                _canID = value;
                OnPropertyChanged(new PropertyChangedEventArgs("CanID"));
            }
        }

        public string EnglishName
        {
            get
            {
                return _englishName;
            }

            set
            {
                _englishName = value;
                OnPropertyChanged(new PropertyChangedEventArgs("EnglishName"));
            }
        }


        public byte RemoteFlag
        {
            get
            {
                return _remoteFlag;
            }

            set
            {
                _remoteFlag = value;
                OnPropertyChanged(new PropertyChangedEventArgs("RemoteFlag"));
            }
        }

        public byte ExternFlag
        {
            get
            {
                return _externFlag;
            }

            set
            {
                _externFlag = value;
                OnPropertyChanged(new PropertyChangedEventArgs("ExternFlag"));
            }
        }
    }
}
