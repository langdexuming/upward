﻿using CarInfoDB;
using CarTool.CommonComponents.Controls;
using CarTool.Main.Models.Base;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using static CarTool.Main.Helper.InfoDetailListBoxItemHelper;

namespace CarTool.Main.Models
{
    public class InfoDetailReview : InfoDetailBase
    {
        private string _content;//数值

        private string _leftTopValue;
        private string _rightTopValue;
        private string _leftBottomValue;
        private string _rightBottomValue;


        public int ValueType { get; set; }

        public string ValueUnit { get; set; }

        /// <summary>
        /// 
        /// </summary>
        private bool _canPlaySound;//是否提示声音


        public ActiveTipArea CurrentActiveTipArea { get; set; }

        /// <summary>
        /// 指示动态活动的时候提示的区域
        /// </summary>
        public enum ActiveTipArea {
            /// <summary>
            /// 不显示
            /// </summary>
            None,
            /// <summary>
            /// 数据信息框区域
            /// </summary>
            DataInfoBoxArea,

            /// <summary>
            /// 虚拟场景框区域（文本提示框）
            /// </summary>
            VirtualScenesLeftBoxArea,

            /// <summary>
            /// 虚拟场景框区域（文本提示框）
            /// </summary>
            VirtualScenesRightBoxArea,

            /// <summary>
            /// 消息提示框区域（包括文本和语音）
            /// </summary>
            MessageBoxArea,

            /// <summary>
            /// 数据信息框区域和消息提示框区域（包括文本和语音）
            /// </summary>
            DataInfoBoxAreaAndMessageBoxArea,
        }


        //可分层

        private Status _currentState;

        public string NormalBrushUri { get; set; }

        public string DisableBrushUri { get; set; }

        public string ActiveBrushUri { get; set; }

        public string DefectiveBrushUri { get; set; }

        public string ExtraLeftBrushUri { get; set; }

        public string ExtraRightBrushUri { get; set; }


        /// <summary>
        /// 额外附加
        /// </summary>
        public bool IsExtraLeftActive { get; set; }

        public bool IsExtraRightActive { get; set; }

        /// <summary>
        /// 门窗专用
        /// </summary>
        public bool IsExtraActive => IsExtraFrontLeftActive || IsExtraFrontRightActive || IsExtraRearLeftActive || IsExtraRearRightActive;

        /// <summary>
        /// 门窗专用
        /// </summary>
        public bool IsExtraFrontLeftActive { get; set; }

        /// <summary>
        /// 门窗专用
        /// </summary>
        public bool IsExtraFrontRightActive { get; set; }
        /// <summary>
        /// 门窗专用
        /// </summary>
        public bool IsExtraRearLeftActive { get; set; }
        /// <summary>
        /// 门窗专用
        /// </summary>
        public bool IsExtraRearRightActive { get; set; }



        /// <summary>
        /// 正常加载
        /// </summary>
        /// <param name="_id"></param>
        /// <param name="_name"></param>
        /// <param name="_isEnabled"></param>
        public InfoDetailReview(int _id,string _name, bool _isEnabled = false)
        {
            this.Id = _id;
            this.InfoItemId = _id;
            this.Name = _name;
            this.IsEnabled = _isEnabled;
            this._currentState = _isEnabled ? Status.Normal : Status.Disable;

            //加载默认资源、默认提示状态位置信息、生成默认数据
            DefaultAssign(_id);
            
        }
        /// <summary>
        /// 设置默认值
        /// </summary>
        public void DefaultAssign()
        {
            DefaultAssign(this.Id);
        }
        /// <summary>
        /// 默认值+Uri
        /// </summary>
        /// <param name="id"></param>
        private void DefaultAssign(int id)
        {
            switch (id)
            {
                case 1://点火开关
                    this._content = "Off";

                    DisableBrushUri = "Images/CarView/info_ignitionswitch_disable.png";
                    NormalBrushUri = "Images/CarView/info_ignitionswitch_default.png";
                    ActiveBrushUri = "Images/CarView/info_ignitionswitch_active.png";
                    DefectiveBrushUri = "Images/CarView/info_ignitionswitch_defective.png";
                    //  ExtraLeftBrushUri = "";
                    //ExtraRightBrushUri = "";
                    CurrentActiveTipArea = ActiveTipArea.DataInfoBoxAreaAndMessageBoxArea;//

                    _canPlaySound = true;//新添加
                    break;
                case 2://Acc
                    this._content = "Off";
                    DisableBrushUri = "Images/CarView/info_acc_disable.png";
                    NormalBrushUri = "Images/CarView/info_acc_default.png";
                    ActiveBrushUri = "Images/CarView/info_acc_active.png";
                    DefectiveBrushUri = "Images/CarView/info_acc_defective.png";
                    //ExtraLeftBrushUri = "";
                    //ExtraRightBrushUri = "";
                    CurrentActiveTipArea = ActiveTipArea.DataInfoBoxAreaAndMessageBoxArea;//

                    _canPlaySound = true;//新添加
                    break;
                case 3://启动(已删)
                    this._content = "×";
                    this._content = "Off";
                    DisableBrushUri = "Images/CarView/info_powerstate_disable.png";
                    NormalBrushUri = "Images/CarView/info_powerstate_default.png";
                    ActiveBrushUri = "Images/CarView/info_powerstate_active.png";
                    DefectiveBrushUri = "Images/CarView/info_powerstate_defective.png";
                    //ExtraLeftBrushUri = "";
                    //ExtraRightBrushUri = "";
                    CurrentActiveTipArea = ActiveTipArea.DataInfoBoxAreaAndMessageBoxArea;//

                    _canPlaySound = true;//新添加
                    break;
                case 4://油门
                    this._content = "↓";
                    DisableBrushUri = "Images/CarView/info_gasstate_disable.png";
                    NormalBrushUri = "Images/CarView/info_gasstate_default.png";
                    ActiveBrushUri = "Images/CarView/info_gasstate_active.png";
                    DefectiveBrushUri = "Images/CarView/info_gasstate_defective.png";
                    //ExtraLeftBrushUri = "";
                    //ExtraRightBrushUri = "";
                    CurrentActiveTipArea = ActiveTipArea.DataInfoBoxAreaAndMessageBoxArea;//

                    _canPlaySound = true;//新添加
                    break;
                case 5://脚刹
                    this._content = "↓";
                    DisableBrushUri = "Images/CarView/info_footbrake_disable.png";
                    NormalBrushUri = "Images/CarView/info_footbrake_default.png";
                    ActiveBrushUri = "Images/CarView/info_footbrake_active.png";
                    DefectiveBrushUri = "Images/CarView/info_footbrake_defective.png";
                    //ExtraLeftBrushUri = "";
                    //ExtraRightBrushUri = "";
                    CurrentActiveTipArea = ActiveTipArea.DataInfoBoxAreaAndMessageBoxArea;//

                    _canPlaySound = true;//新添加
                    break;
                case 6://手刹
                    this._content = "×";
                    DisableBrushUri = "Images/CarView/info_manualbrake_disable.png";
                    NormalBrushUri = "Images/CarView/info_manualbrake_default.png";
                    ActiveBrushUri = "Images/CarView/info_manualbrake_active.png";
                    DefectiveBrushUri = "Images/CarView/info_manualbrake_defective.png";
                    //ExtraLeftBrushUri = "";
                    //ExtraRightBrushUri = "";
                    CurrentActiveTipArea = ActiveTipArea.DataInfoBoxAreaAndMessageBoxArea;//

                    _canPlaySound = true;//新添加
                    break;
                case 7://锁
                     this._content = "Off";
                    DisableBrushUri = "Images/CarView/info_lockstate_disable.png";
                    NormalBrushUri = "Images/CarView/info_lockstate_default.png";
                    ActiveBrushUri = "Images/CarView/info_lockstate_active.png";
                    DefectiveBrushUri = "Images/CarView/info_lockstate_defective.png";
                    //ExtraLeftBrushUri = "";
                    //ExtraRightBrushUri = "";
                    CurrentActiveTipArea = ActiveTipArea.DataInfoBoxAreaAndMessageBoxArea;//

                    _canPlaySound = true;//新添加
                    break;
                case 8://空调
                    this._content = "Off";
                    DisableBrushUri = "Images/CarView/info_airconditioning_disable.png";
                    NormalBrushUri = "Images/CarView/info_airconditioning_default.png";
                    ActiveBrushUri = "Images/CarView/info_airconditioning_active.png";
                    DefectiveBrushUri = "Images/CarView/info_airconditioning_defective.png";
                    //ExtraLeftBrushUri = "";
                    //ExtraRightBrushUri = "";
                    CurrentActiveTipArea = ActiveTipArea.DataInfoBoxAreaAndMessageBoxArea;//

                    _canPlaySound = true;//新添加
                    break;
                case 9://温度

                    this._content = "0 ℃";
                    DisableBrushUri = "Images/CarView/info_temperature_disable.png";
                    NormalBrushUri = "Images/CarView/info_temperature_default.png";
                    ActiveBrushUri = "Images/CarView/info_temperature_active.png";
                    DefectiveBrushUri = "Images/CarView/info_temperature_defective.png";
                    //ExtraLeftBrushUri = "";
                    //ExtraRightBrushUri = "";
                    CurrentActiveTipArea = ActiveTipArea.VirtualScenesLeftBoxArea;//

                    break;
                case 10://小灯
                    this._content = "Off";
                    DisableBrushUri = "Images/CarView/info_smalllight_disable.png";
                    NormalBrushUri = "Images/CarView/info_smalllight_default.png";
                    ActiveBrushUri = "Images/CarView/info_smalllight_active.png";
                    DefectiveBrushUri = "Images/CarView/info_smalllight_defective.png";
                    //ExtraLeftBrushUri = "";
                    //ExtraRightBrushUri = "";
                    CurrentActiveTipArea = ActiveTipArea.DataInfoBoxAreaAndMessageBoxArea;//

                    _canPlaySound = true;//新添加
                    break;
                case 11://档位
                    this._content = "P";
                    DisableBrushUri = "Images/CarView/info_gears_disable.png";
                    NormalBrushUri = "Images/CarView/info_gears_default.png";
                    ActiveBrushUri = "Images/CarView/info_gears_active.png";
                    DefectiveBrushUri = "Images/CarView/info_gears_defective.png";
                    //ExtraLeftBrushUri = "";
                    //ExtraRightBrushUri = "";
                    CurrentActiveTipArea = ActiveTipArea.VirtualScenesLeftBoxArea;//
                    break;
                case 12://天窗
                    this._content = "Off";
                    DisableBrushUri = "Images/CarView/info_skylightstate_disable.png";
                    NormalBrushUri = "Images/CarView/info_skylightstate_default.png";
                    ActiveBrushUri = "Images/CarView/info_skylightstate_active.png";
                    DefectiveBrushUri = "Images/CarView/info_skylightstate_defective.png";
                    //ExtraLeftBrushUri = "";
                    //ExtraRightBrushUri = "";
                    CurrentActiveTipArea = ActiveTipArea.DataInfoBoxAreaAndMessageBoxArea;//

                    _canPlaySound = true;//新添加
                    break;
                case 13://速度
                    this._content = "00 km/h";
                    DisableBrushUri = "Images/CarView/info_speed_disable.png";
                    NormalBrushUri = "Images/CarView/info_speed_default.png";
                    ActiveBrushUri = "Images/CarView/info_speed_active.png";
                    DefectiveBrushUri = "Images/CarView/info_speed_defective.png";
                    //ExtraLeftBrushUri = "";
                    //ExtraRightBrushUri = "";
                    CurrentActiveTipArea = ActiveTipArea.VirtualScenesLeftBoxArea;//
                    break;
                case 14://雨刮
                    this._content = "关";
                    DisableBrushUri = "Images/CarView/info_windscreenwiper_disable.png";
                    NormalBrushUri = "Images/CarView/info_windscreenwiper_default.png";
                    ActiveBrushUri = "Images/CarView/info_windscreenwiper_active.png";
                    DefectiveBrushUri = "Images/CarView/info_windscreenwiper_defective.png";
                    //ExtraLeftBrushUri = "";
                    //ExtraRightBrushUri = "";
                    CurrentActiveTipArea = ActiveTipArea.DataInfoBoxAreaAndMessageBoxArea;//
                    break;
                case 15://里程
                    this._content = "0 km";
                    DisableBrushUri = "Images/CarView/info_mileage_disable.png";
                    NormalBrushUri = "Images/CarView/info_mileage_default.png";
                    ActiveBrushUri = "Images/CarView/info_mileage_active.png";
                    DefectiveBrushUri = "Images/CarView/info_mileage_defective.png";
                    //ExtraLeftBrushUri = "";
                    //ExtraRightBrushUri = "";
                    CurrentActiveTipArea = ActiveTipArea.VirtualScenesLeftBoxArea;//
                    break;
                case 16://水温
                    this._content = "0 ℃";
                    DisableBrushUri = "Images/CarView/info_watertemperature_disable.png";
                    NormalBrushUri = "Images/CarView/info_watertemperature_default.png";
                    ActiveBrushUri = "Images/CarView/info_watertemperature_active.png";
                    DefectiveBrushUri = "Images/CarView/info_watertemperature_defective.png";
                    //ExtraLeftBrushUri = "";
                    //ExtraRightBrushUri = "";
                    CurrentActiveTipArea = ActiveTipArea.VirtualScenesLeftBoxArea;//
                    break;
                case 17://大灯
                    this._content = "On";
                    DisableBrushUri = "Images/CarView/info_headlight_disable.png";
                    NormalBrushUri = "Images/CarView/info_headlight_default.png";
                    ActiveBrushUri = "Images/CarView/info_headlight_active.png";
                    DefectiveBrushUri = "Images/CarView/info_headlight_defective.png";
                    //ExtraLeftBrushUri = "";
                    //ExtraRightBrushUri = "";
                    CurrentActiveTipArea = ActiveTipArea.DataInfoBoxAreaAndMessageBoxArea;//

                    _canPlaySound = true;//新添加
                    break;
                case 24://油箱盖

                    this._content = "Off";
                    DisableBrushUri = "Images/CarView/info_sumpcoverstate_disable.png";
                    NormalBrushUri = "Images/CarView/info_sumpcoverstate_default.png";
                    ActiveBrushUri = "Images/CarView/info_sumpcoverstate_active.png";
                    DefectiveBrushUri = "Images/CarView/info_sumpcoverstate_defective.png";
                    //ExtraLeftBrushUri = "";
                    //ExtraRightBrushUri = "";
                    CurrentActiveTipArea = ActiveTipArea.DataInfoBoxAreaAndMessageBoxArea;//

                    _canPlaySound = true;//新添加
                    break;
                case 25://引擎盖
                    this._content = "Off";
                    DisableBrushUri = "Images/CarView/info_enginecoverstate_disable.png";
                    NormalBrushUri = "Images/CarView/info_enginecoverstate_default.png";
                    ActiveBrushUri = "Images/CarView/info_enginecoverstate_active.png";
                    DefectiveBrushUri = "Images/CarView/info_enginecoverstate_defective.png";
                    //ExtraLeftBrushUri = "";
                    //ExtraRightBrushUri = "";
                    CurrentActiveTipArea = ActiveTipArea.DataInfoBoxAreaAndMessageBoxArea;//

                    _canPlaySound = true;//新添加
                    break;
                case 26://后备箱
                    this._content = "Off";
                    DisableBrushUri = "Images/CarView/info_trunkstate_disable.png";
                    NormalBrushUri = "Images/CarView/info_trunkstate_default.png";
                    ActiveBrushUri = "Images/CarView/info_trunkstate_active.png";
                    DefectiveBrushUri = "Images/CarView/info_trunkstate_defective.png";
                    //ExtraLeftBrushUri = "";
                    //ExtraRightBrushUri = "";
                    CurrentActiveTipArea = ActiveTipArea.DataInfoBoxAreaAndMessageBoxArea;//

                    _canPlaySound = true;//新添加
                    break;
                case 27:
                case 28://转向灯
                    this._content = "左Off 右Off";
                    DisableBrushUri = "Images/CarView/info_turnsignal_disable.png";
                    NormalBrushUri = "Images/CarView/info_turnsignal_default.png";
                    ActiveBrushUri = "Images/CarView/info_turnsignal_active.png";
                    //DefectiveBrushUri = "Images/CarView/info_turnsignal_defective.png";
                    ExtraLeftBrushUri = "Images/CarView/info_turnsignal_extraleft.png";
                    ExtraRightBrushUri = "Images/CarView/info_turnsignal_extraright.png";
                    CurrentActiveTipArea = ActiveTipArea.DataInfoBoxAreaAndMessageBoxArea;//


                    _canPlaySound = true;//新添加
                    break;
                case 29://安全带(主)
                    this._content = "×";
                    DisableBrushUri = "Images/CarView/info_seatbelt_disable.png";
                    NormalBrushUri = "Images/CarView/info_seatbelt_default.png";
                    ActiveBrushUri = "Images/CarView/info_seatbelt_active.png";
                    DefectiveBrushUri = "Images/CarView/info_seatbelt_defective.png";
                    //ExtraLeftBrushUri = "";
                    //ExtraRightBrushUri = "";
                    CurrentActiveTipArea = ActiveTipArea.DataInfoBoxAreaAndMessageBoxArea;//

                    _canPlaySound = true;//新添加
                    break;
                case 30://方向盘
                    this._content = "中";
                    DisableBrushUri = "Images/CarView/info_steeringwheel_disable.png";
                    NormalBrushUri = "Images/CarView/info_steeringwheel_default.png";
                    ActiveBrushUri = "Images/CarView/info_steeringwheel_active.png";
                    DefectiveBrushUri = "Images/CarView/info_steeringwheel_defective.png";
                    //ExtraLeftBrushUri = "";
                    //ExtraRightBrushUri = "";
                    CurrentActiveTipArea = ActiveTipArea.VirtualScenesLeftBoxArea;//
                    break;
                case 31:
                case 32:
                case 33:
                case 34://门
                    this._leftTopValue = "Off";
                    this._rightTopValue = "Off";
                    this._leftBottomValue = "Off";
                    this._rightBottomValue = "Off";
                    this._content = "";

                    DisableBrushUri = "Images/CarView/info_door_disable.png";
                    NormalBrushUri = "Images/CarView/info_door_default.png";
                    ActiveBrushUri = "Images/CarView/info_door_active.png";
                    DefectiveBrushUri = "Images/CarView/info_door_defective.png";
                    //ExtraLeftBrushUri = "";
                    //ExtraRightBrushUri = "";
                    CurrentActiveTipArea = ActiveTipArea.DataInfoBoxAreaAndMessageBoxArea;//

                    _canPlaySound = true;//新添加
                    break;
                case 35:
                case 36:
                case 37:
                case 38://窗
                    this._leftTopValue = "Off";
                    this._rightTopValue = "Off";
                    this._leftBottomValue = "Off";
                    this._rightBottomValue = "Off";
                    this._content = "";

                    DisableBrushUri = "Images/CarView/info_window_disable.png";
                    NormalBrushUri = "Images/CarView/info_window_default.png";
                    ActiveBrushUri = "Images/CarView/info_window_active.png";
                    DefectiveBrushUri = "Images/CarView/info_window_defective.png";
                    //ExtraLeftBrushUri = "";
                    //ExtraRightBrushUri = "";

                    CurrentActiveTipArea = ActiveTipArea.DataInfoBoxAreaAndMessageBoxArea;//

                    _canPlaySound = true;//新添加
                    break;
                case 39:
                case 40:
                case 41:
                case 42://胎压
                    this._leftTopValue = "0";
                    this._rightTopValue = "0";
                    this._leftBottomValue = "0";
                    this._rightBottomValue = "0";
                    //  this._content = string.Format(" {0} {1} {2} {3}  bar", this._leftTopValue, this._rightTopValue, this._leftBottomValue, this._rightBottomValue);
                    this._content = "  bar";

                    DisableBrushUri = "Images/CarView/info_tirepressure_disable.png";
                    NormalBrushUri = "Images/CarView/info_tirepressure_default.png";
                    ActiveBrushUri = "Images/CarView/info_tirepressure_active.png";
                    DefectiveBrushUri = "Images/CarView/info_tirepressure_defective.png";
                    //ExtraLeftBrushUri = "";
                    //ExtraRightBrushUri = "";
                    CurrentActiveTipArea = ActiveTipArea.VirtualScenesLeftBoxArea;//
                    break;
                case 43:
                case 44:
                case 45:
                case 46://车轮速度
                    this._leftTopValue = "0";
                    this._rightTopValue = "0";
                    this._leftBottomValue = "0";
                    this._rightBottomValue = "0";
                    //  this._content = string.Format(" {0} {1} {2} {3}  km/h", this._leftTopValue, this._rightTopValue, this._leftBottomValue, this._rightBottomValue);
                    this._content = "  km/h";

                    DisableBrushUri = "Images/CarView/info_wheelspeed_disable.png";
                    NormalBrushUri = "Images/CarView/info_wheelspeed_default.png";
                    ActiveBrushUri = "Images/CarView/info_wheelspeed_active.png";
                    DefectiveBrushUri = "Images/CarView/info_wheelspeed_defective.png";
                    //ExtraLeftBrushUri = "";
                    //ExtraRightBrushUri = "";
                    CurrentActiveTipArea = ActiveTipArea.VirtualScenesRightBoxArea;//
                    break;
                case 60://剩余油量
                    this._content = "0 L";
                    DisableBrushUri = "Images/CarView/info_remainingfuel_disable.png";
                    NormalBrushUri = "Images/CarView/info_remainingfuel_default.png";
                    ActiveBrushUri = "Images/CarView/info_remainingfuel_active.png";
                    DefectiveBrushUri = "Images/CarView/info_remainingfuel_defective.png";
                    //ExtraLeftBrushUri = "";
                    //ExtraRightBrushUri = "";
                    CurrentActiveTipArea = ActiveTipArea.VirtualScenesRightBoxArea;//
                    break;
                case 61://平均油耗
                    this._content = "0 L/1000km";
                    DisableBrushUri = "Images/CarView/info_averagefuelconsumption_disable.png";
                    NormalBrushUri = "Images/CarView/info_averagefuelconsumption_default.png";
                    ActiveBrushUri = "Images/CarView/info_averagefuelconsumption_active.png";
                    DefectiveBrushUri = "Images/CarView/info_averagefuelconsumption_defective.png";
                    //ExtraLeftBrushUri = "";
                    //ExtraRightBrushUri = "";
                    CurrentActiveTipArea = ActiveTipArea.VirtualScenesRightBoxArea;//
                    break;
                case 62://电池电压
                    this._content = "0 V";
                    DisableBrushUri = "Images/CarView/info_cellvoltate_disable.png";
                    NormalBrushUri = "Images/CarView/info_cellvoltate_default.png";
                    ActiveBrushUri = "Images/CarView/info_cellvoltate_active.png";
                    DefectiveBrushUri = "Images/CarView/info_cellvoltate_defective.png";
                    //ExtraLeftBrushUri = "";
                    //ExtraRightBrushUri = "";
                    CurrentActiveTipArea = ActiveTipArea.VirtualScenesRightBoxArea;//
                    break;
                case 63://再续里程
                    this._content = "0 Km";
                    DisableBrushUri = "Images/CarView/info_renewalmileage_disable.png";
                    NormalBrushUri = "Images/CarView/info_renewalmileage_default.png";
                    ActiveBrushUri = "Images/CarView/info_renewalmileage_active.png";
                    DefectiveBrushUri = "Images/CarView/info_renewalmileage_defective.png";
                    //ExtraLeftBrushUri = "";
                    //ExtraRightBrushUri = "";
                    CurrentActiveTipArea = ActiveTipArea.VirtualScenesRightBoxArea;//
                    break;
                case 64://发动机故障灯
                    this._content = "Off";
                    DisableBrushUri = "Images/CarView/info_enginefailurelight_disable.png";
                    NormalBrushUri = "Images/CarView/info_enginefailurelight_default.png";
                    ActiveBrushUri = "Images/CarView/info_enginefailurelight_active.png";
                    DefectiveBrushUri = "Images/CarView/info_enginefailurelight_defective.png";
                    //ExtraLeftBrushUri = "";
                    //ExtraRightBrushUri = "";
                    CurrentActiveTipArea = ActiveTipArea.DataInfoBoxAreaAndMessageBoxArea;//

                    _canPlaySound = true;//新添加
                    break;
                case 65://气囊故障灯
                    this._content = "Off";
                    DisableBrushUri = "Images/CarView/info_airbagfailurelight_disable.png";
                    NormalBrushUri = "Images/CarView/info_airbagfailurelight_default.png";
                    ActiveBrushUri = "Images/CarView/info_airbagfailurelight_active.png";
                    DefectiveBrushUri = "Images/CarView/info_airbagfailurelight_defective.png";
                    //ExtraLeftBrushUri = "";
                    //ExtraRightBrushUri = "";
                    CurrentActiveTipArea = ActiveTipArea.DataInfoBoxAreaAndMessageBoxArea;//

                    _canPlaySound = true;//新添加
                    break;
                case 66://发动机转速
                    this._content = "0 rpm";
                    DisableBrushUri = "Images/CarView/info_enginespeed_disable.png";
                    NormalBrushUri = "Images/CarView/info_enginespeed_default.png";
                    ActiveBrushUri = "Images/CarView/info_enginespeed_active.png";
                    DefectiveBrushUri = "Images/CarView/info_enginespeed_defective.png";
                    //ExtraLeftBrushUri = "";
                    //ExtraRightBrushUri = "";
                    CurrentActiveTipArea = ActiveTipArea.VirtualScenesRightBoxArea;//
                    break;
                case 67://瞬时油耗
                    this._content = "0 L/1000km";
                    DisableBrushUri = "Images/CarView/info_instantaneousfuelconsumption_disable.png";
                    NormalBrushUri = "Images/CarView/info_instantaneousfuelconsumption_default.png";
                    ActiveBrushUri = "Images/CarView/info_instantaneousfuelconsumption_active.png";
                    DefectiveBrushUri = "Images/CarView/info_instantaneousfuelconsumption_defective.png";
                    //ExtraLeftBrushUri = "";
                    //ExtraRightBrushUri = "";
                    CurrentActiveTipArea = ActiveTipArea.VirtualScenesRightBoxArea;//
                    break;
                case 68://发动机状态
                    this._content = "关";
                    DisableBrushUri = "Images/CarView/info_enginestate_disable.png";
                    NormalBrushUri = "Images/CarView/info_enginestate_default.png";
                    ActiveBrushUri = "Images/CarView/info_enginestate_active.png";
                    DefectiveBrushUri = "Images/CarView/info_enginestate_defective.png";
                    //ExtraLeftBrushUri = "";
                    //ExtraRightBrushUri = "";
                    CurrentActiveTipArea = ActiveTipArea.DataInfoBoxAreaAndMessageBoxArea;//

                    _canPlaySound = true;//新添加
                    break;
                case 69://机油指示灯
                    this._content = "Off";
                    DisableBrushUri = "Images/CarView/info_changeoillight_disable.png";
                    NormalBrushUri = "Images/CarView/info_changeoillight_default.png";
                    ActiveBrushUri = "Images/CarView/info_changeoillight_active.png";
                    DefectiveBrushUri = "Images/CarView/info_changeoillight_defective.png";
                    //ExtraLeftBrushUri = "";
                    //ExtraRightBrushUri = "";
                    CurrentActiveTipArea = ActiveTipArea.DataInfoBoxAreaAndMessageBoxArea;//

                    _canPlaySound = true;//新添加
                    break;
                default:
                    if (this.ValueType == 1)
                    {//值类型
                        this._content = "   "+this.ValueUnit;
                    }
                    else
                    {//0/1
                        
                    }
                    break;
            }

        }

        public string Content
        {
            get
            {
                return (string.Format("{0} {1} {2} {3}", LeftTopValue, RightTopValue, LeftBottomValue, RightBottomValue) + _content).TrimStart();
            }

            set
            {
                _content = value;
                OnPropertyChanged(new PropertyChangedEventArgs("Content"));
            }
        }

        public string LeftTopValue
        {
            get
            {
                return _leftTopValue;
            }

            set
            {
                _leftTopValue = value;
                OnPropertyChanged(new PropertyChangedEventArgs("LeftTopValue"));
            }
        }

        public string RightTopValue
        {
            get
            {
                return _rightTopValue;
            }

            set
            {
                _rightTopValue = value;
                OnPropertyChanged(new PropertyChangedEventArgs("RightTopValue"));
            }
        }

        public string LeftBottomValue
        {
            get
            {
                return _leftBottomValue;
            }

            set
            {
                _leftBottomValue = value;
                OnPropertyChanged(new PropertyChangedEventArgs("LeftBottomValue"));
            }
        }

        public string RightBottomValue
        {
            get
            {
                return _rightBottomValue;
            }

            set
            {
                _rightBottomValue = value;
                OnPropertyChanged(new PropertyChangedEventArgs("RightBottomValue"));
            }
        }

        /// <summary>
        /// 指示数据信息框的项图标切换状态
        /// </summary>
        public Status CurrentState
        {
            get
            {
                return _currentState;
            }

            set
            {
                _currentState = value;
                OnPropertyChanged(new PropertyChangedEventArgs("CurrentState"));
            }
        }

        public bool CanPlaySound
        {
            get
            {
                return _canPlaySound;
            }

            set
            {
                _canPlaySound = value;
                OnPropertyChanged(new PropertyChangedEventArgs("CanPlaySound"));
            }
        }
    }
}
