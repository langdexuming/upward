﻿using CarTool.Main.MVVM;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using CarInfoDB;

namespace CarTool.Main.Models
{
    public class InfoItemReview: NotificationObject
    {
        private int _infoItemId;

        private string _title;
        private bool _isEnable;
        private DataTypeBase _dataTypeObject;//五种类型间转换（bool类型，单字节，双字节，三字节，控制结构体）
        private string _content;

        public string MainDataTypeName { get; set; }//好像没有用到


        public override string ToString()
        {
            return _infoItemId + _title + _isEnable + _content;
        }

        /// <summary>
        /// 待删除
        /// </summary>
        /// <param name="title"></param>
        /// <param name="mainDataTypeName"></param>
        /// <param name="infoItemId"></param>
        /// <param name="isEnable"></param>
        /// <param name="content"></param>
        public InfoItemReview(int infoItemId, string title, string mainDataTypeName, bool isEnable, string content)
        {
            this._infoItemId = infoItemId;
            this._title = title;
            this.MainDataTypeName = mainDataTypeName;
            this._isEnable = isEnable;
            this._content = content;
            this._dataTypeObject= new Models.DataTypeBase( 0, "BOOL类型", "", 1, "Speed",0,0);
        }

        public InfoItemReview(int infoItemId, string title,string mainDataTypeName, bool isEnable, DataTypeBase dataTypeObject)
        {
            this._infoItemId = infoItemId;
            this._title = title;
            this.MainDataTypeName = mainDataTypeName;
            this._isEnable = isEnable;
            this._dataTypeObject = dataTypeObject;
            this._content = dataTypeObject?.ToString();
        }

        public InfoItemReview(InfoItemReview other)
        {
            this.InfoItemId = other.InfoItemId;
            this.Title = other.Title;
            this.MainDataTypeName = other.MainDataTypeName;
            this.IsEnable = other.IsEnable;
            this.DataTypeObject = other.DataTypeObject.Copy();
            this.Content = other.Content;
        }

        public InfoItemReview()
        {
            
        }

        public void SetInfoItem(InfoItem infoItem)
        {
            if (infoItem != null)
            {
                Title = infoItem.InfoItemName;
                InfoItemId = infoItem.InfoItemID;
                if (DataTypeObject != null)
                {
                    DataTypeObject.EnglishName = infoItem.EnglishName;
                }
            }
        }


        public string Title
        {
            get
            {
                return _title;
            }

            set
            {
                _title = value;
                RaisePropertyChanged(()=>Title);
            }
        }

        public bool IsEnable
        {
            get
            {
                return _isEnable;
            }

            set
            {
                _isEnable = value;
                RaisePropertyChanged(()=>IsEnable);
            }
        }

        public string Content
        {
            get
            {
                return _content;
            }

            set
            {
                _content = value;
                RaisePropertyChanged(()=>Content);
            }
        }


        public DataTypeBase DataTypeObject
        {
            get
            {
                return _dataTypeObject;
            }

            set
            {
                _dataTypeObject = value;
                this.Content = DataTypeObject.ToString();
                RaisePropertyChanged(()=> DataTypeObject);
            }
        }

        public int InfoItemId
        {
            get
            {
                return _infoItemId;
            }

            set
            {
                _infoItemId = value;
                RaisePropertyChanged(() => InfoItemId);
            }
        }
    }
}
