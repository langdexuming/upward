﻿using CarTool.Main.Models.Base;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Windows.Input;

namespace CarTool.Main.Models
{
    public class ControlInfoDetailReview : InfoDetailBase
    {
        private bool _isChecked;

        public string NormalBrushUri { get; set; }

        public string DisableBrushUri { get; set; }

        public string ClickBrushUri { get; set; }

        /// <summary>
        /// 单按钮控制开和关使用
        /// </summary>
        public string SwitchOnBrushUri { get; set; }

        /// <summary>
        /// 单按钮控制开和关使用
        /// </summary>
        public string SwitchOffBrushUri { get; set; }


        /// <summary>
        /// 升窗使用
        /// </summary>
        public string ExtraLeftPressBrushUri { get; set; }
        /// <summary>
        /// 降窗使用
        /// </summary>
        public string ExtraRightPressBrushUri { get; set; }


        /// <summary>
        /// 升窗
        /// </summary>
        public ICommand OnCommand{ get; set; }
        /// <summary>
        /// 降窗
        /// </summary>
        public ICommand OffCommand { get; set; }
        /// <summary>
        /// 单向控制命令
        /// </summary>
        public ICommand ClickCommand { get; set; }




        public ControlInfoDetailReview(int _id, string _name, bool _isEnabled=false)
        {
            this.Id = _id;
            this.InfoItemId = _id;
            this.Name = _name;
            this.IsEnabled = _isEnabled;
        }


        public bool IsChecked
        {
            get
            {
                return _isChecked;
            }

            set
            {
                _isChecked = value;
                OnPropertyChanged(new PropertyChangedEventArgs("IsChecked"));
            }
        }


    }
}
