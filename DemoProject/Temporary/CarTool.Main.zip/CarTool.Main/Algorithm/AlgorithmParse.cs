﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Text;

namespace CarTool.Main.Algorithm
{
    public static class AlgorithmParse
    {
        public enum Mode
        {
            Default = 0,
            Normal = 0,
            Gears,
            Wheel
        }

        /// <summary>
        ///     变量解析错误
        /// </summary>
        public const string ParameterParseError = "ParameterParseError";

        /// <summary>
        ///     深度解析/计算错误
        /// </summary>
        public const string DeepParseParseError = "DeepParseParseError";

        private static readonly DataTable ArithmeticTable = new DataTable();
        //
        /// <summary>
        ///     处理按位运算（包括&&，<<,>>,|,^）
        /// </summary>
        /// <param name="_tempStringBuilder"></param>
        /// <returns></returns>
        private static string DeepParse(StringBuilder _tempStringBuilder)
        {
            var postfixExp = _tempStringBuilder.ToString();
            // 循环检查，递归求值
            var _previous_operator_postion = -1;
            var chrs = postfixExp.ToCharArray();
            var length = chrs.Length;

            for (var i = 0; i < length; i++)
            {
                var _chr = chrs[i];
                switch (_chr)
                {
                    case '&':
                        //根据此位置获取左值和右值
                        //  string right_str = postfixExp.Substring(i+1, length-i - 1);
                        try
                        {
                            //此时已标记上已符号位置
                            for (var j = i + 1; j < length; j++)
                            {
                                //直接从下一个值开始
                                var __chr = chrs[j];
                                if (IsOperatersAndBrackets(__chr) || j == length - 1)
                                {
                                    //又碰到运算符
                                    var _left = "";
                                    if (_previous_operator_postion == -1)
                                        _left = postfixExp.Substring(0, i);
                                    else //上一符号的下一位置起，
                                        _left = postfixExp.Substring(_previous_operator_postion + 1,
                                            i - 1 - _previous_operator_postion);
                                    var _right = "";
                                    if (j == length - 1 && chrs[j] != ')')
                                        _right = postfixExp.Substring(i + 1, j - i);
                                    else
                                        _right = postfixExp.Substring(i + 1, j - i - 1);
                                    //如果包含0x说明是16进制
                                    var left_value = _left.Contains("0x")
                                        ? Convert.ToInt32(_left, 16)
                                        : Convert.ToInt32(_left);
                                    var right_value = _right.Contains("0x")
                                        ? Convert.ToInt32(_right, 16)
                                        : Convert.ToInt32(_right);

                                    var value = left_value & right_value;
                                    var value_str = value.ToString();

                                    _tempStringBuilder.Replace(_left + '&' + _right, value_str);
                                    if (_previous_operator_postion != -1)
                                        if (chrs[_previous_operator_postion] == '(' && chrs[j] == ')')
                                        {
                                            //如果是这种情况，替换这2个位子的数,重新作判断
                                            _tempStringBuilder.Replace("(" + value_str + ")", value_str);
                                            return DeepParse(_tempStringBuilder); //递归
                                        }
                                    i = j;
                                    //后一操作符位置
                                    //处理求值
                                    break;
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            Debug.Write(ex.Message + "Error Code:" + "Algo1001 [&]");
                            throw new Exception(ex.Message + "Error Code:" + "Algo1001 [&]"); //抛出异常
                        }
                        break;
                    case '<':
                        //根据此位置获取左值和右值
                        //  string right_str = postfixExp.Substring(i+1, length-i - 1);
                        try
                        {
                            for (var j = i + 1; j < length; j++)
                            {
                                var __chr = chrs[j];
                                if (__chr != '<' && IsOperatersAndBrackets(__chr) || j == length - 1)
                                {
                                    var _left = "";
                                    if (_previous_operator_postion == -1)
                                        _left = postfixExp.Substring(0, i);
                                    else //上一符号的下一位置起，
                                        _left = postfixExp.Substring(_previous_operator_postion + 1,
                                            i - 1 - _previous_operator_postion);

                                    var _right = "";
                                    if (j == length - 1 && chrs[j] != ')')
                                        _right = postfixExp.Substring(i + 1 + 1, j - i + 1 - 2);
                                    else
                                        _right = postfixExp.Substring(i + 1 + 1, j - i - 2);

                                    var left_value = _left.Contains("0x")
                                        ? Convert.ToInt32(_left, 16)
                                        : Convert.ToInt32(_left);
                                    var right_value = _right.Contains("0x")
                                        ? Convert.ToInt32(_right, 16)
                                        : Convert.ToInt32(_right);

                                    var value = left_value << right_value;
                                    var value_str = value.ToString();

                                    _tempStringBuilder.Replace(_left + "<<" + _right, value_str);
                                    if (_previous_operator_postion != -1)
                                        if (chrs[_previous_operator_postion] == '(' && chrs[j] == ')')
                                        {
                                            //如果是这种情况，替换这2个位子的数,重新作判断
                                            _tempStringBuilder.Replace("(" + value_str + ")", value_str);
                                            return DeepParse(_tempStringBuilder); //递归
                                        }
                                    i = j;
                                    //后一操作符位置
                                    //处理求值
                                    break;
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            Debug.Write(ex.Message + "Error Code:" + "Algo1001 [<]");
                            throw new Exception(ex.Message + "Error Code:" + "Algo1001 [<]"); //抛出异常
                        }
                        break;
                    case '>':
                        //根据此位置获取左值和右值
                        //  string right_str = postfixExp.Substring(i+1, length-i - 1);
                        try
                        {
                            for (var j = i + 1; j < length; j++)
                            {
                                var __chr = chrs[j];
                                if (__chr != '>' && IsOperatersAndBrackets(__chr) || j == length - 1)
                                {
                                    var _left = "";
                                    if (_previous_operator_postion == -1)
                                        _left = postfixExp.Substring(0, i);
                                    else //上一符号的下一位置起，
                                        _left = postfixExp.Substring(_previous_operator_postion + 1,
                                            i - 1 - _previous_operator_postion);
                                    var _right = "";

                                    if (j == length - 1 && chrs[j] != ')')
                                        _right = postfixExp.Substring(i + 1 + 1, j - i + 1 - 2);
                                    else
                                        _right = postfixExp.Substring(i + 1 + 1, j - i - 2);
                                    var left_value = _left.Contains("0x")
                                        ? Convert.ToInt32(_left, 16)
                                        : Convert.ToInt32(_left);
                                    var right_value = _right.Contains("0x")
                                        ? Convert.ToInt32(_right, 16)
                                        : Convert.ToInt32(_right);

                                    var value = left_value >> right_value;
                                    var value_str = value.ToString();

                                    _tempStringBuilder.Replace(_left + ">>" + _right, value_str);
                                    if (_previous_operator_postion != -1)
                                        if (chrs[_previous_operator_postion] == '(' && chrs[j] == ')')
                                        {
                                            //如果是这种情况，替换这2个位子的数,重新作判断
                                            _tempStringBuilder.Replace("(" + value_str + ")", value_str);
                                            return DeepParse(_tempStringBuilder); //递归
                                        }
                                    i = j;
                                    //后一操作符位置
                                    //处理求值
                                    break;
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            Debug.Write(ex.Message + "Error Code:" + "Algo1001 [>]");
                            throw new Exception(ex.Message + "Error Code:" + "Algo1001 [>]"); //抛出异常
                        }

                        break;
                    //case '/':
                    //    //根据此位置获取左值和右值
                    //    //  string right_str = postfixExp.Substring(i+1, length-i - 1);
                    //    for (int j = i + 1; j < length; j++)
                    //    {
                    //        char __chr = chrs[j];
                    //        if (IsOperatersAndBrackets(__chr))
                    //        {
                    //            string _left = postfixExp.Substring(_previous_operator_postion + 1, i - _previous_operator_postion - 1);
                    //            string _right = postfixExp.Substring(i + 1, j - i - 1);
                    //            double left_value = Convert.ToDouble(_left);
                    //            double right_value = Convert.ToDouble(_right);
                    //            double value = left_value / right_value;

                    //            _tempStringBuilder.Replace(_left + '/' + _right, value.ToString());
                    //            i = j + 1;
                    //            //后一操作符位置
                    //            //处理求值
                    //            break;
                    //        }
                    //    }
                    //    break;
                    //case '%':
                    //    break;
                    case '|':
                        //根据此位置获取左值和右值
                        //  string right_str = postfixExp.Substring(i+1, length-i - 1);
                        try
                        {
                            for (var j = i + 1; j < length; j++)
                            {
                                var __chr = chrs[j];
                                if (IsOperatersAndBrackets(__chr) || j == length - 1)
                                {
                                    var _left = "";
                                    if (_previous_operator_postion == -1)
                                        _left = postfixExp.Substring(0, i);
                                    else //上一符号的下一位置起，
                                        _left = postfixExp.Substring(_previous_operator_postion + 1,
                                            i - 1 - _previous_operator_postion);
                                    var _right = "";
                                    if (j == length - 1 && chrs[j] != ')')
                                        _right = postfixExp.Substring(i + 1, j - i);
                                    else
                                        _right = postfixExp.Substring(i + 1, j - i - 1);
                                    var left_value = _left.Contains("0x")
                                        ? Convert.ToInt32(_left, 16)
                                        : Convert.ToInt32(_left);
                                    var right_value = _right.Contains("0x")
                                        ? Convert.ToInt32(_right, 16)
                                        : Convert.ToInt32(_right);

                                    var value = left_value | right_value;
                                    var value_str = value.ToString();

                                    _tempStringBuilder.Replace(_left + '|' + _right, value_str);
                                    if (_previous_operator_postion != -1)
                                        if (chrs[_previous_operator_postion] == '(' && chrs[j] == ')')
                                        {
                                            //如果是这种情况，替换这2个位子的数,重新作判断
                                            _tempStringBuilder.Replace("(" + value_str + ")", value_str);
                                            return DeepParse(_tempStringBuilder); //递归
                                        }
                                    i = j;
                                    //后一操作符位置
                                    //处理求值
                                    break;
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            Debug.Write(ex.Message + "Error Code:" + "Algo1001 [|]");
                            throw new Exception(ex.Message + "Error Code:" + "Algo1001 [|]"); //抛出异常
                        }
                        break;
                    case '^':
                        //根据此位置获取左值和右值
                        //  string right_str = postfixExp.Substring(i+1, length-i - 1);
                        try
                        {
                            for (var j = i + 1; j < length; j++)
                            {
                                var __chr = chrs[j];
                                if (IsOperatersAndBrackets(__chr) || j == length - 1)
                                {
                                    var _left = "";
                                    if (_previous_operator_postion == -1)
                                        _left = postfixExp.Substring(0, i);
                                    else //上一符号的下一位置起
                                        _left = postfixExp.Substring(_previous_operator_postion + 1,
                                            i - 1 - _previous_operator_postion);
                                    var _right = "";

                                    if (j == length - 1 && chrs[j] != ')')
                                        _right = postfixExp.Substring(i + 1, j - i);
                                    else
                                        _right = postfixExp.Substring(i + 1, j - i - 1);

                                    var left_value = _left.Contains("0x")
                                        ? Convert.ToInt32(_left, 16)
                                        : Convert.ToInt32(_left);
                                    var right_value = _right.Contains("0x")
                                        ? Convert.ToInt32(_right, 16)
                                        : Convert.ToInt32(_right);
                                    //string _left = postfixExp.Substring(_previous_operator_postion + 1, i - _previous_operator_postion - 1);
                                    //string _right = postfixExp.Substring(i + 1, j - i - 1);
                                    //int left_value = Convert.ToInt32(_left);
                                    //int right_value = Convert.ToInt32(_right, 16);

                                    var value = left_value ^ right_value;
                                    var value_str = value.ToString();

                                    _tempStringBuilder.Replace(_left + '^' + _right, value_str);
                                    if (_previous_operator_postion != -1)
                                        if (chrs[_previous_operator_postion] == '(' && chrs[j] == ')')
                                        {
                                            //如果是这种情况，替换这2个位子的数,重新作判断
                                            _tempStringBuilder.Replace("(" + value_str + ")", value_str);
                                            return DeepParse(_tempStringBuilder); //递归
                                        }

                                    i = j;
                                    //后一操作符位置
                                    //处理求值
                                    break;
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            Debug.Write(ex.Message + "Error Code:" + "Algo1001 [^]");
                            throw new Exception(ex.Message + "Error Code:" + "Algo1001 [^]"); //抛出异常
                        }
                        break;


                    /**以下计算位置*/
                    default:
                        break;
                }
                if (IsOperatersAndBrackets(_chr))
                    _previous_operator_postion = i; //前一操作符位置

                if (i == length - 1 && _previous_operator_postion == -1)
                    if (_tempStringBuilder.ToString().Contains("0x"))
                        return Convert.ToInt32(_tempStringBuilder.ToString(), 16).ToString();
            }
            return _tempStringBuilder.ToString();
        }

        /// <summary>
        ///     原版本测试通过
        /// </summary>
        /// <param name="data"></param>
        /// <param name="_expression"></param>
        /// <param name="_postion"></param>
        /// <param name="_postion1"></param>
        /// <param name="_postion2"></param>
        /// <returns></returns>
        private static StringBuilder ParameterParse(byte[] data, string _expression, int _postion, int _postion1 = -1,
            int _postion2 = -1)
        {
            var TempStringBuilder = new StringBuilder(_expression);
            /*************把变量转化为数值******************/
            int[] byteKey = {_postion, _postion1, _postion2};
            foreach (var a in byteKey)
                if (a != -1) //判断单，双，三 字节
                {
                    //支持data
                    var ___str = "data" + a;
                    TempStringBuilder.Replace(___str, data[a].ToString()); //字节为10进制

                    //支持byte
                    ___str = "byte" + a;
                    TempStringBuilder.Replace(___str, data[a].ToString()); //字节为10进制
                }
            return TempStringBuilder;
        }

        /// <summary>
        ///     新增重载版本
        /// </summary>
        /// <param name="data"></param>
        /// <param name="_expression"></param>
        /// <returns></returns>
        private static StringBuilder ParameterParse(byte[] data, string _expression)
        {
            var TempStringBuilder = new StringBuilder(_expression);
            /*************把变量转化为数值******************/
            for (var a = 0; a < data.Length; a++)
                if (a != -1) //判断单，双，三 字节
                {
                    //支持data
                    var ___str = "data" + a;
                    TempStringBuilder.Replace(___str, data[a].ToString()); //字节为10进制

                    //支持byte
                    ___str = "byte" + a;
                    TempStringBuilder.Replace(___str, data[a].ToString()); //字节为10进制
                }
            return TempStringBuilder;
        }

        /// <summary>
        ///     新增重载版本(不需要指定替换的字节)
        /// </summary>
        /// <param name="data"></param>
        /// <param name="_expression"></param>
        /// <param name="mode"></param>
        /// <returns></returns>
        public static object Parse(Mode mode, byte[] data, string _expression)
        {
            //进行大小写，及全半角检查,并修改
            var _str = ToSBC(_expression).ToLower().Trim(' ');
            StringBuilder builder = null;
            try
            {
                builder = ParameterParse(data, _str);
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message + "Error Code : " + "ParameterParse");
                return ParameterParseError;
            }

            //根据模式具体处理
            if (mode == Mode.Default)
            {
                var _value = new object(); //防止传null
                var value = string.Empty;
                try
                {
                    value = DeepParse(builder);
                    _value = ArithmeticTable.Compute(value, "");
                }
                catch (Exception ex)
                {
                    Debug.WriteLine(ex.Message + "Error Code : " + "Alo1");
                    return DeepParseParseError;
                }

                return _value;
            } //可能造成很多异常，暂时无视

            #region 捕捉所有异常

            try
            {
                //1.特殊解析
                var leftStr = builder.ToString().Split('?')[0].Trim(' ');
                var rightStr = builder.ToString().Split('?')[1].Trim(' ');

                //算出公式
                var value = DeepParse(new StringBuilder(leftStr));
                //以下只可以做四则运算(包括%)，可以包含括号
                var _value = new object(); //防止传null
                _value = ArithmeticTable.Compute(value, "");
                switch (mode)
                {
                    case Mode.Gears:
                        //生成结果集合
                        var values = new Dictionary<int, string>();
                        foreach (var str in rightStr.Split(' '))
                        {
                            //算法->十进制数
                            var _keyStr = str.Remove(0, 1).Trim('(', ')');
                            var _ex = DeepParse(new StringBuilder(_keyStr));
                            var _exValue = ArithmeticTable.Compute(_ex, "");
                            var __key = Convert.ToInt32(_exValue);
                            var __value = str[0].ToString();
                            //可能存在值相同的档位，舍掉一个
                            if (!values.ContainsKey(__key))
                                values.Add(__key, __value);
                            else
                                values[__key] += "/" + __value;
                        }
                        var gearsValue = Convert.ToInt32(_value);
                        //得出档位
                        string gears;
                        if (values.TryGetValue(gearsValue, out gears))
                            return (gears + "").ToUpper();
                        return "?";
                    case Mode.Wheel:
                        //方向+角度模式算法
                        switch (rightStr[0])
                        {
                            case 'd':
                                //求指示方向的值
                                var byteStr = rightStr.Remove(0, 2).Split(' ')[0];
                                var bitStr = rightStr.Remove(0, 2).Split(' ')[1];

                                var byteValue = Convert.ToInt32(byteStr.Trim(' '));
                                var bitPostion = Convert.ToInt32(bitStr.Replace("bit", "").Trim(' '));
                                    //bit暂时没有在ParamterParse方法中替换

                                var mask = 1 << bitPostion; //掩码
                                var directionValue = 0;

                                if ((byteValue & mask) == mask)
                                    directionValue = 1;

                                //指示方向
                                var attachStr = _str.Split('?')[2].Trim(' ');
                                //生成结果集合
                                var directionValues = new Dictionary<string, char>();
                                foreach (var str in attachStr.Split(' '))
                                {
                                    var __key = "";
                                    //先从16进制转成数字，再转成字符串
                                    __key = Convert.ToInt32(str.Remove(0, 1).Trim('(', ')'), 16).ToString();
                                    var __value = str[0];
                                    directionValues.Add(__key, __value);
                                }
                                //得出方向
                                char direction;
                                if (directionValues.TryGetValue(directionValue.ToString(), out direction))
                                    switch (direction)
                                    {
                                        case 'l': //-
                                            return 0 - Convert.ToDouble(_value);
                                        case 'r': //+
                                            return Convert.ToDouble(_value);
                                        default:
                                            break;
                                    }
                                break;
                            case 'm':
                                //角度模式算法
                                var minStr = rightStr.Split(' ')[0];
                                var maxStr = rightStr.Split(' ')[1];

                                var minValue =
                                    Convert.ToInt32(
                                        ArithmeticTable.Compute(DeepParse(new StringBuilder(minStr.Split('=')[1])), ""));
                                var maxValue =
                                    Convert.ToInt32(
                                        ArithmeticTable.Compute(DeepParse(new StringBuilder(maxStr.Split('=')[1])), ""));

                                var valueD = Convert.ToDouble(_value);
                                var range = maxValue - minValue;
                                var medianValue = (maxValue + minValue) / 2;
                                return (valueD - medianValue) * 1080 / range;
                            case 'l':
                                //四值算法（L LC RC R）左 左中 右中 右
                                //int _lValue = 0;
                                //int _lcValue = 0;
                                //int _rcValue = 0;
                                //int _rValue = 0;
                                var strs = rightStr.Split(' ');
                                var keyValues = new Dictionary<string, int>();
                                for (var i = 0; i < strs.Length; i++)
                                    if (!string.IsNullOrWhiteSpace(strs[i]))
                                    {
                                        var items = strs[i].Trim(' ').TrimEnd(')').Split('(');
                                        var _ex = DeepParse(new StringBuilder(items[1]));
                                        var _exValue = ArithmeticTable.Compute(_ex, "");
                                        keyValues.Add(items[0], Convert.ToInt32(_exValue));
                                    }
                                var iValue = Convert.ToInt32(_value);

                                //左边跨度
                                var leftRangeValue = keyValues["lc"] - keyValues["l"];
                                if (leftRangeValue < 0)
                                    leftRangeValue = 0 - leftRangeValue; //取正
                                //右边跨度
                                var rightRangeValue = keyValues["rc"] - keyValues["r"];
                                if (rightRangeValue < 0)
                                    rightRangeValue = 0 - rightRangeValue; //取正

                                //如果左中>左
                                if (keyValues["lc"] > keyValues["l"])
                                {
                                    if (keyValues["l"] <= iValue && iValue <= keyValues["lc"])
                                        return (double) (-(keyValues["lc"] - iValue) * 540 / leftRangeValue);
                                }
                                else //如果左中<左
                                {
                                    if (keyValues["lc"] <= iValue && iValue <= keyValues["l"])
                                        return (double) (-(iValue - keyValues["lc"]) * 540 / leftRangeValue);
                                }

                                //如果右中>右
                                if (keyValues["rc"] > keyValues["r"])
                                {
                                    if (keyValues["r"] <= iValue && iValue <= keyValues["rc"])
                                        return (double) ((keyValues["rc"] - iValue) * 540 / rightRangeValue);
                                }
                                else //如果右中<右
                                {
                                    if (keyValues["rc"] <= iValue && iValue <= keyValues["r"])
                                        return (double) ((iValue - keyValues["rc"]) * 540 / rightRangeValue);
                                }
                                break;
                            default:
                                break;
                        }
                        break;
                    default:
                        break;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }

            #endregion

            return "?";
        }

        /// <summary>
        ///     新增加特殊解析(档位，方向盘)）
        /// </summary>
        /// <param name="data"></param>
        /// <param name="_expression"></param>
        /// <param name="_postion"></param>
        /// <param name="_postion1"></param>
        /// <param name="_postion2"></param>
        /// <param name="mode"></param>
        /// <returns></returns>
        public static object Parse(Mode mode, byte[] data, string _expression, int _postion, int _postion1 = -1,
            int _postion2 = -1)
        {
            //进行大小写，及全半角检查,并修改
            var _str = ToSBC(_expression).ToLower().Trim(' ');
            StringBuilder builder = null;
            try
            {
                builder = ParameterParse(data, _str, _postion, _postion1, _postion2);
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message + "Error Code : " + "ParameterParse");
                return ParameterParseError;
            }

            //根据模式具体处理
            if (mode == Mode.Default)
            {
                var _value = new object(); //防止传null
                var value = string.Empty;
                try
                {
                    value = DeepParse(builder);
                    _value = ArithmeticTable.Compute(value, "");
                }
                catch (Exception ex)
                {
                    Debug.WriteLine(ex.Message + "Error Code : " + "Alo1");
                    return DeepParseParseError;
                }

                return _value;
            } //可能造成很多异常，暂时无视

            #region 捕捉所有异常

            try
            {
                //1.特殊解析
                var leftStr = builder.ToString().Split('?')[0].Trim(' ');
                var rightStr = builder.ToString().Split('?')[1].Trim(' ');

                //算出公式
                var value = DeepParse(new StringBuilder(leftStr));
                //以下只可以做四则运算(包括%)，可以包含括号
                var _value = new object(); //防止传null
                _value = ArithmeticTable.Compute(value, "");
                switch (mode)
                {
                    case Mode.Gears:
                        //生成结果集合
                        var values = new Dictionary<int, string>();
                        foreach (var str in rightStr.Split(' '))
                        {
                            //算法->十进制数
                            var _keyStr = str.Remove(0, 1).Trim('(', ')');
                            var _ex = DeepParse(new StringBuilder(_keyStr));
                            var _exValue = ArithmeticTable.Compute(_ex, "");
                            var __key = Convert.ToInt32(_exValue);
                            var __value = str[0].ToString();
                            //可能存在值相同的档位，舍掉一个
                            if (!values.ContainsKey(__key))
                                values.Add(__key, __value);
                            else
                                values[__key] += "/" + __value;
                        }
                        var gearsValue = Convert.ToInt32(_value);
                        //得出档位
                        string gears;
                        if (values.TryGetValue(gearsValue, out gears))
                            return (gears + "").ToUpper();
                        return "?";
                    case Mode.Wheel:
                        //方向+角度模式算法
                        switch (rightStr[0])
                        {
                            case 'd':
                                //求指示方向的值
                                var byteStr = rightStr.Remove(0, 2).Split(' ')[0];
                                var bitStr = rightStr.Remove(0, 2).Split(' ')[1];

                                var byteValue = Convert.ToInt32(byteStr.Trim(' '));
                                var bitPostion = Convert.ToInt32(bitStr.Replace("bit", "").Trim(' '));
                                    //bit暂时没有在ParamterParse方法中替换

                                var mask = 1 << bitPostion; //掩码
                                var directionValue = 0;

                                if ((byteValue & mask) == mask)
                                    directionValue = 1;

                                //指示方向
                                var attachStr = _str.Split('?')[2].Trim(' ');
                                //生成结果集合
                                var directionValues = new Dictionary<string, char>();
                                foreach (var str in attachStr.Split(' '))
                                {
                                    var __key = "";
                                    //先从16进制转成数字，再转成字符串
                                    __key = Convert.ToInt32(str.Remove(0, 1).Trim('(', ')'), 16).ToString();
                                    var __value = str[0];
                                    directionValues.Add(__key, __value);
                                }
                                //得出方向
                                char direction;
                                if (directionValues.TryGetValue(directionValue.ToString(), out direction))
                                    switch (direction)
                                    {
                                        case 'l': //-
                                            return 0 - Convert.ToDouble(_value);
                                        case 'r': //+
                                            return Convert.ToDouble(_value);
                                        default:
                                            break;
                                    }
                                break;
                            case 'm':
                                //角度模式算法
                                var minStr = rightStr.Split(' ')[0];
                                var maxStr = rightStr.Split(' ')[1];

                                var minValue =
                                    Convert.ToInt32(
                                        ArithmeticTable.Compute(DeepParse(new StringBuilder(minStr.Split('=')[1])), ""));
                                var maxValue =
                                    Convert.ToInt32(
                                        ArithmeticTable.Compute(DeepParse(new StringBuilder(maxStr.Split('=')[1])), ""));

                                var valueD = Convert.ToDouble(_value);
                                var range = maxValue - minValue;
                                var medianValue = (maxValue + minValue) / 2;
                                return (valueD - medianValue) * 1080 / range;
                            case 'l':
                                //四值算法（L LC RC R）左 左中 右中 右
                                //int _lValue = 0;
                                //int _lcValue = 0;
                                //int _rcValue = 0;
                                //int _rValue = 0;
                                var strs = rightStr.Split(' ');
                                var keyValues = new Dictionary<string, int>();
                                for (var i = 0; i < strs.Length; i++)
                                    if (!string.IsNullOrWhiteSpace(strs[i]))
                                    {
                                        var items = strs[i].Trim(' ').TrimEnd(')').Split('(');
                                        var _ex = DeepParse(new StringBuilder(items[1]));
                                        var _exValue = ArithmeticTable.Compute(_ex, "");
                                        keyValues.Add(items[0], Convert.ToInt32(_exValue));
                                    }
                                var iValue = Convert.ToInt32(_value);

                                //左边跨度
                                var leftRangeValue = keyValues["lc"] - keyValues["l"];
                                if (leftRangeValue < 0)
                                    leftRangeValue = 0 - leftRangeValue; //取正
                                //右边跨度
                                var rightRangeValue = keyValues["rc"] - keyValues["r"];
                                if (rightRangeValue < 0)
                                    rightRangeValue = 0 - rightRangeValue; //取正

                                //如果左中>左
                                if (keyValues["lc"] > keyValues["l"])
                                {
                                    if (keyValues["l"] <= iValue && iValue <= keyValues["lc"])
                                        return (double) (-(keyValues["lc"] - iValue) * 540 / leftRangeValue);
                                }
                                else //如果左中<左
                                {
                                    if (keyValues["lc"] <= iValue && iValue <= keyValues["l"])
                                        return (double) (-(iValue - keyValues["lc"]) * 540 / leftRangeValue);
                                }

                                //如果右中>右
                                if (keyValues["rc"] > keyValues["r"])
                                {
                                    if (keyValues["r"] <= iValue && iValue <= keyValues["rc"])
                                        return (double) ((keyValues["rc"] - iValue) * 540 / rightRangeValue);
                                }
                                else //如果右中<右
                                {
                                    if (keyValues["rc"] <= iValue && iValue <= keyValues["r"])
                                        return (double) ((iValue - keyValues["rc"]) * 540 / rightRangeValue);
                                }
                                break;
                            default:
                                break;
                        }
                        break;
                    default:
                        break;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }

            #endregion

            return "?";
        }

        /// <summary>
        ///     判断是否是操作符或括弧
        /// </summary>
        /// <param name="_chr"></param>
        /// <returns></returns>
        private static bool IsOperatersAndBrackets(char _chr)
        {
            var _result = false;
            switch (_chr)
            {
                case '<':
                case '>':
                case '/':
                case '%':
                case '|':
                case '^':
                case '&':
                case '(':
                case ')':
                case '+':
                case '-':
                case '*':
                    _result = true;
                    break;
                default:
                    break;
            }

            return _result;
        }

        /// <summary>
        ///     是操作符返回true(不包括四则运算)
        /// </summary>
        /// <returns></returns>
        private static bool IsOperaters(char _chr)
        {
            var _result = false;
            switch (_chr)
            {
                case '<':
                case '>':
                case '^':
                case '&':
                case '|':
                    _result = true;
                    break;
                default:
                    break;
            }

            return _result;
        }

        /// <summary>
        ///     转化为半角字符串（扩展方法）
        /// </summary>
        /// <param name="input">要转化的字符串</param>
        /// <returns>半角字符串</returns>
        private static string ToSBC(string input) //single byte charactor
        {
            var c = input.ToCharArray();
            for (var i = 0; i < c.Length; i++)
            {
                if (c[i] == 12288) //全角空格为12288，半角空格为32
                {
                    c[i] = (char) 32;
                    continue;
                }
                if (c[i] > 65280 && c[i] < 65375) //其他字符半角(33-126)与全角(65281-65374)的对应关系是：均相差65248
                    c[i] = (char) (c[i] - 65248);
            }
            return new string(c);
        }

        /// <summary>
        ///     转化为全角字符串（扩展方法）
        /// </summary>
        /// <param name="input">要转化的字符串</param>
        /// <returns>全角字符串</returns>
        private static string ToDBC(string input) //double byte charactor 
        {
            var c = input.ToCharArray();
            for (var i = 0; i < c.Length; i++)
            {
                if (c[i] == 32)
                {
                    c[i] = (char) 12288;
                    continue;
                }
                if (c[i] < 127)
                    c[i] = (char) (c[i] + 65248);
            }
            return new string(c);
        }
    }
}