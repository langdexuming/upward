﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CarTool.Main.Services
{
    public class PerformInfoEventArgs: System.EventArgs
    {
        public int _infoItemId;

        public object _result;

        public PerformInfoEventArgs(int _id, object _result)
        {
            this._infoItemId = _id;
            this._result = _result;
        }
    }
}
