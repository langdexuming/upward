﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CarTool.Main.HeaderFile;
using static CarTool.Main.HeaderFile.CanDataBoredom;

namespace CarTool.Main.Services
{
    public class CanDataEventArgs : System.EventArgs
    {
        public DetailedCanData DetailedCanDataObject;

        public CanDataEventArgs(DetailedCanData detailedCanDataObject)
        {
            this.DetailedCanDataObject = detailedCanDataObject;
        }
    }
}
