﻿/************************
 *与Can串口的核心通讯类
 * Author:langdexuming
 * Update:2016.12.11
 * 更新内容：加了帧格式和帧类型的判断，
 * 帧命令唯一标识 改为 帧格式+帧类型+命令ID
 * 涉及该模块的多个函数，字典
 * 字典结果集的键值由命令ID=>帧格式+帧类型+命令ID 对应的字符串格式
 * ********************/

using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Timers;
using CarTool.Main.Algorithm;
using CarTool.Main.ECanUsb;
using CarTool.Main.HeaderFile;
using ECAN;
using static CarTool.Main.HeaderFile.CanDataBoredom;
using Timer = System.Timers.Timer;
using CarInfoDB;

namespace CarTool.Main.Services
{
    public class CanCoreCommunicateService : ICanCoreCommunicateService
    {
        private const string TAG = nameof(CanCoreCommunicateService);

        public event CanDataInfoEventHandler OnCanDataActive;
        public event ConnectStateChangedEventHandler OnConnectStateChanged;
        public event PerformInfoEventHandler OnPerformInfoActive;
        public event PerformInfoEventHandler OnEobdPerformInfoActive;

        private const uint DeviceType = 3;
        private const int MaxSendSemaphoreCounts = 100000;

        //使用栈队列(Struct)
        private readonly Queue<CanData> CanDataQueue = new Queue<CanData>(200); //用于数据分析
        private readonly Queue<CanData> CanDataQueue_Can2 = new Queue<CanData>(200); //用于数据分析
        //使用栈队列
        private readonly Queue<CanData> CanDataSendQueue = new Queue<CanData>();
        private readonly Queue<CanData> CanDataSendQueue2 = new Queue<CanData>();

        //存储只读信息数据处理规则
        private readonly List<CanDataWithRule> CarViewInfoGroup = new List<CanDataWithRule>();

        private readonly object lock_sync_CanDataQueue = new object(); //数据分析数据队列

        private readonly object lock_sync_CanDataQueue_Can2 = new object();

        /**can1*/
        private readonly object lock_sync1 = new object();

        /*can2**/
        private readonly object lock_sync1_can2 = new object();
        private readonly object lock_sync3 = new object();
        private readonly object lock_sync3_can2 = new object();
        private readonly object lock_sync4 = new object();
        private readonly object lock_sync4_can2 = new object();
        private readonly object lock_sync5 = new object();
        private readonly object lock_sync5_can2 = new object();
        private readonly object lock_syncSendQueue = new object();
        private readonly object lock_syncSendQueue2 = new object();

        private readonly object lock_syncWrite = new object();//Can1
        private readonly object lock_syncWrite2 = new object();//Can2

        //Can串口相关操作
        private readonly ComProc mCan = new ComProc();

        private byte _baudRate;
        private byte _baudRate2;
        //存储控制信息数据处理规则
        private readonly Dictionary<int, ControlInfo> SendControlDataFrameDictionary =
            new Dictionary<int, ControlInfo>();

        private readonly Mutex sendMutex = new Mutex();
        private readonly Semaphore sendSemaphore = new Semaphore(0, MaxSendSemaphoreCounts);

        private readonly Mutex sendMutex2 = new Mutex();
        private readonly Semaphore sendSemaphore2 = new Semaphore(0, MaxSendSemaphoreCounts);

        //只是Can类型，单/双
        //单Can：无视Can通道 双Can：根据只读信息处理规则中的CanId区分比较
        private int CanType;

        //轮询式读取Can串口数据(采用定时器,50ms周期)
        private readonly Timer dispatcherTimer;
        private readonly Timer dispatcherTimer2;

/****************************************EOBD**********************************************/

        private Modules CurrentEobdConnectMoudle = Modules.DataAnalysis;

        private ConnectState CurrentEobdConnectState;

        /// <summary>
        ///     当前EOBD协议
        /// </summary>
        private EobdProtocolType CurrentEobdProtocolType;

        /// <summary>
        ///     指示当前进行Eobd请求的CanId
        /// </summary>
        private byte CurrentEobdRequestCanId;

        private EobdCommunicatedInfo _currentEobdCommunicatedInfo;

        /// <summary>
        /// 用作导出功能！-与当前数据分析通信数据集合共同引用一个对象
        /// </summary>
        private Dictionary<int, EobdCommunicatedInfo> EobdCommunicatedInfoExportDictionary;
        /// <summary>
        /// 标准帧协议请求的命令集合
        /// </summary>
        private Dictionary<int, uint> EobdStandardRequestOrderIdDictionary;
        /// <summary>
        /// 扩展帧协议请求的命令集合
        /// </summary>
        private Dictionary<int, uint> EobdExtendRequestOrderIdDictionary;
        /// <summary>
        ///     EOBD请求信息集合
        /// </summary>
        private Dictionary<int, EobdCommunicatedInfo> EobdCommunicatedInfoDictionary;

        private RequestStatus EobdRequestState = RequestStatus.None;

        //用于EOBD的VinCode/故障码临时数据缓存
        private EobdSecondInfo EobdSecondInfoInstance;

        //拥有数据分析界面，EOBD标准帧请求
        private EobdCommunicatedInfo HandshakeStandardCommunicatedInfo;

        //拥有数据分析界面，EOBD扩展帧请求
        private EobdCommunicatedInfo HandshakeExtendCommunicatedInfo;

        /****************************************EOBD**********************************************/

        //是否转发
        private bool _isForwarding;

        //是否运行车型库
        private bool IsRunCarView = false;

        //是否运行数据分析
        private bool IsRunDataAnalysis = false;

        //指示是否处理Can1数据
        private bool IsRunDisplayCan = true;

        //指示是否处理Can2数据
        private bool IsRunDisplayCan2 = true;

        //指示连接状态
        private int m_connect;

        //从100修改为200（有些车数据较多，如现代-瑞纳 日产-轩逸）
        private int ReadBaseNumbers = 200;

        //50ms读取的最大帧数
        private int ReadMaxCounts = 30;
        private int ReadMaxCounts_can2 = 30;

        /// <summary>
        ///     指示是否连接
        /// </summary>
        /// <returns></returns>
        public bool IsOpen => m_connect > 0;

        public CanCoreCommunicateService()
        {
            dispatcherTimer = new Timer(30);
            dispatcherTimer.AutoReset = true;
            dispatcherTimer.Elapsed += dispatcherTimer_Tick;

            dispatcherTimer2 = new Timer(30);
            dispatcherTimer2.AutoReset = true;
            dispatcherTimer2.Elapsed += dispatcherTimer_Tick2;

            //数据分析界面的主列表发送按钮相关线程
            var canCoreSendThred = new Thread(SendCanData);
            canCoreSendThred.IsBackground = true;
            canCoreSendThred.Start();

            var canCoreSendThred2 = new Thread(SendCanData2);
            canCoreSendThred2.IsBackground = true;
            canCoreSendThred2.Start();

            var canCoreThread = new Thread(ThreadCanCoreDeal);
            canCoreThread.IsBackground = true;
            canCoreThread.Start();

            var canCoreThreadCan2 = new Thread(ThreadCanCoreDeal2);
            canCoreThreadCan2.IsBackground = true;
            canCoreThreadCan2.Start();

            _canCoreConfig1=new CanCoreConfig();
            _canCoreConfig2=new CanCoreConfig();
        }

        /// <summary>
        ///     开始过滤
        /// </summary>
        /// <param name="canId">Can通道</param>
        /// <param name="mode">过滤模式</param>
        /// <param name="readyCallBack">开始过滤时执行</param>
        /// <param name="callback">定时报告</param>
        /// <param name="completeAction"></param>
        /// <param name="pars">
        ///     时间 Within模式：n
        ///     Period模式:m,n
        /// </param>
        public void StartFilter(byte canId, FilterMode mode, Action readyCallBack,AsyncCallback callback,Action<List<string>> completeAction, params int[] pars)
        {
            var canCoreConfig = canId == 1 ? _canCoreConfig1 : _canCoreConfig2;

            #region 更改模式前准备

            switch (mode)
            {
                case FilterMode.Within:
                    if (pars.Length >= 1)
                    {
                        var nSec = pars[0];
                        //初始化控制变量
                        canCoreConfig.FilterStatusInstance = FilterStatus.None;

                        #region 开始前的处理

                        canCoreConfig.FilterWithinResultDictionary.Clear();
                        canCoreConfig.CanDataIdentiyMatchGroup.Clear();
                        lock (canCoreConfig.LockUniqueObjectGroupObject)
                        {
                            foreach (var detailedCanData in canCoreConfig.CanDataUniqueObjectGroup.Values)
                            {
                                canCoreConfig.CanDataIdentiyMatchGroup.Add(detailedCanData.Identity);
                                canCoreConfig.FilterWithinResultDictionary.Add(detailedCanData.Identity, new byte[64]);
                            }
                        }

                        #endregion

                        var thread = new Thread(() =>
                        {
                            int countDown = nSec;
                            canCoreConfig.FilterStatusInstance = FilterStatus.Filtering;
                            //同步回调
                            readyCallBack?.Invoke();
                            FilterTimingReport report = new FilterTimingReport();
                            for (int i = 0; i < nSec; i++)
                            {
                                Thread.Sleep(1000);
                                countDown--;
                                report.CountDown = countDown;
                                //异步回调
                                callback?.BeginInvoke(report, null, null);
                            }

                            //等待结果生成
                            canCoreConfig.FilterStatusInstance = FilterStatus.None;
                            //等待最后一个数据处理结束(此处由于多线程问题，会有1帧数据的误差,暂忽略不计)
                            //Thread.Sleep(10);

                            #region 处理结果(结束)

                            foreach (var pair in canCoreConfig.FilterWithinResultDictionary)
                            {
                                var isOk = false;
                                foreach (var result in pair.Value)
                                {
                                    if (!isOk) //没有发现合适的,就继续判断
                                        if (result == 1) //如果寻找到合适的位，就把该项添加到集合
                                            isOk = true;
                                }
                                // 移除不符合要求的
                                if (!isOk)
                                {
                                    canCoreConfig.CanDataIdentiyMatchGroup.Remove(pair.Key);
                                }
                            }
                            #endregion

                            completeAction?.Invoke(canCoreConfig.CanDataIdentiyMatchGroup);
                            canCoreConfig.FilterStatusInstance = FilterStatus.Filtered;
                        });

                        thread.Start();
                    }
                    break;
                case FilterMode.Period:
                    if (pars.Length >= 2)
                    {
                        //n秒
                        var nSec = pars[0];
                        //m秒
                        var mSec = pars[1];
                        //初始化控制变量
                        canCoreConfig.FilterStatusInstance = FilterStatus.None;

                        #region 开始前的处理
                        canCoreConfig.FilterPeriodResultDictionary.Clear(); //清除结果集字典
                        canCoreConfig.CanDataIdentiyMatchGroup.Clear();
                        lock (canCoreConfig.LockUniqueObjectGroupObject)
                        {
                            foreach (var item in canCoreConfig.CanDataUniqueObjectGroup.Values)
                            {
                                canCoreConfig.CanDataIdentiyMatchGroup.Add(item.Identity);
                                canCoreConfig.FilterPeriodResultDictionary.Add(item.Identity, new int[64]);
                            }
                        }


                        #endregion

                        var thread = new Thread(() =>
                        {
                            int countDown = mSec;
                            int countUp = 0;
                            canCoreConfig.FilterStatusInstance = FilterStatus.FilteringWithN;
                            //同步回调
                            readyCallBack?.Invoke();
                            FilterTimingReport report = new FilterTimingReport();
                            for (int i = 0; i < mSec; i++)
                            {
                                if (countUp == nSec)
                                {
                                    canCoreConfig.FilterStatusInstance = FilterStatus.FilteringWithM;
                                }
                                Thread.Sleep(1000);
                                countUp++;
                                countDown--;
                                report.CountDown = countDown;
                                //异步回调
                                callback?.BeginInvoke(report, null, null);
                            }
                            //等待结果生成
                            canCoreConfig.FilterStatusInstance = FilterStatus.None;
                            //等待最后一个数据处理结束(此处由于多线程问题，会有1帧数据的误差,暂忽略不计)
                            //Thread.Sleep(10);

                            #region 处理结果(结束)

                            foreach (var pair in canCoreConfig.FilterPeriodResultDictionary)
                            {
                                bool isOk = false;
                                for (int i = 0; i < 8; i++)
                                {
                                    int _result = pair.Value[i];
                                    if (_result >= 1)
                                    {
                                        isOk = true;
                                        i = 8; //跳出
                                    }
                                }
                                // 移除不符合要求的
                                if (!isOk)
                                {
                                    canCoreConfig.CanDataIdentiyMatchGroup.Remove(pair.Key);
                                }
                            }
                            #endregion

                            completeAction?.Invoke(canCoreConfig.CanDataIdentiyMatchGroup);
                            canCoreConfig.FilterStatusInstance = FilterStatus.Filtered;
                        });
                        thread.Start();
                    }
                    break;
            }

            #endregion

            //更改模式
            canCoreConfig.FilterModeInstance = mode;
        }

        /// <summary>
        ///     清空缓存的数据
        /// </summary>
        /// <param name="canId">Can通道</param>
        public void ClearCanData(byte canId)
        {
            switch (canId)
            {
                case 1:
                    //过滤中不允许清空
                    if ((_canCoreConfig1.FilterModeInstance != FilterMode.None) &&
                        ((_canCoreConfig1.FilterStatusInstance & FilterStatus.Filtering) > 0))
                    {
                        return;
                    }
                    //锁掉Can1处理
                    lock (_canCoreConfig1.LockUniqueObjectGroupObject)
                    {
                        _canCoreConfig1.CanDataUniqueObjectGroup.Clear();
                    }
                    break;
                case 2:
                    //过滤中不允许清空
                    if ((_canCoreConfig2.FilterModeInstance != FilterMode.None) &&
                        ((_canCoreConfig2.FilterStatusInstance & FilterStatus.Filtering) > 0))
                    {
                        return;
                    }
                    //锁掉Can2处理
                    lock (_canCoreConfig2.LockUniqueObjectGroupObject)
                    {
                        _canCoreConfig2.CanDataUniqueObjectGroup.Clear();
                    }
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        ///     打开CAN串口
        /// </summary>
        public bool OpenDevice(byte m_Baudrate, byte m_Baudrate2)
        {
            _baudRate = m_Baudrate;
            _baudRate2 = m_Baudrate2;
            return DoOpenDevice(m_Baudrate,_baudRate2);
        }
        /// <summary>
        ///     打开CAN串口
        /// </summary>
        private bool DoOpenDevice(byte m_Baudrate, byte m_Baudrate2)
        {
            //初始化指定的CAN
            var init_config = new INIT_CONFIG
            {
                AccCode = 0,
                AccMask = 0xffffff,
                Filter = 0
            };

            switch (m_Baudrate)
            {
                case 0: //1000

                    init_config.Timing0 = 0;
                    init_config.Timing1 = 0x14;

                    ReadMaxCounts = ReadBaseNumbers;
                    break;
                case 1: //800

                    init_config.Timing0 = 0;
                    init_config.Timing1 = 0x16;

                    ReadMaxCounts = (int) (ReadBaseNumbers * 0.8);
                    break;
                case 2: //666

                    init_config.Timing0 = 0x80;
                    init_config.Timing1 = 0xb6;

                    ReadMaxCounts = (int) (ReadBaseNumbers * 0.6);
                    break;
                case 3: //500

                    init_config.Timing0 = 0;
                    init_config.Timing1 = 0x1c;

                    ReadMaxCounts = (int) (ReadBaseNumbers * 0.5);
                    break;
                case 4: //400

                    init_config.Timing0 = 0x80;
                    init_config.Timing1 = 0xfa;

                    ReadMaxCounts = (int) (ReadBaseNumbers * 0.4);
                    break;
                case 5: //250

                    init_config.Timing0 = 0x01;
                    init_config.Timing1 = 0x1c;

                    ReadMaxCounts = (int) (ReadBaseNumbers * 0.3);
                    break;
                case 6: //200

                    init_config.Timing0 = 0x81;
                    init_config.Timing1 = 0xfa;

                    ReadMaxCounts = (int) (ReadBaseNumbers * 0.3);
                    break;
                case 7: //125

                    init_config.Timing0 = 0x03;
                    init_config.Timing1 = 0x1c;

                    ReadMaxCounts = (int) (ReadBaseNumbers * 0.125);
                    break;
                case 8: //100

                    init_config.Timing0 = 0x04;
                    init_config.Timing1 = 0x1c;

                    ReadMaxCounts = (int) (ReadBaseNumbers * 0.10);
                    break;
                case 9: //80

                    init_config.Timing0 = 0x83;
                    init_config.Timing1 = 0xff;

                    ReadMaxCounts = (int) (ReadBaseNumbers * 0.08);
                    break;
                case 10: //50

                    init_config.Timing0 = 0x09;
                    init_config.Timing1 = 0x1c;

                    ReadMaxCounts = (int) (ReadBaseNumbers * 0.05);
                    break;
            }
            //取30为最小值
            if (ReadMaxCounts < 30)
                ReadMaxCounts = 30;

            init_config.Mode = 0; //0：正常模式 1：只听模式

            if (ECANDLL.OpenDevice(DeviceType, 0, 0) != ECANStatus.STATUS_OK)
                return false;
            //Set can1 baud
            if (ECANDLL.InitCAN(DeviceType, 0, 0, ref init_config) != ECANStatus.STATUS_OK)
                return false;

            //set can2 baud
            switch (m_Baudrate2)
            {
                case 0: //1000

                    init_config.Timing0 = 0;
                    init_config.Timing1 = 0x14;

                    ReadMaxCounts_can2 = ReadBaseNumbers;
                    break;
                case 1: //800

                    init_config.Timing0 = 0;
                    init_config.Timing1 = 0x16;

                    ReadMaxCounts_can2 = (int) (ReadBaseNumbers * 0.8);
                    break;
                case 2: //666

                    init_config.Timing0 = 0x80;
                    init_config.Timing1 = 0xb6;

                    ReadMaxCounts_can2 = (int) (ReadBaseNumbers * 0.6);
                    break;
                case 3: //500

                    init_config.Timing0 = 0;
                    init_config.Timing1 = 0x1c;

                    ReadMaxCounts_can2 = (int) (ReadBaseNumbers * 0.5);
                    break;
                case 4: //400

                    init_config.Timing0 = 0x80;
                    init_config.Timing1 = 0xfa;

                    ReadMaxCounts_can2 = (int) (ReadBaseNumbers * 0.4);
                    break;
                case 5: //250

                    init_config.Timing0 = 0x01;
                    init_config.Timing1 = 0x1c;

                    ReadMaxCounts_can2 = (int) (ReadBaseNumbers * 0.3);
                    break;
                case 6: //200

                    init_config.Timing0 = 0x81;
                    init_config.Timing1 = 0xfa;

                    ReadMaxCounts_can2 = (int) (ReadBaseNumbers * 0.3);
                    break;
                case 7: //125

                    init_config.Timing0 = 0x03;
                    init_config.Timing1 = 0x1c;

                    ReadMaxCounts_can2 = (int) (ReadBaseNumbers * 0.125);
                    break;
                case 8: //100

                    init_config.Timing0 = 0x04;
                    init_config.Timing1 = 0x1c;

                    ReadMaxCounts_can2 = (int) (ReadBaseNumbers * 0.100);
                    break;
                case 9: //80

                    init_config.Timing0 = 0x83;
                    init_config.Timing1 = 0xff;

                    ReadMaxCounts_can2 = (int) (ReadBaseNumbers * 0.080);
                    break;
                case 10: //50

                    init_config.Timing0 = 0x09;
                    init_config.Timing1 = 0x1c;

                    ReadMaxCounts_can2 = (int) (ReadBaseNumbers * 0.050);
                    break;
            }
            //取30为最小值
            if (ReadMaxCounts_can2 < 30)
                ReadMaxCounts_can2 = 30;

            init_config.Mode = 0;

            if (ECANDLL.InitCAN(DeviceType, 0, 1, ref init_config) != ECANStatus.STATUS_OK)
                return false;

            m_connect = 1;
            mCan.EnableProc = true;

            if (m_connect == 0)
                return false;

            var canConnectNums = 0;
            //Start Can1

            if (ECANDLL.StartCAN(DeviceType, 0, 0) == ECANStatus.STATUS_OK)
            {
                App.Log("Start CAN1 Success,baudrate is " + m_Baudrate);
                dispatcherTimer.Enabled = true;
                canConnectNums++;
            }

            //start CAN2
            if (ECANDLL.StartCAN(DeviceType, 0, 1) == ECANStatus.STATUS_OK)
            {
                App.Log("Start CAN2 Success,baudrate is " + m_Baudrate2);
                dispatcherTimer2.Enabled = true;
                canConnectNums++;
            }

            ////可增加处理，若波特率不正确不予打开设备
            //Thread.Sleep(500);//等待判断错误值
            //bool isOk = !IsReceivedError && IsReceivedOk;

            //如果连接失败，则关闭
            if (canConnectNums == 0)
            {
                CloseDevice();
                return false;
            }
            OnConnectStateChanged?.Invoke(this, new ConnectStateChangeEventArgs(ConnectState.Connect));
            App.Log("the device is open");
            return true;
        }

        /// <summary>
        ///     close the Device
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void CloseDevice()
        {
            m_connect = 0;
            mCan.EnableProc = false;

            ECANDLL.CloseDevice(DeviceType, 0);

            dispatcherTimer.Enabled = false;
            dispatcherTimer2.Enabled = false;

            if (CurrentEobdConnectState == ConnectState.Connect)
                CurrentEobdConnectState = ConnectState.Disconnect;

            OnConnectStateChanged?.Invoke(this, new ConnectStateChangeEventArgs(ConnectState.Disconnect));

            App.Log("the device is closed");
        }

        /// <summary>
        ///     通知PerformInfo变化（车型库界面--包括(EOBD车型库)）
        /// </summary>
        /// <param name="_infoItemId"></param>
        /// <param name="_result"></param>
        public void ActivatePerformInfo(int _infoItemId, object _result)
        {
            //使用同步委托，确保数据按顺序处理
            OnPerformInfoActive?.Invoke(this, new PerformInfoEventArgs(_infoItemId, _result));
        }


        /// <summary>
        ///     通知PerformInfo变化（EOBD---数据分析）
        /// </summary>
        /// <param name="_infoItemId"></param>
        /// <param name="_result"></param>
        public void ActivateEobdPerformInfo(int _infoItemId, object _result)
        {
            //使用同步委托，确保数据按顺序处理
            OnEobdPerformInfoActive?.Invoke(this, new PerformInfoEventArgs(_infoItemId, _result));
        }


        /// <summary>
        ///     通知CanData变化（数据分析）
        /// </summary>
        /// <param name="detailedCanData"></param>
        public void ActivateCanData(DetailedCanData detailedCanData)
        {
            //使用同步委托，确保数据按顺序处理
            OnCanDataActive?.Invoke(this, new CanDataEventArgs(detailedCanData));
        }

        /// <summary>
        /// Can1数据核心处理
        /// </summary>
        private void ThreadCanCoreDeal()
        {
#if false
            Stopwatch sw = new Stopwatch();
            sw.Start();
#endif
            byte canId = 1;

            while (true)
            {
                if (CanDataQueue.Count > 0)
                {
                    CanData canData;

                    lock (lock_sync_CanDataQueue)
                    {
                        canData = CanDataQueue.Dequeue();
                    }
#if false
                    App.Log($"receive Data(can{canId}):" + canData, App.Module.Normal);
#else

#endif

                    /***************************车型库***************************************/
                    if (IsRunCarView)
                    {
                        ThreadCheckCarView(canData, canId);
                    }
                    /**********************数据分析***************************/
                    if (IsRunDataAnalysis && IsRunDisplayCan)
                    {
                        /***普通模块**/
                        lock (_canCoreConfig1.LockUniqueObjectGroupObject)
                        {
                            CanCoreDeal(canData, canId);
                        }

                        /***EOBD模块**/
                        if (CurrentEobdConnectMoudle == Modules.DataAnalysis &&
                            CurrentEobdConnectState == ConnectState.Connect)
                        {
                            CanCoreEobdDeal(canData, canId);
                        }

                        //如果需要转发
                        if (_isForwarding)
                        {
                            //转发
                            CanCoreForward(canData, canId);
                        }
                    }
                }
                else
                {
#if false
                    sw.Stop();
                    Console.WriteLine(sw.ElapsedTicks + "-" + sw.ElapsedMilliseconds);
#endif

                    Thread.Sleep(50);

#if false
                    sw.Restart();
#endif

                }
            }
        }

        /// <summary>
        /// 标准处理
        /// </summary>
        /// <param name="canData"></param>
        /// <param name="canId"></param>
        private void CanCoreDeal(ICanData canData,byte canId)
        {
            var currentFilterMode = canId == 1 ? _canCoreConfig1.FilterModeInstance : _canCoreConfig2.FilterModeInstance;
            var currentFilterStatus = canId == 1 ? _canCoreConfig1.FilterStatusInstance : _canCoreConfig2.FilterStatusInstance;

            switch (currentFilterMode)
            {
                case FilterMode.None:
                    ThreadCheckUnique(canData, canId);
                    break;
                case FilterMode.Within:
                    switch (currentFilterStatus)
                    {
                        case FilterStatus.None:
                            ThreadCheckUnique(canData, canId);
                            break;
                        case FilterStatus.Filtering:
                            ThreadFilterDisplay(canData, canId);
                            break;
                        case FilterStatus.Filtered:
                            ThreadCheckUnique(canData, canId);
                            break;
                        default:
                            break;
                    }
                    break;
                case FilterMode.Period:
                    switch (currentFilterStatus)
                    {
                        case FilterStatus.None:
                            ThreadCheckUnique(canData, canId);
                            break;
                        case FilterStatus.FilteringWithN:
                            ThreadFilterDisplay_PeriodN(canData, canId);
                            break;
                        case FilterStatus.FilteringWithM:
                            ThreadFilterDisplay_PeriodM(canData, canId);
                            break;
                        default:
                            ThreadCheckUnique(canData, canId);
                            break;
                    }
                    break;
            }
        }

        /// <summary>
        /// Can2数据核心处理
        /// </summary>
        private void ThreadCanCoreDeal2()
        {
            byte canId = 2;

            while (true)
            {
                if (CanDataQueue_Can2.Count > 0)
                {
                    CanData canData;
                    lock (lock_sync_CanDataQueue_Can2)
                    {
                        canData = CanDataQueue_Can2.Dequeue();
                    }
#if false
                    App.Log($"receive Data(can{canId}):" + canData, App.Module.Normal);
#else

#endif
                    /***************************车型库***************************************/
                    if (IsRunCarView)
                    {
                        ThreadCheckCarView(canData, canId);
                    }

                    /**********************数据分析***************************/
                    if (IsRunDataAnalysis && IsRunDisplayCan2)
                    {
                        /***普通模块***/
                        lock (_canCoreConfig2.LockUniqueObjectGroupObject)
                        {
                            CanCoreDeal(canData, canId);
                        }

                        /***EOBD模块***/
                        if (CurrentEobdConnectMoudle == Modules.DataAnalysis &&
                            CurrentEobdConnectState == ConnectState.Connect)
                        {
                            CanCoreEobdDeal(canData, canId);
                        }
                        //如果需要转发
                        if (_isForwarding)
                        {
                            CanCoreForward(canData, canId);
                        }
                    }
                }
                else
                {
                    Thread.Sleep(50);
                }
            }
        }

        private uint _startExternOrderId;
        private uint _endExternOrderId;
        /// <summary>
        ///     处理EOBD数据--
        /// </summary>
        /// <param name="canData"></param>
        /// <param name="info"></param>
        /// <param name="result"></param>
        private void EobdCoreDeal(ICanData canData, ref EobdCommunicatedInfo info, out object result)
        {
            result = null; //默认值

            var requestType = info.RequestType;

            //进行扩展帧解析的时候
            if (requestType == EobdRequestType.Handshake && CurrentEobdProtocolType == EobdProtocolType.Extend)
                if ((canData.ExternFlag == 1)&&(canData.OrderId != info.AnswerInfo.OrderId))
                    if (canData.OrderId >= _startExternOrderId &&
                        canData.OrderId <= _endExternOrderId)
                    {
                        //0x18dafxxx
                        info.AnswerInfo.OrderId = canData.OrderId;
                        info.IsReplyOk = true; //说明应答成功，则标志位
                    }
            if (info.AnswerInfo.Identity == canData.Identity)
            {
#region eobd信息解析

                if (requestType == EobdRequestType.Handshake)
                    info.IsReplyOk = true; //说明应答成功，则标志位
                //请求信息项
                if ((requestType & EobdRequestType.Info) > 0)
                    switch (requestType)
                    {
                        case EobdRequestType.VinCode:
                            if (canData.Length == 8)
                                if (canData.Data[0] == 16) //0x10
                                {
                                    if (CanCore.IsEobdAnswerData(info.RequestInfo.FrameData[0].Data, canData.Data, true))
                                    {
                                        //不重新初始化对象
                                        EobdSecondInfoInstance.Index = 0;
                                        EobdSecondInfoInstance.MaxIndex = 0;
                                        EobdSecondInfoInstance.IsHasSecond = true; //连帧
                                        info.Result = "";
                                        //处理结果
                                        var _vbytes = new byte[3];
                                        for (var i = 0; i < 3; i++)
                                            _vbytes[i] = canData.Data[5 + i];
                                        info.Result += Encoding.ASCII.GetString(_vbytes); //
                                        EobdSecondInfoInstance.MaxIndex = canData.Data[1] - 1; //字节数-1
                                        EobdSecondInfoInstance.Index += 3;
                                        info.IsReplyOk = true; //说明应答成功，则标志位
                                    }
                                }
                                else
                                {
                                    //无结果
                                    if (CanCore.IsEobdAnswerData(info.RequestInfo.FrameData[0].Data, canData.Data, false))
                                    {
                                        EobdSecondInfoInstance.Index = 0;
                                        EobdSecondInfoInstance.MaxIndex = 0;
                                        EobdSecondInfoInstance.IsHasSecond = false; //没有二次请求
                                        info.Result = "无";
                                        result = info.Result;
                                        info.IsReplyOk = true; //说明应答成功，则标志位
                                    }
                                }
                            break;
                        case EobdRequestType.VinSecond:
                            //如果是2次请求，全部接收完之后，才算应答成功
                            if (EobdSecondInfoInstance.Index < EobdSecondInfoInstance.MaxIndex)
                            {
                                if (canData.Data[0] == 0x21 + EobdSecondInfoInstance.Index / 8) //0x21
                                {
                                    info.Result += Encoding.ASCII.GetString(canData.Data, 1, canData.Length - 1);
                                    EobdSecondInfoInstance.Index += canData.Length;
                                }
                                if (EobdSecondInfoInstance.Index >= EobdSecondInfoInstance.MaxIndex)
                                {
                                    result = info.Result;
                                    info.IsReplyOk = true; //说明应答成功，则标志位
                                }
                            }
                            break;
                        case EobdRequestType.FaultCode:
                            if (canData.Length == 8)
                                if (canData.Data[0] == 0x10) //0x10
                                {
                                    if (CanCore.IsEobdAnswerData(info.RequestInfo.FrameData[0].Data, canData.Data, true))
                                    {
                                        EobdSecondInfoInstance.Index = 0;
                                        EobdSecondInfoInstance.MaxIndex = 0;
                                        EobdSecondInfoInstance.IsHasSecond = true; //连帧
                                        info.Result = "";
                                        for (var i = 4; i < 8; i++)
                                        {
                                            info.Result += CanCore.ParseFaultCode(canData.Data[i], canData.Data[i + 1]) + ",";
                                            i++;
                                        }

                                        EobdSecondInfoInstance.MaxIndex = canData.Data[1] - 1; //字节数-1
                                        EobdSecondInfoInstance.Index += 3;
                                        info.IsReplyOk = true; //说明应答成功，则标志位
                                    }
                                }
                                else
                                {
                                    //无连帧
                                    if (CanCore.IsEobdAnswerData(info.RequestInfo.FrameData[0].Data, canData.Data, false))
                                    {
                                        EobdSecondInfoInstance.Index = 0;
                                        EobdSecondInfoInstance.MaxIndex = 0;
                                        info.Result = "";
                                        EobdSecondInfoInstance.IsHasSecond = false; //没有二次请求
                                        EobdSecondInfoInstance.MaxIndex = canData.Data[2] * 2 - 1; //字节数-1(data2故障码个数)
                                        if (EobdSecondInfoInstance.MaxIndex >= 0)
                                        {
                                            int headIndex = 3;
                                            for (; EobdSecondInfoInstance.Index < EobdSecondInfoInstance.MaxIndex;EobdSecondInfoInstance.Index++)
                                            {
                                                var index = EobdSecondInfoInstance.Index;
                                                info.Result += CanCore.ParseFaultCode(canData.Data[headIndex + index], canData.Data[headIndex + index + 1]) + ",";
                                                EobdSecondInfoInstance.Index++;
                                            }
                                            result = info.Result.TrimEnd(',');
                                        }
                                        else
                                        {
                                            result = "无";
                                        }
                                        info.IsReplyOk = true; //说明应答成功，则标志位
                                    }
                                }

                            break;
                        case EobdRequestType.FaultSecond:
                            //如果是2次请求，全部接收完之后，才算应答成功
                            if (EobdSecondInfoInstance.Index < EobdSecondInfoInstance.MaxIndex)
                            {
                                if (canData.Data[0] == 0x21 + EobdSecondInfoInstance.Index / 8) //0x21
                                {
                                    //忽略首末字节
                                    for (var i = 1; i < canData.Length - 2; i++)
                                    {
                                        info.Result += CanCore.ParseFaultCode(canData.Data[i], canData.Data[i + 1]) + ",";
                                        i++;
                                    }
                                    EobdSecondInfoInstance.Index += canData.Length - 1; //末位并不算在数据长度里
                                }
                                if (EobdSecondInfoInstance.Index >= EobdSecondInfoInstance.MaxIndex)
                                {
                                    result = info.Result.TrimEnd(',');
                                    info.IsReplyOk = true; //说明应答成功，则标志位
                                }
                            }
                            break;
                        default:
                            //说明应答正常
                            if (CanCore.IsEobdAnswerData(info.RequestInfo.FrameData[0].Data, canData.Data, false))
                            {
                                result = AlgorithmParse.Parse(AlgorithmParse.Mode.Default, canData.Data,
                                    info.AnswerInfo.Algorithm);
                                info.IsReplyOk = true; //说明应答成功，则标志位
                            }
                            break;
                    }

#endregion

                App.Log("eobd receive Data:" + canData, App.Module.Eobd);
            }
        }

        /// <summary>
        ///     轮询读取值(仿真处理，不跟界面交互，最高达延时16ms)小于30ms（定时器周期）
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dispatcherTimer_Tick(object sender, EventArgs e)
        {
            ReadMessages();
            ReadError1();
        }

        private void dispatcherTimer_Tick2(object sender, ElapsedEventArgs e)
        {
            ReadMessages2();
            ReadError2();
        }

        /// <summary>
        ///     根据错误码，确定端口是否正常
        /// </summary>
        private void ReadError1()
        {
            if (_isAutoSpotBaudRateActively && (_autoSpotBaudRateCanId == 0))
            {
                CAN_ERR_INFO mErrInfo;

                if (ECANDLL.ReadErrInfo(DeviceType, 0, 0, out mErrInfo) == ECANStatus.STATUS_OK)
                {
                    if ((mErrInfo.ErrCode & 0x0006) == 0x0006)
                        IsReceivedError = true;
                    if ((mErrInfo.ErrCode & 0x0010) == 0x0010)
                        IsReceivedOk = true;
                    if ((mErrInfo.ErrCode & 0x0FA0) == 0x0FA0)
                        IsReceivedError = true;
                    App.Log("Auto spot baudRate- CAN1: Error Code:" +
                            string.Format("{0:X4}h", mErrInfo.ErrCode));
                }
                else
                {
                    App.Log("Auto spot baudRate- Can1 has error");
                }
            }
        }

        /// <summary>
        ///     根据错误码，确定端口是否正常
        /// </summary>
        private void ReadError2()
        {
            if (_isAutoSpotBaudRateActively && (_autoSpotBaudRateCanId == 1))
            {
                CAN_ERR_INFO mErrInfo;

                if (ECANDLL.ReadErrInfo(DeviceType, 0, 1, out mErrInfo) == ECANStatus.STATUS_OK)
                {
                    if ((mErrInfo.ErrCode & 0x0006) == 0x0006)
                        IsReceivedError = true;
                    if ((mErrInfo.ErrCode & 0x0010) == 0x0010)
                        IsReceivedOk = true;
                    if ((mErrInfo.ErrCode & 0x0FA0) == 0x0FA0)
                        IsReceivedError = true;
                    App.Log("Auto spot baudRate ing- CAN2: Error Code:" +
                            string.Format("{0:X4}h", mErrInfo.ErrCode));
                }
                else
                {
                    App.Log("Auto spot baudRate ing- Can2 has error");
                }
            }
        }

        /// <summary>
        ///     处理CAN1口接收到的信息(数据处理需要按顺序处理)
        /// </summary>
        private void ReadMessages()
        {
            var mCount = 0;

            lock (lock_sync1)
            {
                while (mCan.gRecMsgBufHead != mCan.gRecMsgBufTail)
                {
                    var frameinfo = mCan.gRecMsgBuf[mCan.gRecMsgBufTail];
                    mCan.gRecMsgBufTail += 1;
                    if (mCan.gRecMsgBufTail >= ComProc.REC_MSG_BUF_MAX)
                        mCan.gRecMsgBufTail = 0;

                    CanData canData = new CanData
                    {
                        RemoteFlag = frameinfo.RemoteFlag == 0 ? (byte)0 : (byte)1
                    };
                    if (frameinfo.ExternFlag == 0)
                    {
                        canData.ExternFlag = 0;
                        canData.OrderId = frameinfo.ID;
                    }
                    else
                    {
                        canData.ExternFlag = 1;
                        canData.OrderId = frameinfo.ID;
                    }
                    if (frameinfo.RemoteFlag == 0)
                    {
                        if (frameinfo.DataLen > 8)
                            frameinfo.DataLen = 8;
                        canData.Length = frameinfo.DataLen;
                        canData.Data = new byte[frameinfo.DataLen];
                        for (var i = 0; i < frameinfo.DataLen; i++)
                            canData.Data[i] = frameinfo.data[i];
                    }
                    else //远程帧
                    {
                        canData.Length = 0;
                        //较为安全
                        canData.Data = new byte[0];
                    }

                    canData.Time = Environment.TickCount;

                    if (IsRunCarView || (IsRunDataAnalysis && IsRunDisplayCan))
                    {
                        lock (lock_sync_CanDataQueue)
                        {
                            CanDataQueue.Enqueue(canData);
                        }
                    }

                    mCount++;
                    if (mCount >= ReadMaxCounts) //根据波特率的值改变
                        break;
                }
            }
        }

        /// <summary>
        ///     CarView(对应集合发生项更改事件)---暂时只检测更改
        /// </summary>
        /// <param name="state"></param>
        /// <param name="canId"></param>
        private void ThreadCheckCarView(ICanData state,byte canId)
        {
            //跳过远程帧的处理
            if (state.RemoteFlag != 0)
                return;

            var infoData = new InfoCanData(state,canId);

            //已改为顺序执行
            //  lock (lock_sync_carView)
            {
                var count = CarViewInfoGroup.Count;

#region 处理

                for (var i = 0; i < count; i++)
                {
                    var isOk = false;
                    switch (CanType)
                    {
                        case 1: //无视CanID
                            isOk = true;
                            break;
                        case 2: //如果CanID不同，跳过
                            if (infoData.CanId == CarViewInfoGroup[i].CanId)
                                isOk = true;
                            break;
                        default: //未赋值
                            return;
                    }

                    if (!isOk)
                        continue;

                    if (string.CompareOrdinal(CarViewInfoGroup[i].Identity, infoData.Identity)==0)
                    {
                        //普通信息
                        if (CarViewInfoGroup[i].InfoType == 0)
                        {
#region 正常处理
                            //这个判断纠结(初始化的数据规则处理集合CarViewInfoGroup中的data大小为8，这里只比较当前来的数据的有效区域)
                            if (CanCore.DataCompare(infoData.Data, CarViewInfoGroup[i].Data, infoData.Length,
                                infoData.Length))
                                return;
                            var item = CarViewInfoGroup[i];
                            //推测算法
                            var mode = AlgorithmParse.Mode.Default;
                            //自动识别相关
                            switch (item.InfoItemId)
                            {
                                case 11: //档位
                                    mode = AlgorithmParse.Mode.Gears;
                                    break;
                                case 30: //方向盘
                                    mode = AlgorithmParse.Mode.Wheel;
                                    break;
                                default:
                                    break;
                            }
                            //引入有效字节（4种+1判断）
                            switch (item.DataTypeId)
                            {
                                case 0: //Bool类型
                                    //效验有效字节
                                    if (item.EffectiveBytePostion >= infoData.Data.Length)
                                        break; //帧标识相同,数据长度不同(暂时没检测出来这样的帧)

                                    var p = item.EffectiveBytePostion;
                                    var by = item.Data[p];
                                    var _bitp = item.EffectiveBitPostion;
                                    //获取掩码
                                    var _bi = 1; //后续更改
                                    for (var _i = 0; _i < _bitp; _i++)
                                        _bi = _bi << 1;
                                    var value = item.EffectiveValue; //默认为1
                                    ////如果遇到数据长度减小的情况
                                    if ((by & _bi) != (infoData.Data[item.EffectiveBytePostion] & _bi))
                                        //如果状态发生改变 //TODO
                                    {
                                        item.Length = infoData.Length;
                                        item.Data = infoData.Data;
                                        var _result = false; //指示状态(与有效值状态)
                                        //
                                        by = item.Data[p]; //已更新的
                                        if (value > 0 && (by & _bi) > 0) //有效值跟当前有效字节&有效位都为真
                                            _result = true;
                                        if (value == 0 && (by & _bi) == 0) //有效值跟当前有效字节&有效位都为真
                                            _result = true;

                                        ActivatePerformInfo(item.InfoItemId, _result);
                                    }
                                    break;
                                case 1: //单字节
                                    //效验有效字节
                                    if (item.EffectiveBytePostion >= infoData.Data.Length)
                                        break; //帧标识相同,数据长度不同(暂时没检测出来这样的帧)

                                    var _p = item.EffectiveBytePostion;
                                    var _mask = item.Mask;
                                    if (_mask == 0)
                                        _mask = 255;
                                    if (CanCore.Operaten(item.Data[_p], _mask, infoData.Data[_p]))
                                    {
                                        item.Length = infoData.Length;
                                        item.Data = infoData.Data;

                                        var _result = AlgorithmParse.Parse(mode, infoData.Data, item.Algorithm, _p);
                                        ActivatePerformInfo(item.InfoItemId, _result);
                                    }
                                    break;
                                case 2: //双字节
                                    //效验有效字节
                                    if (item.EffectiveBytePostion >= infoData.Data.Length ||
                                        item.EffectiveByte2Postion >= infoData.Data.Length
                                    )
                                        break; //帧标识相同,数据长度不同(暂时没检测出来这样的帧)

                                    var _pair1 = item.EffectiveBytePostion;
                                    var pair1_mask = item.Mask; //High

                                    var _pair2 = item.EffectiveByte2Postion;
                                    var pair2_mask = item.Mask2; //Low

                                    if (pair1_mask == 0)
                                        pair1_mask = 255;
                                    if (pair2_mask == 0)
                                        pair2_mask = 255;

                                    if (CanCore.Operaten(item.Data[_pair1], pair1_mask, infoData.Data[_pair1]) ||
                                        CanCore.Operaten(item.Data[_pair2], pair2_mask, infoData.Data[_pair2]))
                                    {
                                        item.Length = infoData.Length;
                                        item.Data = infoData.Data;

                                        var _result = AlgorithmParse.Parse(mode, infoData.Data, item.Algorithm, _pair1,
                                            _pair2);
                                        ActivatePerformInfo(item.InfoItemId, _result);
                                    }

                                    break;
                                case 3:
                                    //效验有效字节
                                    if (item.EffectiveBytePostion >= infoData.Data.Length ||
                                        item.EffectiveByte2Postion >= infoData.Data.Length ||
                                        item.EffectiveByte3Postion >= infoData.Data.Length
                                    )
                                        break; //帧标识相同,数据长度不同(暂时没检测出来这样的帧)

                                    var _high = item.EffectiveBytePostion;
                                    var high_mask = item.Mask; //High

                                    var _middle = item.EffectiveByte2Postion;
                                    var middle_mask = item.Mask2; //middle

                                    var _low = item.EffectiveByte3Postion;
                                    var low_mask = item.Mask3; //Low

                                    if (high_mask == 0)
                                        high_mask = 255;
                                    if (middle_mask == 0)
                                        middle_mask = 255;
                                    if (low_mask == 0)
                                        low_mask = 255;

                                    if (CanCore.Operaten(item.Data[_high], high_mask, infoData.Data[_high]) ||
                                        CanCore.Operaten(item.Data[_middle], middle_mask, infoData.Data[_middle]) ||
                                        CanCore.Operaten(item.Data[_low], low_mask, infoData.Data[_low]))
                                    {
                                        item.Length = infoData.Length;
                                        item.Data = infoData.Data;

                                        var _result = AlgorithmParse.Parse(mode, infoData.Data, item.Algorithm, _high,
                                            _middle, _low);
                                        ActivatePerformInfo(item.InfoItemId, _result);
                                    }
                                    break;
                                case 16: //通用算法
                                    var tResult = AlgorithmParse.Parse(mode, infoData.Data, item.Algorithm);
                                    ActivatePerformInfo(item.InfoItemId, tResult);
                                    break;
                                case 128: //特殊
                                    //
                                    break;
                                default:
                                    break;
                            }

#endregion
                        }
                        else
                        {
#region Eobd处理

                            if (CurrentEobdConnectMoudle == Modules.CarView &&
                                CurrentEobdConnectState == ConnectState.Connect)
                                if (EobdRequestState == RequestStatus.WaitReply && _currentEobdCommunicatedInfo != null &&
                                    !_currentEobdCommunicatedInfo.IsReplyOk &&
                                    _currentEobdCommunicatedInfo.ForNotificationId == CarViewInfoGroup[i].InfoItemId)
                                {
                                    object result = null;
                                    var id = _currentEobdCommunicatedInfo.ForNotificationId;
                                    try
                                    {
                                        EobdCoreDeal(infoData, ref _currentEobdCommunicatedInfo, out result);
                                    }
                                    catch (Exception ex)
                                    {
                                        App.Log(TAG + ":" + "对Can数据进行EOBD解析出错,异常为" + ex.Message, App.Module.Eobd,
                                            App.LogLevel.Fatal);
                                    }

                                    if (result != null)
                                        ActivatePerformInfo(id, result);
                                }

#endregion
                        }

                        //更新数据
                        for (var j = 0; j < infoData.Length; j++)
                            CarViewInfoGroup[i].Data[j] = infoData.Data[j];
                    }
                }

#endregion
            }
        }

        /// <summary>
        ///     m秒外，n秒内匹配过程
        /// </summary>
        /// <param name="stateInfo"></param>
        /// <param name="canId"></param>
        private void ThreadFilterDisplay_PeriodN(ICanData stateInfo,byte canId)
        {
            string identity = stateInfo.Identity;
            var dealCanData = new DetailedCanData(stateInfo, canId);
            var canCoreConfig = dealCanData.CanId == 1 ? _canCoreConfig1 : _canCoreConfig2;

            //已改为顺序执行
            //   lock (lock_sync5)
            {
                if (canCoreConfig.CanDataIdentiyMatchGroup.Contains(item: identity))
                {
                    dealCanData.IsExist = true;
                    dealCanData = CanCore.CompareDealCanData(dealCanData, canCoreConfig.CanDataUniqueObjectGroup[identity]);

                    //如果发生了变化,标记为失效状态
                    for (int i = 0; i < dealCanData.Length; i++)
                    {
                        if (dealCanData.Data[i] != canCoreConfig.CanDataUniqueObjectGroup[identity].Data[i])
                            canCoreConfig.FilterPeriodResultDictionary[identity][i] = -1;
                    }

                    canCoreConfig.CanDataUniqueObjectGroup[identity] = dealCanData;

                }
                else
                {
                    canCoreConfig.FilterPeriodResultDictionary.Add(identity,new int[8]);
                    canCoreConfig.CanDataIdentiyMatchGroup.Add(identity);
                    canCoreConfig.CanDataUniqueObjectGroup.Add(identity, dealCanData);
                }

                ActivateCanData(dealCanData); //通知
            }
        }

        /// <summary>
        ///     m秒外，n秒内匹配过程
        /// </summary>
        /// <param name="stateInfo"></param>
        /// <param name="canId"></param>
        private void ThreadFilterDisplay_PeriodM(ICanData stateInfo,byte canId)
        {
            string identity = stateInfo.Identity;
            var dealCanData = new DetailedCanData(stateInfo,canId);
            var canCoreConfig = dealCanData.CanId == 1 ? _canCoreConfig1 : _canCoreConfig2;

            //已改为顺序执行
            //   lock (lock_sync5)
            {
                if (canCoreConfig.CanDataIdentiyMatchGroup.Contains(item: identity))
                {
                    dealCanData.IsExist = true;
                    dealCanData = CanCore.CompareDealCanData(dealCanData, canCoreConfig.CanDataUniqueObjectGroup[identity]);

                    //标记有效字节，忽略失效字节
                    for (int i = 0; i < dealCanData.Length; i++)
                    {
                        if (dealCanData.Data[i] != canCoreConfig.CanDataUniqueObjectGroup[identity].Data[i])
                            if (canCoreConfig.FilterPeriodResultDictionary[identity][i] != -1)
                                canCoreConfig.FilterPeriodResultDictionary[identity][i]++;
                    }

                    canCoreConfig.CanDataUniqueObjectGroup[identity] = dealCanData;

                }
                else
                {
                    canCoreConfig.FilterPeriodResultDictionary.Add(identity, new int[8]);
                    canCoreConfig.CanDataIdentiyMatchGroup.Add(identity);
                    canCoreConfig.CanDataUniqueObjectGroup.Add(identity, dealCanData);
                }

                ActivateCanData(dealCanData); //通知
            }
        }

        /// <summary>
        ///     n秒内匹配过程
        /// </summary>
        /// <param name="stateInfo"></param>
        /// <param name="canId"></param>
        private void ThreadFilterDisplay(ICanData stateInfo,byte canId)
        {
            string identiy = stateInfo.Identity;
            var dealCanData=new DetailedCanData(stateInfo, canId);
            var canCoreConfig = dealCanData.CanId == 1 ? _canCoreConfig1 : _canCoreConfig2;
            //已改为顺序执行
            // lock (lock_sync4)
            {
                if (canCoreConfig.CanDataIdentiyMatchGroup.Contains(item: identiy))
                {
                    dealCanData.IsExist = true;
                    dealCanData = CanCore.CompareDealCanData(dealCanData, canCoreConfig.CanDataUniqueObjectGroup[identiy]);

                    var _old = canCoreConfig.CanDataUniqueObjectGroup[identiy].Data;
                    var _new = dealCanData.Data;
                    byte[] _result=canCoreConfig.FilterWithinResultDictionary[identiy];
                    CanCore.CompareBit(_old, _new, ref _result); //引用更改

                    canCoreConfig.CanDataUniqueObjectGroup[identiy] = dealCanData;
                }
                else
                {
                    canCoreConfig.FilterWithinResultDictionary.Add(dealCanData.Identity, new byte[64]);
                    canCoreConfig.CanDataIdentiyMatchGroup.Add(identiy);

                    canCoreConfig.CanDataUniqueObjectGroup.Add(identiy, dealCanData);
                }
                //通知
                ActivateCanData(dealCanData);
            }
        }

        /// <summary>
        ///     供控制按钮使用(更新为主动控制发送)
        /// </summary>
        public bool SendControlCanData(int infoItemId)
        {
            var key = infoItemId;
            ControlInfo info;

            App.Log("Control info key ready send:" + key);

            if (SendControlDataFrameDictionary.TryGetValue(key, out info)) //查找不到就返回
            {
                if (!info.IsValid) return false;

                var list = info.FrameData;

                App.Log($"control Data(can{info.CanId}):...", App.Module.Control);

                SendCanData(list,info.CanId);

                return true;
            }

            return false;
        }

        /// <summary>
        ///     提供一个测试发送控制数据的方法(测试使用)
        /// </summary>
        public void TestControlSend(string _frameText, byte canId = 1)
        {
            List<CanData> list;
            try
            {
                list = CanCore.GetCanDataListBy(_frameText);
            }
            catch (Exception ex)
            {
                throw;
            }

            SyncSendCanData(list,canId);
        }

        /// <summary>
        ///     发送CanData数据
        /// </summary>
        public void SendCanData(ICanData iCanData, byte canId)
        {
            var canData = new CanData(iCanData) {TimeInterval = 0};
            switch (canId)
            {
                case 1:
                    //入队列
                    lock (lock_syncSendQueue)
                    {
                        CanDataSendQueue.Enqueue(canData);
                        App.Log("send Can1 Data:" + canData, App.Module.Normal);
                    }
                    sendSemaphore.Release();
                    break;
                case 2:
                    //入队列
                    lock (lock_syncSendQueue2)
                    {
                        CanDataSendQueue2.Enqueue(canData);
                        App.Log("send Can2 Data:" + canData, App.Module.Normal);
                    }
                    sendSemaphore2.Release();
                    break;
            }
        }

        /// <summary>
        ///     发送CanData数据
        /// </summary>
        public void SendCanData(CanData canData,byte canId)
        {
            canData.TimeInterval = 0;
            switch (canId)
            {
                case 1:
                    //入队列
                    lock (lock_syncSendQueue)
                    {
                        CanDataSendQueue.Enqueue(canData);
                        App.Log("send Can1 Data:" + canData, App.Module.Normal);
                    }
                    sendSemaphore.Release();
                    break;
                case 2:
                    //入队列
                    lock (lock_syncSendQueue2)
                    {
                        CanDataSendQueue2.Enqueue(canData);
                        App.Log("send Can2 Data:" + canData, App.Module.Normal);
                    }
                    sendSemaphore2.Release();
                    break;
            }

        }

        /// <summary>
        ///     发送CanData数据列（控制数据）
        /// </summary>
        public void SendCanData(List<ICanData> oList,byte canId)
        {
            if (oList?.Count > 0)
            {
                //copy一份
                var list = new List<CanData>();
                foreach (var canData in oList)
                {
                    list.Add(new CanData(canData));
                }

                //为了兼容之前的版本(旧版本,采集数据时，第一条数据的间隔时间有误)
                var indexItem = list[0];
                indexItem.TimeInterval = 0;
                list[0] = indexItem;

                ThreadStart ts = null;
                int index = 0;
                switch (canId)
                {
                    case 1:
                        ts = () =>
                        {
                            lock (lock_syncWrite)
                            {
                                foreach (var item in list)
                                {
                                    Thread.Sleep(item.TimeInterval);
                                    CanCoreWrite(item, canId);
                                    App.Log($"send list[{index}] Data(can{canId}):{list[index]}", App.Module.Normal);
                                    index++;
                                }
                            }
                        };
                        break;
                    case 2:
                        ts = () =>
                        {
                            lock (lock_syncWrite2)
                            {
                                foreach (var item in list)
                                {
                                    Thread.Sleep(item.TimeInterval);
                                    CanCoreWrite(item, canId);
                                    App.Log($"send list[{index}] Data(can{canId}):{list[index]}", App.Module.Normal);
                                    index++;
                                }
                            }
                        };
                        break;
                }

                if (ts != null) new Thread(ts).Start();

            }
        }

        /// <summary>
        ///     发送CanData数据列（控制数据）
        /// </summary>
        public void SendCanData(IList<CanData> oList, byte canId)
        {
            if (oList?.Count > 0)
            {
                //copy一份
                var list = new List<CanData>();
                foreach (var canData in oList)
                {
                    list.Add(canData);
                }

                //为了兼容之前的版本(旧版本,采集数据时，第一条数据的间隔时间有误)
                var indexItem = list[0];
                indexItem.TimeInterval = 0;
                list[0] = indexItem;

                ThreadStart ts = null;

                int index = 0;
                switch (canId)
                {
                    case 1:
                        ts = () =>
                        {
                            lock (lock_syncWrite)
                            {
                                foreach (var item in list)
                                {
                                    Thread.Sleep(item.TimeInterval);
                                    CanCoreWrite(item, canId);
                                    App.Log($"send list[{index}] Data(can{canId}):{list[index]}", App.Module.Normal);
                                    index++;
                                }
                            }
                        };
                        break;
                    case 2:
                        ts = () =>
                        {
                            lock (lock_syncWrite2)
                            {
                                foreach (var item in list)
                                {
                                    Thread.Sleep(item.TimeInterval);
                                    CanCoreWrite(item, canId);
                                    App.Log($"send list[{index}] Data(can{canId}):{list[index]}", App.Module.Normal);
                                    index++;
                                }
                            }
                        };
                        break;
                }

                if (ts != null) new Thread(ts).Start();

            }
        }

        /// <summary>
        ///     发送CanData数据列表(同步)
        /// </summary>
        public void SyncSendCanData(IList<CanData> oList, byte canId)
        {
            if (oList?.Count > 0)
            {
                //copy一份
                var list = new List<CanData>();
                foreach (var canData in oList)
                {
                    list.Add(canData);
                }

                //为了兼容之前的版本(旧版本,采集数据时，第一条数据的间隔时间有误)
                var indexItem = list[0];
                indexItem.TimeInterval = 0;
                list[0] = indexItem;

                int index = 0;
                switch (canId)
                {
                    case 1:
                        lock (lock_syncWrite)
                        {
                            foreach (var item in list)
                            {
                                Thread.Sleep(item.TimeInterval);
                                CanCoreWrite(item, canId);
                                App.Log($"send list[{index}] Data(can{canId}):{list[index]}", App.Module.Normal);
                                index++;
                            }
                        }
                        break;
                    case 2:
                        lock (lock_syncWrite2)
                        {
                            foreach (var item in list)
                            {
                                Thread.Sleep(item.TimeInterval);
                                CanCoreWrite(item, canId);
                                App.Log($"send list[{index}] Data(can{canId}):{list[index]}", App.Module.Normal);
                                index++;
                            }
                        }
                        break;
                }
            }
        }

        /// <summary>
        ///     后续需优化(在线程方法中进行)
        /// </summary>
        private void SendCanData()
        {
            while (true)
            {
                sendSemaphore.WaitOne();
                {
                    sendMutex.WaitOne();
                    //出队列
                    while (CanDataSendQueue.Count > 0)
                    {
                        CanData canData;
                        lock (lock_syncSendQueue)
                        {
                            canData = CanDataSendQueue.Dequeue();
                        }
                        
                        if (canData.TimeInterval > 0)
                        {
                            Thread.Sleep(canData.TimeInterval);
                        }

                        App.Log("send Can1 Data:" + canData, App.Module.Normal);

                        //此处需同步
                        lock (lock_syncWrite)
                        {
                            CanCoreWrite(canData, 1);
                        }
                    }
                    sendMutex.ReleaseMutex();
                }
                // sendSemaphore.Release();
            }
        }

        /// <summary>
        ///     后续需优化(在线程方法中进行)
        /// </summary>
        private void SendCanData2()
        {
            while (true)
            {
                sendSemaphore2.WaitOne();
                {
                    sendMutex2.WaitOne();
                    //出队列
                    while (CanDataSendQueue2.Count > 0)
                    {
                        CanData canData;
                        lock (lock_syncSendQueue2)
                        {
                            canData = CanDataSendQueue2.Dequeue();
                        }
                        App.Log("send Can2 Data:" + canData, App.Module.Normal);
                        if (canData.TimeInterval > 0)
                        {
                            Thread.Sleep(canData.TimeInterval);
                        }

                        //此处需同步
                        lock (lock_syncWrite2)
                        {
                            CanCoreWrite(canData, 2);
                        }
                    }
                    sendMutex2.ReleaseMutex();
                }
                // sendSemaphore2.Release();
            }
        }

        /// <summary>
        /// EOBD处理
        /// </summary>
        private void CanCoreEobdDeal(ICanData canDataOjbect, byte canId)
        {
            if (CurrentEobdRequestCanId == canId)
            {
                if (EobdRequestState == RequestStatus.WaitReply && _currentEobdCommunicatedInfo != null
                    && !_currentEobdCommunicatedInfo.IsReplyOk)
                {
                    object result = null;
                    var id = _currentEobdCommunicatedInfo.ForNotificationId;
                    try
                    {
                        EobdCoreDeal(canDataOjbect, ref _currentEobdCommunicatedInfo, out result);
                    }
                    catch (Exception ex)
                    {
                        App.Log(TAG + ":" + "对Can数据进行EOBD解析出错,异常为：" + ex.Message, App.Module.Eobd,
                            App.LogLevel.Fatal);
                    }

                    if (result != null)
                        ActivateEobdPerformInfo(id, result);
                }
            }
        }


        /// <summary>
        /// 数据转发
        /// </summary>
        public void CanCoreForward(ICanData iCanData,byte canId)
        {
            CanData canData = new CanData(iCanData);
            if (canId == 1)
            {
                SendCanData(canData, 2);
            }
            else if (canId == 2)
            {
                SendCanData(canData, 1);
            }
        }

        /// <summary>
        /// 设置是否运行
        /// </summary>
        /// <param name="canId"></param>
        /// <param name="value"></param>
        public void SetRun(byte canId,bool value)
        {
            if (canId == 1)
            {
                IsRunDisplayCan = value;
            }
            else
            {
                IsRunDisplayCan2 = value;
            }
        }

        /// <summary>
        /// 设置是否转发
        /// </summary>
        /// <param name="value"></param>
        public void SetForwarding(bool value)
        {
            _isForwarding = value;
        }
        /// <summary>
        /// 数据转发
        /// </summary>
        private void CanCoreForward(CanData canDataOjbect,byte canId)
        {
            if (canId == 1)
            {
                SendCanData(canDataOjbect,2);
            }
            else if (canId == 2)
            {
                SendCanData(canDataOjbect, 1);
            }
        }

        /// <summary>
        ///     对Can口进行写操作
        /// </summary>
        private void CanCoreWrite(CanData canDataOjbect,byte canId)
        {
            if (m_connect == 0)
                return;

            var frameinfo = new CAN_OBJ
            {
                data = new byte[8],
                SendType = 0,
                Reserved = new byte[2],
                ID = canDataOjbect.OrderId,
                DataLen = canDataOjbect.Length
            };

            //发送数组大小必须为8
            for (var i = 0; i < canDataOjbect.Length; i++)
                frameinfo.data[i] = canDataOjbect.Data[i];

            frameinfo.ExternFlag = canDataOjbect.ExternFlag; //standard

            frameinfo.RemoteFlag = canDataOjbect.RemoteFlag;

            switch (canId)
            {
                case 1:
                    mCan.gSendMsgBuf[mCan.gSendMsgBufHead].ID = frameinfo.ID;
                    mCan.gSendMsgBuf[mCan.gSendMsgBufHead].DataLen = frameinfo.DataLen;
                    mCan.gSendMsgBuf[mCan.gSendMsgBufHead].data = frameinfo.data;
                    mCan.gSendMsgBuf[mCan.gSendMsgBufHead].ExternFlag = frameinfo.ExternFlag;
                    mCan.gSendMsgBuf[mCan.gSendMsgBufHead].RemoteFlag = frameinfo.RemoteFlag;
                    mCan.gSendMsgBufHead += 1;
                    if (mCan.gSendMsgBufHead >= ComProc.SEND_MSG_BUF_MAX)
                        mCan.gSendMsgBufHead = 0;
                    break;
                case 2:
                    mCan.gSendMsgBuf2[mCan.gSendMsgBufHead2].ID = frameinfo.ID;
                    mCan.gSendMsgBuf2[mCan.gSendMsgBufHead2].DataLen = frameinfo.DataLen;
                    mCan.gSendMsgBuf2[mCan.gSendMsgBufHead2].data = frameinfo.data;
                    mCan.gSendMsgBuf2[mCan.gSendMsgBufHead2].ExternFlag = frameinfo.ExternFlag;
                    mCan.gSendMsgBuf2[mCan.gSendMsgBufHead2].RemoteFlag = frameinfo.RemoteFlag;
                    mCan.gSendMsgBufHead2 += 1;
                    if (mCan.gSendMsgBufHead2 >= ComProc.SEND_MSG_BUF_MAX)
                        mCan.gSendMsgBufHead2 = 0;
                    break;
                default:
                    break;
            }
        }


        /// <summary>
        ///     加载请求数据--内置文本文件(特殊)
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        public bool LoadEobdCommunicatedInfo(string text)
        {
            Tuple<List<List<CanData>>, List<CanDataWithRule>> tuple;
            this.HandshakeStandardCommunicatedInfo = null;
            this.HandshakeExtendCommunicatedInfo = null;
            try
            {
                tuple = CanCore.GetListBy(text);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            if (tuple != null)
            {
                EobdCommunicatedInfoDictionary = new Dictionary<int, EobdCommunicatedInfo>();

                var listRequest = tuple.Item1;
                var listAnswer = tuple.Item2;

                //此处定义核心通讯机制
                ////连接
                //标准协议
                var handshakeStandardCommunicatedInfo = new EobdCommunicatedInfo
                {
                    RequestInfo = new ControlInfo
                    {
                        FrameData = listRequest[0],
                        InfoImteId = (int)EobdRequestId.Handshake,
                        InfoType = (int)InfoTypeFlag.Eobd,
                        RemoteFlag = 0,
                        ExternFlag = 0,
                        CanId = 1,
                    },
                    AnswerInfo = new CanDataWithRule
                    {
                        OrderId = listAnswer[0].OrderId,
                        RemoteFlag = 0,
                        ExternFlag = 0,
                        Algorithm = listAnswer[0].Algorithm,
                        DataTypeId = (int)DataTypeFlag.Special,
                        InfoType = (int)InfoTypeFlag.Eobd,
                        CanId = 1,
                        InfoItemId = (int)EobdAnswerId.Handshake,
                    },
                    RequestType = EobdRequestType.Handshake,
                    IsReplyOk = false,
                    ForNotificationId = (int) EobdForNotificationId.Handshake,
                };

                //扩展帧协议请求数据
                var handshakeExtendCommunicatedInfo = new EobdCommunicatedInfo
                {
                    RequestInfo = new ControlInfo
                    {
                        FrameData = listRequest[1],
                        InfoImteId = (int)EobdRequestId.Handshake,
                        InfoType = (int)InfoTypeFlag.Eobd,
                        RemoteFlag = 0,
                        ExternFlag = 1,
                        CanId = 1,
                    },
                    AnswerInfo = new CanDataWithRule
                    {
                        OrderId = listAnswer[1].OrderId,
                        RemoteFlag = 0,
                        ExternFlag = 1,//扩展帧
                        Algorithm = listAnswer[1].Algorithm,
                        DataTypeId = (int)DataTypeFlag.Special,
                        InfoType = (int)InfoTypeFlag.Eobd,
                        CanId = 1,
                        InfoItemId = (int)EobdAnswerId.Handshake,
                    },
                    RequestType = EobdRequestType.Handshake,
                    IsReplyOk = false,
                    ForNotificationId = (int)EobdForNotificationId.Handshake,
                };

                //全局缓存
                this.HandshakeStandardCommunicatedInfo = handshakeStandardCommunicatedInfo;
                this.HandshakeExtendCommunicatedInfo = handshakeExtendCommunicatedInfo;
                //得出扩展帧应答范围
                _startExternOrderId = handshakeExtendCommunicatedInfo.AnswerInfo.OrderId;
                _endExternOrderId = handshakeExtendCommunicatedInfo.AnswerInfo.OrderId + 0xfff;

                //默认添加标准帧连接请求
                EobdCommunicatedInfoDictionary.Add((int)EobdRequestId.Handshake,
                    new EobdCommunicatedInfo
                    {
                        RequestInfo = new ControlInfo
                        {
                            FrameData = listRequest[0],
                            InfoImteId = (int)EobdRequestId.Handshake,
                            InfoType = (int)InfoTypeFlag.Eobd,
                            RemoteFlag = 0,
                            ExternFlag = 0,
                            CanId = 1,
                        },
                        AnswerInfo = new CanDataWithRule
                        {
                            OrderId = listAnswer[0].OrderId,
                            RemoteFlag = 0,
                            ExternFlag = 0,
                            Algorithm = listAnswer[0].Algorithm,
                            DataTypeId = (int)DataTypeFlag.Special,
                            InfoType = (int)InfoTypeFlag.Eobd,
                            CanId = 1,
                            InfoItemId = (int)EobdAnswerId.Handshake,
                        },
                        RequestType = EobdRequestType.Handshake,
                        IsReplyOk = false,
                        ForNotificationId = (int)EobdForNotificationId.Handshake,
                    });

                //VIN码
                EobdCommunicatedInfoDictionary.Add((int)EobdRequestId.VinCode, new EobdCommunicatedInfo
                {
                    RequestInfo = new ControlInfo
                    {
                        FrameData = listRequest[2],
                        InfoImteId = (int)EobdRequestId.VinCode,
                        InfoType = (int)InfoTypeFlag.Eobd,
                        RemoteFlag = 0,
                        ExternFlag = 0,
                        CanId = 1,
                    },
                    AnswerInfo = new CanDataWithRule
                    {
                        OrderId = listAnswer[2].OrderId,
                        RemoteFlag = 0,
                        ExternFlag = 0,
                        Algorithm = listAnswer[2].Algorithm,
                        DataTypeId = (int)DataTypeFlag.Algorithm,
                        InfoType = (int)InfoTypeFlag.Eobd,
                        CanId = 1,
                        InfoItemId = (int)EobdAnswerId.VinCode,
                    },
                    RequestType = EobdRequestType.VinCode,
                    IsReplyOk = false,
                    ForNotificationId = (int)EobdForNotificationId.VinCode,
                });

                //Vin码二次请求
                EobdCommunicatedInfoDictionary.Add((int)EobdRequestId.VinSecond, new EobdCommunicatedInfo
                {
                    RequestInfo = new ControlInfo
                    {
                        FrameData = listRequest[3],
                        InfoImteId = (int)EobdRequestId.VinSecond,
                        InfoType = (int)InfoTypeFlag.Eobd,
                        RemoteFlag = 0,
                        ExternFlag = 0,
                        CanId = 1,
                    },
                    AnswerInfo = new CanDataWithRule
                    {
                        OrderId = listAnswer[3].OrderId,
                        RemoteFlag = 0,
                        ExternFlag = 0,
                        Algorithm = listAnswer[3].Algorithm,
                        DataTypeId = (int)DataTypeFlag.Algorithm,
                        InfoType = (int)InfoTypeFlag.Eobd,
                        CanId = 1,
                        InfoItemId = (int)EobdAnswerId.VinSecond,
                    },
                    RequestType = EobdRequestType.VinSecond,
                    IsReplyOk = false,
                    ForNotificationId = (int)EobdForNotificationId.VinSecond,
                });

                //故障码请求
                EobdCommunicatedInfoDictionary.Add((int)EobdRequestId.FaultCode, new EobdCommunicatedInfo
                {
                    RequestInfo = new ControlInfo
                    {
                        FrameData = listRequest[4],
                        InfoImteId = (int)EobdRequestId.FaultCode,
                        InfoType = (int)InfoTypeFlag.Eobd,
                        RemoteFlag = 0,
                        ExternFlag = 0,
                        CanId = 1,
                    },
                    AnswerInfo = new CanDataWithRule
                    {
                        OrderId = listAnswer[4].OrderId,
                        RemoteFlag = 0,
                        ExternFlag = 0,
                        Algorithm = listAnswer[4].Algorithm,
                        DataTypeId = (int)DataTypeFlag.Algorithm,
                        InfoType = (int)InfoTypeFlag.Eobd,
                        CanId = 1,
                        InfoItemId = (int)EobdAnswerId.FaultCode,
                    },
                    RequestType = EobdRequestType.FaultCode,
                    IsReplyOk = false,
                    ForNotificationId = (int)EobdForNotificationId.FaultCode,
                });

                //故障码二次请求
                EobdCommunicatedInfoDictionary.Add((int)EobdRequestId.FaultSecond, new EobdCommunicatedInfo
                {
                    RequestInfo = new ControlInfo
                    {
                        FrameData = listRequest[5],
                        InfoImteId = (int)EobdRequestId.FaultSecond,
                        InfoType = (int)InfoTypeFlag.Eobd,
                        RemoteFlag = 0,
                        ExternFlag = 0,
                        CanId = 1,
                    },
                    AnswerInfo = new CanDataWithRule
                    {
                        OrderId = listAnswer[5].OrderId,
                        RemoteFlag = 0,
                        ExternFlag = 0,
                        Algorithm = listAnswer[5].Algorithm,
                        DataTypeId = (int)DataTypeFlag.Algorithm,
                        InfoType = (int)InfoTypeFlag.Eobd,
                        CanId = 1,
                        InfoItemId = (int)EobdAnswerId.FaultSecond
                    },
                    RequestType = EobdRequestType.FaultSecond,
                    IsReplyOk = false,
                    ForNotificationId = (int)EobdForNotificationId.FaultSecond
                });

                ////信息请求
                //-绝对负荷值请求
                EobdCommunicatedInfoDictionary.Add((int)EobdRequestId.AbsoluteLoadValue, new EobdCommunicatedInfo
                {
                    RequestInfo = new ControlInfo
                    {
                        FrameData = listRequest[6],
                        InfoImteId = (int)EobdRequestId.AbsoluteLoadValue,
                        InfoType = (int)InfoTypeFlag.Eobd,
                        RemoteFlag = 0,
                        ExternFlag = 0,
                        CanId = 1,
                    },
                    AnswerInfo = new CanDataWithRule
                    {
                        OrderId = listAnswer[6].OrderId,
                        RemoteFlag = 0,
                        ExternFlag = 0,
                        Algorithm = listAnswer[6].Algorithm,
                        DataTypeId = (int)DataTypeFlag.Algorithm,
                        InfoType = (int)InfoTypeFlag.Eobd,
                        CanId = 1,
                        InfoItemId = (int)EobdAnswerId.AbsoluteLoadValue,
                    },
                    RequestType = EobdRequestType.AbsoluteLoadValue,
                    IsReplyOk = false,
                    ForNotificationId = (int)EobdForNotificationId.AbsoluteLoadValue,
                });

                //-冷却液温度请求
                EobdCommunicatedInfoDictionary.Add((int)EobdRequestId.CoolantTemperature, new EobdCommunicatedInfo
                {
                    RequestInfo = new ControlInfo
                    {
                        FrameData = listRequest[7],
                        InfoImteId = (int)EobdRequestId.CoolantTemperature,
                        InfoType = (int)InfoTypeFlag.Eobd,
                        RemoteFlag = 0,
                        ExternFlag = 0,
                        CanId = 1,
                    },
                    AnswerInfo = new CanDataWithRule
                    {
                        OrderId = listAnswer[7].OrderId,
                        RemoteFlag = 0,
                        ExternFlag = 0,
                        Algorithm = listAnswer[7].Algorithm,
                        DataTypeId = (int)DataTypeFlag.Algorithm,
                        InfoType = (int)InfoTypeFlag.Eobd,
                        CanId = 1,
                        InfoItemId = (int)EobdAnswerId.CoolantTemperature,
                    },
                    RequestType = EobdRequestType.CoolantTemperature,
                    IsReplyOk = false,
                    ForNotificationId = (int)EobdForNotificationId.CoolantTemperature,
                });

                //-节气门绝对位置请求
                EobdCommunicatedInfoDictionary.Add((int)EobdRequestId.AbsoluteThrottlePosition, new EobdCommunicatedInfo
                {
                    RequestInfo = new ControlInfo
                    {
                        FrameData = listRequest[8],
                        InfoImteId = (int)EobdRequestId.AbsoluteThrottlePosition,
                        InfoType = (int)InfoTypeFlag.Eobd,
                        RemoteFlag = 0,
                        ExternFlag = 0,
                        CanId = 1,
                    },
                    AnswerInfo = new CanDataWithRule
                    {
                        OrderId = listAnswer[8].OrderId,
                        RemoteFlag = 0,
                        ExternFlag = 0,
                        Algorithm = listAnswer[8].Algorithm,
                        DataTypeId = (int)DataTypeFlag.Algorithm,
                        InfoType = (int)InfoTypeFlag.Eobd,
                        CanId = 1,
                        InfoItemId = (int)EobdAnswerId.AbsoluteThrottlePosition,
                    },
                    RequestType = EobdRequestType.AbsoluteThrottlePosition,
                    IsReplyOk = false,
                    ForNotificationId = (int)EobdForNotificationId.AbsoluteThrottlePosition,
                });

                //-控制模块电压请求
                EobdCommunicatedInfoDictionary.Add((int)EobdRequestId.ControlModuleVoltage, new EobdCommunicatedInfo
                {
                    RequestInfo = new ControlInfo
                    {
                        FrameData = listRequest[9],
                        InfoImteId = (int)EobdRequestId.ControlModuleVoltage,
                        InfoType = (int)InfoTypeFlag.Eobd,
                        RemoteFlag = 0,
                        ExternFlag = 0,
                        CanId = 1,
                    },
                    AnswerInfo = new CanDataWithRule
                    {
                        OrderId = listAnswer[9].OrderId,
                        RemoteFlag = 0,
                        ExternFlag = 0,
                        Algorithm = listAnswer[9].Algorithm,
                        DataTypeId = (int)DataTypeFlag.Algorithm,
                        InfoType = (int)InfoTypeFlag.Eobd,
                        CanId = 1,
                        InfoItemId = (int)EobdAnswerId.ControlModuleVoltage,
                    },
                    RequestType = EobdRequestType.ControlModuleVoltage,
                    IsReplyOk = false,
                    ForNotificationId = (int)EobdForNotificationId.ControlModuleVoltage,
                });

                //-燃油液位输入请求
                EobdCommunicatedInfoDictionary.Add((int)EobdRequestId.FuelLevelInput, new EobdCommunicatedInfo
                {
                    RequestInfo = new ControlInfo
                    {
                        FrameData = listRequest[10],
                        InfoImteId = (int)EobdRequestId.FuelLevelInput,
                        InfoType = (int)InfoTypeFlag.Eobd,
                        RemoteFlag = 0,
                        ExternFlag = 0,
                        CanId = 1,
                    },
                    AnswerInfo = new CanDataWithRule
                    {
                        OrderId = listAnswer[10].OrderId,
                        RemoteFlag = 0,
                        ExternFlag = 0,
                        Algorithm = listAnswer[10].Algorithm,
                        DataTypeId = (int)DataTypeFlag.Algorithm,
                        InfoType = (int)InfoTypeFlag.Eobd,
                        CanId = 1,
                        InfoItemId = (int)EobdAnswerId.FuelLevelInput,
                    },
                    RequestType = EobdRequestType.FuelLevelInput,
                    IsReplyOk = false,
                    ForNotificationId = (int)EobdForNotificationId.FuelLevelInput,
                });

                //-气缸1点火提前角请求
                EobdCommunicatedInfoDictionary.Add((int)EobdRequestId.Cylinder1IgnitionAdvanceAngle, new EobdCommunicatedInfo
                {
                    RequestInfo = new ControlInfo
                    {
                        FrameData = listRequest[11],
                        InfoImteId = (int)EobdRequestId.Cylinder1IgnitionAdvanceAngle,
                        InfoType = (int)InfoTypeFlag.Eobd,
                        RemoteFlag = 0,
                        ExternFlag = 0,
                        CanId = 1,
                    },
                    AnswerInfo = new CanDataWithRule
                    {
                        OrderId = listAnswer[11].OrderId,
                        RemoteFlag = 0,
                        ExternFlag = 0,
                        Algorithm = listAnswer[11].Algorithm,
                        DataTypeId = (int)DataTypeFlag.Algorithm,
                        InfoType = (int)InfoTypeFlag.Eobd,
                        CanId = 1,
                        InfoItemId = (int)EobdAnswerId.Cylinder1IgnitionAdvanceAngle,
                    },
                    RequestType = EobdRequestType.Cylinder1IgnitionAdvanceAngle,
                    IsReplyOk = false,
                    ForNotificationId = (int)EobdForNotificationId.Cylinder1IgnitionAdvanceAngle,
                });

                //-发动机负荷
                EobdCommunicatedInfoDictionary.Add((int)EobdRequestId.EngineLoad, new EobdCommunicatedInfo
                {
                    RequestInfo = new ControlInfo
                    {
                        FrameData = listRequest[12],
                        InfoImteId = (int)EobdRequestId.EngineLoad,
                        InfoType = (int)InfoTypeFlag.Eobd,
                        RemoteFlag = 0,
                        ExternFlag = 0,
                        CanId = 1,
                    },
                    AnswerInfo = new CanDataWithRule
                    {
                        OrderId = listAnswer[12].OrderId,
                        RemoteFlag = 0,
                        ExternFlag = 0,
                        Algorithm = listAnswer[12].Algorithm,
                        DataTypeId = (int)DataTypeFlag.Algorithm,
                        InfoType = (int)InfoTypeFlag.Eobd,
                        CanId = 1,
                        InfoItemId = (int)EobdAnswerId.EngineLoad,
                    },
                    RequestType = EobdRequestType.EngineLoad,
                    IsReplyOk = false,
                    ForNotificationId = (int)EobdForNotificationId.EngineLoad,
                });

                //-空气流量传感器的空气流量
                EobdCommunicatedInfoDictionary.Add((int)EobdRequestId.AirFlowRateOfAirFlowSensor, new EobdCommunicatedInfo
                {
                    RequestInfo = new ControlInfo
                    {
                        FrameData = listRequest[13],
                        InfoImteId = (int)EobdRequestId.AirFlowRateOfAirFlowSensor,
                        InfoType = (int)InfoTypeFlag.Eobd,
                        RemoteFlag = 0,
                        ExternFlag = 0,
                        CanId = 1,
                    },
                    AnswerInfo = new CanDataWithRule
                    {
                        OrderId = listAnswer[13].OrderId,
                        RemoteFlag = 0,
                        ExternFlag = 0,
                        Algorithm = listAnswer[13].Algorithm,
                        DataTypeId = (int)DataTypeFlag.Algorithm,
                        InfoType = (int)InfoTypeFlag.Eobd,
                        CanId = 1,
                        InfoItemId = (int)EobdAnswerId.AirFlowRateOfAirFlowSensor,
                    },
                    RequestType = EobdRequestType.AirFlowRateOfAirFlowSensor,
                    IsReplyOk = false,
                    ForNotificationId = (int)EobdForNotificationId.AirFlowRateOfAirFlowSensor,
                });

                //-自发动机起动的时间
                EobdCommunicatedInfoDictionary.Add((int)EobdRequestId.StartingTimeOfEngine, new EobdCommunicatedInfo
                {
                    RequestInfo = new ControlInfo
                    {
                        FrameData = listRequest[14],
                        InfoImteId = (int)EobdRequestId.StartingTimeOfEngine,
                        InfoType = (int)InfoTypeFlag.Eobd,
                        RemoteFlag = 0,
                        ExternFlag = 0,
                        CanId = 1,
                    },
                    AnswerInfo = new CanDataWithRule
                    {
                        OrderId = listAnswer[14].OrderId,
                        RemoteFlag = 0,
                        ExternFlag = 0,
                        Algorithm = listAnswer[14].Algorithm,
                        DataTypeId = (int)DataTypeFlag.Algorithm,
                        InfoType = (int)InfoTypeFlag.Eobd,
                        CanId = 1,
                        InfoItemId = (int)EobdAnswerId.StartingTimeOfEngine,
                    },
                    RequestType = EobdRequestType.StartingTimeOfEngine,
                    IsReplyOk = false,
                    ForNotificationId = (int)EobdForNotificationId.StartingTimeOfEngine,
                });

                //-进气温度请求
                EobdCommunicatedInfoDictionary.Add((int)EobdRequestId.IntakeAirTemperature, new EobdCommunicatedInfo
                {
                    RequestInfo = new ControlInfo
                    {
                        FrameData = listRequest[15],
                        InfoImteId = (int)EobdRequestId.IntakeAirTemperature,
                        InfoType = (int)InfoTypeFlag.Eobd,
                        RemoteFlag = 0,
                        ExternFlag = 0,
                        CanId = 1,
                    },
                    AnswerInfo = new CanDataWithRule
                    {
                        OrderId = listAnswer[15].OrderId,
                        RemoteFlag = 0,
                        ExternFlag = 0,
                        Algorithm = listAnswer[15].Algorithm,
                        DataTypeId = (int)DataTypeFlag.Algorithm,
                        InfoType = (int)InfoTypeFlag.Eobd,
                        CanId = 1,
                        InfoItemId = (int)EobdAnswerId.IntakeAirTemperature,
                    },
                    RequestType = EobdRequestType.IntakeAirTemperature,
                    IsReplyOk = false,
                    ForNotificationId = (int)EobdForNotificationId.IntakeAirTemperature,
                });

                //-进气歧管传感器压力
                EobdCommunicatedInfoDictionary.Add((int)EobdRequestId.IntakeManifoldPressureSensor, new EobdCommunicatedInfo
                {
                    RequestInfo = new ControlInfo
                    {
                        FrameData = listRequest[16],
                        InfoImteId = (int)EobdRequestId.IntakeManifoldPressureSensor,
                        InfoType = (int)InfoTypeFlag.Eobd,
                        RemoteFlag = 0,
                        ExternFlag = 0,
                        CanId = 1,
                    },
                    AnswerInfo = new CanDataWithRule
                    {
                        OrderId = listAnswer[16].OrderId,
                        RemoteFlag = 0,
                        ExternFlag = 0,
                        Algorithm = listAnswer[16].Algorithm,
                        DataTypeId = (int)DataTypeFlag.Algorithm,
                        InfoType = (int)InfoTypeFlag.Eobd,
                        CanId = 1,
                        InfoItemId = (int)EobdAnswerId.IntakeManifoldPressureSensor,
                    },
                    RequestType = EobdRequestType.IntakeManifoldPressureSensor,
                    IsReplyOk = false,
                    ForNotificationId = (int)EobdForNotificationId.IntakeManifoldPressureSensor,
                });


                //拷贝一份用作导出功能！-与当前数据分析通信数据集合共同引用一个对象
                EobdCommunicatedInfoExportDictionary = EobdCommunicatedInfoDictionary;

                //保存一份标准帧协议请求的命令集合
                EobdStandardRequestOrderIdDictionary = new Dictionary<int, uint>();
                //保存一份扩展帧协议请求的命令集合
                EobdExtendRequestOrderIdDictionary = new Dictionary<int, uint>();

                uint extendOrderId =0;
                if (handshakeExtendCommunicatedInfo.RequestInfo.FrameData?.Count > 0)
                {
                    extendOrderId = handshakeExtendCommunicatedInfo.RequestInfo.FrameData[0].OrderId;
                }

                foreach (var item in EobdCommunicatedInfoDictionary)
                {
                    var value = item.Value.RequestInfo.FrameData;
                    if (value?.Count > 0)
                    {
                        EobdStandardRequestOrderIdDictionary.Add(item.Key, value[0].OrderId);
                    }

                    EobdExtendRequestOrderIdDictionary.Add(item.Key, extendOrderId);
                }

                return true;
            }

            return false;
        }

                /// <summary>
        ///     连接EOBD
        /// </summary>
        /// <param name="error"></param>
        /// <param name="canId"></param>
        /// <param name="module"></param>
        /// <returns></returns>
        public bool ConnectEobd(Modules module, out ConnectError error, byte canId = 0)
        {
            error = null;
            if (CurrentEobdConnectState == ConnectState.Connect)
            {
                error = new ConnectError {ErrorCode = 6};
                return false; //已有连接
            }

            switch (module)
            {
                case Modules.DataAnalysis:
                    //引用副本
                    EobdCommunicatedInfoDictionary = EobdCommunicatedInfoExportDictionary;

#region 开始进行连接请求，成功后执行任务
                    if (EobdCommunicatedInfoDictionary?.Count > 0)
                    {
                        //设置CanId
                        foreach (var item in EobdCommunicatedInfoDictionary)
                        {
                            item.Value.SetCanId(canId);
                        }
                        HandshakeStandardCommunicatedInfo.SetCanId(canId);
                        HandshakeExtendCommunicatedInfo.SetCanId(canId);

                        //进行EOBD的请求模块配置
                        CurrentEobdConnectMoudle = module;
                        CurrentEobdConnectState = ConnectState.Connect;
                        CurrentEobdRequestCanId = canId;

                        //车型库只有一次请求,数据分析界面请求有2次
                        //先尝试第一次请求
                        EobdCommunicatedInfo info;
                        //Index
                        if (EobdCommunicatedInfoDictionary.TryGetValue((int)EobdRequestId.Handshake, out info))
                        {
                            //上次的成功的请求协议
                            CurrentEobdProtocolType = info.CurrentEobdProtocolType;

                            //更换连接请求数据
                            _currentEobdCommunicatedInfo = CurrentEobdProtocolType == EobdProtocolType.Extend ? HandshakeExtendCommunicatedInfo : HandshakeStandardCommunicatedInfo;

                            //重置数据
                            if (TryRequestEobd())
                            {
                                //请求完毕后务必置空，保证此时再接收到的数据不进行处理
                                _currentEobdCommunicatedInfo = null;
                                //重置请求数据
                                ResetEobdCommunicatedInfo();

                                //连接成功后，开启定时请求数据任务
                                StartPeriodEobdRequest(module);
                                return true;
                            }
                            //尝试第二次请求
                            if (CurrentEobdConnectMoudle == Modules.DataAnalysis)
                            {
                                //使用另外一种协议
                                CurrentEobdProtocolType = CurrentEobdProtocolType == EobdProtocolType.Standard
                                    ? EobdProtocolType.Extend
                                    : EobdProtocolType.Standard;

                                //更换连接请求数据
                                _currentEobdCommunicatedInfo = CurrentEobdProtocolType == EobdProtocolType.Extend ? HandshakeExtendCommunicatedInfo : HandshakeStandardCommunicatedInfo;

                                if (TryRequestEobd())
                                {
                                    _currentEobdCommunicatedInfo = null;

                                    //重置请求数据
                                    ResetEobdCommunicatedInfo();

                                    //连接成功后，开启定时请求数据任务
                                    StartPeriodEobdRequest(module);
                                    return true;
                                }
                                //如果，扩展帧协议连接失败，重置当前连接协议
                                CurrentEobdProtocolType = EobdProtocolType.Standard;
                            }
                        }

                        _currentEobdCommunicatedInfo = null;
                    }

#endregion

                    break;
                case Modules.CarView:
                    if (SendControlDataFrameDictionary?.Count > 0)
                    {
                        ControlInfo handshakeInfo;
                        //1.获取连接请求--如果没有，直接跳过，连接不成功
                        if (SendControlDataFrameDictionary.TryGetValue((int)EobdRequestId.Handshake, out handshakeInfo))
                        {
                            //CanId根据连接请求的canId数据而定
                            canId = handshakeInfo.CanId;

                            EobdCommunicatedInfoDictionary = new Dictionary<int, EobdCommunicatedInfo>();

#region 从ControlInfoDictionary中获取控制信息
                            foreach (var controlInfo in SendControlDataFrameDictionary.Values)
                            {
                                if (controlInfo.InfoType == 1)
                                {
                                    if (!controlInfo.IsValid)
                                    {
                                        //EOBD信息请求数据格式出错
                                        error = new ConnectError { ErrorCode = 12 };

                                        CurrentEobdConnectState = ConnectState.Disconnect;
                                        return false;
                                    }

                                    EobdRequestType type;
                                    switch (controlInfo.InfoImteId)
                                    {
                                        case (int)EobdRequestId.Handshake:
                                            type = EobdRequestType.Handshake;
                                            break;
                                        case (int)EobdRequestId.VinCode:
                                            type = EobdRequestType.VinCode;
                                            break;
                                        case (int)EobdRequestId.VinSecond:
                                            type = EobdRequestType.VinSecond;
                                            break;
                                        case (int)EobdRequestId.FaultCode:
                                            type = EobdRequestType.FaultCode;
                                            break;
                                        case (int)EobdRequestId.FaultSecond:
                                            type = EobdRequestType.FaultSecond;
                                            break;
                                        default:
                                            type = EobdRequestType.Info;
                                            break;
                                    }
                                    var onlyReadInfo =
                                        CarViewInfoGroup.Find(x => x.InfoItemId == controlInfo.InfoImteId + 1);

                                    //应答数据Id=请求数据Id+1
                                    if (onlyReadInfo.InfoItemId == controlInfo.InfoImteId + 1)
                                    {
                                        EobdCommunicatedInfoDictionary.Add(controlInfo.InfoImteId,
                                            new EobdCommunicatedInfo
                                            {
                                                RequestInfo = controlInfo,
                                                AnswerInfo = onlyReadInfo,
                                                ForNotificationId = onlyReadInfo.InfoItemId,
                                                IsReplyOk = false,
                                                RequestType = type
                                            });
                                    }
                                }
                            }

#endregion

#region 开始进行连接请求，成功后执行任务
                            if (EobdCommunicatedInfoDictionary.Count > 0)
                            {
                                //进行EOBD的请求模块配置
                                CurrentEobdConnectMoudle = module;
                                CurrentEobdConnectState = ConnectState.Connect;
                                CurrentEobdRequestCanId = canId;

                                //车型库只有一次请求,数据分析界面请求有2次
                                //先尝试第一次请求
                                EobdCommunicatedInfo info;
                                //Index
                                if (EobdCommunicatedInfoDictionary.TryGetValue((int)EobdRequestId.Handshake, out info))
                                {
                                    CurrentEobdProtocolType = info.CurrentEobdProtocolType;
                                    _currentEobdCommunicatedInfo = info;
                                    //重置数据
                                    if (TryRequestEobd())
                                    {
                                        //请求完毕后务必置空，保证此时再接收到的数据不进行处理
                                        _currentEobdCommunicatedInfo = null;

                                        //连接成功后，开启定时请求数据任务
                                        StartPeriodEobdRequest(module);
                                        return true;
                                    }
                                }

                                _currentEobdCommunicatedInfo = null;
                            }
#endregion
                        }
                    }
                    break;
            }

            CurrentEobdConnectState = ConnectState.Disconnect;
            return false;
        }

        /// <summary>
        /// 重置EOBD通信信息(根据当前通信协议切换)
        /// </summary>
        private void ResetEobdCommunicatedInfo()
        {
            switch (CurrentEobdProtocolType)
            {
                case EobdProtocolType.Standard:
                    foreach (var info in EobdCommunicatedInfoDictionary.Values)
                    {
                        uint requestOrderId;
                        if (EobdStandardRequestOrderIdDictionary.TryGetValue(info.RequestInfo.InfoImteId,
                            out requestOrderId))
                        {
                            if (info.RequestInfo.FrameData?.Count > 0)
                            {
                                for (int i = 0; i < info.RequestInfo.FrameData.Count;i++)
                                {
                                    var temp = info.RequestInfo.FrameData[i];
                                    temp.OrderId = requestOrderId;
                                    temp.ExternFlag = 0;
                                    info.RequestInfo.FrameData[i] = temp;
                                }
                            }

                            info.AnswerInfo.ExternFlag = 0;
                            info.AnswerInfo.OrderId = HandshakeStandardCommunicatedInfo.AnswerInfo.OrderId;
                        }
                    }
                    break;
                case EobdProtocolType.Extend:
                    foreach (var info in EobdCommunicatedInfoDictionary.Values)
                    {
                        uint requestOrderId;
                        if (EobdExtendRequestOrderIdDictionary.TryGetValue(info.RequestInfo.InfoImteId,
                            out requestOrderId))
                        {
                            if (info.RequestInfo.FrameData?.Count > 0)
                            {
                                for (int i = 0; i < info.RequestInfo.FrameData.Count; i++)
                                {
                                    var temp = info.RequestInfo.FrameData[i];
                                    temp.OrderId = requestOrderId;
                                    temp.ExternFlag = 1;
                                    info.RequestInfo.FrameData[i] = temp;
                                }
                            }

                            info.AnswerInfo.ExternFlag = 1;
                            info.AnswerInfo.OrderId = HandshakeExtendCommunicatedInfo.AnswerInfo.OrderId;
                        }
                    }
                    break;
            }
        }
        /// <summary>
        ///     断开EOBD
        /// </summary>
        /// <returns></returns>
        public bool DisconnectEobd(Modules module)
        {
            if (CurrentEobdConnectMoudle == module)
                CurrentEobdConnectState = ConnectState.Disconnect;
            return true;
        }
        /// <summary>
        ///     开启定时请求任务
        /// </summary>
        private void StartPeriodEobdRequest(Modules module)
        {
            var thread = new Thread(() =>
            {
                while (CurrentEobdConnectState == ConnectState.Connect)
                {
                    foreach (var item in EobdCommunicatedInfoDictionary.Values)
                    {
                        //OBD已断开
                        if (CurrentEobdConnectState == ConnectState.Disconnect)
                            return;
                        //不是请求信息项
                        if ((item.RequestType & EobdRequestType.Info) == 0)
                            continue;
                        //判断具体请求信息类型
                        switch (item.RequestType)
                        {
                            case EobdRequestType.VinCode: //*
                                //进行一次请求
                                _currentEobdCommunicatedInfo = item;
                                if (TryRequestEobd() && EobdSecondInfoInstance.IsHasSecond)
                                {
                                    //进行二次请求
                                    var firstResult = _currentEobdCommunicatedInfo.Result;
                                    //特殊
                                    _currentEobdCommunicatedInfo = EobdCommunicatedInfoDictionary[155];
                                    _currentEobdCommunicatedInfo.Result = firstResult;
                                    TryRequestEobd();
                                }
                                break;
                            case EobdRequestType.VinSecond:
                                break;
                            case EobdRequestType.FaultCode: //*
                                _currentEobdCommunicatedInfo = item;
                                //进行一次请求
                                if (TryRequestEobd() && EobdSecondInfoInstance.IsHasSecond)
                                {
                                    //进行二次请求
                                    var firstResult = _currentEobdCommunicatedInfo.Result;
                                    _currentEobdCommunicatedInfo = EobdCommunicatedInfoDictionary[159];
                                    _currentEobdCommunicatedInfo.Result = firstResult;
                                    TryRequestEobd();
                                }
                                break;
                            case EobdRequestType.FaultSecond:
                                break;
                            default: //普通请求信息
                                _currentEobdCommunicatedInfo = item; //指示当前EOBD信息项
                                TryRequestEobd();
                                break;
                        }
                        //择机退出
                    }
                    ;
                    //间隔500ms
                    Thread.Sleep(500);
                }
            });
            thread.Start();
        }

        /// <summary>
        ///     Eobd请求
        /// </summary>
        /// <param name="tries">超时次数</param>
        /// <param name="msec">超时时间--暂无实现</param>
        /// <returns></returns>
        private bool TryRequestEobd(int tries = 3, int msec = 0)
        {
            if ((_currentEobdCommunicatedInfo != null) &&(_currentEobdCommunicatedInfo.RequestInfo.FrameData?.Count > 0))
            {
                App.Log(
                    "eobd request type:" + _currentEobdCommunicatedInfo.RequestType + " Id:" + _currentEobdCommunicatedInfo.RequestInfo.InfoImteId
                    + " Can" + _currentEobdCommunicatedInfo.RequestInfo.CanId, App.Module.Eobd);

                for (var i = 0; i < tries; i++)
                {
                    var timeInterval = _currentEobdCommunicatedInfo.RequestInfo.FrameData[0].TimeInterval;

                    App.Log("eobd request tries[" + i + "] Data:...", App.Module.Eobd);

                    //请求后，等待应答
                    SyncSendCanData(_currentEobdCommunicatedInfo.RequestInfo.FrameData, _currentEobdCommunicatedInfo.RequestInfo.CanId);

                    EobdRequestState = RequestStatus.WaitReply;

                    //延时-等待Can数据处理线程返回结果
                    Thread.Sleep(timeInterval);

                    //此处的延时--无意中出现的BUG,还未找出原因
                    if (_currentEobdCommunicatedInfo == null)
                    {
                        EobdRequestState = RequestStatus.End;
                        App.Log("出现Eobd严重BUG,Error 1,书签位置1", App.Module.Eobd);
                        return false;
                    }

                    //判断是否接受到应答
                    if (_currentEobdCommunicatedInfo.IsReplyOk)
                    {
                        EobdRequestState = RequestStatus.End;
                        _currentEobdCommunicatedInfo.IsReplyOk = false;
                        App.Log("eobd request:IsReplyOk.infoItemId:" + _currentEobdCommunicatedInfo.RequestInfo.InfoImteId, App.Module.Eobd);
                        return true;
                    }
                }
            }
            EobdRequestState = RequestStatus.End;
            return false;
        }

        /// <summary>
        /// 断开EOBD
        /// </summary>
        /// <returns></returns>
        public bool DisconnectEobd()
        {
            CurrentEobdConnectState = ConnectState.Disconnect;
            return true;
        }

        /// <summary>
        ///     添加实时动态展示的数据消息
        /// </summary>
        /// <param name="key"></param>
        /// <param name="infoAttribute"></param>
        /// <param name="infoType"></param>
        public void AddRealTimeInfo(int key, InfoAttribute infoAttribute, byte infoType)
        {
            //处理底层数据集合
            //->可能转换成4种类型
            var covertObject = new CanDataWithRule
            {
                DataTypeId = infoAttribute.DataTypeID,
                InfoItemId = key
            };
            try
            {
                covertObject.OrderId = Convert.ToUInt32(infoAttribute.OrderID, 16);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("信息项Id[" + key + "]命令有误");
                //不作处理
            }
            covertObject.CanId = infoAttribute.CanID;
            covertObject.Length = 8;//固定设置为8
            covertObject.Data = new byte[8];//固定设置为8
            covertObject.InfoType = infoType;
            switch (covertObject.DataTypeId)
            {
                case (int)DataTypeFlag.Bool:
                    covertObject.ExternFlag = infoAttribute.ExternFlag;
                    covertObject.RemoteFlag = infoAttribute.RemoteFlag;
                    covertObject.EffectiveBytePostion = infoAttribute.EffectiveByte;
                    covertObject.EffectiveBitPostion = infoAttribute.EffectiveBit;
                    covertObject.EffectiveValue = infoAttribute.EffectiveValue;
                    CarViewInfoGroup.Add(covertObject);
                    break;
                case 1:
                    covertObject.ExternFlag = infoAttribute.ExternFlag;
                    covertObject.RemoteFlag = infoAttribute.RemoteFlag;
                    covertObject.EffectiveBytePostion = infoAttribute.EffectiveByte;
                    covertObject.Mask = infoAttribute.Mask;
                    covertObject.Algorithm = infoAttribute.Algorithm;
                    CarViewInfoGroup.Add(covertObject);
                    break;
                case 2:
                    covertObject.ExternFlag = infoAttribute.ExternFlag;
                    covertObject.RemoteFlag = infoAttribute.RemoteFlag;
                    covertObject.EffectiveBytePostion = infoAttribute.HighEffectiveByte;
                    covertObject.Mask = infoAttribute.HighMask;
                    covertObject.EffectiveByte2Postion = infoAttribute.LowEffectiveByte;
                    covertObject.Mask2 = infoAttribute.LowMask;
                    covertObject.Algorithm = infoAttribute.Algorithm;
                    CarViewInfoGroup.Add(covertObject);
                    break;
                case 3:
                    covertObject.ExternFlag = infoAttribute.ExternFlag;
                    covertObject.RemoteFlag = infoAttribute.RemoteFlag;
                    covertObject.EffectiveBytePostion = infoAttribute.HighEffectiveByte;
                    covertObject.Mask = infoAttribute.HighMask;
                    covertObject.EffectiveByte2Postion = infoAttribute.MiddleEffectiveByte;
                    covertObject.Mask2 = infoAttribute.MiddleMask;
                    covertObject.EffectiveByte3Postion = infoAttribute.LowEffectiveByte;
                    covertObject.Mask3 = infoAttribute.LowMask;
                    covertObject.Algorithm = infoAttribute.Algorithm;
                    CarViewInfoGroup.Add(covertObject);
                    break;
                case 4:
                    var info = new ControlInfo
                    {
                        InfoImteId = key,
                        CanId = infoAttribute.CanID,
                        ExternFlag = infoAttribute.ExternFlag,
                        RemoteFlag = infoAttribute.RemoteFlag,
                        InfoType = infoType
                    };
                    try
                    {
                        info.FrameData = CanCore.GetCanDataListBy(infoAttribute.FrameData);
                    }
                    catch(Exception ex)
                    {
                        App.Log("加载控制数据时出错:控制数据格式有误，Id为:" + info.InfoImteId,App.Module.Control);
                    }
                    SendControlDataFrameDictionary.Add(key, info);
                    break;
                case 16: //通用算法
                    covertObject.ExternFlag = infoAttribute.ExternFlag;
                    covertObject.RemoteFlag = infoAttribute.RemoteFlag;
                    covertObject.Algorithm = infoAttribute.Algorithm;
                    CarViewInfoGroup.Add(covertObject);
                    break;
                case 128: //特殊
                    covertObject.ExternFlag = infoAttribute.ExternFlag;
                    covertObject.RemoteFlag = infoAttribute.RemoteFlag;
                    CarViewInfoGroup.Add(covertObject);
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        ///     清空实时动态展示的数据消息
        /// </summary>
        public void ClearRealTimeInfo()
        {
            CarViewInfoGroup.Clear();
            SendControlDataFrameDictionary.Clear();
        }

        /// <summary>
        ///     查询信息，用于导出(针对数据分析)
        /// </summary>
        /// <param name="id"></param>
        /// <param name="mdFlag"></param>
        /// <returns></returns>
        public EobdCommunicatedInfo SearchEobdCommunicatedInfo(int id, MainDataTypeFlag mdFlag)
        {
            EobdCommunicatedInfo info = null;
            if (EobdCommunicatedInfoExportDictionary != null)
            {
                //请求类型
                if (mdFlag == MainDataTypeFlag.Request)
                {
                    //通过请求Id查找
                    EobdCommunicatedInfoExportDictionary.TryGetValue(id, out info);
                }
                else if(mdFlag==MainDataTypeFlag.Answer)
                {
                    //通过应答id查找
                    foreach (var item in EobdCommunicatedInfoExportDictionary.Values)
                    {
                        if (item.AnswerInfo.InfoItemId == id)
                        {
                            return item;
                        }
                    }
                }

            }
            return info;
        }

        /// <summary>
        /// Can核心配置
        /// </summary>
        public class CanCoreConfig
        {

            public FilterMode FilterModeInstance;

            public FilterStatus FilterStatusInstance;

            /// <summary>
            /// 过滤n秒内模式结果字典
            /// </summary>
            public readonly Dictionary<string, byte[]> FilterWithinResultDictionary=new Dictionary<string, byte[]>();

            /// <summary>
            /// 过滤n-m模式结果字典
            /// </summary>
            public readonly Dictionary<string, int[]> FilterPeriodResultDictionary=new Dictionary<string, int[]>();

            /// <summary>
            /// Candata标识匹配集合
            /// </summary>
            public readonly List<string> CanDataIdentiyMatchGroup = new List<string>();

            /// <summary>
            /// 所有数据集合(唯一标识)
            /// </summary>
            public readonly Dictionary<string, DetailedCanData> CanDataUniqueObjectGroup=new Dictionary<string, DetailedCanData>();

            /// <summary>
            /// 对CanDataUniqueObjectGroup相关处理进行加锁
            /// </summary>
            public readonly object LockUniqueObjectGroupObject = new object();
        }

        private readonly CanCoreConfig _canCoreConfig1;
        private readonly CanCoreConfig _canCoreConfig2;

        /// <summary>
        ///     使用嵌套类将复杂逻辑处理分离出来
        /// </summary>
        private static class CanCore
        {
            /// <summary>
            /// 解析得到故障码
            /// </summary>
            /// <returns></returns>
            public static string ParseFaultCode(int high,int low)
            {
                uint codeSource = (uint)((high << 8) | low);
                StringBuilder builder=new StringBuilder();
                //1.得到前缀
                //判断第15位和16位
                char codeHead;
                switch (codeSource & 0xC000)
                {
                    case 0x0000:
                        codeHead = 'P';
                        break;
                    case 0x0100:
                        codeHead = 'C';
                        break;
                    case 0x1000:
                        codeHead = 'B';
                        break;
                    case 0x1100:
                        codeHead = 'U';
                        break;
                    default:
                        codeHead = '?';
                        break;
                }
                builder.Append(codeHead);
                builder.Append((codeSource & 0x3000) >> 12);
                builder.Append((codeSource & 0x0f00) >> 8);
                builder.Append((codeSource & 0x00f0) >> 4);
                builder.Append(codeSource & 0x000f);
                return builder.ToString();
            }

            /// <summary>
            /// 是否是指定EOBD应答的帧数据
            /// </summary>
            /// <param name="infoData"></param>
            /// <param name="canData"></param>
            /// <param name="isContinuous"></param>
            /// <returns></returns>
            public static bool IsEobdAnswerData(byte[] infoData, byte[] canData, bool isContinuous = false)
            {
                var result = false;
                var offset = 0;
                if (isContinuous)
                    offset = 1;
                if ((infoData[1] | 0x40) == canData[1 + offset])
                {
                    result = true;
                    for (var i = 0; i < infoData[0] - 1; i++)
                        if (infoData[i + 2] != canData[i + offset + 2])
                        {
                            result = false;
                            break;
                        }
                }
                return result;
            }

            /// <summary>
            ///     比较CanData.Data,相同返回true,否则返回false,并更新引用的bool[]数组结果集，比较注：使用该函数前，需确认a,b,_isChanged不会为null
            /// </summary>
            /// <param name="old_length"></param>
            /// <param name="_isChanged"></param>
            /// <param name="_new"></param>
            /// <param name="_old"></param>
            /// <param name="new_length"></param>
            /// <returns></returns>
            private static bool DataCompareOutResult(byte[] _new, byte[] _old, int new_length, int old_length,
                ref bool[] _isChanged)
            {
                if (_new == null || _old == null)
                    throw new ArgumentException();
                var _result = true;
                var _length = new_length;
                //  _isChanged = new bool[Length];
                if (new_length == old_length)
                {
                    for (var i = 0; i < _length; i++)
                        if (_new[i] != _old[i])
                        {
                            _result = false;
                            _isChanged[i] = true;
                        }
                        else
                        {
                            _isChanged[i] = false;
                        }
                }
                else
                {
                    _result = false;
                    for (var i = 0; i < _length; i++)
                        _isChanged[i] = false;
                }

                return _result;
            }

            /// <summary>
            ///     字节有效位相同，则返回true，否则返回false
            /// </summary>
            /// <param name="_byte">字节</param>
            /// <param name="_mask">掩码</param>
            /// <param name="_byte2">字节</param>
            /// <returns></returns>
            public static bool Operaten(byte _byte, byte _mask, byte _byte2)
            {
                return (_byte & _mask) != (_byte2 & _mask);
            }

            /// <summary>
            ///     比较CanData.Data,相同返回true,否则返回false
            ///     数组长度为0时，不会抛出异常！为null时抛出异常！
            /// </summary>
            /// <param name="a"></param>
            /// <param name="b"></param>
            /// <returns></returns>
            public static bool DataCompare(byte[] a, byte[] b, int a_length, int b_length)
            {
                if (a == null || b == null)
                    throw new ArgumentException(TAG+" Errod Code:005");

                if (a_length != b_length)
                    return false;
                for (var i = 0; i < a_length; i++)
                    if (a[i] != b[i])
                        return false;

                return true;
            }

            /// <summary>
            ///     比较CanData数据,,返回obj对象的修改值
            /// </summary>
            /// <param name="obj"></param>
            /// <param name="item"></param>
            public static DetailedCanData CompareDealCanData(DetailedCanData obj, DetailedCanData item)
            {
                obj.TimeInterval = obj.Time - item.Time;
                if (obj.TimeInterval < 0)
                    throw new Exception("处理机制时序发生异常，请重启程序，确保数据读取正确！");
                //DataIsChanged
                obj.IsDataSame = DataCompareOutResult(obj.Data, item.Data, obj.Length, item.Length,
                    ref obj.DataIsChanged);

                // if (!obj.IsDataSame)
                {
                    if (obj.Length == item.Length)
                        for (var i = 0; i < obj.Length; i++)
                            if (obj.DataIsChanged[i]) //如果变化
                            {
                                if (item.DataIsChanged[i]) //如果是连续变化
                                    obj.DataChangedTimeInterval[i] = obj.TimeInterval; //02
                                else //间隔变化
                                    obj.DataChangedTimeInterval[i] = item.DataChangedTimeInterval[i]; //01
                            }
                            else //00-00-01-01 1-3 00-00-01-02 1-3-4
                            {
                                if (item.DataIsChanged[i])
                                    obj.DataChangedTimeInterval[i] = obj.TimeInterval; //该字节间隔时间置位//01
                                else
                                    obj.DataChangedTimeInterval[i] = item.DataChangedTimeInterval[i] + obj.TimeInterval;
                                //00 00
                            }
                }
                return obj;
            }

            /// <summary>
            ///     引用更改-位比较，并更新引用的byte[]结果集
            /// </summary>
            /// <param name="_old"></param>
            /// <param name="_new"></param>
            /// <param name="_result"></param>
            public static void CompareBit(byte[] _old, byte[] _new, ref byte[] _result)
            {
                if (_new == null || _old == null)
                    throw new ArgumentException();
                var count = _new.Length;
                if (_old.Length < _new.Length)
                    count = _old.Length;
                for (var i = 0; i < count; i++)
                {
                    var re = _old[i] ^ _new[i];
                    var n = 1;
                    for (var j = 0; j < 8; j++)
                    {
                        if ((re & n) != 0)
                            if (_result[i * 8 + j] < 255) //确保不会溢出
                                _result[i * 8 + j]++;
                        n = n << 1;
                    }
                }
            }

            /// <summary>
            ///     得到控制数据和算法数据
            /// </summary>
            /// <returns></returns>
            public static Tuple<List<List<CanData>>, List<CanDataWithRule>> GetListBy(string frameText, byte canId = 1)
            {
                if (string.IsNullOrEmpty(frameText))
                    throw new Exception("frameText为空");
                var listRequest = new List<List<CanData>>();
                var listAnswer = new List<CanDataWithRule>();
                //ControlInfo->DetailedCanData
                char[] _splitChrs = {'\r', '\n'};
                var builder = new StringBuilder();
                var _strs = frameText.Split(_splitChrs);
                var isRequest = false;
                foreach (var item in _strs)
                {
                    if (item == "")
                        continue;
                    isRequest = !isRequest; //第一次为true--请求行 数据
                    if (isRequest)
                    {
                        try
                        {
                            var canData = GetCanDataListBy(item);
                            listRequest.Add(canData);
                        }
                        catch
                        {
                            throw;
                        }
                    }
                    else
                    {
                        try
                        {
                            var _canDataWithRule = GetCanDataWithRuleBy(item, canId);
                            listAnswer.Add(_canDataWithRule);
                        }
                        catch
                        {
                            throw;
                        }
                    }
                }
        return new Tuple<List<List<CanData>>, List<CanDataWithRule>>(listRequest, listAnswer);
            }

            /// <summary>
            ///     解析控制数据
            ///     注意捕捉异常
            /// </summary>
            /// <param name="frameText"></param>
            /// <param name="canId"></param>
            /// <returns></returns>
            public static List<CanData> GetCanDataListBy(string frameText)
            {
                if (string.IsNullOrEmpty(frameText))
                    throw new Exception("frameText为空");
                var list = new List<CanData>();
                //ControlInfo->CanData
                char[] _splitChrs = {'\r', '\n'};
                var builder = new StringBuilder();
                var _strs = frameText.Split(_splitChrs);
                foreach (var item in _strs)
                {
                    if (item == "")
                        continue;
                    try
                    {
                        var _canData = GetCanDataBy(item);
                        list.Add(_canData);
                    }
                    catch
                    {
                        throw;
                    }
                }
                return list;
            }

            /// <summary>
            ///     解析控制数据行
            /// </summary>
            /// <returns></returns>
            private static CanData GetCanDataBy(string item)
            {
                var _canData = new CanData();
                var _line = item.Split('\t');
                var _orderId = Convert.ToUInt32(_line[0], 16);
                var _timeInterval = Convert.ToInt32(_line[1]);

                //新版本添加帧格式和帧类型
                var _remoteFlag = Convert.ToByte(_line[2]);
                var _externFlag = Convert.ToByte(_line[3]);

                //数据帧
                if (_remoteFlag == 0)
                {
                    var _length = Convert.ToByte(_line[4]);
                    if (_length > 8)
                        throw new Exception("控制数据长度有误！");
                    var _data = _line[5].Split(' ');
                    if (_data.Length < _length)
                        throw new Exception("控制数据实际长度少于目标长度！");
                    _canData.Length = _length;
                    _canData.Data = new byte[_length]; //重要初始化
                    for (var i = 0; i < _length; i++)
                        _canData.Data[i] = Convert.ToByte(_data[i], 16);
                }
                else //扩展帧
                {
                    _canData.Length = 0;
                }

                _canData.OrderId = _orderId;
                _canData.RemoteFlag = _remoteFlag;
                _canData.ExternFlag = _externFlag;
                _canData.TimeInterval = _timeInterval;
                return _canData;
            }

            /// <summary>
            ///     解析只读信息解析规则（只提供算法,命令Id,长度,帧格式,帧类型，canId）
            /// </summary>
            /// <returns></returns>
            private static CanDataWithRule GetCanDataWithRuleBy(string item, byte canId)
            {
                var _canData = new CanDataWithRule();
                var _line = item.Split('\t');
                var _orderId = Convert.ToUInt32(_line[0], 16);
                if (_line.Length > 6)
                {
                    //获取算法
                    _canData.Algorithm = _line[6];
                    //新版本添加帧格式和帧类型
                    var _remoteFlag = Convert.ToByte(_line[2]);
                    var _externFlag = Convert.ToByte(_line[3]);
                    _canData.RemoteFlag = _remoteFlag;
                    _canData.ExternFlag = _externFlag;
                }

                _canData.CanId = canId;
                _canData.OrderId = _orderId;

                return _canData;
            }
        }

        /// <summary>
        ///     添加到主列表(普通模式)
        /// </summary>
        /// <param name="stateInfo"></param>
        /// <param name="canId"></param>
        private void ThreadCheckUnique(ICanData stateInfo, byte canId)
        {
            string identity = stateInfo.Identity;
            var dealCanData = new DetailedCanData(stateInfo, canId);
            var canCoreConfig = dealCanData.CanId == 1 ? _canCoreConfig1 : _canCoreConfig2;

            //已改为单线程顺序处理，无需加锁
            //  lock (lock_sync3)
            {
                DetailedCanData detailedCanData;
                if (canCoreConfig.CanDataUniqueObjectGroup.TryGetValue(identity, out detailedCanData))
                {
                    dealCanData.IsExist = true;
                    dealCanData = CanCore.CompareDealCanData(dealCanData, detailedCanData);
                    canCoreConfig.CanDataUniqueObjectGroup[identity] = dealCanData;
                }
                else
                {
                    canCoreConfig.CanDataUniqueObjectGroup.Add(identity, dealCanData);
                }
                ActivateCanData(dealCanData); //通知
            }
        }

        private void ReadMessages2()
        {
            var mCount = 0;

            lock (lock_sync1_can2)
            {
                while (mCan.gRecMsgBufHead2 != mCan.gRecMsgBufTail2)
                {
                    var frameinfo = mCan.gRecMsgBuf2[mCan.gRecMsgBufTail2];
                    mCan.gRecMsgBufTail2 += 1;
                    if (mCan.gRecMsgBufTail2 >= ComProc.REC_MSG_BUF_MAX)
                        mCan.gRecMsgBufTail2 = 0;

                    var canData = new CanData
                    {
                        RemoteFlag = frameinfo.RemoteFlag == 0 ? (byte)0 : (byte)1
                    };

                    if (frameinfo.ExternFlag == 0)
                    {
                        canData.ExternFlag = 0;
                        canData.OrderId = frameinfo.ID;
                    }
                    else
                    {
                        canData.ExternFlag = 1;
                        canData.OrderId = frameinfo.ID;
                    }
                    if (frameinfo.RemoteFlag == 0)
                    {
                        if (frameinfo.DataLen > 8)
                            frameinfo.DataLen = 8;
                        canData.Length = frameinfo.DataLen;
                        canData.Data = new byte[frameinfo.DataLen];
                        for (var i = 0; i < frameinfo.DataLen; i++)
                            canData.Data[i] = frameinfo.data[i];
                    }
                    else //数据帧
                    {
                        canData.Length = 0;
                        canData.Data = new byte[0];
                    }

                    canData.Time = Environment.TickCount;

                    if (IsRunCarView || (IsRunDataAnalysis && IsRunDisplayCan2))
                    {
                        lock (lock_sync_CanDataQueue_Can2)
                        {
                            CanDataQueue_Can2.Enqueue(canData);
                        }
                    }

                    mCount++;
                    if (mCount >= ReadMaxCounts_can2) //根据波特率的值改变
                        break;
                }
            }
        }

        /// <summary>
        /// 设置CanType
        /// </summary>
        /// <param name="canType"></param>
        public void SetCanType(int canType)
        {
            this.CanType = canType;
        }

#region 自动识别波特率模块

        private byte _autoSpotBaudRateCanId;

        private bool _isAutoSpotBaudRateActively;

        private bool _isCancelAutoSpotBaudRate;

        private bool IsReceivedOk;

        private bool IsReceivedError;

#endregion
        /// <summary>
        /// 开始自动识别
        /// </summary>
        /// <param name="canId"></param>
        /// <param name="baudRates"></param>
        /// <param name="callback"></param>
        /// <param name="completeAction"></param>
        /// <returns></returns>
        public AutoSpotBaudRateStatus StartAutoSpotBaudRate(byte canId, List<string> baudRates, AsyncCallback callback, Action completeAction)
        {
            if (_isAutoSpotBaudRateActively)
            {
                return AutoSpotBaudRateStatus.Busy;
            }

            bool isPreviousConnect = false;

            //连接断开时，尝试连接
            if (m_connect == 0)
            {
                if (ECANDLL.OpenDevice(DeviceType, 0, 0) != ECANStatus.STATUS_OK)
                {
                    return AutoSpotBaudRateStatus.DeviceOpenError;
                }
            }
            else
            {
                //已经打开了设备
                isPreviousConnect = true;
            }

            _isAutoSpotBaudRateActively = true;
            _autoSpotBaudRateCanId = canId;
            //开始进行自动识别波特率操作
            var thread = new Thread(() =>
            {
                //mode:0：正常模式 1：只听模式
                var init_config = new INIT_CONFIG
                {
                    AccCode = 0,
                    AccMask = 0xffffff,
                    Filter = 0,
                    Mode = 0
                };

                foreach (var baudRate in baudRates)
                {
                    //取消
                    if (_isCancelAutoSpotBaudRate)
                    {
                        _isCancelAutoSpotBaudRate = false;
                        break;
                    }
                    switch (baudRate)
                    {
                        case "1000k": //1000
                            init_config.Timing0 = 0;
                            init_config.Timing1 = 0x14;
                            break;
                        case "800k": //800
                            init_config.Timing0 = 0;
                            init_config.Timing1 = 0x16;
                            break;
                        case "666k": //666
                            init_config.Timing0 = 0x80;
                            init_config.Timing1 = 0xb6;
                            break;
                        case "500k": //500
                            init_config.Timing0 = 0;
                            init_config.Timing1 = 0x1c;
                            break;
                        case "400k": //400
                            init_config.Timing0 = 0x80;
                            init_config.Timing1 = 0xfa;
                            break;
                        case "250k": //250
                            init_config.Timing0 = 0x01;
                            init_config.Timing1 = 0x1c;
                            break;
                        case "200k": //200
                            init_config.Timing0 = 0x81;
                            init_config.Timing1 = 0xfa;
                            break;
                        case "125k": //125
                            init_config.Timing0 = 0x03;
                            init_config.Timing1 = 0x1c;
                            break;
                        case "100k": //100
                            init_config.Timing0 = 0x04;
                            init_config.Timing1 = 0x1c;
                            break;
                        case "80k": //80
                            init_config.Timing0 = 0x83;
                            init_config.Timing1 = 0xff;
                            break;
                        case "50k": //50
                            init_config.Timing0 = 0x09;
                            init_config.Timing1 = 0x1c;
                            break;
                    }
                    //初始化CAN
                    var isOk = ECANDLL.InitCAN(DeviceType, 0, canId, ref init_config) == ECANStatus.STATUS_OK;
                    //开启Can
                    if (isOk)
                    {
                        if (ECANDLL.StartCAN(DeviceType, 0, canId) == ECANStatus.STATUS_OK)
                        {
                            //开启CAN通道成功
                            isOk = true;
                            Thread.Sleep(1000); //由于判断机制的问题，此处需留合适的延时时间
                            mCan.EnableProc = true;
                            if (canId == 0)
                            {
                                dispatcherTimer.Enabled = true;
                            }
                            else if (canId == 1)
                            {
                                dispatcherTimer2.Enabled = true;
                            }

                        }
                        else
                        {
                            isOk = false;
                        }
                    }
                    //等待读取Can状态信息
                    if (isOk)
                    {
                        IsReceivedOk = false;
                        IsReceivedError = false;
                        Thread.Sleep(500);
                        isOk = !IsReceivedError && IsReceivedOk;
                    }
                    //关闭
                    mCan.EnableProc = false;
                    dispatcherTimer.Enabled = false;
                    dispatcherTimer2.Enabled = false;

                    var result = new AutoSpotBaudRateResult(baudRate,isOk);

                    //通知结果
                    callback?.Invoke(result);

                    //跳出
                    if (isOk)
                        break;

                    //复位--可能没用
                    if (ECANDLL.ResetCAN(DeviceType, 0, canId) == ECANStatus.STATUS_OK) { }
                    Thread.Sleep(100);
                }

                //关闭设备
                ECANDLL.CloseDevice(DeviceType, 0);
                //关闭
                mCan.EnableProc = false;
                dispatcherTimer.Enabled = false;
                dispatcherTimer2.Enabled = false;

                //如果识别已经打开设备，则恢复连接
                if (isPreviousConnect)
                {
                    DoOpenDevice(_baudRate, _baudRate2);
                }

                _isAutoSpotBaudRateActively = false;
                //指示自动识别完成
                completeAction?.Invoke();
            });

            thread.Start();

            return AutoSpotBaudRateStatus.Ok;
        }

        /// <summary>
        /// 停止自动识别波特率
        /// </summary>
        /// <param name="canId"></param>
        public void StopAutoSpotBaudRate(byte canId)
        {
            _isCancelAutoSpotBaudRate = true;
        }

        /*************************************自动识别波特率（结尾）*****************************************************/

        /// <summary>
        /// 解析仿真车型使用的数据类型文本
        /// </summary>
        /// <param name="_str"></param>
        /// <returns></returns>
        public static ICanData SimulateStringToCanData(string _str)
        {
            var _candata = new CanData();
            try
            {
                string[] __strs = _str.Split(',');
                string[] _strs = new string[__strs.Length];
                int postion = 0;
                foreach (var item in __strs)
                {
                    if (item.Trim(' ') != "")
                    {
                        bool isOk = true;
                        foreach (var _chr in item)
                        {
                            if (char.IsControl(_chr))
                                isOk = false;
                        }
                        if (isOk)
                        {
                            _strs[postion] = item;
                            postion++;
                        }
                    }
                }
                _candata.ExternFlag = System.Convert.ToByte(_strs[1]);
                _candata.RemoteFlag = System.Convert.ToByte(_strs[2]);
                _candata.OrderId = System.Convert.ToUInt32(_strs[3], 16);
                string[] _dataStrs = _strs[4].Split(' ');
                List<string> dataStrs = new List<string>();
                foreach (var item in _dataStrs)
                {
                    if (item.Trim(' ') != "")
                        dataStrs.Add(item);
                }
                _candata.Length = System.Convert.ToByte(dataStrs.Count);
                _candata.Data = new byte[_candata.Length];
                if (_candata.Length != _candata.Data.Length)
                {
                    Debug.WriteLine("_candata.Length != _candata.Data.Length");
                }
                else
                {
                    for (int i = 0; i < _candata.Length; i++)
                    {
                        _candata.Data[i] = System.Convert.ToByte(dataStrs[i], 16);
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }
            return _candata;
        }

        /// <summary>
        /// 设置运行模块
        /// </summary>
        /// <param name="module"></param>
        public void SetRunModule(Modules module)
        {
            switch (module)
            {
                case Modules.DataAnalysis:
                    IsRunDataAnalysis = true;
                    IsRunCarView = false;
                    break;
                case Modules.CarView:
                    IsRunDataAnalysis = false;
                    IsRunCarView = true;
                    break;
                case Modules.None:
                    IsRunDataAnalysis = false;
                    IsRunCarView = false;
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// 调试用，用于设置读取Can数据的速度
        /// </summary>
        /// <param name="count"></param>
        public void SetReadBaseNumbers(int count)
        {
            this.ReadBaseNumbers = count;
        }
    }
}