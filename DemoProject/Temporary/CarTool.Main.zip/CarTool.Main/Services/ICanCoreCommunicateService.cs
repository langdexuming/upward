﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Threading;
using CarInfoDB;
using static CarTool.Main.HeaderFile.CanDataBoredom;

namespace CarTool.Main.Services
{
    public delegate void CanDataInfoEventHandler(object sender, CanDataEventArgs e);
    /// 定义CanDataInfo改变事件触发源(匹配显示)
    public delegate void CanDataInfoMatchEventHandler(object sender, CanDataEventArgs e);

    /// 定义PerformInfo改变事件触发源
    public delegate void ConnectStateChangedEventHandler(object sender, ConnectStateChangeEventArgs e);

    /// 定义PerformInfo改变事件触发源
    public delegate void PerformInfoEventHandler(object sender, PerformInfoEventArgs e);

    /// <summary>
    /// EOBD协议类型
    /// </summary>
    public enum EobdProtocolType
    {
        /// <summary>
        /// 标准帧协议
        /// </summary>
        Standard,
        /// <summary>
        /// 扩展帧协议
        /// </summary>
        Extend,
    }

    /// <summary>
    /// 过滤模式倒计时报告
    /// </summary>
    public class FilterTimingReport : IAsyncResult
    {
        public int CountDown;

        public object AsyncState
        {
            get
            {
                throw new NotImplementedException();
            }
        }

        public WaitHandle AsyncWaitHandle
        {
            get
            {
                throw new NotImplementedException();
            }
        }

        public bool CompletedSynchronously
        {
            get
            {
                throw new NotImplementedException();
            }
        }

        public bool IsCompleted
        {
            get
            {
                throw new NotImplementedException();
            }
        }
    }

    /// <summary>
    /// 自动识别结果
    /// </summary>
    public class AutoSpotBaudRateResult : IAsyncResult
    {
        public AutoSpotBaudRateResult(string baudRate, bool isOk)
        {
            BaudRate = baudRate;
            IsOk = isOk;
        }

        public string BaudRate { get; set; }

        public bool IsOk { get; set; }

        public object AsyncState
        {
            get
            {
                throw new NotImplementedException();
            }
        }

        public WaitHandle AsyncWaitHandle
        {
            get
            {
                throw new NotImplementedException();
            }
        }

        public bool CompletedSynchronously
        {
            get
            {
                throw new NotImplementedException();
            }
        }

        public bool IsCompleted
        {
            get
            {
                throw new NotImplementedException();
            }
        }
    }

    public enum CommunicatedType
    {
        Request,

        Answer,
    }
    /// <summary>
    /// EOBD请求信息
    /// </summary>
    public class EobdCommunicatedInfo
    {
        //请求信息
        public ControlInfo RequestInfo;

        //应答信息
        public CanDataWithRule AnswerInfo;

        //请求类型
        public EobdRequestType RequestType;

        //是否应答Ok
        public bool IsReplyOk;

        //通知信息的信息Id
        public int ForNotificationId;

        //算出来的结果
        public string Result;

        public EobdProtocolType CurrentEobdProtocolType
        {
            get
            {
                if (RequestInfo.FrameData?.Count > 0)
                {
                    return RequestInfo.FrameData[0].ExternFlag == 0
                        ? EobdProtocolType.Standard
                        : EobdProtocolType.Extend;
                }
                return EobdProtocolType.Standard;
            }
        }

        public void SetCanId(byte canId)
        {
            RequestInfo.CanId = canId;
            AnswerInfo.CanId = canId;
        }

    }
    /// <summary>
    /// 请求状态
    /// </summary>
    public enum RequestStatus
    {
        /// <summary>
        ///     未请求
        /// </summary>
        None,

        /// <summary>
        ///     等待应答
        /// </summary>
        WaitReply,

        /// <summary>
        ///     请求完成
        /// </summary>
        End
    }

    public enum Modules
    {
        None,

        DataAnalysis,

        CarView
    }

    public enum ConnectState
    {
        /// <summary>
        ///     断开
        /// </summary>
        Disconnect,

        /// <summary>
        ///     连接
        /// </summary>
        Connect
    }

    public enum SendPriority
    {
        /// <summary>
        ///     最低优先级
        /// </summary>
        Lowest = 0,

        /// <summary>
        ///     普通
        /// </summary>
        Normal = 5,

        /// <summary>
        ///     最高优先级
        /// </summary>
        Highest = 10
    }

    [Flags]
    public enum FilterStatus
    {
        /// <summary>
        /// 未过滤
        /// </summary>
        None = 0,

        /// <summary>
        /// 过滤中
        /// </summary>
        Filtering = 2,

        /// <summary>
        /// 过滤中n秒内
        /// </summary>
        FilteringWithN = 3,

        /// <summary>
        /// 过滤中n-m秒
        /// </summary>
        FilteringWithM = 6,

        /// <summary>
        /// 已经过滤了
        /// </summary>
        Filtered = 256,

    }

    public enum FilterMode
    {
        /// <summary>
        /// 未过滤
        /// </summary>
        None,
        /// <summary>
        ///     n秒内,位发生一次变化
        /// </summary>
        Within,

        /// <summary>
        ///     m-n秒，m秒内不变化，m后字节变化
        /// </summary>
        Period
    }


    public enum AutoSpotBaudRateStatus
    {
        /// <summary>
        /// 无
        /// </summary>
        Ok,

        /// <summary>
        /// 设备打开错误
        /// </summary>
        DeviceOpenError,

        /// <summary>
        /// 繁忙(自动识别中)
        /// </summary>
        Busy
    }

    public class ConnectError
    {
        /// <summary>
        ///     1:无法连接 6:已有连接 12:信息请求格式出错
        /// </summary>
        public int ErrorCode;
    }

    public struct AutoSpotResult
    {
        public string baudRate;

        public bool isOk;

        public AutoSpotResult(string baudRate, bool isOk)
        {
            this.baudRate = baudRate;
            this.isOk = isOk;
        }
    }


    public class ConnectStateChangeEventArgs : EventArgs
    {
        public ConnectStateChangeEventArgs(ConnectState currentConnectState)
        {
            CurrentConnectState = currentConnectState;
        }

        public ConnectState CurrentConnectState { get; set; }
    }

    public interface ICanCoreCommunicateService
    {

        event CanDataInfoEventHandler OnCanDataActive;

        event PerformInfoEventHandler OnEobdPerformInfoActive;

        event PerformInfoEventHandler OnPerformInfoActive;

        event ConnectStateChangedEventHandler OnConnectStateChanged;

        bool IsOpen { get; }
        /// <summary>
        /// 自动识别波特率-返回是否成功开启识别
        /// </summary>
        /// <param name="canId">can通道</param>
        /// <param name="baudRates">波特率集合</param>
        /// <param name="callback">波特率识别通知回调</param>
        /// <param name="completeAction">自动识别完成后发生</param>
        /// <returns></returns>
        AutoSpotBaudRateStatus StartAutoSpotBaudRate(byte canId, List<string> baudRates,AsyncCallback callback,Action completeAction);
        /// <summary>
        /// 停止自动识别
        /// </summary>
        /// <param name="canId">can通道</param>
        void StopAutoSpotBaudRate(byte canId);

        /// <summary>
        ///     开始过滤
        /// </summary>
        /// <param name="canId">Can通道</param>
        /// <param name="mode">过滤模式</param>
        /// <param name="readyCallBack"></param>
        /// <param name="callback">每隔1秒回调一次</param>
        /// <param name="completeAction"></param>
        /// <param name="pars">
        ///     时间 Within模式：n
        ///     Period模式:m,n
        /// </param>
        void StartFilter(byte canId, FilterMode mode, Action readyCallBack, AsyncCallback callback, Action<List<string>> completeAction, params int[] pars);

        /// <summary>
        ///     清空缓存的数据
        /// </summary>
        /// <param name="canId">Can通道</param>
        void ClearCanData(byte canId);

        ///// <summary>
        ///// 加载EOBD的请求数据
        ///// </summary>
        ///// <typeparam name="EobdCommunicatedInfo"></typeparam>
        ///// <param name="list"></param>
        ///// <returns></returns>
        //bool LoadEobdCommunicatedInfo(List<EobdCommunicatedInfo> list, Modules module);

        /// <summary>
        /// 加载EOBD的请求数据
        /// </summary>
        /// <param name="text">字符串文本</param>
        /// <returns></returns>
        bool LoadEobdCommunicatedInfo(string text);

        /// <summary>
        ///     连接EOBD
        /// </summary>
        /// <returns></returns>
        bool ConnectEobd(Modules module, out ConnectError error, byte canId=0);

        /// <summary>
        ///     断开EOBD
        /// </summary>
        /// <returns></returns>
        bool DisconnectEobd(Modules module);

        /// <summary>
        ///     提供一个测试发送控制数据的方法(测试使用)
        /// </summary>
        void TestControlSend(string _frameText, byte canId = 1);

        /// <summary>
        ///     发送控制数据
        /// </summary>
        bool SendControlCanData(int infoItemId);

        /// <summary>
        ///     发送CanData数据
        /// </summary>
        void SendCanData(ICanData canData,byte canId);

        /// <summary>
        ///     打开Can设备
        /// </summary>
        /// <param name="m_Baudrate"></param>
        /// <param name="m_Baudrate2"></param>
        bool OpenDevice(byte m_Baudrate, byte m_Baudrate2);

        /// <summary>
        ///     close the Device
        /// </summary>
        void CloseDevice();

        /// <summary>
        /// 设置是否转发
        /// </summary>
        /// <param name="value"></param>
        void SetForwarding(bool value);

        /// <summary>
        /// 设置是否运行
        /// </summary>
        /// <param name="canId"></param>
        /// <param name="value"></param>
        void SetRun(byte canId, bool value);

        /// <summary>
        /// 添加实时信息
        /// </summary>
        void AddRealTimeInfo(int key, InfoAttribute infoAttribute, byte infoType);

        /// <summary>
        /// 设置CanType
        /// </summary>
        /// <param name="canType"></param>
        void SetCanType(int canType);

        /// <summary>
        /// 清空实时动态展示车的车型数据信息
        /// </summary>
        void ClearRealTimeInfo();

        /// <summary>
        /// 设置运行模块
        /// </summary>
        /// <param name="module"></param>
        void SetRunModule(Modules module);

        /// <summary>
        /// 查询Eobd信息
        /// </summary>
        /// <param name="infoItemId"></param>
        /// <param name="mdFlag"></param>
        EobdCommunicatedInfo SearchEobdCommunicatedInfo(int infoItemId, MainDataTypeFlag mdFlag);

        /// <summary>
        /// 调试用，用于设置读取Can数据的速度
        /// </summary>
        /// <param name="count"></param>
        void SetReadBaseNumbers(int count);
    }
}