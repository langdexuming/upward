﻿using System;
using System.Collections.Generic;

namespace CarTool.Main.HeaderFile
{
    public class CanDataBoredom
    {
        public interface IdentityKey
        {
            string Identity { get; }
        }

        /// <summary>
        /// 属性（规范）
        /// </summary>
        public interface ICanData: IdentityKey
        {
            uint OrderId { get; set; }
            byte Length { get; set; }
            byte[] Data { get; set; }
            byte RemoteFlag { get; set; }
            byte ExternFlag { get; set; }
            int TimeInterval { get; set; }
            int Time { get; set; }
        }

        /// <summary>
        /// 
        /// </summary>
        public struct CanData : ICanData
        {
            public uint OrderId { get; set; }

            public byte Length { get; set; }

            public byte[] Data { get; set; }

            public byte RemoteFlag { get; set; }

            public byte ExternFlag { get; set; }

            public int TimeInterval { get; set; }

            public int Time { get; set; }

            public CanData(ICanData canData)
            {
                OrderId = canData.OrderId;
                Length = canData.Length;
                Data = canData.Data;
                RemoteFlag = canData.RemoteFlag;
                ExternFlag = canData.ExternFlag;
                TimeInterval = canData.TimeInterval;
                Time = canData.Time;
            }

            public string Identity => OrderId.ToString() + ExternFlag.ToString() + RemoteFlag.ToString();

            public override string ToString()//*
            {
                string dataStr = string.Empty;
                for (int i = 0; i < Length; i++)
                {
                    dataStr += string.Format("{0:X2}", Data[i]) + " ";
                }
                dataStr = dataStr.PadRight(24);
                return string.Format("0x{0:x}", OrderId) + "\t" + RemoteFlag.ToString() + "\t" + ExternFlag.ToString() + "\t" + Length.ToString() + "\t" + dataStr;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public class DetailedCanData : ICanData
        {
            public uint OrderId { get; set; }

            public byte Length { get; set; }

            public byte[] Data { get; set; }

            public byte CanId { get; set; }

            public byte RemoteFlag { get; set; }

            public byte ExternFlag { get; set; }

            public int TimeInterval { get; set; }

            public int Time { get; set; }


            public bool IsExist; //已经存在
            public bool IsRefreshed; //指示是否已经刷新
            public bool IsDataSame; //指示是否数据相同

            public int[] DataChangedTimeInterval; //代表字节变化的间隔时间
            public bool[] DataIsChanged;

            public DetailedCanData(ICanData canData,byte canId)
            {
                OrderId = canData.OrderId;
                Length = canData.Length;
                Data = canData.Data;
                CanId = canId;
                RemoteFlag = canData.RemoteFlag;
                ExternFlag = canData.ExternFlag;
                TimeInterval = canData.TimeInterval;
                Time = canData.Time;

                IsExist = false;
                IsRefreshed = false;
                IsDataSame = false;
                DataChangedTimeInterval = new int[canData.Length];
                DataIsChanged=new bool[canData.Length];
            }

            public string Identity => OrderId.ToString() + ExternFlag.ToString() + RemoteFlag.ToString();

            public override string ToString() //*
            {
                string dataStr = string.Empty;
                for (int i = 0; i < Length; i++)
                {
                    dataStr += string.Format("{0:X2}", Data[i]) + " ";
                }
                dataStr = dataStr.PadRight(24);
                return string.Format("0x{0:x}", OrderId) + "\t" + RemoteFlag.ToString() + "\t" + ExternFlag.ToString() +
                       "\t" + Length.ToString() + "\t" + dataStr;
            }
        }

        public class InfoCanData : ICanData
        {
            public uint OrderId { get; set; }

            public byte Length { get; set; }

            public byte[] Data { get; set; }

            public byte CanId { get; set; }

            public byte RemoteFlag { get; set; }

            public byte ExternFlag { get; set; }

            public int TimeInterval { get; set; }

            public int Time { get; set; }

            public string Identity => OrderId.ToString() + ExternFlag.ToString() + RemoteFlag.ToString();

            public InfoCanData(ICanData canData,byte canId)
            {
                OrderId = canData.OrderId;
                Length = canData.Length;
                Data = canData.Data;
                CanId = canId;
                RemoteFlag = canData.RemoteFlag;
                ExternFlag = canData.ExternFlag;
                TimeInterval = canData.TimeInterval;
                Time = canData.Time;
            }

            public override string ToString() //*
            {
                string dataStr = string.Empty;
                for (int i = 0; i < Length; i++)
                {
                    dataStr += string.Format("{0:X2}", Data[i]) + " ";
                }
                dataStr = dataStr.PadRight(24);
                return string.Format("0x{0:x}", OrderId) + "\t" + RemoteFlag.ToString() + "\t" + ExternFlag.ToString() +
                       "\t" + Length.ToString() + "\t" + dataStr;
            }
        }

        public struct CanDataWithRule : ICanData
        {
            public uint OrderId { get; set; }

            public byte Length { get; set; }

            public byte[] Data { get; set; }

            public byte CanId { get; set; }

            public byte RemoteFlag { get; set; }

            public byte ExternFlag { get; set; }

            public int TimeInterval { get; set; }

            public int Time { get; set; }

            public int InfoItemId;//对应项目ID
            public string Algorithm;//对应算法
            public byte DataTypeId;
            public byte InfoType;

            public byte EffectiveBytePostion;//复用High
            public byte EffectiveByte2Postion;//复用middle
            public byte EffectiveByte3Postion;//复用low
            public byte Mask;//复用High
            public byte Mask2;//复用middle
            public byte Mask3;//复用low
            public byte EffectiveBitPostion;
            public byte EffectiveValue;

            public string Identity => OrderId.ToString() + ExternFlag.ToString() + RemoteFlag.ToString();
        }

        public struct ControlInfo
        {
            public int InfoImteId;
            public IList<CanData> FrameData;
            public byte CanId;
            public byte InfoType;

            public byte RemoteFlag;
            public byte ExternFlag;

            //指示控制数据是否有效（格式是否正确）
            public bool IsValid
            {
                get
                {
                    if (FrameData?.Count > 0)
                    {
                        return true;
                    }
                    return false;
                }
            }

        }


        public struct EobdSecondInfo
        {
            public bool IsHasSecond;
            public int MaxIndex;
            public int Index;
        }

        [Flags]
        public enum EobdRequestType : uint
        {
            /// <summary>
            /// 暂无进行请求
            /// </summary>
            None = 0x0,
            /// <summary>
            /// 握手
            /// </summary>
            Handshake = 0x8000,
            /// <summary>
            /// 信息
            /// </summary>
            Info = 0x4000,
            ///// <summary>
            ///// 握手(标准帧握手)
            ///// </summary>
            //HandshakeStandard = 0x8000 | 0x01,
            ///// <summary>
            ///// 握手(扩展帧握手)
            ///// </summary>
            //HandshakeExtend = 0x8000 | 0x02,
            /// <summary>
            /// Vin码
            /// </summary>
            VinCode = 0x4000 | 0x2000,
            /// <summary>
            /// 故障码
            /// </summary>
            FaultCode = 0x4000 | 0x1000,
            /// <summary>
            /// Vin码二次请求
            /// </summary>
            VinSecond = 0x4000 | 0x2000 | 0x01,
            /// <summary>
            ///故障码二次请求
            /// </summary>
            FaultSecond = 0x4000 | 0x1000 | 0x01,
            /// <summary>
            /// 绝对负荷值
            /// </summary>
            AbsoluteLoadValue = 0x4000 | 0x01,
            /// <summary>
            /// 冷却液温度
            /// </summary>
            CoolantTemperature = 0x4000 | 0x02,
            /// <summary>
            /// 节气门绝对位置
            /// </summary>
            AbsoluteThrottlePosition = 0x4000 | 0x03,
            /// <summary>
            /// 控制模块电压
            /// </summary>
            ControlModuleVoltage = 0x4000 | 0x04,
            /// <summary>
            /// 燃油液位输入
            /// </summary>
            FuelLevelInput = 0x4000 | 0x05,
            /// <summary>
            /// 气缸1点火提前角
            /// </summary>
            Cylinder1IgnitionAdvanceAngle = 0x4000 | 0x06,
            /// <summary>
            /// 发动机负荷
            /// </summary>
            EngineLoad = 0x4000 | 0x07,
            /// <summary>
            /// 空气流量传感器的空气流量
            /// </summary>
            AirFlowRateOfAirFlowSensor = 0x4000 | 0x08,
            /// <summary>
            /// 自发动机起动的时间
            /// </summary>
            StartingTimeOfEngine = 0x4000 | 0x09,
            /// <summary>
            /// 进气温度
            /// </summary>
            IntakeAirTemperature = 0x4000 | 0x0A,
            /// <summary>
            /// 进气歧管传感器压力
            /// </summary>
            IntakeManifoldPressureSensor = 0x4000 | 0x0B,
        }

        public enum EobdRequestId: int
        {
            /// <summary>
            /// 握手
            /// </summary>
            Handshake = 151,
            /// <summary>
            /// Vin码
            /// </summary>
            VinCode = 153,
            /// <summary>
            /// Vin码二次请求
            /// </summary>
            VinSecond = 155,
            /// <summary>
            /// 故障码
            /// </summary>
            FaultCode = 157,
            /// <summary>
            ///故障码二次请求
            /// </summary>
            FaultSecond = 159,
            /// <summary>
            /// 绝对负荷值
            /// </summary>
            AbsoluteLoadValue = 161,
            /// <summary>
            /// 冷却液温度
            /// </summary>
            CoolantTemperature = 163,
            /// <summary>
            /// 节气门绝对位置
            /// </summary>
            AbsoluteThrottlePosition = 165,
            /// <summary>
            /// 控制模块电压
            /// </summary>
            ControlModuleVoltage = 167,
            /// <summary>
            /// 燃油液位输入
            /// </summary>
            FuelLevelInput = 169,
            /// <summary>
            /// 气缸1点火提前角
            /// </summary>
            Cylinder1IgnitionAdvanceAngle = 171,
            /// <summary>
            /// 发动机负荷
            /// </summary>
            EngineLoad = 173,
            /// <summary>
            /// 空气流量传感器的空气流量
            /// </summary>
            AirFlowRateOfAirFlowSensor = 175,
            /// <summary>
            /// 自发动机起动的时间
            /// </summary>
            StartingTimeOfEngine = 177,
            /// <summary>
            /// 进气温度
            /// </summary>
            IntakeAirTemperature = 179,
            /// <summary>
            /// 进气歧管传感器压力
            /// </summary>
            IntakeManifoldPressureSensor = 181,
        }

        public enum EobdAnswerId : int
        {
            /// <summary>
            /// 握手
            /// </summary>
            Handshake = 152,
            /// <summary>
            /// Vin码
            /// </summary>
            VinCode = 154,
            /// <summary>
            /// Vin码二次请求
            /// </summary>
            VinSecond = 156,
            /// <summary>
            /// 故障码
            /// </summary>
            FaultCode = 158,
            /// <summary>
            ///故障码二次请求
            /// </summary>
            FaultSecond = 160,
            /// <summary>
            /// 绝对负荷值
            /// </summary>
            AbsoluteLoadValue = 162,
            /// <summary>
            /// 冷却液温度
            /// </summary>
            CoolantTemperature = 164,
            /// <summary>
            /// 节气门绝对位置
            /// </summary>
            AbsoluteThrottlePosition = 166,
            /// <summary>
            /// 控制模块电压
            /// </summary>
            ControlModuleVoltage = 168,
            /// <summary>
            /// 燃油液位输入
            /// </summary>
            FuelLevelInput = 170,
            /// <summary>
            /// 气缸1点火提前角
            /// </summary>
            Cylinder1IgnitionAdvanceAngle = 172,
            /// <summary>
            /// 发动机负荷
            /// </summary>
            EngineLoad = 174,
            /// <summary>
            /// 空气流量传感器的空气流量
            /// </summary>
            AirFlowRateOfAirFlowSensor = 176,
            /// <summary>
            /// 自发动机起动的时间
            /// </summary>
            StartingTimeOfEngine = 178,
            /// <summary>
            /// 进气温度
            /// </summary>
            IntakeAirTemperature = 180,
            /// <summary>
            /// 进气歧管传感器压力
            /// </summary>
            IntakeManifoldPressureSensor = 182,
        }


        public enum EobdForNotificationId : int
        {
            /// <summary>
            /// 握手
            /// </summary>
            Handshake = 152,
            /// <summary>
            /// Vin码
            /// </summary>
            VinCode = 154,
            /// <summary>
            /// Vin码二次请求
            /// </summary>
            VinSecond = 156,
            /// <summary>
            /// 故障码
            /// </summary>
            FaultCode = 158,
            /// <summary>
            ///故障码二次请求
            /// </summary>
            FaultSecond = 160,
            /// <summary>
            /// 绝对负荷值
            /// </summary>
            AbsoluteLoadValue = 162,
            /// <summary>
            /// 冷却液温度
            /// </summary>
            CoolantTemperature = 164,
            /// <summary>
            /// 节气门绝对位置
            /// </summary>
            AbsoluteThrottlePosition = 166,
            /// <summary>
            /// 控制模块电压
            /// </summary>
            ControlModuleVoltage = 168,
            /// <summary>
            /// 燃油液位输入
            /// </summary>
            FuelLevelInput = 170,
            /// <summary>
            /// 气缸1点火提前角
            /// </summary>
            Cylinder1IgnitionAdvanceAngle = 172,
            /// <summary>
            /// 发动机负荷
            /// </summary>
            EngineLoad = 174,
            /// <summary>
            /// 空气流量传感器的空气流量
            /// </summary>
            AirFlowRateOfAirFlowSensor = 176,
            /// <summary>
            /// 自发动机起动的时间
            /// </summary>
            StartingTimeOfEngine = 178,
            /// <summary>
            /// 进气温度
            /// </summary>
            IntakeAirTemperature = 180,
            /// <summary>
            /// 进气歧管传感器压力
            /// </summary>
            IntakeManifoldPressureSensor = 182,
        }
    }
}
