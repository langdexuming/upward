﻿using System;
using CarTool.Main.Utils;
using CarTool.Main.Windows;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using CarTool.Main.Config;
using CarTool.Main.Helper;
using CarTool.Main.Services;
using CarTool.Main.ViewModels;
using Microsoft.Win32;
using Microsoft.Windows.Shell;

namespace CarTool.Main
{
    /// <summary>
    ///     MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow
    {
        private enum TabId
        {
            ConnectDevice,
            DataAnalysis,
            CarView
        } //代表当前TabeItem项ID

        private TabId _currentTabId = TabId.ConnectDevice;

        public MainWindow()
        {
            SetFontFamily();

            InitializeComponent();

            DataContext = App.ViewModel;

            CommandBindings.Add(new CommandBinding(Microsoft.Windows.Shell.SystemCommands.CloseWindowCommand, OnCloseWindow));
            CommandBindings.Add(new CommandBinding(Microsoft.Windows.Shell.SystemCommands.MaximizeWindowCommand, OnMaximizeWindow,
                OnCanResizeWindow));
            CommandBindings.Add(new CommandBinding(Microsoft.Windows.Shell.SystemCommands.MinimizeWindowCommand, OnMinimizeWindow,
                OnCanMinimizeWindow));
            CommandBindings.Add(new CommandBinding(Microsoft.Windows.Shell.SystemCommands.RestoreWindowCommand, OnRestoreWindow,
                OnCanResizeWindow));

            MaxHeight = SystemParameters.WorkArea.Height + 14;
            MaxWidth = SystemParameters.WorkArea.Width + 14;

            DataAnalysisView.Loaded += dataAnalysisView_Loaded;
            DataAnalysisView.Unloaded += dataAnalysisView_Unloaded;

            CarView.Loaded += carView_Loaded;
            CarView.Unloaded += dcarView_Unloaded;

            if (IsTestRunMode()) this.tabItemTest.Visibility = Visibility.Visible;


            Visibility = Visibility.Collapsed;

            //检测序列号
            if (!CheckSeriesNumber())
            {
                Application.Current.Shutdown();
                return;
            }

            Visibility = Visibility.Visible;
        }


        /// <summary>
        /// 检测登录
        /// </summary>
        private bool CheckSeriesNumber()
        {
            if (AppUtil.IsProductActived())
            {
                return true;
            }

            var window = new ProductActivationWindow();
            return window.ShowDialog() == true;
        }

        /// <summary>
        /// 运行模式是否为测试
        /// </summary>
        /// <returns></returns>
        private bool IsTestRunMode()
        {
            //检测APP模式
            var value = XmlUtil.GetValue(AppConstants.ConfigFilePath, "AppConfig/RunMode");
            if (!string.IsNullOrEmpty(value))
            {
                App.RunMode mode;
                if (Enum.TryParse(value, out mode))
                {
                    if (mode == App.RunMode.Test)
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// 设置字体（Microsoft YaHei UI>Microsoft YaHei>SimSun）
        /// </summary>
        private void SetFontFamily()
        {
            var fontFamilys = new List<FontFamily>();
            //获取可以使用的字体
            foreach (var fontfamily in Fonts.SystemFontFamilies)
            {
                if (string.CompareOrdinal(fontfamily.Source, "Microsoft YaHei UI") == 0)
                    fontFamilys.Add(fontfamily);
                if (string.CompareOrdinal(fontfamily.Source, "Microsoft YaHei") == 0)
                    fontFamilys.Add(fontfamily);
                if (string.CompareOrdinal(fontfamily.Source, "SimSun") == 0)
                    fontFamilys.Add(fontfamily);
            }

            //使用优先级高的字体
            var count = fontFamilys.Count;
            //
            switch (count)
            {
                case 1:
                case 2:
                case 3:
                    var postion = 0;
                    var highPriorityPostion = 0;

                    var middlePriorityPostion = 0;

                    var priority = 0;
                    foreach (var item in fontFamilys)
                    {
                        if (string.CompareOrdinal(item.Source, "Microsoft YaHei UI") == 0)
                        {
                            priority = 2;
                            highPriorityPostion = postion;
                        }
                        if (string.CompareOrdinal(item.Source, "Microsoft YaHei") == 0)
                        {
                            if (priority < 1)
                                priority = 1;
                            middlePriorityPostion = postion;
                        }
                        postion++;
                    }

                    //找到最高优先级的
                    if (priority == 2)
                    {
                        FontFamily = fontFamilys[highPriorityPostion];
                    }
                    else if (priority == 1)
                    {
                        //找到最第二优先级的
                        FontFamily = fontFamilys[middlePriorityPostion];
                    }
                    else
                    {
                        //只有一个
                        FontFamily = fontFamilys[0];
                    }
                    break;
                default:
                    break;
            }

        }

        /// <summary>
        ///     窗体加载完执行
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //将界面设置为默认状态
            // IsWindowSyncLoaded = true;
        }

        #region 设置菜单项

        private void MenuCarManageClick(object sender, RoutedEventArgs e)
        {
            var window = new CarManageWindow();
            window.Show();
        }

        private void MenuInfoManageClick(object sender, RoutedEventArgs e)
        {
            var window = new InfoManageWindow();
            window.Show();
        }

        private void MenuHelpClick(object sender, RoutedEventArgs e)
        {
            var window = new HelpWindow();
            window.Show();
        }

        private void MenuAboutClick(object sender, RoutedEventArgs e)
        {
            var box = new AboutBox();
            box.Show();
        }

        #endregion

        #region 选项卡切换逻辑

        private bool _isdataAnalysisViewLoaded;
        private bool _iscarViewLoaded;

        private void dcarView_Unloaded(object sender, RoutedEventArgs e)
        {
            _iscarViewLoaded = false;
        }

        private void carView_Loaded(object sender, RoutedEventArgs e)
        {
            _iscarViewLoaded = true;
        }

        private void dataAnalysisView_Unloaded(object sender, RoutedEventArgs e)
        {
            _isdataAnalysisViewLoaded = false;
        }

        private void dataAnalysisView_Loaded(object sender, RoutedEventArgs e)
        {
            _isdataAnalysisViewLoaded = true;
        }

        /// <summary>
        ///     TabControl的TabItem项选择发生变化
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //确认是哪一个TabItem
            var tabControl = (TabControl) sender;
            switch (tabControl.SelectedIndex)
            {
                case 0: //连接设备
                    _currentTabId = TabId.ConnectDevice;
                    ServiceManager.GetInstance().CanCoreCommunicateService.SetRunModule(Modules.None);
                    break;
                case 1: //数据分析
                    _currentTabId = TabId.DataAnalysis;
                    Task.Factory.StartNew(() =>
                    {
                        while (!_isdataAnalysisViewLoaded) Thread.Sleep(50);
                        Thread.Sleep(200);
                        ServiceManager.GetInstance().CanCoreCommunicateService.SetRunModule(Modules.DataAnalysis);
                    });
                    break;
                case 2: //车型库
                    _currentTabId = TabId.CarView;
                    Task.Factory.StartNew(() =>
                    {
                        while (!_iscarViewLoaded) Thread.Sleep(50);
                        Thread.Sleep(200);
                        ServiceManager.GetInstance().CanCoreCommunicateService.SetRunModule(Modules.CarView);
                    });
                    break;
                default:
                    break;
            }
        }

        #endregion

        /*********************测试模块窗口弹出**********************/

        #region 测试模块窗口弹出

        /// <summary>
        ///     Can数据发送测试
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button_canSendTest_Click(object sender, RoutedEventArgs e)
        {
            var window = new CanSendTestWindow();
            window.Show();
        }

        /// <summary>
        ///     遥控车
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button_carRemoteControlTest_Click(object sender, RoutedEventArgs e)
        {
            var window = new RemoteControlWindow();
            window.Show();
        }

        private void button_carInstructions_Click(object sender, RoutedEventArgs e)
        {
            var window = new CarInstructionsWindow();
            window.Show();
        }

        private void button_carMessageTipClick(object sender, RoutedEventArgs e)
        {
            var window = new CarMessageTipWindow();
            window.Show();
        }

        private void button_carViewClick(object sender, RoutedEventArgs e)
        {
            var window = new CarViewWindow();
            window.Show();
        }

        private void btton_autoCanDataTest_Click(object sender, RoutedEventArgs e)
        {
            var window = new AutoCanDataTestWindow();
            window.Show();
        }

        private void btton_speechTest_Click(object sender, RoutedEventArgs e)
        {
            var window = new SpeechTestWindow();
            window.Show();
        }

        private void button_canSetting_Click(object sender, RoutedEventArgs e)
        {
            var window = new CanSettingWindow();
            window.Show();
        }

        private void button_uiTest_Click(object sender, RoutedEventArgs e)
        {
            var window = new ControlTestWindow();
            window.Show();
        }

        private void button_commPortcarView_Click(object sender, RoutedEventArgs e)
        {
            //Windows.CommPortParts.MainWindow window = new Windows.CommPortParts.MainWindow();
            //window.Show();
        }

        /// <summary>
        ///     提供升级数据库的方法
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button_updateDatabase_Click(object sender, RoutedEventArgs e)
        {
            var value = App.CarDataSet.UpdateDatabase();
        }


        /// <summary>
        /// 导入旧版数据库
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button_importOldDatabase_Click(object sender, RoutedEventArgs e)
        {
            var of = new OpenFileDialog();

            of.Title = "导入旧版数据库";
            of.DefaultExt = "sdf";
            of.Filter = "sdf files (*.sdf)|*.sdf";
            //of.Filter = "sdf files (*.sdf)|*.sdf|All files (*.*)|*.*";
            of.FilterIndex = 1;
            of.RestoreDirectory = true;

            if (of.ShowDialog() == true)
            {
                var vm = new LoadingViewModel();

                DialogHelper.Show(vm);

                Task.Factory.StartNew(() =>
                {
                //更新数据库
                bool result = App.CarDataSet.UpdateOldDatabase(of.FileName);
                    Application.Current.Dispatcher.Invoke(new Action(() =>
                    {
                        DialogHelper.Close(vm);
                        if (result)
                        {
                            MessageBox.Show("导入成功，重启该软件后生效！");
                        }
                        else
                        {
                            MessageBox.Show("导入失败！");
                        }
                    }));
                });
            }
            
        }
        #endregion

        /*************************Windows自定义窗口界面操作所需逻辑*************************************/

        private void OnCanMinimizeWindow(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = ResizeMode != ResizeMode.NoResize;
        }

        private void OnCanResizeWindow(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = ResizeMode == ResizeMode.CanResize || ResizeMode == ResizeMode.CanResizeWithGrip;
        }

        private void OnRestoreWindow(object sender, ExecutedRoutedEventArgs e)
        {
            Microsoft.Windows.Shell.SystemCommands.RestoreWindow(this);
        }

        private void OnMinimizeWindow(object sender, ExecutedRoutedEventArgs e)
        {
            Microsoft.Windows.Shell.SystemCommands.MinimizeWindow(this);
        }

        private void OnMaximizeWindow(object sender, ExecutedRoutedEventArgs e)
        {
            if (WindowState == WindowState.Maximized)
                Microsoft.Windows.Shell.SystemCommands.RestoreWindow(this);
            else
                Microsoft.Windows.Shell.SystemCommands.MaximizeWindow(this);
        }

        private void OnCloseWindow(object sender, ExecutedRoutedEventArgs e)
        {
            Microsoft.Windows.Shell.SystemCommands.CloseWindow(this);
        }

        private void border_titleBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ClickCount == 2) //双击
                OnMaximizeWindow(this, null);
            DragMove();
        }

        private void border_titleBar_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            Microsoft.Windows.Shell.SystemCommands.ShowSystemMenu(this, PointToScreen(e.GetPosition((IInputElement) e.Source)));
        }

        private void thumb_right_DragDelta(object sender, DragDeltaEventArgs e)
        {
            var source = e.Source as Thumb;
            if (source != null)
            {
                var thumb = source;
                var yadjust = Height;
                var xadjust = Width + e.HorizontalChange;
                if (xadjust >= 0 && yadjust >= 0)
                {
                    Width = xadjust;
                    Height = yadjust;
                    Canvas.SetLeft(this, Canvas.GetLeft(thumb) +
                                         e.HorizontalChange);
                    Canvas.SetTop(this, Canvas.GetTop(thumb) +
                                        e.VerticalChange);
                }
            }
        }

        private void thumb_left_DragDelta(object sender, DragDeltaEventArgs e)
        {
            var source = e.Source as Thumb;
            if (source != null)
            {
                var thumb = source;
                Left = Left + e.HorizontalChange;
                var yadjust = Height;
                var xadjust = Width - e.HorizontalChange;
                if (xadjust >= 0 && yadjust >= 0)
                {
                    Width = xadjust;
                    Height = yadjust;
                    Canvas.SetLeft(this, Canvas.GetLeft(thumb) +
                                         e.HorizontalChange);
                    Canvas.SetTop(this, Canvas.GetTop(thumb) +
                                        e.VerticalChange);
                }
            }
        }

        private void thumb_bottom_DragDelta(object sender, DragDeltaEventArgs e)
        {
            var source = e.Source as Thumb;
            if (source != null)
            {
                var thumb = source;
                var yadjust = Height + e.VerticalChange;
                var xadjust = Width;
                if (xadjust >= 0 && yadjust >= 0)
                {
                    Width = xadjust;
                    Height = yadjust;
                    Canvas.SetLeft(this, Canvas.GetLeft(thumb) +
                                         e.HorizontalChange);
                    Canvas.SetTop(this, Canvas.GetTop(thumb) +
                                        e.VerticalChange);
                }
            }
        }

        private void thumb_top_DragDelta(object sender, DragDeltaEventArgs e)
        {
            var source = e.Source as Thumb;
            if (source != null)
            {
                var thumb = source;
                Top = Top + e.VerticalChange;
                var yadjust = Height - e.VerticalChange;
                var xadjust = Width;
                if (xadjust >= 0 && yadjust >= 0)
                {
                    Width = xadjust;
                    Height = yadjust;
                    Canvas.SetLeft(this, Canvas.GetLeft(thumb) +
                                         e.HorizontalChange);
                    Canvas.SetTop(this, Canvas.GetTop(thumb) +
                                        e.VerticalChange);
                }
            }
        }

        private void thumb_topLeft_DragDelta(object sender, DragDeltaEventArgs e)
        {
            var source = e.Source as Thumb;
            if (source != null)
            {
                var thumb = source;
                Left = Left + e.HorizontalChange;
                Top = Top + e.VerticalChange;
                var yadjust = Height - e.VerticalChange;
                var xadjust = Width - e.HorizontalChange;
                if (xadjust >= 0 && yadjust >= 0)
                {
                    Width = xadjust;
                    Height = yadjust;
                    Canvas.SetLeft(this, Canvas.GetLeft(thumb) +
                                         e.HorizontalChange);
                    Canvas.SetTop(this, Canvas.GetTop(thumb) +
                                        e.VerticalChange);
                }
            }
        }

        private void thumb_topRight_DragDelta(object sender, DragDeltaEventArgs e)
        {
            var source = e.Source as Thumb;
            if (source != null)
            {
                var thumb = source;
                Top = Top + e.VerticalChange;
                var yadjust = Height - e.VerticalChange;
                var xadjust = Width + e.HorizontalChange;
                if (xadjust >= 0 && yadjust >= 0)
                {
                    Width = xadjust;
                    Height = yadjust;
                    Canvas.SetLeft(this, Canvas.GetLeft(thumb) +
                                         e.HorizontalChange);
                    Canvas.SetTop(this, Canvas.GetTop(thumb) +
                                        e.VerticalChange);
                }
            }
        }

        private void thumb_bottomLeft_DragDelta(object sender, DragDeltaEventArgs e)
        {
            var source = e.Source as Thumb;
            if (source != null)
            {
                var thumb = source;
                Left = Left + e.HorizontalChange;
                var yadjust = Height + e.VerticalChange;
                var xadjust = Width - e.HorizontalChange;
                if (xadjust >= 0 && yadjust >= 0)
                {
                    Width = xadjust;
                    Height = yadjust;

                    Canvas.SetLeft(this, Canvas.GetLeft(thumb) +
                                         e.HorizontalChange);
                    Canvas.SetTop(this, Canvas.GetTop(thumb) +
                                        e.VerticalChange);
                }
            }
        }

        private void thumb_bottomRight_DragDelta(object sender, DragDeltaEventArgs e)
        {
            var source = e.Source as Thumb;
            if (source != null)
            {
                var thumb = source;
                var yadjust = Height + e.VerticalChange;
                var xadjust = Width + e.HorizontalChange;
                if (xadjust >= 0 && yadjust >= 0)
                {
                    Width = xadjust;
                    Height = yadjust;

                    Canvas.SetLeft(this, Canvas.GetLeft(thumb) +
                                         e.HorizontalChange);
                    Canvas.SetTop(this, Canvas.GetTop(thumb) +
                                        e.VerticalChange);
                }
            }
        }

    }
}
