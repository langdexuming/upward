﻿using CarTool.Main.ECanUsb;
using CarTool.Main.Helper;
using ECAN;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using CarTool.Main.Utils;
using CarTool.Main.ViewModels;

namespace CarTool.Main.Views
{
    /// <summary>
    /// ConnectDevice.xaml 的交互逻辑
    /// </summary>
    public partial class ConnectDevice : UserControl
    {
        private const int ComboxDefaultSelectIndex = 0;

        byte m_Baudrate;
        byte m_Baudrate2;

        private readonly Storyboard Storyboard1;
        private readonly Storyboard Storyboard2;

        private int CurrentDurationCounts = 15;

        private readonly ViewModels.ConnectDeviceVm ViewModel = App.ViewModel.ConnectDeviceVM;

        public ConnectDevice()
        {
            InitializeComponent();

            this.ComboBox_Can1.ItemsSource = DataManager.GetInstance().GetBaudRates();
            this.ComboBox_Can2.ItemsSource = DataManager.GetInstance().GetBaudRates();

            //default to select combox
            this.ComboBox_Can1.SelectedIndex = ComboxDefaultSelectIndex;
            this.ComboBox_Can2.SelectedIndex = ComboxDefaultSelectIndex;

            this.DataContext = ViewModel;

            try
            {
                this.Storyboard1 = (Storyboard)FindResource("Storyboard1");
            }
            catch
            {
                Debug.WriteLine("Load Storyboard1 error");
            }
            try
            {
                this.Storyboard2 = (Storyboard)FindResource("Storyboard2");
            }
            catch
            {
                Debug.WriteLine("Load Storyboard2 error");
            }

        }


        /// <summary>
        /// 自动识别CAN1
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_Can1_Click(object sender, RoutedEventArgs e)
        {
            AutoSpotBaudRateViewModel vm= ViewModel.autoSpotBaudRateVm1;
            if (DialogHelper.ShowDialog(vm) == true)
            {
                this.ComboBox_Can1.SelectedIndex = this.ComboBox_Can1.Items.IndexOf(ViewModel.autoSpotBaudRateVm1.BaudRate);
            }
        }

        /// <summary>
        /// 自动识别CAN2
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_Can2_Click(object sender, RoutedEventArgs e)
        {
            AutoSpotBaudRateViewModel vm = ViewModel.autoSpotBaudRateVm2;
            if (DialogHelper.ShowDialog(vm) == true)
            {
                this.ComboBox_Can2.SelectedIndex = this.ComboBox_Can2.Items.IndexOf(ViewModel.autoSpotBaudRateVm2.BaudRate);
            }
        }

        private void button_OpenDevice_Click(object sender, RoutedEventArgs e)
        {
            if (ServiceManager.GetInstance().CanCoreCommunicateService.IsOpen)
            {
                MessageBox.Show("设备已打开");
                return;
            }
            this.m_Baudrate = System.Convert.ToByte(this.ComboBox_Can1.SelectedIndex);
            this.m_Baudrate2 = System.Convert.ToByte(this.ComboBox_Can2.SelectedIndex);
            //打开设备
            if (ServiceManager.GetInstance().CanCoreCommunicateService.OpenDevice(this.m_Baudrate,this.m_Baudrate2) == false)
            {
                MessageBox.Show("设备异常，请重新接入!");
                return;
            }
        }
        /// <summary>
        /// close the Device
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button_CloseDevice_Click(object sender, RoutedEventArgs e)
        {
            ServiceManager.GetInstance().CanCoreCommunicateService.CloseDevice();
        }
       

        private void ComboBox_Can1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (this.Storyboard1 != null)
            {
                CurrentDurationCounts = DataManager.GetInstance().GetBaudRates(false).IndexOf((string)this.ComboBox_Can1.SelectedValue) + 1;
                Duration duration = new Duration(TimeSpan.FromSeconds(0.1* CurrentDurationCounts));
                this.Storyboard1.Duration = duration;
                this.Storyboard1.Begin();
            }
                
        }

        private void ComboBox_Can2_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (this.Storyboard2 != null)
            {
                CurrentDurationCounts = DataManager.GetInstance().GetBaudRates(false).IndexOf((string)this.ComboBox_Can2.SelectedValue) +1;
                Duration duration = new Duration(TimeSpan.FromSeconds(0.1 * CurrentDurationCounts));
                this.Storyboard2.Duration = duration;
                this.Storyboard2.Begin();
            }
        }
    }
}
