﻿using CarTool.Main.Models;
using CarTool.Main.Utils;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CarTool.Main.Views.Parts
{
    /// <summary>
    /// PagingDatagrid.xaml 的交互逻辑
    /// </summary>
    public partial class PagingDatagrid : UserControl
    {
        //每页5行
        // private const int MaxRow = 5;

        ////定义一个委托
        //public delegate void PageChangedHandle(object sender, EventArgs e);

        ////定义一个事件
        //public event PageChangedHandle PageChanged;

        //private void PageChangedFunc()
        //{
        //    if (PageChanged != null)
        //        PageChanged(this,new EventArgs());
        //}


        ////总页数
        //private int totalPage = 1;

        //// 当前页
        //private int currentPage = 1;

        /// <summary>
        /// 注册当前页属性(省去值验证)
        /// </summary>


        public static int GetCurrentPage(DependencyObject obj)
        {
            return (int)obj.GetValue(CurrentPageProperty);
        }

        public static void SetCurrentPage(DependencyObject obj, int value)
        {
            obj.SetValue(CurrentPageProperty, value);
        }

        // Using a DependencyProperty as the backing store for CurrentPage.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty CurrentPageProperty =
            DependencyProperty.RegisterAttached("CurrentPage", typeof(int), typeof(PagingDatagrid), new PropertyMetadata(0));

        //private static bool ValueRangeValidate(object value)
        //{
        //    if(value is int)
        //    {
        //        int _value = Convert.ToInt32(value);
        //        if ((_value<0) ||(_value >5))
        //            return true;
        //    }
        //    return false;
        //    //throw new NotImplementedException();
        //}

        /// <summary>
        /// 注册总页属性(省去值验证)
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>

        public static int GetPageSize(DependencyObject obj)
        {
            return (int)obj.GetValue(PageSizeProperty);
        }

        public static void SetPageSize(DependencyObject obj, int value)
        {
            obj.SetValue(PageSizeProperty, value);
        }

        // Using a DependencyProperty as the backing store for PageSize.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty PageSizeProperty =
            DependencyProperty.RegisterAttached("PageSize", typeof(int), typeof(PagingDatagrid), new PropertyMetadata(0));

        public static int GetMaxPageRowCounts(DependencyObject obj)
        {
            return (int)obj.GetValue(MaxPageRowCountsProperty);
        }

        public static void SetMaxPageRowCounts(DependencyObject obj, int value)
        {
            obj.SetValue(MaxPageRowCountsProperty, value);
        }

        // Using a DependencyProperty as the backing store for MaxRowCounts.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty MaxPageRowCountsProperty =
            DependencyProperty.RegisterAttached("MaxPageRowCounts", typeof(int), typeof(PagingDatagrid), new PropertyMetadata(5));


        public PagingDatagrid()
        {
            InitializeComponent();

            //根据附加属性绑定ViewModel中对应的值

            Binding binding = new Binding("CurrentPage");
            binding.Mode = BindingMode.TwoWay;
            BindingOperations.SetBinding(this, CurrentPageProperty, binding);

            //当前页数发生改变，引发ViewModel当前页发生改变
            Binding binding2 = new Binding("MaxPageSize");
            binding2.Mode = BindingMode.TwoWay;
            BindingOperations.SetBinding(this, PageSizeProperty, binding2);

            //每页的行数
            Binding binding3 = new Binding("MaxPageRowCounts");
            binding3.Mode = BindingMode.OneWayToSource;
            BindingOperations.SetBinding(this, MaxPageRowCountsProperty, binding3);

            this.dataGrid_Can.SizeChanged += new SizeChangedEventHandler(this.dataGrid_Can_SizeChanged);
            // this.dataGrid_Can.CopyingRowClipboardContent += new EventHandler<DataGridRowClipboardEventArgs>(this.dataGrid_Can_CopyingRowClipboardContent);

            this.DataContextChanged += new DependencyPropertyChangedEventHandler(this.DataContextChangedDoing);

            // this.menuItem_autoSpot.ItemsSource = DataManager.GetInstance().InfoItems;

            KeyDown += HasKeyDown;
        }

        /// <summary>
        ///   
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void HasKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (this.tbxInputPageNum.IsFocused)
                {
                    this.dataGrid_Can.Focus();
                }
            }
        }

        /// <summary>
        /// 去掉不必要的列
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dataGrid_Can_CopyingRowClipboardContent(object sender, DataGridRowClipboardEventArgs e)
        {
            e.ClipboardRowContent.RemoveRange(0,2);

            while (e.ClipboardRowContent.Last().Content.ToString() == "")
            {
                e.ClipboardRowContent.RemoveAt(e.ClipboardRowContent.Count-1);
            }
        }

        private void DataContextChangedDoing(object sender, DependencyPropertyChangedEventArgs e)
        {

            if (this.DataContext is ViewModels.CanDataVm)
                this.button_clearGoNowOrder.Command = ((ViewModels.CanDataVm)this.DataContext).ClearGoNowOrderCommand;

        }
        private const double RowHeight = 30;//行高度

        private const double ColumnHeaderHeight = 36;

        private double InitFlagWidth = 651.6363;

        private const int DataGridColumnCount = 16;//已改为16

        //运行生成
       // private double[] InitColumnsWidth = new double[DataGridColumnCount] { 29, 51.7466666666667, 39.23, 29, 38.0866666666667, 38.0866666666667, 38.0866666666667, 38.0866666666667, 38.0866666666667, 38.0866666666667, 38.0866666666667, 38.0866666666667, 35, 70 };
        private double[] InitColumnsWidth = new double[DataGridColumnCount] { 29, 51.7466666666667, 42.5066666666667, 40, 40, 29, 38.0866666666667, 38.0866666666667, 38.0866666666667, 38.0866666666667, 38.0866666666667, 38.0866666666667, 38.0866666666667, 38.0866666666667, 33, 64 };
       
        
        /// <summary>
        /// 动态改变行数
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dataGrid_Can_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            if (e.HeightChanged)//如果高度改变
            {
                //延时滚动
                double totalHeight = e.NewSize.Height - ColumnHeaderHeight - 0;//去掉横滑动条的高度(已隐藏滑动条)--
                if (totalHeight >= RowHeight)
                {
                    int rowCounts = (int)(totalHeight / RowHeight);
                    if (rowCounts>0)
                        this.SetValue(MaxPageRowCountsProperty, rowCounts);
                }
            }
            ////获取DataGrid的Column宽度
            //int count = this.dataGrid_Can.Columns.Count;
            //for (int i = 0; i < count; i++)
            //{
            //    Debug.Write(this.dataGrid_Can.Columns[i].ActualWidth + ",");

            //}
            //Debug.WriteLine("");
            ////调整宽度
            if (e.WidthChanged)
            {
                //一定差后才进行改变
                if ((e.NewSize.Width - DataGridColumnCount / 2) > InitFlagWidth)
                {
                    double _value = 0;
                    _value = (e.NewSize.Width - InitFlagWidth) / DataGridColumnCount;
                    for (int i = 0; i < DataGridColumnCount; i++)
                    {
                        this.dataGrid_Can.Columns[i].Width = InitColumnsWidth[i] + _value;
                    }

                }
                else
                {
                    for (int i = 0; i < DataGridColumnCount; i++)
                    {
                        this.dataGrid_Can.Columns[i].Width = InitColumnsWidth[i];

                    }
                }
            }

        }

        private void button_indexPage_Click(object sender, RoutedEventArgs e)
        {
            this.SetValue(CurrentPageProperty,1);
           
        }

        private void button_previousPage_Click(object sender, RoutedEventArgs e)
        {
            int value = (int)this.GetValue(CurrentPageProperty);
            this.SetValue(CurrentPageProperty, value-1);
        

        }

        private void button_nextPage_Click(object sender, RoutedEventArgs e)
        {
            int value = (int)this.GetValue(CurrentPageProperty);
            this.SetValue(CurrentPageProperty, value + 1);
        
        }

        private void button_lastPage_Click(object sender, RoutedEventArgs e)
        {
            int value = (int)this.GetValue(PageSizeProperty);
            this.SetValue(CurrentPageProperty, value);
        }

        private void dataGrid_CanSorting(object sender, DataGridSortingEventArgs e)
        {
            e.Handled = true;
            string sortField = string.Empty;
            switch (e.Column.SortMemberPath)
            {
                case ("CanDataBaseObject.OrderId"):
                    sortField = "CanDataBaseObject.OrderId";
                    break;
                case ("Id"):
                    sortField = "Id";
                    break;
            }
            ListSortDirection direction = (e.Column.SortDirection != ListSortDirection.Ascending) ?
                ListSortDirection.Ascending : ListSortDirection.Descending;

            bool sortAscending = direction == ListSortDirection.Ascending;
            ViewModels.CanDataVm viewModel = (ViewModels.CanDataVm)this.DataContext;

            viewModel.Sort(sortField, sortAscending);
            e.Column.SortDirection = direction;
        }


        /// <summary>
        /// 由UpdateSourceTrigger=PropertyChanged代替
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (e.Source is TextBox)
            {
                TextBox tb = (TextBox)e.Source;
                this.button_nextPage.Focus();
                // tb.Focusable = false;
                // tb.Focusable = true;
                tb.Focus();

            }

        }

        private void DataGridColumn_CopyingCellClipboardContent(object sender, DataGridCellClipboardEventArgs e)
        {
            switch (e.Column.DisplayIndex)
            {
                case 2:
                    e.Content = string.Format("0x{0:x}", e.Content);
                    break;
                case 3:
                    e.Content = string.Format("{0}", ((CarTool.Main.Models.CanDataReview)e.Item).CanDataBaseObject.RemoteFlag);
                    break;
                case 4:
                    e.Content = string.Format("{0}", ((CarTool.Main.Models.CanDataReview)e.Item).CanDataBaseObject.ExternFlag);
                    break;
                default:
                    e.Content = "";
                    break;
            }
            
        }

    }
}
