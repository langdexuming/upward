﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CarTool.Main.Views.Parts
{
    /// <summary>
    /// AdderSubtractorCase.xaml 的交互逻辑
    /// </summary>
    public partial class AdderSubtractorCase : UserControl
    {
        public AdderSubtractorCase()
        {
            InitializeComponent();
        }
        private void button_reduce_click(object sender, RoutedEventArgs e)
        {
            this.textblock_num.Text = (Convert.ToInt32(this.textblock_num.Text) - 1).ToString();
        }

        private void button_add_click(object sender, RoutedEventArgs e)
        {
            this.textblock_num.Text = (Convert.ToInt32(this.textblock_num.Text) + 1).ToString();
        }
    }
}
