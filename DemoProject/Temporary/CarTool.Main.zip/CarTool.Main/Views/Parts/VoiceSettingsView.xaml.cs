﻿using CarTool.Main.ViewModels;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CarTool.Main.Views.Parts
{
    /// <summary>
    /// VoiceSettingDialog.xaml 的交互逻辑
    /// </summary>
    public partial class VoiceSettingsView : UserControl
    {
        public VoiceSettingsView()
        {
            InitializeComponent();
        }

        private void button_submit(object sender, RoutedEventArgs e)
        {
            foreach (var item in Helper.ControlsSearchHelper.GetChildObjects<CheckBox>(this.listBox_voiceItem, string.Empty))
            {
                item.GetBindingExpression(CheckBox.IsCheckedProperty).UpdateSource();
            }
            var window = Helper.ControlsSearchHelper.GetParentObject<Window>(this,string.Empty);
            if (window != null)
            {
                window.DialogResult = true;
            }
        }

        private void button_reset(object sender, RoutedEventArgs e)
        {
            foreach (var item in Helper.ControlsSearchHelper.GetChildObjects<CheckBox>(this.listBox_voiceItem, string.Empty))
            {
                item.GetBindingExpression(CheckBox.IsCheckedProperty).UpdateTarget();
            }
        }

        private void menuItem_selectAll(object sender, RoutedEventArgs e)
        {
            foreach (var item in Helper.ControlsSearchHelper.GetChildObjects<CheckBox>(this.listBox_voiceItem, string.Empty))
            {
                item.IsChecked = true;
            }
        }

        private void menuItem_unselectAll(object sender, RoutedEventArgs e)
        {
            foreach (var item in Helper.ControlsSearchHelper.GetChildObjects<CheckBox>(this.listBox_voiceItem, string.Empty))
            {
                item.IsChecked = false;
            }
        }

    }
}
