﻿using CarTool.Main.Helper;
using CarTool.Main.Utils;
using CarTool.Main.ViewModels;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using CarTool.Main.Models;

namespace CarTool.Main.Views.Parts
{
    /// <summary>
    /// CarInfoEditCard.xaml 的交互逻辑
    /// </summary>
    public partial class CarInfoEditCard : UserControl
    {
        public CarInfoEditCard()
        {
            InitializeComponent();
            this.grid.MouseLeftButtonDown += new MouseButtonEventHandler(delegate (object sender, MouseButtonEventArgs e) {
                this.checkBox.RaiseEvent(e);
            });
            this.checkBox.Click += (s, e) =>
            {
                if (this.checkBox.IsChecked == true)
                {
                    var model = this.DataContext as Models.InfoItemReview;
                    if (model != null)
                    {
                        if ((model.DataTypeObject == null) || typeof(DataTypeBase) == model.DataTypeObject.GetType())
                        {
                            this.checkBox.IsChecked = false;
                            MessageBox.Show("该项数据为空，无法使能！");
                            e.Handled = true;
                        }
                    }
                }
            };
        }
        private void button_editInfo(object sender, RoutedEventArgs e)
        {
            //此处应该传递当前信息
            if (!App.ViewModel.DataAnalysisVM.IsLoadedCarInfoSuccessful)
            {
                MessageBox.Show("请载入车型");
                return;
            }
            //获取该ListViewBoxItem的数据源
            Button button = (Button)sender;
            ListBoxItem listBoxItem = Helper.ControlsSearchHelper.GetParentObject<ListBoxItem>(button, string.Empty);
            var item = new InfoItemReview(((Models.InfoItemReview)listBoxItem.DataContext));
            //var findItems = DataManager.GetInstance().InfoItems.Where(x => x.InfoItemID == item.InfoItemId);

            //foreach(var findItem in findItems)
            //{
            //    item.InfoItem = findItem;
            //    break;
            //}

            SaveCarInfoViewModel model = new SaveCarInfoViewModel("修改数据", item,Enums.CommonEnums.ActionTypes.Edit);

            var result = DialogHelper.ShowDialog(model);

            //此处发生更改，则需要寻找ListBox_info的数据源对应的项，然后更改
            if (result == true)
            {
                ((Models.InfoItemReview)(listBoxItem.DataContext)).DataTypeObject = model.CurrentInfoItemReview?.DataTypeObject;
            }

        }

        private void button_clearInfo(object sender, RoutedEventArgs e)
        {

        }
    }
}
