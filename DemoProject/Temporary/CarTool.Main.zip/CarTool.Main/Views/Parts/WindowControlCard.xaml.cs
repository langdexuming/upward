﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CarTool.Main.Views.Parts
{
    /// <summary>
    /// WindowControlCard.xaml 的交互逻辑
    /// </summary>
    public partial class WindowControlCard : UserControl
    {
  //      public static readonly DependencyProperty LeftIconPressBrushProperty = DependencyProperty.Register("LeftIconPressBrush",
  //          typeof(Brush), typeof(WindowControlCard), new FrameworkPropertyMetadata(default(Brush), FrameworkPropertyMetadataOptions.AffectsRender));

  //      public Brush LeftIconPressBrush
  //      {
  //          get { return (Brush)GetValue(LeftIconPressBrushProperty); }
  //          set { SetValue(LeftIconPressBrushProperty, value); }
  //      }

  //      public static readonly DependencyProperty RightIconPressBrushProperty = DependencyProperty.Register("RightIconPressBrush",
  //          typeof(Brush), typeof(WindowControlCard), new FrameworkPropertyMetadata(default(Brush), FrameworkPropertyMetadataOptions.AffectsRender));

  //      public Brush RightIconPressBrush
  //      {
  //          get { return (Brush)GetValue(RightIconPressBrushProperty); }
  //          set { SetValue(RightIconPressBrushProperty, value); }
  //      }

  //      public static readonly DependencyProperty IconBackgroundProperty = DependencyProperty.Register("IconBackground",
  //        typeof(Brush), typeof(WindowControlCard), new FrameworkPropertyMetadata(default(Brush), FrameworkPropertyMetadataOptions.AffectsRender));

  //      public Brush IconBackground
  //      {
  //          get { return (Brush)GetValue(IconBackgroundProperty); }
  //          set { SetValue(IconBackgroundProperty, value); }
  //      }

  //      public static readonly DependencyProperty IconDisableBrushProperty = DependencyProperty.Register("IconDisableBrush",
  //typeof(Brush), typeof(WindowControlCard), new FrameworkPropertyMetadata(default(Brush), FrameworkPropertyMetadataOptions.AffectsRender));


  //      public Brush IconDisableBrush
  //      {
  //          get { return (Brush)GetValue(IconDisableBrushProperty); }
  //          set { SetValue(IconDisableBrushProperty, value); }
  //      }


        /// <summary>
        /// 暂时忽略选择和未选中的路由事件
        /// </summary>
        [Bindable(true)]
        public bool CanSelect
        {
            get { return (bool)GetValue(CanSelectProperty); }
            set
            {
                if (!CanSelect)
                    IsSelected = false;
                SetValue(CanSelectProperty, value);
            }
        }

        // Using a DependencyProperty as the backing store for CanSelect.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty CanSelectProperty =
            DependencyProperty.Register("CanSelect", typeof(bool), typeof(WindowControlCard), new PropertyMetadata(default(bool), new PropertyChangedCallback(CanSelectionChanged)));


        private static void CanSelectionChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            WindowControlCard control = (WindowControlCard)d;

            if (e.Property.Name == CanSelectProperty.Name)
            {
                if (!(bool)e.NewValue)
                {
                    if (control.IsSelected)
                        control.IsSelected = false;
                }
            }

        }

        private static void SelectionChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            WindowControlCard control = (WindowControlCard)d;

            if (e.Property.Name == IsSelectedProperty.Name)
            {
                control.IsSelected = (bool)e.NewValue;
            }

        }

        protected override void OnMouseLeftButtonDown(MouseButtonEventArgs e)
        {
            if (CanSelect)
                IsSelected = !IsSelected;
            base.OnMouseLeftButtonDown(e);
        }

        [Bindable(true)]
        public bool IsSelected
        {
            get { return (bool)GetValue(IsSelectedProperty); }
            set {
                SetValue(IsSelectedProperty, value);
            }
        }

        // Using a DependencyProperty as the backing store for IsSelected.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty IsSelectedProperty =
            DependencyProperty.Register("IsSelected", typeof(bool), typeof(WindowControlCard), new PropertyMetadata((false), new PropertyChangedCallback(SelectionChanged)));



        public Dock IconStripPlacement
        {
            get { return (Dock)GetValue(IconStripPlacementProperty); }
            set {
                SetValue(IconStripPlacementProperty, value);
            }
        }

        // Using a DependencyProperty as the backing store for IconStripPlacement.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty IconStripPlacementProperty =
            DependencyProperty.Register("IconStripPlacement", typeof(Dock), typeof(WindowControlCard), new PropertyMetadata(Dock.Right,
                (s, e) =>
                {
                    var control = s as WindowControlCard;
                    if (control != null)
                    {
                        switch (control.IconStripPlacement)
                        {
                            case Dock.Bottom:
                                control.grid_right.Visibility = Visibility.Collapsed;
                                control.grid_bottom.Visibility = Visibility.Visible;
                                break;
                            case Dock.Right:
                                control.grid_right.Visibility = Visibility.Visible;
                                control.grid_bottom.Visibility = Visibility.Collapsed;
                                break;
                            default:
                                break;
                        }
                    }

                }));

        public WindowControlCard()
        {
            InitializeComponent();
        }
    }
}
