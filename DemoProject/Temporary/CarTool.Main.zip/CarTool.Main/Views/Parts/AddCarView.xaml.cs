﻿using CarTool.Main.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CarTool.Main.Views.Parts
{
    /// <summary>
    /// AddCarView.xaml 的交互逻辑
    /// </summary>
    public partial class AddCarView : UserControl
    {
        public AddCarView()
        {
            InitializeComponent();

            var years = new List<string>();
            var currentYear = DateTime.Now.Year;
            for (int i = 0; i < 5; i++)
            {
                years.Add((currentYear - i).ToString());
            }
            this.cbxSuitYear.ItemsSource = years;

            this.DataContextChanged += ((s,e)=>
            {
                var vm = this.DataContext as AddCarViewModel;
                if(vm != null)
                {
                    this.textBox_brand.IsEnabled = vm.AddType != AddCarViewModel.AddTypes.AddModel;
                    if (vm.AddType == AddCarViewModel.AddTypes.AddModel)
                    {
                        this.textBox_model.Focus();
                    }
                    else
                    {
                        this.textBox_brand.Focus();
                    }
                }
            });

        }
    }
}
