﻿using CarTool.Main.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CarTool.Main.Views.Parts
{
    /// <summary>
    /// DraggablePopup.xaml 的交互逻辑
    /// </summary>
    public partial class DraggablePopup : Popup
    {

        public object Content
        {
            get { return (object)GetValue(ContentProperty); }
            set { SetValue(ContentProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ContentPresenter.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ContentProperty =
            DependencyProperty.Register("Content", typeof(object), typeof(DraggablePopup), new PropertyMetadata(null));



        public DraggablePopup()
        {
            InitializeComponent();
            var thumb = new Thumb
            {
                Width = 0,
                Height = 0,
            };
            ContentGrid.Children.Add(thumb);

            MouseLeftButtonDown += (sender, e) =>
            {
                thumb.RaiseEvent(e);
            };
            MouseRightButtonDown += (sender, e) => {
                this.IsOpen = false;
            };

            thumb.DragDelta += (sender, e) =>
            {
                HorizontalOffset += e.HorizontalChange;
                VerticalOffset += e.VerticalChange;
            };
        }
    }
}
