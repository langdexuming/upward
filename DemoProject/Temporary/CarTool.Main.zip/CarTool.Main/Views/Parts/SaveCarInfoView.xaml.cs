﻿using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CarInfoDB;
using CarTool.Main.Models;
using CarTool.Main.ViewModels;
using CarTool.Main.Utils;

namespace CarTool.Main.Views.Parts
{
    /// <summary>
    /// SaveCarInfoView.xaml 的交互逻辑
    /// </summary>
    public partial class SaveCarInfoView : UserControl
    {
        //暂时
        public string FrameData = "";

        //缓存一个最初的副本
        public DataTypeBase UnmodifiedDataTypeObject;

        public SaveCarInfoView()
        {
            InitializeComponent();

            this.comboBox_infoItem.ItemsSource = DataManager.GetInstance().InfoItems;
            //this.comboBox_dataType.ItemsSource = DataManager.GetInstance().DataTypes;//前面项改变触发该项集合改变

            ICollectionView view = CollectionViewSource.GetDefaultView(this.comboBox_infoItem.ItemsSource);
            view.GroupDescriptions.Clear();
            view.GroupDescriptions.Add(new PropertyGroupDescription("MainDataTypeName"));
            //view.GroupDescriptions.Add(new PropertyGroupDescription("InfoTypeName"));

            this.DataContextChanged += (s,e)=> {

                var vm = this.DataContext as SaveCarInfoViewModel;

                if (vm != null)
                {
                    switch (vm.ActionType)
                    {
                        case Enums.CommonEnums.ActionTypes.Edit:
                            this.comboBox_infoItem.IsEnabled = false;
                            break;
                        case Enums.CommonEnums.ActionTypes.Save:
                            this.FrameData = vm.FrameText ?? "";
                            break;
                        default:
                            break;
                    }
                    UnmodifiedDataTypeObject = vm.CurrentInfoItemReview?.DataTypeObject?.Copy();
                }

            };

        }

        //~SaveCarInfoView()
        //{
        //    ICollectionView view = CollectionViewSource.GetDefaultView(this.comboBox_infoItem.ItemsSource);
        //    view.GroupDescriptions.Clear();
        //}
         

        private void comboBox_dataType_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (this.comboBox_dataType.SelectedItem == null)
                return;
            var vm = this.DataContext as SaveCarInfoViewModel;
            if (vm?.CurrentInfoItemReview == null)
                return;
            // 传数据进来时，没有该项信息采用DataTypeBase基类的实例
            //基类数据必须转换
            DataTypeBase dataTypeObject = null;
            var source = vm.CurrentInfoItemReview.DataTypeObject;
            //获取源类型
            if (source != null)
            {
                Type sourceType = source.GetType();
                switch (((DataType)this.comboBox_dataType.SelectedItem).DataTypeID)
                {
                    case (int)DataTypeFlag.Bool://BOOL类型
                        this.grid_oneByteType.Visibility = Visibility.Collapsed;
                        this.grid_twoByteType.Visibility = Visibility.Collapsed;
                        this.grid_threeByteType.Visibility = Visibility.Collapsed;
                        this.grid_controlType.Visibility = Visibility.Collapsed;
                        this.grid_commonAlgorithm.Visibility = Visibility.Collapsed;

                        this.grid_boolType.Visibility = Visibility.Visible;
                        if (typeof(DataTypeBool) != sourceType)
                        {
                            dataTypeObject = new DataTypeBool(source);
                            vm.CurrentInfoItemReview.DataTypeObject = dataTypeObject;
                        }

                        break;
                    case (int)DataTypeFlag.SingleByte://单字节类型
                        this.grid_boolType.Visibility = Visibility.Collapsed;
                        this.grid_twoByteType.Visibility = Visibility.Collapsed;
                        this.grid_threeByteType.Visibility = Visibility.Collapsed;
                        this.grid_controlType.Visibility = Visibility.Collapsed;
                        this.grid_commonAlgorithm.Visibility = Visibility.Collapsed;

                        this.grid_oneByteType.Visibility = Visibility.Visible;

                        //转换
                        if (typeof(DataTypeSingleByte) != sourceType)
                        {
                            dataTypeObject = new DataTypeSingleByte(source);
                            vm.CurrentInfoItemReview.DataTypeObject = dataTypeObject;
                        }


                        break;
                    case (int)DataTypeFlag.DoubleByte://双字节类型
                        this.grid_boolType.Visibility = Visibility.Collapsed;
                        this.grid_oneByteType.Visibility = Visibility.Collapsed;
                        this.grid_threeByteType.Visibility = Visibility.Collapsed;
                        this.grid_controlType.Visibility = Visibility.Collapsed;
                        this.grid_commonAlgorithm.Visibility = Visibility.Collapsed;

                        this.grid_twoByteType.Visibility = Visibility.Visible;

                        //转换
                        if (typeof(DataTypeDoubleByte) != sourceType)
                        {
                            dataTypeObject = new DataTypeDoubleByte(source);
                            vm.CurrentInfoItemReview.DataTypeObject = dataTypeObject;
                        }
                        break;
                    case (int)DataTypeFlag.ThreeByte://3字节类型
                        this.grid_boolType.Visibility = Visibility.Collapsed;
                        this.grid_oneByteType.Visibility = Visibility.Collapsed;
                        this.grid_twoByteType.Visibility = Visibility.Collapsed;
                        this.grid_controlType.Visibility = Visibility.Collapsed;
                        this.grid_commonAlgorithm.Visibility = Visibility.Collapsed;

                        this.grid_threeByteType.Visibility = Visibility.Visible;

                        //转换
                        if (typeof(DataTypeThreeByte) != sourceType)
                        {
                            dataTypeObject = new DataTypeThreeByte(source);
                            vm.CurrentInfoItemReview.DataTypeObject = dataTypeObject;

                        }
                        break;
                    case (int)DataTypeFlag.Control://控制类型
                        this.grid_boolType.Visibility = Visibility.Collapsed;
                        this.grid_oneByteType.Visibility = Visibility.Collapsed;
                        this.grid_twoByteType.Visibility = Visibility.Collapsed;
                        this.grid_threeByteType.Visibility = Visibility.Collapsed;
                        this.grid_commonAlgorithm.Visibility = Visibility.Collapsed;

                        this.grid_controlType.Visibility = Visibility.Visible;
                        //转换
                        if (typeof(DataTypeControl) != sourceType)
                        {
                            dataTypeObject = new DataTypeControl(source);
                            vm.CurrentInfoItemReview.DataTypeObject = dataTypeObject;
                            //如果是采集的时候保存
                            if (vm.ActionType == Enums.CommonEnums.ActionTypes.Save)
                            {
                                ((DataTypeControl)dataTypeObject).FrameData = this.FrameData;
                            }
                        }

                        break;
                    case (int)DataTypeFlag.Algorithm://万能算法类型
                        this.grid_boolType.Visibility = Visibility.Collapsed;
                        this.grid_oneByteType.Visibility = Visibility.Collapsed;
                        this.grid_twoByteType.Visibility = Visibility.Collapsed;
                        this.grid_controlType.Visibility = Visibility.Collapsed;
                        this.grid_threeByteType.Visibility = Visibility.Collapsed;

                        this.grid_commonAlgorithm.Visibility = Visibility.Visible;

                        //转换
                        if (typeof(DataTypeAlgorithm) != sourceType)
                        {
                            dataTypeObject = new DataTypeAlgorithm(source);
                            vm.CurrentInfoItemReview.DataTypeObject = dataTypeObject;
                        }
                        break;
                    case (int)DataTypeFlag.Special://特殊类型
                        this.grid_boolType.Visibility = Visibility.Collapsed;
                        this.grid_oneByteType.Visibility = Visibility.Collapsed;
                        this.grid_twoByteType.Visibility = Visibility.Collapsed;
                        this.grid_controlType.Visibility = Visibility.Collapsed;
                        this.grid_threeByteType.Visibility = Visibility.Collapsed;
                        this.grid_commonAlgorithm.Visibility = Visibility.Collapsed;

                        //转换
                        if (typeof(DataTypeSpecial) != sourceType)
                        {

                            dataTypeObject = new DataTypeSpecial(source);
                            vm.CurrentInfoItemReview.DataTypeObject = dataTypeObject;
                        }
                        break;
                    default:
                        break;
                }

            }
        }

        /// <summary>
        /// InfoItem选择项不同，则DataType可选取数据源也变化（影响绑定，采用手动更改DataType选取项）TODO: 重要修改
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void combobox_infoItem_selectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //xp系统下，DataType的Combobox下拉框选择时，会触发该事件
            if (this.comboBox_infoItem.SelectedItem == null)
            {
                this.comboBox_dataType.SelectedIndex = -1;//默认
                return;
            }
            var selectedMainDataType = ((InfoItem) this.comboBox_infoItem.SelectedItem).MainDataType;
            if (this.comboBox_dataType.ItemsSource != null)
            {
                var currentMainDataType =
                    (this.comboBox_dataType.ItemsSource.Cast<DataType>()).FirstOrDefault()?.MainDataType;
                if (selectedMainDataType != currentMainDataType)
                {
                    this.comboBox_dataType.ItemsSource =
                        DataManager.GetInstance().DataTypes.Where(x => x.MainDataType == selectedMainDataType);
                }
            }
            else
            {
                this.comboBox_dataType.ItemsSource =
                         DataManager.GetInstance().DataTypes.Where(x => x.MainDataType == selectedMainDataType);
            }

            if ((UnmodifiedDataTypeObject == null) || (UnmodifiedDataTypeObject.GetType() == typeof(DataTypeBase)))
            {
                var vm = this.DataContext as SaveCarInfoViewModel;
                if (vm != null)
                {
                    vm.CurrentDataType = this.comboBox_dataType.ItemsSource.Cast<DataType>().FirstOrDefault();
                }
            }
        }

        private void Expander_Collapsed(object sender, RoutedEventArgs e)
        {
            if (e.Source is Expander)
            {
                Expander expander = e.Source as Expander;
                string name = expander.Header.ToString();
                foreach (var item in this.comboBox_infoItem.ItemsSource)
                {
                    if (((CarInfoDB.InfoItem)item).MainDataTypeName.Equals(name))
                        ((CarInfoDB.InfoItem)item).IsDisplay = false;
                }
            }
        }

        private void Expander_Expanded(object sender, RoutedEventArgs e)
        {
            if (e.Source is Expander)
            {
                Expander expander = e.Source as Expander;
                string name = expander.Header.ToString();
                foreach (var item in this.comboBox_infoItem.ItemsSource)
                {
                    if (((CarInfoDB.InfoItem)item).MainDataTypeName.Equals(name))
                        ((CarInfoDB.InfoItem)item).IsDisplay = true;
                }
            }
        }
    }
}
