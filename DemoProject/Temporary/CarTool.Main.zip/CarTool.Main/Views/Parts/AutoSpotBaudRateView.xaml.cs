﻿using CarTool.Main.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CarTool.Main.Views.Parts
{
    /// <summary>
    /// AutoSpotBaudRateView.xaml 的交互逻辑
    /// </summary>
    public partial class AutoSpotBaudRateView : UserControl
    {
        public AutoSpotBaudRateView()
        {
            InitializeComponent();
        }

        private void UserControl_Load(object sender, RoutedEventArgs e)
        {
            ((ObservableCollection<AutoSpotBaudRateReview>)this.list_AutoSpotBaudRate.ItemsSource).CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(this.list_AutoSpotBaudRate_CollectionChanged);
        }

        private void list_AutoSpotBaudRate_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            if (string.Compare(e.Action.ToString(), "Add") == 0)
            {
                var enumerator_new = e.NewItems.GetEnumerator();
                AutoSpotBaudRateReview item_new = null;
                while (enumerator_new.MoveNext())
                {
                    item_new = (AutoSpotBaudRateReview)enumerator_new.Current;
                    this.list_AutoSpotBaudRate.ScrollIntoView(item_new);
                }

            }
        }

        private void button_ok_Click(object sender, RoutedEventArgs e)
        {
            var window = Helper.ControlsSearchHelper.GetParentObject<Window>(this, string.Empty);
            if (window != null)
                window.DialogResult = true;
        }

        private void button_cancel_Click(object sender, RoutedEventArgs e)
        {
            var window = Helper.ControlsSearchHelper.GetParentObject<Window>(this, string.Empty);
            if (window != null)
                window.DialogResult = false;
        }
    }
}
