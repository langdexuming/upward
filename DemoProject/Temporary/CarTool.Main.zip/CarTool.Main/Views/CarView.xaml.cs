﻿using CarTool.Main.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml;
using System.ComponentModel;
using CarTool.Main.Helper;
using CarTool.Main.ViewModels;

namespace CarTool.Main.Views
{
    /// <summary>
    /// CarView.xaml 的交互逻辑
    /// </summary>
    public partial class CarView : UserControl
    {
        private Storyboard storyboadr = null;

        private ViewModels.CarViewVm ViewModel= App.ViewModel.CarViewVM;

        private bool IsRunStoryboad;

        public CarView()
        {
            InitializeComponent();
            this.DataContext = ViewModel;

            ViewModel.MessageTipListBox = this.listBox_messageTip;

            this.comboBox_Brand.SelectedIndex = 0;

            //this.listBox_carView.ItemsSource =App.ViewModel.carView_vm.CurrentOnlyReadInfoDetailReviews;

            //this.listBox_viewLeft.ItemsSource = from item in App.ViewModel.carView_vm.CurrentOnlyReadInfoDetailReviews where item.CurrentActiveTipArea == InfoDetailReview.ActiveTipArea.VirtualScenesLeftBoxArea select item;
            //this.listBox_viewRight.ItemsSource = from item in App.ViewModel.carView_vm.CurrentOnlyReadInfoDetailReviews where item.CurrentActiveTipArea ==InfoDetailReview.ActiveTipArea.VirtualScenesRightBoxArea select item;

            try
            {
                storyboadr = (Storyboard)FindResource("EngineStoryboard");
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }

            this.storyboadr.Completed += new EventHandler(this.storyboadr_Completed);

            //构建一个绑定或者事件通知，指示发动机动画运行
            ViewModel.OnlyReadInfoImageAndTipDictionary[68].PropertyChanged += new System.ComponentModel.PropertyChangedEventHandler(this.storyboadrDoing);

        }


        /// <summary>
        /// 设置动画运行状态
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void storyboadr_Completed(object sender, EventArgs e)
        {
            IsRunStoryboad = false;
        }


        /// <summary>
        /// 发动机动画(特殊)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void storyboadrDoing(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == "ImgUrl")
            {
                if (ViewModel.OnlyReadInfoImageAndTipDictionary[68].State)
                {
                    if (!IsRunStoryboad)
                    {
                        storyboadr.Begin(this);
                        IsRunStoryboad = true;
                    }
                }
             
            }
        }

        /// <summary>
        /// 界面加载完成事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
           // ((ObservableCollection<MessageTipReview>)this.listBox_messageTip.ItemsSource).CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(this.MessageTipReviews_CollectionChanged);
        }


        /// <summary>
        /// 操作集合，会通知多次事件(废弃)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MessageTipReviews_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            if (e.Action==NotifyCollectionChangedAction.Add)
            {
                var enumerator_new = e.NewItems.GetEnumerator();
                while (enumerator_new.MoveNext())
                {
                    object obj = enumerator_new.Current;
                    this.listBox_messageTip.ScrollIntoView(obj);
                }
            }
        }


        /// <summary>
        /// 修改声音设置（需播报的信息项）
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void menuItem_voiceSetting_Click(object sender, RoutedEventArgs e)
        {
            ///可设置运行缓存，在程序开始时，进行一次读取（考虑到暂时几乎不用，先放这）
            Dictionary<int, bool> voiceInfoItemConfigDictionary = new Dictionary<int, bool>();
            //初始化设置键值集合(---)
            foreach (var item in ((ViewModels.CarViewVm)this.DataContext).AllOnlyReadInfoDetailReviews)
            {
                if (!item.IsExtend)
                {
                    voiceInfoItemConfigDictionary.Add(item.InfoItemId, item.CanPlaySound);
                }
            }
            //根据本地配置修改设置键值集合
            Task task = Task.Factory.StartNew(() =>
            {
                XmlDocument readXml = new XmlDocument();
                try
                {
                    readXml.LoadXml(Properties.Settings.Default.VoiceInfoItemConfig);
                }
                catch (Exception ex)
                {
                    Debug.WriteLine(ex.Message);
                }

                foreach (XmlElement element in readXml.SelectSingleNode("Config").ChildNodes)
                {
                    int key = System.Convert.ToInt32(element.Attributes["InfoItemId"].Value);
                    bool value = System.Convert.ToBoolean(element.Attributes["CanPlaySound"].Value);

                    if (voiceInfoItemConfigDictionary.ContainsKey(key))
                    {
                        voiceInfoItemConfigDictionary[key] = value;
                    }
                }
            });

            task.Wait();//超时不会造成错误

            //根据设置键集合返回到只读信息项对象集合
            foreach (var item in ((ViewModels.CarViewVm)this.DataContext).AllOnlyReadInfoDetailReviews)
            {
                bool value = false;
                if (voiceInfoItemConfigDictionary.TryGetValue(item.InfoItemId, out value))
                {
                    item.CanPlaySound = value;
                }
            }
            var vm = new VoiceSettingsViewModel("声音设置", new ObservableCollection<InfoDetailReview>(((ViewModels.CarViewVm)this.DataContext).AllOnlyReadInfoDetailReviews.Where(x => (x.IsEnabled == true)&&(!x.IsExtend))));

            if (DialogHelper.ShowDialog(vm)==true)
            {
                //根据修改后的只读信息项集合修改设置键值集合
                foreach (var item in ((ViewModels.CarViewVm)this.DataContext).AllOnlyReadInfoDetailReviews)
                {
                    voiceInfoItemConfigDictionary[item.InfoItemId] = item.CanPlaySound;
                }

                //  Properties.Settings.Default.Reset();
                ///可设置运行缓存，在程序退出时，进行最终修改
                //根据修改后的设置键值集合，修改本地配置
                Task.Factory.StartNew(() =>
                {
                    string xmlText = Properties.Settings.Default.VoiceInfoItemConfig;
                    XmlDocument xml = new XmlDocument();
                    try
                    {
                        xml.LoadXml(xmlText);
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine(ex.Message);
                    }
                    XmlNode root = xml.SelectSingleNode("Config");
                    XmlNodeList xnList = root.ChildNodes;
                    foreach (XmlElement element in xnList)
                    {
                        int key = System.Convert.ToInt32(element.Attributes["InfoItemId"].Value);
                        bool value = false;
                        if (voiceInfoItemConfigDictionary.TryGetValue(key, out value))
                        {
                            element.SetAttribute("CanPlaySound", value.ToString());
                        }
                    }
                    //xml=>string
                    Stream stream = new MemoryStream();
                    xml.Save(stream);
                    stream.Position = 0;
                    StreamReader sr = new StreamReader(stream);
                    xmlText = sr.ReadToEnd();
                    //  Debug.WriteLine(xmlText);

                    Properties.Settings.Default.VoiceInfoItemConfig = xmlText;
                    Properties.Settings.Default.Save();
                    //  Debug.WriteLine(Properties.Settings.Default.VoiceInfoItemConfig);
                });
                #region 创建xml
                //foreach (var item in voiceInfoItemConfigDictionary)
                //{
                //    int key = item.Key;
                //    bool value = item.Value;
                //    XmlNode node = root.SelectSingleNode("InfoItemId=\"" + key + "\"");
                //    if (node != null)
                //    {
                //        node.Value = value.ToString();
                //    }
                //    XmlElement infoitem = xml.CreateElement("Infoitem");
                //    infoitem.SetAttribute("InfoItemId", item.Key.ToString());
                //    infoitem.SetAttribute("CanPlaySound", item.Value.ToString());
                //    config.AppendChild(infoitem);
                //}

                ////XmlDeclaration dec = xml.CreateXmlDeclaration("1.0", "GB2312", "yes");
                //XmlElement config = xml.CreateElement("Config");
                //xml.AppendChild(config);

                //foreach (var item in voiceInfoItemConfigDictionary)
                //{
                //    XmlElement infoitem = xml.CreateElement("Infoitem"+item.Key);
                //    infoitem.SetAttribute("InfoItemId", item.Key.ToString());
                //    infoitem.SetAttribute("CanPlaySound", item.Value.ToString());
                //    config.AppendChild(infoitem);
                //}

                //xml.Save("D:/test.xml");
                #endregion

            }
        }
    }
}
