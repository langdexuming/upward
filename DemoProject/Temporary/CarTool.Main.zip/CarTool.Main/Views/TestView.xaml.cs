﻿using CarTool.Main.Helper;
using CarTool.Main.ViewModels;
using CarTool.Main.Windows;
using Microsoft.Win32;
using System;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace CarTool.Main.Views
{
    /// <summary>
    /// Interaction logic for TestView
    /// </summary>
    public partial class TestView : UserControl
    {
        public TestView()
        {
            InitializeComponent();
        }

        #region 测试模块窗口弹出

        /// <summary>
        ///     Can数据发送测试
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button_canSendTest_Click(object sender, RoutedEventArgs e)
        {
            var window = new CanSendTestWindow();
            window.Show();
        }

        /// <summary>
        ///     遥控车
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button_carRemoteControlTest_Click(object sender, RoutedEventArgs e)
        {
            var window = new RemoteControlWindow();
            window.Show();
        }

        private void button_carInstructions_Click(object sender, RoutedEventArgs e)
        {
            var window = new CarInstructionsWindow();
            window.Show();
        }

        private void button_carMessageTipClick(object sender, RoutedEventArgs e)
        {
            var window = new CarMessageTipWindow();
            window.Show();
        }

        private void button_carViewClick(object sender, RoutedEventArgs e)
        {
            var window = new CarViewWindow();
            window.Show();
        }

        private void btton_autoCanDataTest_Click(object sender, RoutedEventArgs e)
        {
            var window = new AutoCanDataTestWindow();
            window.Show();
        }

        private void btton_speechTest_Click(object sender, RoutedEventArgs e)
        {
            var window = new SpeechTestWindow();
            window.Show();
        }

        private void button_canSetting_Click(object sender, RoutedEventArgs e)
        {
            var window = new CanSettingWindow();
            window.Show();
        }

        private void button_uiTest_Click(object sender, RoutedEventArgs e)
        {
            var window = new ControlTestWindow();
            window.Show();
        }

        private void button_commPortcarView_Click(object sender, RoutedEventArgs e)
        {
            //Windows.CommPortParts.MainWindow window = new Windows.CommPortParts.MainWindow();
            //window.Show();
        }

        /// <summary>
        ///     提供升级数据库的方法
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button_updateDatabase_Click(object sender, RoutedEventArgs e)
        {
            var value = App.CarDataSet.UpdateDatabase();
        }


        /// <summary>
        /// 导入旧版数据库
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button_importOldDatabase_Click(object sender, RoutedEventArgs e)
        {
            var of = new OpenFileDialog();

            of.Title = "导入旧版数据库";
            of.DefaultExt = "sdf";
            of.Filter = "sdf files (*.sdf)|*.sdf";
            //of.Filter = "sdf files (*.sdf)|*.sdf|All files (*.*)|*.*";
            of.FilterIndex = 1;
            of.RestoreDirectory = true;

            if (of.ShowDialog() == true)
            {
                var vm = new LoadingViewModel();

                DialogHelper.Show(vm);

                Task.Factory.StartNew(() =>
                {
                    //更新数据库
                    bool result = App.CarDataSet.UpdateOldDatabase(of.FileName);
                    Application.Current.Dispatcher.Invoke(new Action(() =>
                    {
                        DialogHelper.Close(vm);
                        if (result)
                        {
                            MessageBox.Show("导入成功，重启该软件后生效！");
                        }
                        else
                        {
                            MessageBox.Show("导入失败！");
                        }
                    }));
                });
            }

        }
        #endregion
    }
}
