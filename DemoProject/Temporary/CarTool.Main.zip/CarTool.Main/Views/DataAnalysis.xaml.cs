﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using CarInfoDB;
using CarTool.Main.Helper;
using CarTool.Main.Models;
using CarTool.Main.Utils;
using CarTool.Main.ViewModels;

namespace CarTool.Main.Views
{
    /// <summary>
    ///     DataAnalysis.xaml 的交互逻辑
    /// </summary>
    public partial class DataAnalysis : UserControl
    {
        private readonly DataAnalysisVm ViewModel = App.ViewModel.DataAnalysisVM;

        private const int DataGridColumnCount = 14;

        private readonly double[] InitColumnsWidth = new double[DataGridColumnCount]
            {28, 51, 39, 39, 39, 30, 37, 37, 37, 37, 37, 37, 37, 37};

        private readonly double InitFlagWidth = 524 + 12; //加上滚动条

        private bool IsTransformLayout; //指示是否变化布局

        private int tabControl_canId;

        private byte _canId;

        public DataAnalysis()
        {
            InitializeComponent();

            DataContext = ViewModel;

            ViewModel.AutoScrollContainer = this.dataGrid_selectedOrder;

            comboBox_can1_baudRate.ItemsSource = DataManager.GetInstance().GetBaudRates();
            comboBox_can2_baudRate.ItemsSource = DataManager.GetInstance().GetBaudRates();

            popup_eobd.DataContext = App.ViewModel.EobdVM;

            comboBox_Brand.SelectedIndex = 0;

            dataGrid_selectedOrder.SizeChanged += dataGrid_selectedOrder_SizeChanged;

            KeyDown += HasKeyDown;

        }

        /// <summary>
        /// 刷新切换Can通道选项卡后的DataContext
        /// </summary>
        private void RefreshCanModuleDataContext()
        {
            switch (tabControl_canId)
            {
                case 0:
                    grid_canDataSet.DataContext = ViewModel.CanDataFirstVm;
                    dockPanel_selectedOrder.DataContext = ViewModel.CanDataFirstVm;
                    wrapPanel_commonPart.DataContext = ViewModel.CanDataFirstVm;

                    PagingDatagrid_Can1.DataContext = ViewModel.CanDataFirstVm;
                    PagingDatagrid_Can2.DataContext = ViewModel.CanDataSecondVm;

                    _canId = 1;
                    break;
                case 1:
                    grid_canDataSet.DataContext = ViewModel.CanDataSecondVm;
                    dockPanel_selectedOrder.DataContext = ViewModel.CanDataSecondVm;
                    wrapPanel_commonPart.DataContext = ViewModel.CanDataSecondVm;

                    PagingDatagrid_Can1.DataContext = ViewModel.CanDataFirstVm;
                    PagingDatagrid_Can2.DataContext = ViewModel.CanDataSecondVm;

                    _canId = 2;
                    break;
                default:
                    break;
            }
        }


        /// <summary>
        ///     后期修正
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void HasKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
            {
                textBox_orderId.Focus();
                PagingDatagrid_Can1.dataGrid_Can.SelectedIndex = -1;
                PagingDatagrid_Can2.dataGrid_Can.SelectedIndex = -1;
                dataGrid_selectedOrder.SelectedIndex = -1;
                listBox_info.SelectedIndex = -1;
            }

            if ((Keyboard.Modifiers & ModifierKeys.Control) == ModifierKeys.Control && e.Key == Key.P)
            {
                button_transformLayout.IsChecked = !button_transformLayout.IsChecked;
                button_transformLayout.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));
            }

#if DEBUG
            if ((Keyboard.Modifiers & ModifierKeys.Control) == ModifierKeys.Control && e.Key == Key.NumPad1)
            {
                if (!(bool) PagingDatagrid_Can1.dataGrid_Can.GetValue(VirtualizingStackPanel.IsVirtualizingProperty))
                {
                    PagingDatagrid_Can1.dataGrid_Can.SetValue(VirtualizingStackPanel.IsVirtualizingProperty, true);
                    PagingDatagrid_Can1.dataGrid_Can.SetValue(VirtualizingStackPanel.VirtualizationModeProperty,
                        VirtualizationMode.Recycling);
                    MessageBox.Show("已开启主列表虚拟化支持");
                }
                else
                {
                    PagingDatagrid_Can1.dataGrid_Can.SetValue(VirtualizingStackPanel.IsVirtualizingProperty, false);
                    PagingDatagrid_Can1.dataGrid_Can.SetValue(VirtualizingStackPanel.VirtualizationModeProperty,
                        VirtualizationMode.Recycling);
                    MessageBox.Show("已关闭主列表虚拟化支持");
                }
                if (!(bool) PagingDatagrid_Can2.dataGrid_Can.GetValue(VirtualizingStackPanel.IsVirtualizingProperty))
                {
                    PagingDatagrid_Can2.dataGrid_Can.SetValue(VirtualizingStackPanel.IsVirtualizingProperty, true);
                    PagingDatagrid_Can2.dataGrid_Can.SetValue(VirtualizingStackPanel.VirtualizationModeProperty,
                        VirtualizationMode.Recycling);
                    MessageBox.Show("已开启主列表虚拟化支持,回收模式");
                }
                else
                {
                    PagingDatagrid_Can2.dataGrid_Can.SetValue(VirtualizingStackPanel.IsVirtualizingProperty, false);
                    PagingDatagrid_Can2.dataGrid_Can.SetValue(VirtualizingStackPanel.VirtualizationModeProperty,
                        VirtualizationMode.Recycling);
                    MessageBox.Show("已关闭主列表虚拟化支持");
                }
            }
            if ((Keyboard.Modifiers & ModifierKeys.Control) == ModifierKeys.Control && e.Key == Key.NumPad2)
                if (!(bool) dataGrid_selectedOrder.GetValue(VirtualizingStackPanel.IsVirtualizingProperty))
                {
                    dataGrid_selectedOrder.SetValue(VirtualizingStackPanel.IsVirtualizingProperty, true);
                    dataGrid_selectedOrder.SetValue(VirtualizingStackPanel.VirtualizationModeProperty,
                        VirtualizationMode.Recycling);
                    MessageBox.Show("已开启副列表虚拟化支持,回收模式");
                }
                else
                {
                    dataGrid_selectedOrder.SetValue(VirtualizingStackPanel.IsVirtualizingProperty, false);
                    dataGrid_selectedOrder.SetValue(VirtualizingStackPanel.VirtualizationModeProperty,
                        VirtualizationMode.Recycling);
                    MessageBox.Show("已关闭副列表虚拟化支持");
                }
            if ((Keyboard.Modifiers & ModifierKeys.Control) == ModifierKeys.Control && e.Key == Key.H)
            {
                ViewModel.SetTimerSpan(50);
                MessageBox.Show("定时时间:" + ViewModel.GetTimerSpan());
            }
            if ((Keyboard.Modifiers & ModifierKeys.Control) == ModifierKeys.Control && e.Key == Key.S)
            {
                ViewModel.SetTimerSpan(100);
                MessageBox.Show("定时时间:" + ViewModel.GetTimerSpan());
            }

            if ((Keyboard.Modifiers & ModifierKeys.Control) == ModifierKeys.Control && e.Key == Key.M)
            {
                ViewModel.SetTimerSpan(200);
                MessageBox.Show("定时时间:" + ViewModel.GetTimerSpan());
            }
            if ((Keyboard.Modifiers & ModifierKeys.Control) == ModifierKeys.Control && e.Key == Key.L)
            {
                ViewModel.SetTimerSpan(500);
                MessageBox.Show("定时时间:" + ViewModel.GetTimerSpan());
            }
#else

#endif
        }


        /// <summary>
        ///     滚现列表大小发生改变
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dataGrid_selectedOrder_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            if (e.NewSize.Width - (double) DataGridColumnCount / 2 > InitFlagWidth)
            {
                double _value = 0;
                _value = (e.NewSize.Width - InitFlagWidth) / DataGridColumnCount;
                for (var i = 0; i < DataGridColumnCount; i++)
                    dataGrid_selectedOrder.Columns[i].Width = InitColumnsWidth[i] + _value;
            }
            else
            {
                for (var i = 0; i < DataGridColumnCount; i++)
                    dataGrid_selectedOrder.Columns[i].Width = InitColumnsWidth[i];
            }
        }

        /// <summary>
        ///     加载行时发生滚动（弃用）---事件模型触发滚动，对于，行发生变化过快时，效果不佳
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dataGrid_selectedOrder_LoadingRow(object sender, DataGridRowEventArgs e)
        {
            dataGrid_selectedOrder.ScrollIntoView(e.Row);
        }

        /// <summary>
        ///     模式设置
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button_displaySet_Click(object sender, RoutedEventArgs e)
        {
            uniformGrid_displaySet.Visibility = uniformGrid_displaySet.Visibility == Visibility.Visible ? Visibility.Hidden : Visibility.Visible;
        }


        /// <summary>
        ///     纯界面操作
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void comboBox_canType_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ////选择事件跟双向绑定互斥
            var comboBox = (ComboBox) e.Source;
            if (comboBox.SelectedValue == null)
                return;
            switch (comboBox.SelectedIndex)
            {
                case 0:
                    //this.textBlock_can1.Text = "Can";
                    textBlock_can1.Visibility = Visibility.Hidden;
                    comboBox_can1_baudRate.Visibility = Visibility.Visible;

                    textBlock_can2.Visibility = Visibility.Hidden;
                    comboBox_can2_baudRate.Visibility = Visibility.Hidden;
                    break;
                case 1:
                    //  this.textBlock_can1.Text = "     Can1：";
                    textBlock_can1.Visibility = Visibility.Visible;
                    comboBox_can1_baudRate.Visibility = Visibility.Visible;

                    //   this.textBlock_can2.Text = "     Can2：";
                    textBlock_can2.Visibility = Visibility.Visible;
                    comboBox_can2_baudRate.Visibility = Visibility.Visible;
                    break;
                default:
                    break;
            }
        }


        /// <summary>
        ///     通过滚现列表旁的保存按钮进行信息项保存
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button_savaData_Click(object sender, RoutedEventArgs e)
        {
            //判断车型是否载入成功
            if (!ViewModel.IsLoadedCarInfoSuccessful)
            {
                MessageBox.Show("请载入车型！");
                return;
            }

            //空白项
            var infoItemReview = new InfoItemReview()
            {
                DataTypeObject=new DataTypeBase()
            };
            var frameDataText = string.Empty;

            infoItemReview.DataTypeObject.CanID = _canId;
            var selectedCount = dataGrid_selectedOrder.SelectedItems.Count;

            //附加值
            if (selectedCount > 0)
            {
                var canDataStandardReview = (CanDataStandardReview) dataGrid_selectedOrder.SelectedItem;
                infoItemReview.DataTypeObject.OrderID = string.Format("0x{0:X}", canDataStandardReview.CanDataBaseObject.OrderId);
                infoItemReview.DataTypeObject.ExternFlag = canDataStandardReview.CanDataBaseObject.ExternFlag;
                infoItemReview.DataTypeObject.RemoteFlag = canDataStandardReview.CanDataBaseObject.RemoteFlag;

                if (dataGrid_selectedOrder.SelectedItems.Count == 1)
                {
                    frameDataText += canDataStandardReview.ToString("Frame") + "\r\n";
                }
                else
                {
                    //选取多行
                    var selectReviews = new List<CanDataStandardReview>();

                    foreach (var item in dataGrid_selectedOrder.SelectedItems)
                        selectReviews.Add((CanDataStandardReview) item);

                    //可能从下往上复制
                    var items = selectReviews.OrderBy(x => x.Id);

                    int index = 0;
                    foreach (var item in items)
                    {
                        if (index == 0)
                        {
                            //首行无需时间间隔,在不影响原来的集合下进行修改
                            var indexItemCopy = new CanDataStandardReview(item);
                            indexItemCopy.CanDataBaseObject.TimeInterval = 0;
                            frameDataText += indexItemCopy.ToString("Frame", null) + "\r\n";
                        }
                        else
                        {
                            frameDataText += item.ToString("Frame", null) + "\r\n";
                        }

                        index++;
                    }
                }
            }
            else //暂定
            {
                //如果选中了主列表某行数据，则使用该行数据
                var dataGrid = tabControl_canId == 0
                    ? PagingDatagrid_Can1.dataGrid_Can
                    : PagingDatagrid_Can2.dataGrid_Can;
                var canDataReview = dataGrid.SelectedItem as CanDataReview;
                if (canDataReview != null)
                {
                    infoItemReview.DataTypeObject.OrderID = string.Format("0x{0:X}", canDataReview.CanDataBaseObject.OrderId);
                    infoItemReview.DataTypeObject.ExternFlag = canDataReview.CanDataBaseObject.ExternFlag;
                    infoItemReview.DataTypeObject.RemoteFlag = canDataReview.CanDataBaseObject.RemoteFlag;
                }

                int index = 0;
                foreach (CanDataStandardReview item in dataGrid_selectedOrder.ItemsSource)
                {
                    if (index == 0)
                    {
                        //首行无需时间间隔,在不影响原来的集合下进行修改
                        var indexItemCopy = new CanDataStandardReview(item);
                        indexItemCopy.CanDataBaseObject.TimeInterval = 0;
                        frameDataText += indexItemCopy.ToString("Frame", null) + "\r\n";
                    }
                    else
                    {
                        frameDataText += item.ToString("Frame", null) + "\r\n";
                    }

                    index++;
                }
            }

            var vm = new SaveCarInfoViewModel("保存数据", infoItemReview,Enums.CommonEnums.ActionTypes.Save, frameDataText);

            var result = DialogHelper.ShowDialog(vm);

            //此处发生更改，则需要寻找ListBox_info的数据源对应的项，然后更改
            if (result == true)
            {
                //没有选择信息项，无法保存
                while (vm.CurrentInfoItem == null && result == true)
                {
                    MessageBox.Show("保存失败，请选择信息项！");
                    result = DialogHelper.ShowDialog(vm);
                }

                foreach (var item in ViewModel.AllInfoItemReviews.Where(x => x.InfoItemId == vm.CurrentInfoItemReview?.InfoItemId))
                {
                    item.DataTypeObject = vm.CurrentInfoItemReview.DataTypeObject;
                }
            }
        }


        /// <summary>
        ///     上下文绑定有点乱，后期优化
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tabControl_can_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (e.Source is TabControl)
            {
                tabControl_canId = tabControl_can.SelectedIndex;
                
                RefreshCanModuleDataContext();
            }
        }



        /// <summary>
        ///     Ctrl+P---改变滚现列表位置
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button_transformLayout_Click(object sender, RoutedEventArgs e)
        {
            if (!IsTransformLayout)
            {
                grid_carInfo.Visibility = Visibility.Collapsed;
                dockPanel_infoItems.Visibility = Visibility.Collapsed;

                dockPanel_selectedOrder.SetValue(Grid.RowProperty, 0);
                dockPanel_selectedOrder.SetValue(Grid.ColumnProperty, 2);
                dockPanel_selectedOrder.SetValue(Grid.RowSpanProperty, 5);
                dockPanel_selectedOrder.SetValue(Grid.ColumnSpanProperty, 1);

                dockPanel_commonPart.SetValue(Grid.RowSpanProperty, 3);

                //滚现列表的操作按钮
                uniformGrid_selectedOrder.SetValue(Grid.RowProperty, 0);
                uniformGrid_selectedOrder.SetValue(Grid.ColumnProperty, 0);
                uniformGrid_selectedOrder.SetValue(Grid.ColumnSpanProperty, 2);
                uniformGrid_selectedOrder.Rows = 1;
                uniformGrid_selectedOrder.Columns = 4;
                uniformGrid_selectedOrder.HorizontalAlignment = HorizontalAlignment.Right;

                dataGrid_selectedOrder.SetValue(Grid.ColumnSpanProperty, 2);

                IsTransformLayout = true;
            }
            else
            {
                grid_carInfo.Visibility = Visibility.Visible;
                dockPanel_infoItems.Visibility = Visibility.Visible;

                dockPanel_commonPart.SetValue(Grid.RowSpanProperty, 1);

                dockPanel_selectedOrder.SetValue(Grid.RowProperty, 4);
                dockPanel_selectedOrder.SetValue(Grid.ColumnProperty, 0);
                dockPanel_selectedOrder.SetValue(Grid.RowSpanProperty, 1);
                dockPanel_selectedOrder.SetValue(Grid.ColumnSpanProperty, 1);

                uniformGrid_selectedOrder.SetValue(Grid.RowProperty, 1);
                uniformGrid_selectedOrder.SetValue(Grid.ColumnProperty, 1);
                uniformGrid_selectedOrder.Rows = 4;
                uniformGrid_selectedOrder.Columns = 1;
                uniformGrid_selectedOrder.HorizontalAlignment = HorizontalAlignment.Stretch;


                dataGrid_selectedOrder.SetValue(Grid.ColumnSpanProperty, 1);

                IsTransformLayout = false;
            }
        }


        /// <summary>
        ///     复制DataGrid行时发生，对剪切板对应的单元格内容更改
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DataGridTextColumn_CopyingCellClipboardContent(object sender, DataGridCellClipboardEventArgs e)
        {
            switch (e.Column.DisplayIndex)
            {
                case 2:
                    e.Content = string.Format("0x{0:x}", e.Content);
                    break;
                case 3:
                    e.Content = string.Format("{0}", ((CanDataStandardReview) e.Item).CanDataBaseObject.RemoteFlag);
                    break;
                case 4:
                    e.Content = string.Format("{0}", ((CanDataStandardReview) e.Item).CanDataBaseObject.ExternFlag);
                    break;
                default:
                    e.Content = "";
                    break;
            }
        }


        /// <summary>
        ///     复制时去掉不必要的列
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dataGrid_Can_CopyingRowClipboardContent(object sender, DataGridRowClipboardEventArgs e)
        {
            e.ClipboardRowContent.RemoveRange(0, 2);

            while (e.ClipboardRowContent.Last().Content.ToString() == "")
                e.ClipboardRowContent.RemoveAt(e.ClipboardRowContent.Count - 1);
        }


        /// <summary>
        ///     新建品牌和车型
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void comboBox_Brand_Click(object sender, RoutedEventArgs e)
        {
            var model = new BrandAndModel();
            var vm = new AddCarViewModel("新建品牌和车型", model);
            var result = DialogHelper.ShowDialog(vm);
            if (result == true)
            {
                while ((string.IsNullOrWhiteSpace(model.Brand) || string.IsNullOrWhiteSpace(model.Model)) &&
                       result == true)
                {
                    MessageBox.Show("品牌和型号不可为空，请重新输入！");
                    result = DialogHelper.ShowDialog(vm);
                    if (result == false)
                        return;
                }

                var buildResult = DataManager.GetInstance().UpdateBrand(null,
                    new Brand(model.Brand,new ObservableCollection <BrandAndModel> {model}
                        ));
                if (buildResult)
                    MessageBox.Show("新建成功");
                else
                    MessageBox.Show("新建失败，已存在该品牌！");
            }
        }


        /// <summary>
        ///     新建车型
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void comboBox_Model_Click(object sender, RoutedEventArgs e)
        {
            var model = new BrandAndModel(comboBox_Brand.Text, string.Empty,string.Empty);
            var vm = new AddCarViewModel("新建车型", model);
            var result = DialogHelper.ShowDialog(vm);
            if (result == true)
            {
                while ((string.IsNullOrWhiteSpace(model.Brand) || string.IsNullOrWhiteSpace(model.Model)) &&
                       result == true)
                {
                    MessageBox.Show("品牌和型号不可为空，请重新输入！");
                    result = DialogHelper.ShowDialog(vm);
                    if (result == false)
                        return;
                }

                var buildResult = DataManager.GetInstance().UpdateBrandAndModel(null, model);
                if (buildResult)
                    MessageBox.Show("新建成功");
                else
                    MessageBox.Show("新建失败，已存在该型号！");
            }
        }
    }
}