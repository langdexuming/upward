﻿/****************************************************************
*   作者：yinruimin 5339
*   创建时间：2018/11/6 19:39:38
*   描述说明：
*
* Copyright (c) 2018 GoSunCN Corporation. All rights reserved.
*┌──────────────────────────────────┐
*│　此技术信息为本公司机密信息，未经本公司书面同意禁止向第三方披露．　│
*│　版权所有：高新兴科技集团股份有限公司　　　　　　　　　　　　      │
*└──────────────────────────────────┘
*****************************************************************/
using CarInfoDB;
using CarTool.Main.ViewModels;
using QuickConverter;
using Reggie.WPF.Utilities.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace CarTool.Main
{
    /// <summary>
    ///     App.xaml 的交互逻辑
    /// </summary>
    public class App
    {
        public enum LogLevel
        {
            /// <summary>
            ///     正常记录
            /// </summary>
            Normal,

            /// <summary>
            ///     致命错误
            /// </summary>
            Fatal
        }


        public enum Module
        {
            /// <summary>
            ///     Eobd
            /// </summary>
            Eobd,

            /// <summary>
            ///     Control
            /// </summary>
            Control,

            /// <summary>
            ///     普通（数据分析-测试发送）--公共
            /// </summary>
            Normal,

            /// <summary>
            ///     收到只读信息
            /// </summary>
            ReceiveOnlyReadInfo
        }

        public enum RunMode
        {
            Normal,

            Test
        }

        public const string Name = "CarTool.Main";

        private static CarDB _carDB;
        private static CarDataSet _carDataSet;

        private static ViewModel _viewModel;

        public App()
        {
            // Setup Quick Converter.
            // Add the System namespace so we can use primitive types (i.e. int, etc.).
            EquationTokenizer.AddNamespace(typeof(object));
            // Add the System.Windows namespace so we can use Visibility.Collapsed, etc.
            EquationTokenizer.AddNamespace(typeof(Visibility));
        }

        /// <summary>
        ///     记录
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="module">模块</param>
        /// <param name="level">日志级别</param>
        public static void Log(string msg, Module module = Module.Normal, LogLevel level = LogLevel.Normal)
        {
            Logger.Info("CarTool.Main", msg);
        }

        public static CarDB CarDB => _carDB ?? (_carDB = new CarDB());

        public static CarDataSet CarDataSet => _carDataSet ?? (_carDataSet = new CarDataSet());

        public static ViewModel ViewModel => _viewModel ?? (_viewModel = new ViewModel());

       
    }
}
