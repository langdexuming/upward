﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CarTool.Main.Enums
{
    public class CommonEnums
    {
        public enum OpStatus
        {
            Default,
            /// <summary>
            /// 查看
            /// </summary>
            Lookup,
            /// <summary>
            /// 添加
            /// </summary>
            Add,
            /// <summary>
            /// 替换
            /// </summary>
            Replace=Default,
            /// <summary>
            /// 删除
            /// </summary>
            Delete,

        }

        public enum ActionTypes
        {
            Save,

            Edit,
        }

        public enum InfoReviewDisplayModes
        {
            All = 0,
            Enabled,
            Disenabled,
            Collected,
            NotCollected
        }
        public enum EobdStatus
        {
            /// <summary>
            /// 未连接
            /// </summary>
            None,
            /// <summary>
            /// 正在连接
            /// </summary>
            Connecting,
            /// <summary>
            /// 已连接
            /// </summary>
            Connected
        }

        public enum LoadStatus
        {
            /// <summary>
            /// 未开始
            /// </summary>
            None,
            /// <summary>
            /// 正在加载
            /// </summary>
            Loading,
            
            /// <summary>
            /// 失败
            /// </summary>
            Failure,

            /// <summary>
            /// 成功
            /// </summary>
            Success
        }

        public enum SubmitStatus
        {
            /// <summary>
            /// 未开始
            /// </summary>
            None,
            /// <summary>
            /// 正在提交
            /// </summary>
            Committing,

            /// <summary>
            /// 失败
            /// </summary>
            Failure,

            /// <summary>
            /// 成功
            /// </summary>
            Success
        }
    }
}
